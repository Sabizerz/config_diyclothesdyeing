window.__require = function e(t, r, n) {
function i(s, a) {
if (!r[s]) {
if (!t[s]) {
var f = s.split("/");
f = f[f.length - 1];
if (!t[f]) {
var c = "function" == typeof __require && __require;
if (!a && c) return c(f, !0);
if (o) return o(f, !0);
throw new Error("Cannot find module '" + s + "'");
}
s = f;
}
var u = r[s] = {
exports: {}
};
t[s][0].call(u.exports, function(e) {
return i(t[s][1][e] || e);
}, u, u.exports, e, t, r, n);
}
return r[s].exports;
}
for (var o = "function" == typeof __require && __require, s = 0; s < n.length; s++) i(n[s]);
return i;
}({
BundleControl: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "042a81rvuJLIYsEHYhfH5Th", "BundleControl");
Object.defineProperty(r, "__esModule", {
value: !0
});
var n = e("./Configs"), i = e("./Global"), o = function() {
function e() {}
e.init = function(e) {
this.serverVersion = e;
};
e.loadSceneGame = function(e, t, r, n) {
console.error("loadSceneGame", t);
this.loadBundle(e, function(e) {
e.loadScene(t, function(e, t) {
r(e, t);
}, function() {
cc.director.preloadScene(t, function(e, t) {
r(e, t);
}, function() {
cc.director.loadScene(t);
n();
});
});
});
};
e.loadPrefabGame = function(e, t, r, n) {
this.loadBundle(e, function(e) {
e.load(t, cc.Prefab, function(e, t) {
r(e, t);
}, function(t, r) {
n(r, e);
});
});
};
e.loadBundle = function(e, t) {
if (n.default.App.IS_LOCAL) {
var r = e;
cc.assetManager.loadBundle(r, function(e, r) {
null == e && t(r);
});
} else {
var i = this.serverVersion[e];
r = e;
cc.sys.isNative && (r = i.url);
cc.assetManager.loadBundle(r, {
version: i.hash
}, function(e, r) {
null == e && t(r);
});
}
};
e.loadPrefabPopup = function(e, t) {
i.Global.BundleLobby.load(e, function(e, r) {
e || t(r);
});
};
e.serverVersion = {};
return e;
}();
r.default = o;
cc._RF.pop();
}, {
"./Configs": "Configs",
"./Global": "Global"
} ],
Configs: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "a8b148ShhNECLRCMfJf61sO", "Configs");
Object.defineProperty(r, "__esModule", {
value: !0
});
var n, i = e("./VersionConfig");
(function(e) {
var t = function() {
function t() {}
t.clear = function() {
this.UserId = 0;
this.Username = "";
this.Password = "";
this.Nickname = "";
this.Avatar = "";
this.Mail = "";
this.Coin = 0;
this.TokenPayment = "";
this.IsLogin = !1;
this.AccessToken = "";
this.AccessToken2 = "";
this.AccessTokenSockJs = "";
this.SessionKey = "";
this.CreateTime = "";
this.Birthday = "";
this.IpAddress = "";
this.VipPoint = 0;
this.VipPointSave = 0;
this.CoinFish = 0;
this.UserIdFish = 0;
this.UsernameFish = "";
this.PasswordFish = "";
this.BitcoinToken = "";
};
t.getVipPointName = function() {
for (var t = this.VipPoints.length - 1; t >= 0; t--) if (e.Login.VipPoint > this.VipPoints[t]) return this.VipPointsName[t + 1];
return this.VipPointsName[0];
};
t.GetListMailNew = function() {
if (null == this.ListMail || 0 == this.ListMail.length) return 0;
for (var e = 0, t = 0; t < this.ListMail.length; t++) 0 == this.ListMail[t].status && e++;
return e;
};
t.getVipPointNextLevel = function() {
for (var t = this.VipPoints.length - 1; t >= 0; t--) if (e.Login.VipPoint > this.VipPoints[t]) return t == this.VipPoints.length - 1 ? this.VipPoints[t] : this.VipPoints[t + 1];
return this.VipPoints[0];
};
t.getVipPointIndex = function() {
for (var t = this.VipPoints.length - 1; t >= 0; t--) if (e.Login.VipPoint > this.VipPoints[t]) return t;
return 0;
};
t.UserId = 0;
t.Username = "";
t.Password = "";
t.Nickname = "";
t.Avatar = "";
t.Coin = 0;
t.IsLogin = !1;
t.AccessToken = "";
t.AccessToken2 = "";
t.AccessTokenSockJs = "";
t.AccessTokenFB = "";
t.FacebookID = "";
t.SessionKey = "";
t.LuckyWheel = 0;
t.CreateTime = "";
t.Birthday = "";
t.IpAddress = "";
t.VipPoint = 0;
t.Address = "";
t.VipPointSave = 0;
t.Mail = "";
t.Gender = !0;
t.RefferalCode = "";
t.CoinFish = 0;
t.UserIdFish = 0;
t.UsernameFish = "";
t.PasswordFish = "";
t.FishConfigs = null;
t.BitcoinToken = "";
t.UserType = "0";
t.TokenPayment = "";
t.ListBankRut = null;
t.ListPayment = null;
t.ClickPayPayment = null;
t.CACHE_AG = !1;
t.CACHE_IBC = !1;
t.CACHE_WM = !1;
t.ListMail = null;
t.VipPoints = [ 80, 800, 4500, 8600, 12e3, 5e4, 1e6, 2e6, 5e6 ];
t.VipPointsName = [ "Đá", "Đồng", "Bạc", "Vàng", "BK1", "BK2", "KC1", "KC2", "KC3" ];
return t;
}();
e.Login = t;
var r = function() {
function e() {}
e.getServerConfig = function() {};
e.getPlatformName = function() {
return cc.sys.isNative && cc.sys.os == cc.sys.OS_ANDROID ? "android" : cc.sys.isNative && cc.sys.os == cc.sys.OS_IOS ? "ios" : "web";
};
e.getLinkFanpage = function() {
i.default.CPName;
return "https://www.facebook.com/Bit88vin-Game-B%C3%A0i-%C4%90%E1%BA%B3ng-C%E1%BA%A5p-V%C6%B0%E1%BB%A3t-Th%E1%BB%9Di-%C4%90%E1%BA%A1i-109930688080746";
};
e.getLinkTelegram = function() {
i.default.CPName;
return "cskhgame24";
};
e.getLinkTelegramGroup = function() {
i.default.CPName;
return "cskhgame24";
};
e.init = function() {
switch (i.default.ENV) {
case i.default.ENV_DEV:
this.USE_WSS = !0;
this.API = "https://iportal." + i.default.DOMAIN_DEV + "/api";
this.MONEY_TYPE = 1;
this.LINK_DOWNLOAD = "https://" + i.default.DOMAIN_DEV;
this.LINK_EVENT = "https://" + i.default.DOMAIN_DEV + "/event";
this.HOST_MINIGAME.host = "wmini." + i.default.DOMAIN_DEV;
this.HOST_MINIGAME2.host = "wmini2." + i.default.DOMAIN_DEV;
this.HOST_TAI_XIU_MINI2.host = "overunder." + i.default.DOMAIN_DEV;
this.HOST_SLOT.host = "wslot." + i.default.DOMAIN_DEV;
this.HOST_TLMN.host = "wtlmn." + i.default.DOMAIN_DEV;
this.HOST_SHOOT_FISH.host = "wbanca." + i.default.DOMAIN_DEV;
this.HOST_SAM.host = "wsam." + i.default.DOMAIN_DEV;
this.HOST_XOCDIA.host = "wxocdia." + i.default.DOMAIN_DEV;
this.HOST_BACAY.host = "wbacay." + i.default.DOMAIN_DEV;
this.HOST_BAICAO.host = "wbaicao." + i.default.DOMAIN_DEV;
this.HOST_POKER.host = "wpoker." + i.default.DOMAIN_DEV;
this.HOST_XIDACH.host = "wxizach." + i.default.DOMAIN_DEV;
this.HOST_BINH.host = "wbinh." + i.default.DOMAIN_DEV;
this.HOST_LIENG.host = "wlieng." + i.default.DOMAIN_DEV;
break;

case i.default.ENV_PROD:
this.USE_WSS = !0;
this.API = "https://iportal." + i.default.DOMAIN_PRO + "/api";
this.MONEY_TYPE = 1;
this.LINK_DOWNLOAD = "https://" + i.default.DOMAIN_PRO;
this.LINK_EVENT = "https://" + i.default.DOMAIN_PRO + "/event";
this.HOST_MINIGAME.host = "wmini." + i.default.DOMAIN_PRO;
this.HOST_MINIGAME2.host = "wmini2." + i.default.DOMAIN_PRO;
this.HOST_TAI_XIU_MINI2.host = "overunder." + i.default.DOMAIN_PRO;
this.HOST_SLOT.host = "wslot." + i.default.DOMAIN_PRO;
this.HOST_TLMN.host = "wtlmn." + i.default.DOMAIN_PRO;
this.HOST_SHOOT_FISH.host = "wbanca." + i.default.DOMAIN_PRO;
this.HOST_SAM.host = "wsam." + i.default.DOMAIN_PRO;
this.HOST_XOCDIA.host = "wxocdia." + i.default.DOMAIN_PRO;
this.HOST_BACAY.host = "wbacay." + i.default.DOMAIN_PRO;
this.HOST_BAICAO.host = "wbaicao." + i.default.DOMAIN_PRO;
this.HOST_POKER.host = "wpoker." + i.default.DOMAIN_PRO;
this.HOST_XIDACH.host = "wxizach." + i.default.DOMAIN_PRO;
this.HOST_BINH.host = "wbinh." + i.default.DOMAIN_PRO;
this.HOST_LIENG.host = "wlieng." + i.default.DOMAIN_PRO;
break;

default:
this.USE_WSS = !0;
this.API = "https://iportal." + i.default.DOMAIN_DEV + "/api";
this.MONEY_TYPE = 1;
this.LINK_DOWNLOAD = "https://" + i.default.DOMAIN_DEV;
this.LINK_EVENT = "https://" + i.default.DOMAIN_DEV + "/event";
this.HOST_MINIGAME.host = "wmini." + i.default.DOMAIN_DEV;
this.HOST_MINIGAME2.host = "wmini2." + i.default.DOMAIN_DEV;
this.HOST_TAI_XIU_MINI2.host = "overunder." + i.default.DOMAIN_DEV;
this.HOST_SLOT.host = "wslot." + i.default.DOMAIN_DEV;
this.HOST_TLMN.host = "wtlmn." + i.default.DOMAIN_DEV;
this.HOST_SHOOT_FISH.host = "wbanca." + i.default.DOMAIN_DEV;
this.HOST_SAM.host = "wsam." + i.default.DOMAIN_DEV;
this.HOST_XOCDIA.host = "wxocdia." + i.default.DOMAIN_DEV;
this.HOST_BACAY.host = "wbacay." + i.default.DOMAIN_DEV;
this.HOST_BAICAO.host = "wbaicao." + i.default.DOMAIN_DEV;
this.HOST_POKER.host = "wpoker." + i.default.DOMAIN_DEV;
this.HOST_XIDACH.host = "wxizach." + i.default.DOMAIN_DEV;
this.HOST_BINH.host = "wbinh." + i.default.DOMAIN_DEV;
this.HOST_LIENG.host = "wlieng." + i.default.DOMAIN_DEV;
}
};
e.IS_LOCAL = !1;
e.IS_PRO = !0;
e.API = "https://iportal.rik1vip.win/api";
e.API2 = "https://iportal2.rik1vip.win/api";
e.APIROY = "https://portal.rik1vip.win/api";
e.API_PAYIN_PAYWELL_BANKS = "https://iportal.eloras.icu/api/payin/paywell/banks";
e.MONEY_TYPE = 1;
e.LINK_DOWNLOAD = "https://eloras.icu/download";
e.LINK_EVENT = "https://eloras.icu/event";
e.LINK_SUPPORT = "https://eloras.icu";
e.USE_WSS = !1;
e.LINK_GROUP = "https://www.facebook.com/rik1vip.win";
e.FB_APPID = "758971848112749";
e.AGENCY_CODE = "";
e.options = {
rememberUpgrade: !0,
transports: [ "websocket" ],
secure: !0,
rejectUnauthorized: !1,
reconnection: !0,
autoConnect: !0,
auth: {
token: "WERTWER34534FGHFGBFVBCF345234XCVASD"
}
};
e.VERSION_APP = "1.0.3";
e.GameName = {
110: "Đua Xe",
170: "Crypto",
2: "Tài Xỉu",
5: "Xèng",
11: "Tiến Lên",
160: "Chim Điên",
120: "Thần Tài",
150: "Thể Thao",
1: "MiniPoker",
3: "Bầu Cua",
9: "Ba Cây",
4: "Cao Thấp",
191: "Chiêm Tinh",
190: "Tài Xỉu Siêu Tốc",
12: "Xóc Đĩa",
180: "Thần Bài",
197: "Bikini"
};
e.HOST_MINIGAME = {
host: "",
port: 443
};
e.HOST_MINIGAME2 = {
host: "",
port: 443
};
e.HOST_TAI_XIU_MINI2 = {
host: "",
port: 443
};
e.HOST_SLOT = {
host: "",
port: 443
};
e.HOST_TLMN = {
host: "",
port: 443
};
e.HOST_SHOOT_FISH = {
host: "",
port: 443
};
e.HOST_SAM = {
host: "",
port: 443
};
e.HOST_XOCDIA = {
host: "",
port: 443
};
e.HOST_BACAY = {
host: "",
port: 443
};
e.HOST_BAICAO = {
host: "",
port: 443
};
e.HOST_POKER = {
host: "",
port: 443
};
e.HOST_XIDACH = {
host: "",
port: 443
};
e.HOST_BINH = {
host: "",
port: 443
};
e.HOST_LIENG = {
host: "",
port: 443
};
e.SERVER_CONFIG = {
ratioNapThe: 1,
ratioNapMomo: 1.2,
ratioTransfer: .98,
ratioTransferDL: 1,
listTenNhaMang: [ "Viettel", "Vinaphone", "Mobifone", "Vietnamobile" ],
listIdNhaMang: [ 0, 1, 2, 3 ],
listMenhGiaNapThe: [ 1e4, 2e4, 3e4, 5e4, 1e5, 2e5, 5e5 ],
ratioRutThe: 1.2
};
e.CASHOUT_CARD_CONFIG = {
listTenNhaMang: [ "Viettel", "Vinaphone", "Mobifone", "Vietnamobile", "Garena", "Vcoin", "FPT Gate", "Mobi Data" ],
listIdNhaMang: [ "VTT", "VNP", "VMS", "VNM", "GAR", "VTC", "FPT", "DBM" ],
listMenhGiaNapThe: [ 1e4, 1e5, 2e5, 5e5 ],
listQuantity: [ "1", "2", "3" ]
};
e.TXST_SUB_TOPIC = "/topic/tx";
e.nameKeyBank = {
VCB: 0,
TCB: 1,
VIB: 2,
VPB: 3
};
return e;
}();
e.App = r;
var n = function() {
function e() {}
e.getGameName = function(e) {
switch (e) {
case this.MiniPoker:
return "MiniPoker";

case this.TaiXiu:
return "Tài xỉu";

case this.BauCua:
return "Bầu cua";

case this.CaoThap:
return "Cao thấp";

case this.Slot3x3:
return "Slot3x3";

case this.VQMM:
return "VQMM";

case this.Sam:
return "Sâm";

case this.MauBinh:
return "Mậu binh";

case this.TLMN:
return "TLMN";

case this.TaLa:
return "Tá lả";

case this.Lieng:
return "Liêng";

case this.XiTo:
return "Xì tố";

case this.XocXoc:
return "Xóc xóc";

case this.BaiCao:
return "Bài cào";

case this.Poker:
return "Poker";

case this.Bentley:
return "Bentley";

case this.RangeRover:
return "Range Rover";

case this.MayBach:
return "May Bach";

case this.RollsRoyce:
return "Rolls Royce";
}
return "Unknow";
};
e.MiniPoker = 1;
e.TaiXiu = 2;
e.BauCua = 3;
e.CaoThap = 4;
e.Slot3x3 = 5;
e.VQMM = 7;
e.Sam = 8;
e.BaCay = 9;
e.MauBinh = 10;
e.TLMN = 11;
e.TaLa = 12;
e.Lieng = 13;
e.XiTo = 14;
e.XocXoc = 15;
e.BaiCao = 16;
e.Poker = 17;
e.Bentley = 19;
e.RangeRover = 20;
e.MayBach = 21;
e.RollsRoyce = 22;
e.TaiXiuMD5 = 22e3;
return e;
}();
e.GameId = n;
var o = function() {
function e() {}
e.Deposit = null;
return e;
}();
e.Payment = o;
var s = function() {
function e() {}
e.EVENT_NAME_ACTIVATED_APP = "fb_mobile_activate_app";
e.EVENT_NAME_DEACTIVATED_APP = "fb_mobile_deactivate_app";
e.EVENT_NAME_SESSION_INTERRUPTIONS = "fb_mobile_app_interruptions";
e.EVENT_NAME_TIME_BETWEEN_SESSIONS = "fb_mobile_time_between_sessions";
e.EVENT_NAME_COMPLETED_REGISTRATION = "fb_mobile_complete_registration";
e.EVENT_NAME_COMPLETED_LOGIN = "fb_mobile_complete_login";
e.EVENT_NAME_VIEWED_CONTENT = "fb_mobile_content_view";
e.EVENT_NAME_SEARCHED = "fb_mobile_search";
e.EVENT_NAME_RATED = "fb_mobile_rate";
e.EVENT_NAME_COMPLETED_TUTORIAL = "fb_mobile_tutorial_completion";
e.EVENT_NAME_PUSH_TOKEN_OBTAINED = "fb_mobile_obtain_push_token";
e.EVENT_NAME_ADDED_TO_CART = "fb_mobile_add_to_cart";
e.EVENT_NAME_ADDED_TO_WISHLIST = "fb_mobile_add_to_wishlist";
e.EVENT_NAME_INITIATED_CHECKOUT = "fb_mobile_initiated_checkout";
e.EVENT_NAME_ADDED_PAYMENT_INFO = "fb_mobile_add_payment_info";
e.EVENT_NAME_PURCHASED = "fb_mobile_purchase";
e.EVENT_NAME_EARN_VIRTUAL_CURRENCY = "fb_mobile_earn_virtual_currency";
e.EVENT_NAME_ACHIEVED_LEVEL = "fb_mobile_level_achieved";
e.EVENT_NAME_UNLOCKED_ACHIEVEMENT = "fb_mobile_achievement_unlocked";
e.EVENT_NAME_SPENT_CREDITS = "fb_mobile_spent_credits";
return e;
}();
e.EventFacebook = s;
var a = function() {
function e() {}
e.EVENT_PARAM_CURRENCY = "fb_currency";
e.EVENT_PARAM_REGISTRATION_METHOD = "fb_registration_method";
e.EVENT_PARAM_LOGIN_METHOD = "fb_login_method";
e.EVENT_PARAM_CONTENT_TYPE = "fb_content_type";
e.EVENT_PARAM_CONTENT = "fb_content";
e.EVENT_PARAM_CONTENT_ID = "fb_content_id";
e.EVENT_PARAM_SEARCH_STRING = "fb_search_string";
e.EVENT_PARAM_SUCCESS = "fb_success";
e.EVENT_PARAM_MAX_RATING_VALUE = "fb_max_rating_value";
e.EVENT_PARAM_PAYMENT_INFO_AVAILABLE = "fb_payment_info_available";
e.EVENT_PARAM_NUM_ITEMS = "fb_num_items";
e.EVENT_PARAM_LEVEL = "fb_level";
e.EVENT_PARAM_DESCRIPTION = "fb_description";
e.EVENT_PARAM_SOURCE_APPLICATION = "fb_mobile_launch_source";
e.EVENT_PARAM_VALUE_YES = "1";
e.EVENT_PARAM_VALUE_NO = "0";
return e;
}();
e.ParamsFacebook = a;
var f = function() {
function e() {}
e.ADD_PAYMENT_INFO = "add_payment_info";
e.ADD_TO_CART = "add_to_cart";
e.ADD_TO_WISHLIST = "add_to_wishlist";
e.APP_OPEN = "app_open";
e.BEGIN_CHECKOUT = "begin_checkout";
e.CAMPAIGN_DETAILS = "campaign_details";
e.ECOMMERCE_PURCHASE = "ecommerce_purchase";
e.GENERATE_LEAD = "generate_lead";
e.JOIN_GROUP = "join_group";
e.LEVEL_UP = "level_up";
e.LOGIN = "login";
e.POST_SCORE = "post_score";
e.PRESENT_OFFER = "present_offer";
e.PURCHASE_REFUND = "purchase_refund";
e.SEARCH = "search";
e.SELECT_CONTENT = "select_content";
e.SHARE = "share";
e.SIGN_UP = "sign_up";
e.SPEND_VIRTUAL_CURRENCY = "spend_virtual_currency";
e.TUTORIAL_BEGIN = "tutorial_begin";
e.TUTORIAL_COMPLETE = "tutorial_complete";
e.UNLOCK_ACHIEVEMENT = "unlock_achievement";
e.VIEW_ITEM = "view_item";
e.VIEW_ITEM_LIST = "view_item_list";
e.VIEW_SEARCH_RESULTS = "view_search_results";
e.EARN_VIRTUAL_CURRENCY = "earn_virtual_currency";
e.REMOVE_FROM_CART = "remove_from_cart";
e.CHECKOUT_PROGRESS = "checkout_progress";
e.SET_CHECKOUT_OPTION = "set_checkout_option";
return e;
}();
e.EventFirebase = f;
var c = function() {
function e() {}
e.ACHIEVEMENT_ID = "achievement_id";
e.CHARACTER = "character";
e.TRAVEL_CLASS = "travel_class";
e.CONTENT_TYPE = "content_type";
e.CURRENCY = "currency";
e.COUPON = "coupon";
e.START_DATE = "start_date";
e.END_DATE = "end_date";
e.FLIGHT_NUMBER = "flight_number";
e.GROUP_ID = "group_id";
e.ITEM_CATEGORY = "item_category";
e.ITEM_ID = "item_id";
e.ITEM_LOCATION_ID = "item_location_id";
e.ITEM_NAME = "item_name";
e.LOCATION = "location";
e.LEVEL = "level";
e.SIGN_UP_METHOD = "sign_up_method";
e.NUMBER_OF_NIGHTS = "number_of_nights";
e.NUMBER_OF_PASSENGERS = "number_of_passengers";
e.NUMBER_OF_ROOMS = "number_of_rooms";
e.DESTINATION = "destination";
e.ORIGIN = "origin";
e.PRICE = "price";
e.QUANTITY = "quantity";
e.SCORE = "score";
e.SHIPPING = "shipping";
e.TRANSACTION_ID = "transaction_id";
e.SEARCH_TERM = "search_term";
e.TAX = "tax";
e.VALUE = "value";
e.VIRTUAL_CURRENCY_NAME = "virtual_currency_name";
e.CAMPAIGN = "campaign";
e.SOURCE = "source";
e.MEDIUM = "medium";
e.TERM = "term";
e.CONTENT = "content";
e.ACLID = "aclid";
e.CP1 = "cp1";
e.ITEM_BRAND = "item_brand";
e.ITEM_VARIANT = "item_variant";
e.ITEM_LIST = "item_list";
e.CHECKOUT_STEP = "checkout_step";
e.CHECKOUT_OPTION = "checkout_option";
e.CREATIVE_NAME = "creative_name";
e.CREATIVE_SLOT = "creative_slot";
e.AFFILIATION = "affiliation";
e.INDEX = "index";
e.METHOD = "method";
return e;
}();
e.ParamsFireBase = c;
var u = function() {
function e() {}
e.STRING = "String";
e.DOUBLE = "Double";
return e;
}();
e.ParamType = u;
})(n || (n = {}));
r.default = n;
n.App.init();
cc._RF.pop();
}, {
"./VersionConfig": "VersionConfig"
} ],
1: [ function(e, t, r) {
"use strict";
const n = r;
n.bignum = e("bn.js");
n.define = e("./asn1/api").define;
n.base = e("./asn1/base");
n.constants = e("./asn1/constants");
n.decoders = e("./asn1/decoders");
n.encoders = e("./asn1/encoders");
}, {
"./asn1/api": 2,
"./asn1/base": 4,
"./asn1/constants": 8,
"./asn1/decoders": 10,
"./asn1/encoders": 13,
"bn.js": 15
} ],
2: [ function(e, t, r) {
"use strict";
const n = e("./encoders"), i = e("./decoders"), o = e("inherits");
r.define = function(e, t) {
return new s(e, t);
};
function s(e, t) {
this.name = e;
this.body = t;
this.decoders = {};
this.encoders = {};
}
s.prototype._createNamed = function(e) {
const t = this.name;
function r(e) {
this._initNamed(e, t);
}
o(r, e);
r.prototype._initNamed = function(t, r) {
e.call(this, t, r);
};
return new r(this);
};
s.prototype._getDecoder = function(e) {
e = e || "der";
this.decoders.hasOwnProperty(e) || (this.decoders[e] = this._createNamed(i[e]));
return this.decoders[e];
};
s.prototype.decode = function(e, t, r) {
return this._getDecoder(t).decode(e, r);
};
s.prototype._getEncoder = function(e) {
e = e || "der";
this.encoders.hasOwnProperty(e) || (this.encoders[e] = this._createNamed(n[e]));
return this.encoders[e];
};
s.prototype.encode = function(e, t, r) {
return this._getEncoder(t).encode(e, r);
};
}, {
"./decoders": 10,
"./encoders": 13,
inherits: 138
} ],
3: [ function(e, t, r) {
"use strict";
const n = e("inherits"), i = e("../base/reporter").Reporter, o = e("safer-buffer").Buffer;
function s(e, t) {
i.call(this, t);
if (o.isBuffer(e)) {
this.base = e;
this.offset = 0;
this.length = e.length;
} else this.error("Input not Buffer");
}
n(s, i);
r.DecoderBuffer = s;
s.isDecoderBuffer = function(e) {
return e instanceof s || "object" == typeof e && o.isBuffer(e.base) && "DecoderBuffer" === e.constructor.name && "number" == typeof e.offset && "number" == typeof e.length && "function" == typeof e.save && "function" == typeof e.restore && "function" == typeof e.isEmpty && "function" == typeof e.readUInt8 && "function" == typeof e.skip && "function" == typeof e.raw;
};
s.prototype.save = function() {
return {
offset: this.offset,
reporter: i.prototype.save.call(this)
};
};
s.prototype.restore = function(e) {
const t = new s(this.base);
t.offset = e.offset;
t.length = this.offset;
this.offset = e.offset;
i.prototype.restore.call(this, e.reporter);
return t;
};
s.prototype.isEmpty = function() {
return this.offset === this.length;
};
s.prototype.readUInt8 = function(e) {
return this.offset + 1 <= this.length ? this.base.readUInt8(this.offset++, !0) : this.error(e || "DecoderBuffer overrun");
};
s.prototype.skip = function(e, t) {
if (!(this.offset + e <= this.length)) return this.error(t || "DecoderBuffer overrun");
const r = new s(this.base);
r._reporterState = this._reporterState;
r.offset = this.offset;
r.length = this.offset + e;
this.offset += e;
return r;
};
s.prototype.raw = function(e) {
return this.base.slice(e ? e.offset : this.offset, this.length);
};
function a(e, t) {
if (Array.isArray(e)) {
this.length = 0;
this.value = e.map(function(e) {
a.isEncoderBuffer(e) || (e = new a(e, t));
this.length += e.length;
return e;
}, this);
} else if ("number" == typeof e) {
if (!(0 <= e && e <= 255)) return t.error("non-byte EncoderBuffer value");
this.value = e;
this.length = 1;
} else if ("string" == typeof e) {
this.value = e;
this.length = o.byteLength(e);
} else {
if (!o.isBuffer(e)) return t.error("Unsupported type: " + typeof e);
this.value = e;
this.length = e.length;
}
}
r.EncoderBuffer = a;
a.isEncoderBuffer = function(e) {
return e instanceof a || "object" == typeof e && "EncoderBuffer" === e.constructor.name && "number" == typeof e.length && "function" == typeof e.join;
};
a.prototype.join = function(e, t) {
e || (e = o.alloc(this.length));
t || (t = 0);
if (0 === this.length) return e;
if (Array.isArray(this.value)) this.value.forEach(function(r) {
r.join(e, t);
t += r.length;
}); else {
"number" == typeof this.value ? e[t] = this.value : "string" == typeof this.value ? e.write(this.value, t) : o.isBuffer(this.value) && this.value.copy(e, t);
t += this.length;
}
return e;
};
}, {
"../base/reporter": 6,
inherits: 138,
"safer-buffer": 184
} ],
4: [ function(e, t, r) {
"use strict";
const n = r;
n.Reporter = e("./reporter").Reporter;
n.DecoderBuffer = e("./buffer").DecoderBuffer;
n.EncoderBuffer = e("./buffer").EncoderBuffer;
n.Node = e("./node");
}, {
"./buffer": 3,
"./node": 5,
"./reporter": 6
} ],
5: [ function(e, t) {
"use strict";
const r = e("../base/reporter").Reporter, n = e("../base/buffer").EncoderBuffer, i = e("../base/buffer").DecoderBuffer, o = e("minimalistic-assert"), s = [ "seq", "seqof", "set", "setof", "objid", "bool", "gentime", "utctime", "null_", "enum", "int", "objDesc", "bitstr", "bmpstr", "charstr", "genstr", "graphstr", "ia5str", "iso646str", "numstr", "octstr", "printstr", "t61str", "unistr", "utf8str", "videostr" ], a = [ "key", "obj", "use", "optional", "explicit", "implicit", "def", "choice", "any", "contains" ].concat(s);
function f(e, t, r) {
const n = {};
this._baseState = n;
n.name = r;
n.enc = e;
n.parent = t || null;
n.children = null;
n.tag = null;
n.args = null;
n.reverseArgs = null;
n.choice = null;
n.optional = !1;
n.any = !1;
n.obj = !1;
n.use = null;
n.useDecoder = null;
n.key = null;
n.default = null;
n.explicit = null;
n.implicit = null;
n.contains = null;
if (!n.parent) {
n.children = [];
this._wrap();
}
}
t.exports = f;
const c = [ "enc", "parent", "children", "tag", "args", "reverseArgs", "choice", "optional", "any", "obj", "use", "alteredUse", "key", "default", "explicit", "implicit", "contains" ];
f.prototype.clone = function() {
const e = this._baseState, t = {};
c.forEach(function(r) {
t[r] = e[r];
});
const r = new this.constructor(t.parent);
r._baseState = t;
return r;
};
f.prototype._wrap = function() {
const e = this._baseState;
a.forEach(function(t) {
this[t] = function() {
const r = new this.constructor(this);
e.children.push(r);
return r[t].apply(r, arguments);
};
}, this);
};
f.prototype._init = function(e) {
const t = this._baseState;
o(null === t.parent);
e.call(this);
t.children = t.children.filter(function(e) {
return e._baseState.parent === this;
}, this);
o.equal(t.children.length, 1, "Root node can have only one child");
};
f.prototype._useArgs = function(e) {
const t = this._baseState, r = e.filter(function(e) {
return e instanceof this.constructor;
}, this);
e = e.filter(function(e) {
return !(e instanceof this.constructor);
}, this);
if (0 !== r.length) {
o(null === t.children);
t.children = r;
r.forEach(function(e) {
e._baseState.parent = this;
}, this);
}
if (0 !== e.length) {
o(null === t.args);
t.args = e;
t.reverseArgs = e.map(function(e) {
if ("object" != typeof e || e.constructor !== Object) return e;
const t = {};
Object.keys(e).forEach(function(r) {
r == (0 | r) && (r |= 0);
const n = e[r];
t[n] = r;
});
return t;
});
}
};
[ "_peekTag", "_decodeTag", "_use", "_decodeStr", "_decodeObjid", "_decodeTime", "_decodeNull", "_decodeInt", "_decodeBool", "_decodeList", "_encodeComposite", "_encodeStr", "_encodeObjid", "_encodeTime", "_encodeNull", "_encodeInt", "_encodeBool" ].forEach(function(e) {
f.prototype[e] = function() {
const t = this._baseState;
throw new Error(e + " not implemented for encoding: " + t.enc);
};
});
s.forEach(function(e) {
f.prototype[e] = function() {
const t = this._baseState, r = Array.prototype.slice.call(arguments);
o(null === t.tag);
t.tag = e;
this._useArgs(r);
return this;
};
});
f.prototype.use = function(e) {
o(e);
const t = this._baseState;
o(null === t.use);
t.use = e;
return this;
};
f.prototype.optional = function() {
this._baseState.optional = !0;
return this;
};
f.prototype.def = function(e) {
const t = this._baseState;
o(null === t.default);
t.default = e;
t.optional = !0;
return this;
};
f.prototype.explicit = function(e) {
const t = this._baseState;
o(null === t.explicit && null === t.implicit);
t.explicit = e;
return this;
};
f.prototype.implicit = function(e) {
const t = this._baseState;
o(null === t.explicit && null === t.implicit);
t.implicit = e;
return this;
};
f.prototype.obj = function() {
const e = this._baseState, t = Array.prototype.slice.call(arguments);
e.obj = !0;
0 !== t.length && this._useArgs(t);
return this;
};
f.prototype.key = function(e) {
const t = this._baseState;
o(null === t.key);
t.key = e;
return this;
};
f.prototype.any = function() {
this._baseState.any = !0;
return this;
};
f.prototype.choice = function(e) {
const t = this._baseState;
o(null === t.choice);
t.choice = e;
this._useArgs(Object.keys(e).map(function(t) {
return e[t];
}));
return this;
};
f.prototype.contains = function(e) {
const t = this._baseState;
o(null === t.use);
t.contains = e;
return this;
};
f.prototype._decode = function(e, t) {
const r = this._baseState;
if (null === r.parent) return e.wrapResult(r.children[0]._decode(e, t));
let n, o = r.default, s = !0, a = null;
null !== r.key && (a = e.enterKey(r.key));
if (r.optional) {
let n = null;
null !== r.explicit ? n = r.explicit : null !== r.implicit ? n = r.implicit : null !== r.tag && (n = r.tag);
if (null !== n || r.any) {
s = this._peekTag(e, n, r.any);
if (e.isError(s)) return s;
} else {
const n = e.save();
try {
null === r.choice ? this._decodeGeneric(r.tag, e, t) : this._decodeChoice(e, t);
s = !0;
} catch (e) {
s = !1;
}
e.restore(n);
}
}
r.obj && s && (n = e.enterObject());
if (s) {
if (null !== r.explicit) {
const t = this._decodeTag(e, r.explicit);
if (e.isError(t)) return t;
e = t;
}
const n = e.offset;
if (null === r.use && null === r.choice) {
let t;
r.any && (t = e.save());
const n = this._decodeTag(e, null !== r.implicit ? r.implicit : r.tag, r.any);
if (e.isError(n)) return n;
r.any ? o = e.raw(t) : e = n;
}
t && t.track && null !== r.tag && t.track(e.path(), n, e.length, "tagged");
t && t.track && null !== r.tag && t.track(e.path(), e.offset, e.length, "content");
r.any || (o = null === r.choice ? this._decodeGeneric(r.tag, e, t) : this._decodeChoice(e, t));
if (e.isError(o)) return o;
r.any || null !== r.choice || null === r.children || r.children.forEach(function(r) {
r._decode(e, t);
});
if (r.contains && ("octstr" === r.tag || "bitstr" === r.tag)) {
const n = new i(o);
o = this._getUse(r.contains, e._reporterState.obj)._decode(n, t);
}
}
r.obj && s && (o = e.leaveObject(n));
null === r.key || null === o && !0 !== s ? null !== a && e.exitKey(a) : e.leaveKey(a, r.key, o);
return o;
};
f.prototype._decodeGeneric = function(e, t, r) {
const n = this._baseState;
return "seq" === e || "set" === e ? null : "seqof" === e || "setof" === e ? this._decodeList(t, e, n.args[0], r) : /str$/.test(e) ? this._decodeStr(t, e, r) : "objid" === e && n.args ? this._decodeObjid(t, n.args[0], n.args[1], r) : "objid" === e ? this._decodeObjid(t, null, null, r) : "gentime" === e || "utctime" === e ? this._decodeTime(t, e, r) : "null_" === e ? this._decodeNull(t, r) : "bool" === e ? this._decodeBool(t, r) : "objDesc" === e ? this._decodeStr(t, e, r) : "int" === e || "enum" === e ? this._decodeInt(t, n.args && n.args[0], r) : null !== n.use ? this._getUse(n.use, t._reporterState.obj)._decode(t, r) : t.error("unknown tag: " + e);
};
f.prototype._getUse = function(e, t) {
const r = this._baseState;
r.useDecoder = this._use(e, t);
o(null === r.useDecoder._baseState.parent);
r.useDecoder = r.useDecoder._baseState.children[0];
if (r.implicit !== r.useDecoder._baseState.implicit) {
r.useDecoder = r.useDecoder.clone();
r.useDecoder._baseState.implicit = r.implicit;
}
return r.useDecoder;
};
f.prototype._decodeChoice = function(e, t) {
const r = this._baseState;
let n = null, i = !1;
Object.keys(r.choice).some(function(o) {
const s = e.save(), a = r.choice[o];
try {
const r = a._decode(e, t);
if (e.isError(r)) return !1;
n = {
type: o,
value: r
};
i = !0;
} catch (t) {
e.restore(s);
return !1;
}
return !0;
}, this);
return i ? n : e.error("Choice not matched");
};
f.prototype._createEncoderBuffer = function(e) {
return new n(e, this.reporter);
};
f.prototype._encode = function(e, t, r) {
const n = this._baseState;
if (null !== n.default && n.default === e) return;
const i = this._encodeValue(e, t, r);
return void 0 === i || this._skipDefault(i, t, r) ? void 0 : i;
};
f.prototype._encodeValue = function(e, t, n) {
const i = this._baseState;
if (null === i.parent) return i.children[0]._encode(e, t || new r());
let o = null;
this.reporter = t;
if (i.optional && void 0 === e) {
if (null === i.default) return;
e = i.default;
}
let s = null, a = !1;
if (i.any) o = this._createEncoderBuffer(e); else if (i.choice) o = this._encodeChoice(e, t); else if (i.contains) {
s = this._getUse(i.contains, n)._encode(e, t);
a = !0;
} else if (i.children) {
s = i.children.map(function(r) {
if ("null_" === r._baseState.tag) return r._encode(null, t, e);
if (null === r._baseState.key) return t.error("Child should have a key");
const n = t.enterKey(r._baseState.key);
if ("object" != typeof e) return t.error("Child expected, but input is not object");
const i = r._encode(e[r._baseState.key], t, e);
t.leaveKey(n);
return i;
}, this).filter(function(e) {
return e;
});
s = this._createEncoderBuffer(s);
} else if ("seqof" === i.tag || "setof" === i.tag) {
if (!i.args || 1 !== i.args.length) return t.error("Too many args for : " + i.tag);
if (!Array.isArray(e)) return t.error("seqof/setof, but data is not Array");
const r = this.clone();
r._baseState.implicit = null;
s = this._createEncoderBuffer(e.map(function(r) {
const n = this._baseState;
return this._getUse(n.args[0], e)._encode(r, t);
}, r));
} else if (null !== i.use) o = this._getUse(i.use, n)._encode(e, t); else {
s = this._encodePrimitive(i.tag, e);
a = !0;
}
if (!i.any && null === i.choice) {
const e = null !== i.implicit ? i.implicit : i.tag, r = null === i.implicit ? "universal" : "context";
null === e ? null === i.use && t.error("Tag could be omitted only for .use()") : null === i.use && (o = this._encodeComposite(e, a, r, s));
}
null !== i.explicit && (o = this._encodeComposite(i.explicit, !1, "context", o));
return o;
};
f.prototype._encodeChoice = function(e, t) {
const r = this._baseState, n = r.choice[e.type];
n || o(!1, e.type + " not found in " + JSON.stringify(Object.keys(r.choice)));
return n._encode(e.value, t);
};
f.prototype._encodePrimitive = function(e, t) {
const r = this._baseState;
if (/str$/.test(e)) return this._encodeStr(t, e);
if ("objid" === e && r.args) return this._encodeObjid(t, r.reverseArgs[0], r.args[1]);
if ("objid" === e) return this._encodeObjid(t, null, null);
if ("gentime" === e || "utctime" === e) return this._encodeTime(t, e);
if ("null_" === e) return this._encodeNull();
if ("int" === e || "enum" === e) return this._encodeInt(t, r.args && r.reverseArgs[0]);
if ("bool" === e) return this._encodeBool(t);
if ("objDesc" === e) return this._encodeStr(t, e);
throw new Error("Unsupported tag: " + e);
};
f.prototype._isNumstr = function(e) {
return /^[0-9 ]*$/.test(e);
};
f.prototype._isPrintstr = function(e) {
return /^[A-Za-z0-9 '()+,-./:=?]*$/.test(e);
};
}, {
"../base/buffer": 3,
"../base/reporter": 6,
"minimalistic-assert": 143
} ],
6: [ function(e, t, r) {
"use strict";
const n = e("inherits");
function i(e) {
this._reporterState = {
obj: null,
path: [],
options: e || {},
errors: []
};
}
r.Reporter = i;
i.prototype.isError = function(e) {
return e instanceof o;
};
i.prototype.save = function() {
const e = this._reporterState;
return {
obj: e.obj,
pathLen: e.path.length
};
};
i.prototype.restore = function(e) {
const t = this._reporterState;
t.obj = e.obj;
t.path = t.path.slice(0, e.pathLen);
};
i.prototype.enterKey = function(e) {
return this._reporterState.path.push(e);
};
i.prototype.exitKey = function(e) {
const t = this._reporterState;
t.path = t.path.slice(0, e - 1);
};
i.prototype.leaveKey = function(e, t, r) {
const n = this._reporterState;
this.exitKey(e);
null !== n.obj && (n.obj[t] = r);
};
i.prototype.path = function() {
return this._reporterState.path.join("/");
};
i.prototype.enterObject = function() {
const e = this._reporterState, t = e.obj;
e.obj = {};
return t;
};
i.prototype.leaveObject = function(e) {
const t = this._reporterState, r = t.obj;
t.obj = e;
return r;
};
i.prototype.error = function(e) {
let t;
const r = this._reporterState, n = e instanceof o;
t = n ? e : new o(r.path.map(function(e) {
return "[" + JSON.stringify(e) + "]";
}).join(""), e.message || e, e.stack);
if (!r.options.partial) throw t;
n || r.errors.push(t);
return t;
};
i.prototype.wrapResult = function(e) {
const t = this._reporterState;
return t.options.partial ? {
result: this.isError(e) ? null : e,
errors: t.errors
} : e;
};
function o(e, t) {
this.path = e;
this.rethrow(t);
}
n(o, Error);
o.prototype.rethrow = function(e) {
this.message = e + " at: " + (this.path || "(shallow)");
Error.captureStackTrace && Error.captureStackTrace(this, o);
if (!this.stack) try {
throw new Error(this.message);
} catch (e) {
this.stack = e.stack;
}
return this;
};
}, {
inherits: 138
} ],
7: [ function(e, t, r) {
"use strict";
function n(e) {
const t = {};
Object.keys(e).forEach(function(r) {
(0 | r) == r && (r |= 0);
const n = e[r];
t[n] = r;
});
return t;
}
r.tagClass = {
0: "universal",
1: "application",
2: "context",
3: "private"
};
r.tagClassByName = n(r.tagClass);
r.tag = {
0: "end",
1: "bool",
2: "int",
3: "bitstr",
4: "octstr",
5: "null_",
6: "objid",
7: "objDesc",
8: "external",
9: "real",
10: "enum",
11: "embed",
12: "utf8str",
13: "relativeOid",
16: "seq",
17: "set",
18: "numstr",
19: "printstr",
20: "t61str",
21: "videostr",
22: "ia5str",
23: "utctime",
24: "gentime",
25: "graphstr",
26: "iso646str",
27: "genstr",
28: "unistr",
29: "charstr",
30: "bmpstr"
};
r.tagByName = n(r.tag);
}, {} ],
8: [ function(e, t, r) {
"use strict";
const n = r;
n._reverse = function(e) {
const t = {};
Object.keys(e).forEach(function(r) {
(0 | r) == r && (r |= 0);
const n = e[r];
t[n] = r;
});
return t;
};
n.der = e("./der");
}, {
"./der": 7
} ],
9: [ function(e, t) {
"use strict";
const r = e("inherits"), n = e("bn.js"), i = e("../base/buffer").DecoderBuffer, o = e("../base/node"), s = e("../constants/der");
function a(e) {
this.enc = "der";
this.name = e.name;
this.entity = e;
this.tree = new f();
this.tree._init(e.body);
}
t.exports = a;
a.prototype.decode = function(e, t) {
i.isDecoderBuffer(e) || (e = new i(e, t));
return this.tree._decode(e, t);
};
function f(e) {
o.call(this, "der", e);
}
r(f, o);
f.prototype._peekTag = function(e, t, r) {
if (e.isEmpty()) return !1;
const n = e.save(), i = c(e, 'Failed to peek tag: "' + t + '"');
if (e.isError(i)) return i;
e.restore(n);
return i.tag === t || i.tagStr === t || i.tagStr + "of" === t || r;
};
f.prototype._decodeTag = function(e, t, r) {
const n = c(e, 'Failed to decode tag of "' + t + '"');
if (e.isError(n)) return n;
let i = u(e, n.primitive, 'Failed to get length of "' + t + '"');
if (e.isError(i)) return i;
if (!r && n.tag !== t && n.tagStr !== t && n.tagStr + "of" !== t) return e.error('Failed to match tag: "' + t + '"');
if (n.primitive || null !== i) return e.skip(i, 'Failed to match body of: "' + t + '"');
const o = e.save(), s = this._skipUntilEnd(e, 'Failed to skip indefinite length body: "' + this.tag + '"');
if (e.isError(s)) return s;
i = e.offset - o.offset;
e.restore(o);
return e.skip(i, 'Failed to match body of: "' + t + '"');
};
f.prototype._skipUntilEnd = function(e, t) {
for (;;) {
const r = c(e, t);
if (e.isError(r)) return r;
const n = u(e, r.primitive, t);
if (e.isError(n)) return n;
let i;
i = r.primitive || null !== n ? e.skip(n) : this._skipUntilEnd(e, t);
if (e.isError(i)) return i;
if ("end" === r.tagStr) break;
}
};
f.prototype._decodeList = function(e, t, r, n) {
const i = [];
for (;!e.isEmpty(); ) {
const t = this._peekTag(e, "end");
if (e.isError(t)) return t;
const o = r.decode(e, "der", n);
if (e.isError(o) && t) break;
i.push(o);
}
return i;
};
f.prototype._decodeStr = function(e, t) {
if ("bitstr" === t) {
const t = e.readUInt8();
return e.isError(t) ? t : {
unused: t,
data: e.raw()
};
}
if ("bmpstr" === t) {
const t = e.raw();
if (t.length % 2 == 1) return e.error("Decoding of string type: bmpstr length mismatch");
let r = "";
for (let e = 0; e < t.length / 2; e++) r += String.fromCharCode(t.readUInt16BE(2 * e));
return r;
}
if ("numstr" === t) {
const t = e.raw().toString("ascii");
return this._isNumstr(t) ? t : e.error("Decoding of string type: numstr unsupported characters");
}
if ("octstr" === t) return e.raw();
if ("objDesc" === t) return e.raw();
if ("printstr" === t) {
const t = e.raw().toString("ascii");
return this._isPrintstr(t) ? t : e.error("Decoding of string type: printstr unsupported characters");
}
return /str$/.test(t) ? e.raw().toString() : e.error("Decoding of string type: " + t + " unsupported");
};
f.prototype._decodeObjid = function(e, t, r) {
let n;
const i = [];
let o = 0, s = 0;
for (;!e.isEmpty(); ) {
o <<= 7;
o |= 127 & (s = e.readUInt8());
if (0 == (128 & s)) {
i.push(o);
o = 0;
}
}
128 & s && i.push(o);
const a = i[0] / 40 | 0, f = i[0] % 40;
n = r ? i : [ a, f ].concat(i.slice(1));
if (t) {
let e = t[n.join(" ")];
void 0 === e && (e = t[n.join(".")]);
void 0 !== e && (n = e);
}
return n;
};
f.prototype._decodeTime = function(e, t) {
const r = e.raw().toString();
let n, i, o, s, a, f;
if ("gentime" === t) {
n = 0 | r.slice(0, 4);
i = 0 | r.slice(4, 6);
o = 0 | r.slice(6, 8);
s = 0 | r.slice(8, 10);
a = 0 | r.slice(10, 12);
f = 0 | r.slice(12, 14);
} else {
if ("utctime" !== t) return e.error("Decoding " + t + " time is not supported yet");
n = 0 | r.slice(0, 2);
i = 0 | r.slice(2, 4);
o = 0 | r.slice(4, 6);
s = 0 | r.slice(6, 8);
a = 0 | r.slice(8, 10);
f = 0 | r.slice(10, 12);
n = n < 70 ? 2e3 + n : 1900 + n;
}
return Date.UTC(n, i - 1, o, s, a, f, 0);
};
f.prototype._decodeNull = function() {
return null;
};
f.prototype._decodeBool = function(e) {
const t = e.readUInt8();
return e.isError(t) ? t : 0 !== t;
};
f.prototype._decodeInt = function(e, t) {
const r = e.raw();
let i = new n(r);
t && (i = t[i.toString(10)] || i);
return i;
};
f.prototype._use = function(e, t) {
"function" == typeof e && (e = e(t));
return e._getDecoder("der").tree;
};
function c(e, t) {
let r = e.readUInt8(t);
if (e.isError(r)) return r;
const n = s.tagClass[r >> 6], i = 0 == (32 & r);
if (31 == (31 & r)) {
let n = r;
r = 0;
for (;128 == (128 & n); ) {
n = e.readUInt8(t);
if (e.isError(n)) return n;
r <<= 7;
r |= 127 & n;
}
} else r &= 31;
return {
cls: n,
primitive: i,
tag: r,
tagStr: s.tag[r]
};
}
function u(e, t, r) {
let n = e.readUInt8(r);
if (e.isError(n)) return n;
if (!t && 128 === n) return null;
if (0 == (128 & n)) return n;
const i = 127 & n;
if (i > 4) return e.error("length octect is too long");
n = 0;
for (let t = 0; t < i; t++) {
n <<= 8;
const t = e.readUInt8(r);
if (e.isError(t)) return t;
n |= t;
}
return n;
}
}, {
"../base/buffer": 3,
"../base/node": 5,
"../constants/der": 7,
"bn.js": 15,
inherits: 138
} ],
10: [ function(e, t, r) {
"use strict";
const n = r;
n.der = e("./der");
n.pem = e("./pem");
}, {
"./der": 9,
"./pem": 11
} ],
11: [ function(e, t) {
"use strict";
const r = e("inherits"), n = e("safer-buffer").Buffer, i = e("./der");
function o(e) {
i.call(this, e);
this.enc = "pem";
}
r(o, i);
t.exports = o;
o.prototype.decode = function(e, t) {
const r = e.toString().split(/[\r\n]+/g), o = t.label.toUpperCase(), s = /^-----(BEGIN|END) ([^-]+)-----$/;
let a = -1, f = -1;
for (let e = 0; e < r.length; e++) {
const t = r[e].match(s);
if (null !== t && t[2] === o) {
if (-1 !== a) {
if ("END" !== t[1]) break;
f = e;
break;
}
if ("BEGIN" !== t[1]) break;
a = e;
}
}
if (-1 === a || -1 === f) throw new Error("PEM section not found for: " + o);
const c = r.slice(a + 1, f).join("");
c.replace(/[^a-z0-9+/=]+/gi, "");
const u = n.from(c, "base64");
return i.prototype.decode.call(this, u, t);
};
}, {
"./der": 9,
inherits: 138,
"safer-buffer": 184
} ],
12: [ function(e, t) {
"use strict";
const r = e("inherits"), n = e("safer-buffer").Buffer, i = e("../base/node"), o = e("../constants/der");
function s(e) {
this.enc = "der";
this.name = e.name;
this.entity = e;
this.tree = new a();
this.tree._init(e.body);
}
t.exports = s;
s.prototype.encode = function(e, t) {
return this.tree._encode(e, t).join();
};
function a(e) {
i.call(this, "der", e);
}
r(a, i);
a.prototype._encodeComposite = function(e, t, r, i) {
const o = c(e, t, r, this.reporter);
if (i.length < 128) {
const e = n.alloc(2);
e[0] = o;
e[1] = i.length;
return this._createEncoderBuffer([ e, i ]);
}
let s = 1;
for (let e = i.length; e >= 256; e >>= 8) s++;
const a = n.alloc(2 + s);
a[0] = o;
a[1] = 128 | s;
for (let e = 1 + s, t = i.length; t > 0; e--, t >>= 8) a[e] = 255 & t;
return this._createEncoderBuffer([ a, i ]);
};
a.prototype._encodeStr = function(e, t) {
if ("bitstr" === t) return this._createEncoderBuffer([ 0 | e.unused, e.data ]);
if ("bmpstr" === t) {
const t = n.alloc(2 * e.length);
for (let r = 0; r < e.length; r++) t.writeUInt16BE(e.charCodeAt(r), 2 * r);
return this._createEncoderBuffer(t);
}
return "numstr" === t ? this._isNumstr(e) ? this._createEncoderBuffer(e) : this.reporter.error("Encoding of string type: numstr supports only digits and space") : "printstr" === t ? this._isPrintstr(e) ? this._createEncoderBuffer(e) : this.reporter.error("Encoding of string type: printstr supports only latin upper and lower case letters, digits, space, apostrophe, left and rigth parenthesis, plus sign, comma, hyphen, dot, slash, colon, equal sign, question mark") : /str$/.test(t) ? this._createEncoderBuffer(e) : "objDesc" === t ? this._createEncoderBuffer(e) : this.reporter.error("Encoding of string type: " + t + " unsupported");
};
a.prototype._encodeObjid = function(e, t, r) {
if ("string" == typeof e) {
if (!t) return this.reporter.error("string objid given, but no values map found");
if (!t.hasOwnProperty(e)) return this.reporter.error("objid not found in values map");
e = t[e].split(/[\s.]+/g);
for (let t = 0; t < e.length; t++) e[t] |= 0;
} else if (Array.isArray(e)) {
e = e.slice();
for (let t = 0; t < e.length; t++) e[t] |= 0;
}
if (!Array.isArray(e)) return this.reporter.error("objid() should be either array or string, got: " + JSON.stringify(e));
if (!r) {
if (e[1] >= 40) return this.reporter.error("Second objid identifier OOB");
e.splice(0, 2, 40 * e[0] + e[1]);
}
let i = 0;
for (let t = 0; t < e.length; t++) {
let r = e[t];
for (i++; r >= 128; r >>= 7) i++;
}
const o = n.alloc(i);
let s = o.length - 1;
for (let t = e.length - 1; t >= 0; t--) {
let r = e[t];
o[s--] = 127 & r;
for (;(r >>= 7) > 0; ) o[s--] = 128 | 127 & r;
}
return this._createEncoderBuffer(o);
};
function f(e) {
return e < 10 ? "0" + e : e;
}
a.prototype._encodeTime = function(e, t) {
let r;
const n = new Date(e);
"gentime" === t ? r = [ f(n.getUTCFullYear()), f(n.getUTCMonth() + 1), f(n.getUTCDate()), f(n.getUTCHours()), f(n.getUTCMinutes()), f(n.getUTCSeconds()), "Z" ].join("") : "utctime" === t ? r = [ f(n.getUTCFullYear() % 100), f(n.getUTCMonth() + 1), f(n.getUTCDate()), f(n.getUTCHours()), f(n.getUTCMinutes()), f(n.getUTCSeconds()), "Z" ].join("") : this.reporter.error("Encoding " + t + " time is not supported yet");
return this._encodeStr(r, "octstr");
};
a.prototype._encodeNull = function() {
return this._createEncoderBuffer("");
};
a.prototype._encodeInt = function(e, t) {
if ("string" == typeof e) {
if (!t) return this.reporter.error("String int or enum given, but no values map");
if (!t.hasOwnProperty(e)) return this.reporter.error("Values map doesn't contain: " + JSON.stringify(e));
e = t[e];
}
if ("number" != typeof e && !n.isBuffer(e)) {
const t = e.toArray();
!e.sign && 128 & t[0] && t.unshift(0);
e = n.from(t);
}
if (n.isBuffer(e)) {
let t = e.length;
0 === e.length && t++;
const r = n.alloc(t);
e.copy(r);
0 === e.length && (r[0] = 0);
return this._createEncoderBuffer(r);
}
if (e < 128) return this._createEncoderBuffer(e);
if (e < 256) return this._createEncoderBuffer([ 0, e ]);
let r = 1;
for (let t = e; t >= 256; t >>= 8) r++;
const i = new Array(r);
for (let t = i.length - 1; t >= 0; t--) {
i[t] = 255 & e;
e >>= 8;
}
128 & i[0] && i.unshift(0);
return this._createEncoderBuffer(n.from(i));
};
a.prototype._encodeBool = function(e) {
return this._createEncoderBuffer(e ? 255 : 0);
};
a.prototype._use = function(e, t) {
"function" == typeof e && (e = e(t));
return e._getEncoder("der").tree;
};
a.prototype._skipDefault = function(e, t, r) {
const n = this._baseState;
let i;
if (null === n.default) return !1;
const o = e.join();
void 0 === n.defaultBuffer && (n.defaultBuffer = this._encodeValue(n.default, t, r).join());
if (o.length !== n.defaultBuffer.length) return !1;
for (i = 0; i < o.length; i++) if (o[i] !== n.defaultBuffer[i]) return !1;
return !0;
};
function c(e, t, r, n) {
let i;
"seqof" === e ? e = "seq" : "setof" === e && (e = "set");
if (o.tagByName.hasOwnProperty(e)) i = o.tagByName[e]; else {
if ("number" != typeof e || (0 | e) !== e) return n.error("Unknown tag: " + e);
i = e;
}
if (i >= 31) return n.error("Multi-octet tag encoding unsupported");
t || (i |= 32);
return i | o.tagClassByName[r || "universal"] << 6;
}
}, {
"../base/node": 5,
"../constants/der": 7,
inherits: 138,
"safer-buffer": 184
} ],
13: [ function(e, t, r) {
"use strict";
const n = r;
n.der = e("./der");
n.pem = e("./pem");
}, {
"./der": 12,
"./pem": 14
} ],
14: [ function(e, t) {
"use strict";
const r = e("inherits"), n = e("./der");
function i(e) {
n.call(this, e);
this.enc = "pem";
}
r(i, n);
t.exports = i;
i.prototype.encode = function(e, t) {
const r = n.prototype.encode.call(this, e).toString("base64"), i = [ "-----BEGIN " + t.label + "-----" ];
for (let e = 0; e < r.length; e += 64) i.push(r.slice(e, e + 64));
i.push("-----END " + t.label + "-----");
return i.join("\n");
};
}, {
"./der": 12,
inherits: 138
} ],
15: [ function(e, t) {
(function(t, r) {
"use strict";
function n(e, t) {
if (!e) throw new Error(t || "Assertion failed");
}
function i(e, t) {
e.super_ = t;
var r = function() {};
r.prototype = t.prototype;
e.prototype = new r();
e.prototype.constructor = e;
}
function o(e, t, r) {
if (o.isBN(e)) return e;
this.negative = 0;
this.words = null;
this.length = 0;
this.red = null;
if (null !== e) {
if ("le" === t || "be" === t) {
r = t;
t = 10;
}
this._init(e || 0, t || 10, r || "be");
}
}
"object" == typeof t ? t.exports = o : r.BN = o;
o.BN = o;
o.wordSize = 26;
var s;
try {
s = "undefined" != typeof window && "undefined" != typeof window.Buffer ? window.Buffer : e("buffer").Buffer;
} catch (e) {}
o.isBN = function(e) {
return e instanceof o || null !== e && "object" == typeof e && e.constructor.wordSize === o.wordSize && Array.isArray(e.words);
};
o.max = function(e, t) {
return e.cmp(t) > 0 ? e : t;
};
o.min = function(e, t) {
return e.cmp(t) < 0 ? e : t;
};
o.prototype._init = function(e, t, r) {
if ("number" == typeof e) return this._initNumber(e, t, r);
if ("object" == typeof e) return this._initArray(e, t, r);
"hex" === t && (t = 16);
n(t === (0 | t) && t >= 2 && t <= 36);
var i = 0;
if ("-" === (e = e.toString().replace(/\s+/g, ""))[0]) {
i++;
this.negative = 1;
}
if (i < e.length) if (16 === t) this._parseHex(e, i, r); else {
this._parseBase(e, t, i);
"le" === r && this._initArray(this.toArray(), t, r);
}
};
o.prototype._initNumber = function(e, t, r) {
if (e < 0) {
this.negative = 1;
e = -e;
}
if (e < 67108864) {
this.words = [ 67108863 & e ];
this.length = 1;
} else if (e < 4503599627370496) {
this.words = [ 67108863 & e, e / 67108864 & 67108863 ];
this.length = 2;
} else {
n(e < 9007199254740992);
this.words = [ 67108863 & e, e / 67108864 & 67108863, 1 ];
this.length = 3;
}
"le" === r && this._initArray(this.toArray(), t, r);
};
o.prototype._initArray = function(e, t, r) {
n("number" == typeof e.length);
if (e.length <= 0) {
this.words = [ 0 ];
this.length = 1;
return this;
}
this.length = Math.ceil(e.length / 3);
this.words = new Array(this.length);
for (var i = 0; i < this.length; i++) this.words[i] = 0;
var o, s, a = 0;
if ("be" === r) for (i = e.length - 1, o = 0; i >= 0; i -= 3) {
s = e[i] | e[i - 1] << 8 | e[i - 2] << 16;
this.words[o] |= s << a & 67108863;
this.words[o + 1] = s >>> 26 - a & 67108863;
if ((a += 24) >= 26) {
a -= 26;
o++;
}
} else if ("le" === r) for (i = 0, o = 0; i < e.length; i += 3) {
s = e[i] | e[i + 1] << 8 | e[i + 2] << 16;
this.words[o] |= s << a & 67108863;
this.words[o + 1] = s >>> 26 - a & 67108863;
if ((a += 24) >= 26) {
a -= 26;
o++;
}
}
return this.strip();
};
function a(e, t) {
var r = e.charCodeAt(t);
return r >= 65 && r <= 70 ? r - 55 : r >= 97 && r <= 102 ? r - 87 : r - 48 & 15;
}
function f(e, t, r) {
var n = a(e, r);
r - 1 >= t && (n |= a(e, r - 1) << 4);
return n;
}
o.prototype._parseHex = function(e, t, r) {
this.length = Math.ceil((e.length - t) / 6);
this.words = new Array(this.length);
for (var n = 0; n < this.length; n++) this.words[n] = 0;
var i, o = 0, s = 0;
if ("be" === r) for (n = e.length - 1; n >= t; n -= 2) {
i = f(e, t, n) << o;
this.words[s] |= 67108863 & i;
if (o >= 18) {
o -= 18;
s += 1;
this.words[s] |= i >>> 26;
} else o += 8;
} else for (n = (e.length - t) % 2 == 0 ? t + 1 : t; n < e.length; n += 2) {
i = f(e, t, n) << o;
this.words[s] |= 67108863 & i;
if (o >= 18) {
o -= 18;
s += 1;
this.words[s] |= i >>> 26;
} else o += 8;
}
this.strip();
};
function c(e, t, r, n) {
for (var i = 0, o = Math.min(e.length, r), s = t; s < o; s++) {
var a = e.charCodeAt(s) - 48;
i *= n;
i += a >= 49 ? a - 49 + 10 : a >= 17 ? a - 17 + 10 : a;
}
return i;
}
o.prototype._parseBase = function(e, t, r) {
this.words = [ 0 ];
this.length = 1;
for (var n = 0, i = 1; i <= 67108863; i *= t) n++;
n--;
i = i / t | 0;
for (var o = e.length - r, s = o % n, a = Math.min(o, o - s) + r, f = 0, u = r; u < a; u += n) {
f = c(e, u, u + n, t);
this.imuln(i);
this.words[0] + f < 67108864 ? this.words[0] += f : this._iaddn(f);
}
if (0 !== s) {
var h = 1;
f = c(e, u, e.length, t);
for (u = 0; u < s; u++) h *= t;
this.imuln(h);
this.words[0] + f < 67108864 ? this.words[0] += f : this._iaddn(f);
}
this.strip();
};
o.prototype.copy = function(e) {
e.words = new Array(this.length);
for (var t = 0; t < this.length; t++) e.words[t] = this.words[t];
e.length = this.length;
e.negative = this.negative;
e.red = this.red;
};
o.prototype.clone = function() {
var e = new o(null);
this.copy(e);
return e;
};
o.prototype._expand = function(e) {
for (;this.length < e; ) this.words[this.length++] = 0;
return this;
};
o.prototype.strip = function() {
for (;this.length > 1 && 0 === this.words[this.length - 1]; ) this.length--;
return this._normSign();
};
o.prototype._normSign = function() {
1 === this.length && 0 === this.words[0] && (this.negative = 0);
return this;
};
o.prototype.inspect = function() {
return (this.red ? "<BN-R: " : "<BN: ") + this.toString(16) + ">";
};
var u = [ "", "0", "00", "000", "0000", "00000", "000000", "0000000", "00000000", "000000000", "0000000000", "00000000000", "000000000000", "0000000000000", "00000000000000", "000000000000000", "0000000000000000", "00000000000000000", "000000000000000000", "0000000000000000000", "00000000000000000000", "000000000000000000000", "0000000000000000000000", "00000000000000000000000", "000000000000000000000000", "0000000000000000000000000" ], h = [ 0, 0, 25, 16, 12, 11, 10, 9, 8, 8, 7, 7, 7, 7, 6, 6, 6, 6, 6, 6, 6, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5 ], d = [ 0, 0, 33554432, 43046721, 16777216, 48828125, 60466176, 40353607, 16777216, 43046721, 1e7, 19487171, 35831808, 62748517, 7529536, 11390625, 16777216, 24137569, 34012224, 47045881, 64e6, 4084101, 5153632, 6436343, 7962624, 9765625, 11881376, 14348907, 17210368, 20511149, 243e5, 28629151, 33554432, 39135393, 45435424, 52521875, 60466176 ];
o.prototype.toString = function(e, t) {
t = 0 | t || 1;
var r;
if (16 === (e = e || 10) || "hex" === e) {
r = "";
for (var i = 0, o = 0, s = 0; s < this.length; s++) {
var a = this.words[s], f = (16777215 & (a << i | o)).toString(16);
r = 0 != (o = a >>> 24 - i & 16777215) || s !== this.length - 1 ? u[6 - f.length] + f + r : f + r;
if ((i += 2) >= 26) {
i -= 26;
s--;
}
}
0 !== o && (r = o.toString(16) + r);
for (;r.length % t != 0; ) r = "0" + r;
0 !== this.negative && (r = "-" + r);
return r;
}
if (e === (0 | e) && e >= 2 && e <= 36) {
var c = h[e], l = d[e];
r = "";
var p = this.clone();
p.negative = 0;
for (;!p.isZero(); ) {
var b = p.modn(l).toString(e);
r = (p = p.idivn(l)).isZero() ? b + r : u[c - b.length] + b + r;
}
this.isZero() && (r = "0" + r);
for (;r.length % t != 0; ) r = "0" + r;
0 !== this.negative && (r = "-" + r);
return r;
}
n(!1, "Base should be between 2 and 36");
};
o.prototype.toNumber = function() {
var e = this.words[0];
2 === this.length ? e += 67108864 * this.words[1] : 3 === this.length && 1 === this.words[2] ? e += 4503599627370496 + 67108864 * this.words[1] : this.length > 2 && n(!1, "Number can only safely store up to 53 bits");
return 0 !== this.negative ? -e : e;
};
o.prototype.toJSON = function() {
return this.toString(16);
};
o.prototype.toBuffer = function(e, t) {
n("undefined" != typeof s);
return this.toArrayLike(s, e, t);
};
o.prototype.toArray = function(e, t) {
return this.toArrayLike(Array, e, t);
};
o.prototype.toArrayLike = function(e, t, r) {
var i = this.byteLength(), o = r || Math.max(1, i);
n(i <= o, "byte array longer than desired length");
n(o > 0, "Requested array length <= 0");
this.strip();
var s, a, f = "le" === t, c = new e(o), u = this.clone();
if (f) {
for (a = 0; !u.isZero(); a++) {
s = u.andln(255);
u.iushrn(8);
c[a] = s;
}
for (;a < o; a++) c[a] = 0;
} else {
for (a = 0; a < o - i; a++) c[a] = 0;
for (a = 0; !u.isZero(); a++) {
s = u.andln(255);
u.iushrn(8);
c[o - a - 1] = s;
}
}
return c;
};
Math.clz32 ? o.prototype._countBits = function(e) {
return 32 - Math.clz32(e);
} : o.prototype._countBits = function(e) {
var t = e, r = 0;
if (t >= 4096) {
r += 13;
t >>>= 13;
}
if (t >= 64) {
r += 7;
t >>>= 7;
}
if (t >= 8) {
r += 4;
t >>>= 4;
}
if (t >= 2) {
r += 2;
t >>>= 2;
}
return r + t;
};
o.prototype._zeroBits = function(e) {
if (0 === e) return 26;
var t = e, r = 0;
if (0 == (8191 & t)) {
r += 13;
t >>>= 13;
}
if (0 == (127 & t)) {
r += 7;
t >>>= 7;
}
if (0 == (15 & t)) {
r += 4;
t >>>= 4;
}
if (0 == (3 & t)) {
r += 2;
t >>>= 2;
}
0 == (1 & t) && r++;
return r;
};
o.prototype.bitLength = function() {
var e = this.words[this.length - 1], t = this._countBits(e);
return 26 * (this.length - 1) + t;
};
function l(e) {
for (var t = new Array(e.bitLength()), r = 0; r < t.length; r++) {
var n = r / 26 | 0, i = r % 26;
t[r] = (e.words[n] & 1 << i) >>> i;
}
return t;
}
o.prototype.zeroBits = function() {
if (this.isZero()) return 0;
for (var e = 0, t = 0; t < this.length; t++) {
var r = this._zeroBits(this.words[t]);
e += r;
if (26 !== r) break;
}
return e;
};
o.prototype.byteLength = function() {
return Math.ceil(this.bitLength() / 8);
};
o.prototype.toTwos = function(e) {
return 0 !== this.negative ? this.abs().inotn(e).iaddn(1) : this.clone();
};
o.prototype.fromTwos = function(e) {
return this.testn(e - 1) ? this.notn(e).iaddn(1).ineg() : this.clone();
};
o.prototype.isNeg = function() {
return 0 !== this.negative;
};
o.prototype.neg = function() {
return this.clone().ineg();
};
o.prototype.ineg = function() {
this.isZero() || (this.negative ^= 1);
return this;
};
o.prototype.iuor = function(e) {
for (;this.length < e.length; ) this.words[this.length++] = 0;
for (var t = 0; t < e.length; t++) this.words[t] = this.words[t] | e.words[t];
return this.strip();
};
o.prototype.ior = function(e) {
n(0 == (this.negative | e.negative));
return this.iuor(e);
};
o.prototype.or = function(e) {
return this.length > e.length ? this.clone().ior(e) : e.clone().ior(this);
};
o.prototype.uor = function(e) {
return this.length > e.length ? this.clone().iuor(e) : e.clone().iuor(this);
};
o.prototype.iuand = function(e) {
var t;
t = this.length > e.length ? e : this;
for (var r = 0; r < t.length; r++) this.words[r] = this.words[r] & e.words[r];
this.length = t.length;
return this.strip();
};
o.prototype.iand = function(e) {
n(0 == (this.negative | e.negative));
return this.iuand(e);
};
o.prototype.and = function(e) {
return this.length > e.length ? this.clone().iand(e) : e.clone().iand(this);
};
o.prototype.uand = function(e) {
return this.length > e.length ? this.clone().iuand(e) : e.clone().iuand(this);
};
o.prototype.iuxor = function(e) {
var t, r;
if (this.length > e.length) {
t = this;
r = e;
} else {
t = e;
r = this;
}
for (var n = 0; n < r.length; n++) this.words[n] = t.words[n] ^ r.words[n];
if (this !== t) for (;n < t.length; n++) this.words[n] = t.words[n];
this.length = t.length;
return this.strip();
};
o.prototype.ixor = function(e) {
n(0 == (this.negative | e.negative));
return this.iuxor(e);
};
o.prototype.xor = function(e) {
return this.length > e.length ? this.clone().ixor(e) : e.clone().ixor(this);
};
o.prototype.uxor = function(e) {
return this.length > e.length ? this.clone().iuxor(e) : e.clone().iuxor(this);
};
o.prototype.inotn = function(e) {
n("number" == typeof e && e >= 0);
var t = 0 | Math.ceil(e / 26), r = e % 26;
this._expand(t);
r > 0 && t--;
for (var i = 0; i < t; i++) this.words[i] = 67108863 & ~this.words[i];
r > 0 && (this.words[i] = ~this.words[i] & 67108863 >> 26 - r);
return this.strip();
};
o.prototype.notn = function(e) {
return this.clone().inotn(e);
};
o.prototype.setn = function(e, t) {
n("number" == typeof e && e >= 0);
var r = e / 26 | 0, i = e % 26;
this._expand(r + 1);
this.words[r] = t ? this.words[r] | 1 << i : this.words[r] & ~(1 << i);
return this.strip();
};
o.prototype.iadd = function(e) {
var t, r, n;
if (0 !== this.negative && 0 === e.negative) {
this.negative = 0;
t = this.isub(e);
this.negative ^= 1;
return this._normSign();
}
if (0 === this.negative && 0 !== e.negative) {
e.negative = 0;
t = this.isub(e);
e.negative = 1;
return t._normSign();
}
if (this.length > e.length) {
r = this;
n = e;
} else {
r = e;
n = this;
}
for (var i = 0, o = 0; o < n.length; o++) {
t = (0 | r.words[o]) + (0 | n.words[o]) + i;
this.words[o] = 67108863 & t;
i = t >>> 26;
}
for (;0 !== i && o < r.length; o++) {
t = (0 | r.words[o]) + i;
this.words[o] = 67108863 & t;
i = t >>> 26;
}
this.length = r.length;
if (0 !== i) {
this.words[this.length] = i;
this.length++;
} else if (r !== this) for (;o < r.length; o++) this.words[o] = r.words[o];
return this;
};
o.prototype.add = function(e) {
var t;
if (0 !== e.negative && 0 === this.negative) {
e.negative = 0;
t = this.sub(e);
e.negative ^= 1;
return t;
}
if (0 === e.negative && 0 !== this.negative) {
this.negative = 0;
t = e.sub(this);
this.negative = 1;
return t;
}
return this.length > e.length ? this.clone().iadd(e) : e.clone().iadd(this);
};
o.prototype.isub = function(e) {
if (0 !== e.negative) {
e.negative = 0;
var t = this.iadd(e);
e.negative = 1;
return t._normSign();
}
if (0 !== this.negative) {
this.negative = 0;
this.iadd(e);
this.negative = 1;
return this._normSign();
}
var r, n, i = this.cmp(e);
if (0 === i) {
this.negative = 0;
this.length = 1;
this.words[0] = 0;
return this;
}
if (i > 0) {
r = this;
n = e;
} else {
r = e;
n = this;
}
for (var o = 0, s = 0; s < n.length; s++) {
o = (t = (0 | r.words[s]) - (0 | n.words[s]) + o) >> 26;
this.words[s] = 67108863 & t;
}
for (;0 !== o && s < r.length; s++) {
o = (t = (0 | r.words[s]) + o) >> 26;
this.words[s] = 67108863 & t;
}
if (0 === o && s < r.length && r !== this) for (;s < r.length; s++) this.words[s] = r.words[s];
this.length = Math.max(this.length, s);
r !== this && (this.negative = 1);
return this.strip();
};
o.prototype.sub = function(e) {
return this.clone().isub(e);
};
function p(e, t, r) {
r.negative = t.negative ^ e.negative;
var n = e.length + t.length | 0;
r.length = n;
n = n - 1 | 0;
var i = 0 | e.words[0], o = 0 | t.words[0], s = i * o, a = 67108863 & s, f = s / 67108864 | 0;
r.words[0] = a;
for (var c = 1; c < n; c++) {
for (var u = f >>> 26, h = 67108863 & f, d = Math.min(c, t.length - 1), l = Math.max(0, c - e.length + 1); l <= d; l++) {
var p = c - l | 0;
u += (s = (i = 0 | e.words[p]) * (o = 0 | t.words[l]) + h) / 67108864 | 0;
h = 67108863 & s;
}
r.words[c] = 0 | h;
f = 0 | u;
}
0 !== f ? r.words[c] = 0 | f : r.length--;
return r.strip();
}
var b = function(e, t, r) {
var n, i, o, s = e.words, a = t.words, f = r.words, c = 0, u = 0 | s[0], h = 8191 & u, d = u >>> 13, l = 0 | s[1], p = 8191 & l, b = l >>> 13, m = 0 | s[2], v = 8191 & m, y = m >>> 13, g = 0 | s[3], _ = 8191 & g, w = g >>> 13, E = 0 | s[4], S = 8191 & E, M = E >>> 13, A = 0 | s[5], x = 8191 & A, k = A >>> 13, T = 0 | s[6], I = 8191 & T, O = T >>> 13, R = 0 | s[7], C = 8191 & R, N = R >>> 13, j = 0 | s[8], P = 8191 & j, D = j >>> 13, L = 0 | s[9], B = 8191 & L, U = L >>> 13, F = 0 | a[0], q = 8191 & F, V = F >>> 13, H = 0 | a[1], z = 8191 & H, G = H >>> 13, W = 0 | a[2], K = 8191 & W, Y = W >>> 13, X = 0 | a[3], J = 8191 & X, Z = X >>> 13, $ = 0 | a[4], Q = 8191 & $, ee = $ >>> 13, te = 0 | a[5], re = 8191 & te, ne = te >>> 13, ie = 0 | a[6], oe = 8191 & ie, se = ie >>> 13, ae = 0 | a[7], fe = 8191 & ae, ce = ae >>> 13, ue = 0 | a[8], he = 8191 & ue, de = ue >>> 13, le = 0 | a[9], pe = 8191 & le, be = le >>> 13;
r.negative = e.negative ^ t.negative;
r.length = 19;
var me = (c + (n = Math.imul(h, q)) | 0) + ((8191 & (i = (i = Math.imul(h, V)) + Math.imul(d, q) | 0)) << 13) | 0;
c = ((o = Math.imul(d, V)) + (i >>> 13) | 0) + (me >>> 26) | 0;
me &= 67108863;
n = Math.imul(p, q);
i = (i = Math.imul(p, V)) + Math.imul(b, q) | 0;
o = Math.imul(b, V);
var ve = (c + (n = n + Math.imul(h, z) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, G) | 0) + Math.imul(d, z) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, G) | 0) + (i >>> 13) | 0) + (ve >>> 26) | 0;
ve &= 67108863;
n = Math.imul(v, q);
i = (i = Math.imul(v, V)) + Math.imul(y, q) | 0;
o = Math.imul(y, V);
n = n + Math.imul(p, z) | 0;
i = (i = i + Math.imul(p, G) | 0) + Math.imul(b, z) | 0;
o = o + Math.imul(b, G) | 0;
var ye = (c + (n = n + Math.imul(h, K) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, Y) | 0) + Math.imul(d, K) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, Y) | 0) + (i >>> 13) | 0) + (ye >>> 26) | 0;
ye &= 67108863;
n = Math.imul(_, q);
i = (i = Math.imul(_, V)) + Math.imul(w, q) | 0;
o = Math.imul(w, V);
n = n + Math.imul(v, z) | 0;
i = (i = i + Math.imul(v, G) | 0) + Math.imul(y, z) | 0;
o = o + Math.imul(y, G) | 0;
n = n + Math.imul(p, K) | 0;
i = (i = i + Math.imul(p, Y) | 0) + Math.imul(b, K) | 0;
o = o + Math.imul(b, Y) | 0;
var ge = (c + (n = n + Math.imul(h, J) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, Z) | 0) + Math.imul(d, J) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, Z) | 0) + (i >>> 13) | 0) + (ge >>> 26) | 0;
ge &= 67108863;
n = Math.imul(S, q);
i = (i = Math.imul(S, V)) + Math.imul(M, q) | 0;
o = Math.imul(M, V);
n = n + Math.imul(_, z) | 0;
i = (i = i + Math.imul(_, G) | 0) + Math.imul(w, z) | 0;
o = o + Math.imul(w, G) | 0;
n = n + Math.imul(v, K) | 0;
i = (i = i + Math.imul(v, Y) | 0) + Math.imul(y, K) | 0;
o = o + Math.imul(y, Y) | 0;
n = n + Math.imul(p, J) | 0;
i = (i = i + Math.imul(p, Z) | 0) + Math.imul(b, J) | 0;
o = o + Math.imul(b, Z) | 0;
var _e = (c + (n = n + Math.imul(h, Q) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, ee) | 0) + Math.imul(d, Q) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, ee) | 0) + (i >>> 13) | 0) + (_e >>> 26) | 0;
_e &= 67108863;
n = Math.imul(x, q);
i = (i = Math.imul(x, V)) + Math.imul(k, q) | 0;
o = Math.imul(k, V);
n = n + Math.imul(S, z) | 0;
i = (i = i + Math.imul(S, G) | 0) + Math.imul(M, z) | 0;
o = o + Math.imul(M, G) | 0;
n = n + Math.imul(_, K) | 0;
i = (i = i + Math.imul(_, Y) | 0) + Math.imul(w, K) | 0;
o = o + Math.imul(w, Y) | 0;
n = n + Math.imul(v, J) | 0;
i = (i = i + Math.imul(v, Z) | 0) + Math.imul(y, J) | 0;
o = o + Math.imul(y, Z) | 0;
n = n + Math.imul(p, Q) | 0;
i = (i = i + Math.imul(p, ee) | 0) + Math.imul(b, Q) | 0;
o = o + Math.imul(b, ee) | 0;
var we = (c + (n = n + Math.imul(h, re) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, ne) | 0) + Math.imul(d, re) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, ne) | 0) + (i >>> 13) | 0) + (we >>> 26) | 0;
we &= 67108863;
n = Math.imul(I, q);
i = (i = Math.imul(I, V)) + Math.imul(O, q) | 0;
o = Math.imul(O, V);
n = n + Math.imul(x, z) | 0;
i = (i = i + Math.imul(x, G) | 0) + Math.imul(k, z) | 0;
o = o + Math.imul(k, G) | 0;
n = n + Math.imul(S, K) | 0;
i = (i = i + Math.imul(S, Y) | 0) + Math.imul(M, K) | 0;
o = o + Math.imul(M, Y) | 0;
n = n + Math.imul(_, J) | 0;
i = (i = i + Math.imul(_, Z) | 0) + Math.imul(w, J) | 0;
o = o + Math.imul(w, Z) | 0;
n = n + Math.imul(v, Q) | 0;
i = (i = i + Math.imul(v, ee) | 0) + Math.imul(y, Q) | 0;
o = o + Math.imul(y, ee) | 0;
n = n + Math.imul(p, re) | 0;
i = (i = i + Math.imul(p, ne) | 0) + Math.imul(b, re) | 0;
o = o + Math.imul(b, ne) | 0;
var Ee = (c + (n = n + Math.imul(h, oe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, se) | 0) + Math.imul(d, oe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, se) | 0) + (i >>> 13) | 0) + (Ee >>> 26) | 0;
Ee &= 67108863;
n = Math.imul(C, q);
i = (i = Math.imul(C, V)) + Math.imul(N, q) | 0;
o = Math.imul(N, V);
n = n + Math.imul(I, z) | 0;
i = (i = i + Math.imul(I, G) | 0) + Math.imul(O, z) | 0;
o = o + Math.imul(O, G) | 0;
n = n + Math.imul(x, K) | 0;
i = (i = i + Math.imul(x, Y) | 0) + Math.imul(k, K) | 0;
o = o + Math.imul(k, Y) | 0;
n = n + Math.imul(S, J) | 0;
i = (i = i + Math.imul(S, Z) | 0) + Math.imul(M, J) | 0;
o = o + Math.imul(M, Z) | 0;
n = n + Math.imul(_, Q) | 0;
i = (i = i + Math.imul(_, ee) | 0) + Math.imul(w, Q) | 0;
o = o + Math.imul(w, ee) | 0;
n = n + Math.imul(v, re) | 0;
i = (i = i + Math.imul(v, ne) | 0) + Math.imul(y, re) | 0;
o = o + Math.imul(y, ne) | 0;
n = n + Math.imul(p, oe) | 0;
i = (i = i + Math.imul(p, se) | 0) + Math.imul(b, oe) | 0;
o = o + Math.imul(b, se) | 0;
var Se = (c + (n = n + Math.imul(h, fe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, ce) | 0) + Math.imul(d, fe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, ce) | 0) + (i >>> 13) | 0) + (Se >>> 26) | 0;
Se &= 67108863;
n = Math.imul(P, q);
i = (i = Math.imul(P, V)) + Math.imul(D, q) | 0;
o = Math.imul(D, V);
n = n + Math.imul(C, z) | 0;
i = (i = i + Math.imul(C, G) | 0) + Math.imul(N, z) | 0;
o = o + Math.imul(N, G) | 0;
n = n + Math.imul(I, K) | 0;
i = (i = i + Math.imul(I, Y) | 0) + Math.imul(O, K) | 0;
o = o + Math.imul(O, Y) | 0;
n = n + Math.imul(x, J) | 0;
i = (i = i + Math.imul(x, Z) | 0) + Math.imul(k, J) | 0;
o = o + Math.imul(k, Z) | 0;
n = n + Math.imul(S, Q) | 0;
i = (i = i + Math.imul(S, ee) | 0) + Math.imul(M, Q) | 0;
o = o + Math.imul(M, ee) | 0;
n = n + Math.imul(_, re) | 0;
i = (i = i + Math.imul(_, ne) | 0) + Math.imul(w, re) | 0;
o = o + Math.imul(w, ne) | 0;
n = n + Math.imul(v, oe) | 0;
i = (i = i + Math.imul(v, se) | 0) + Math.imul(y, oe) | 0;
o = o + Math.imul(y, se) | 0;
n = n + Math.imul(p, fe) | 0;
i = (i = i + Math.imul(p, ce) | 0) + Math.imul(b, fe) | 0;
o = o + Math.imul(b, ce) | 0;
var Me = (c + (n = n + Math.imul(h, he) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, de) | 0) + Math.imul(d, he) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, de) | 0) + (i >>> 13) | 0) + (Me >>> 26) | 0;
Me &= 67108863;
n = Math.imul(B, q);
i = (i = Math.imul(B, V)) + Math.imul(U, q) | 0;
o = Math.imul(U, V);
n = n + Math.imul(P, z) | 0;
i = (i = i + Math.imul(P, G) | 0) + Math.imul(D, z) | 0;
o = o + Math.imul(D, G) | 0;
n = n + Math.imul(C, K) | 0;
i = (i = i + Math.imul(C, Y) | 0) + Math.imul(N, K) | 0;
o = o + Math.imul(N, Y) | 0;
n = n + Math.imul(I, J) | 0;
i = (i = i + Math.imul(I, Z) | 0) + Math.imul(O, J) | 0;
o = o + Math.imul(O, Z) | 0;
n = n + Math.imul(x, Q) | 0;
i = (i = i + Math.imul(x, ee) | 0) + Math.imul(k, Q) | 0;
o = o + Math.imul(k, ee) | 0;
n = n + Math.imul(S, re) | 0;
i = (i = i + Math.imul(S, ne) | 0) + Math.imul(M, re) | 0;
o = o + Math.imul(M, ne) | 0;
n = n + Math.imul(_, oe) | 0;
i = (i = i + Math.imul(_, se) | 0) + Math.imul(w, oe) | 0;
o = o + Math.imul(w, se) | 0;
n = n + Math.imul(v, fe) | 0;
i = (i = i + Math.imul(v, ce) | 0) + Math.imul(y, fe) | 0;
o = o + Math.imul(y, ce) | 0;
n = n + Math.imul(p, he) | 0;
i = (i = i + Math.imul(p, de) | 0) + Math.imul(b, he) | 0;
o = o + Math.imul(b, de) | 0;
var Ae = (c + (n = n + Math.imul(h, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, be) | 0) + Math.imul(d, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, be) | 0) + (i >>> 13) | 0) + (Ae >>> 26) | 0;
Ae &= 67108863;
n = Math.imul(B, z);
i = (i = Math.imul(B, G)) + Math.imul(U, z) | 0;
o = Math.imul(U, G);
n = n + Math.imul(P, K) | 0;
i = (i = i + Math.imul(P, Y) | 0) + Math.imul(D, K) | 0;
o = o + Math.imul(D, Y) | 0;
n = n + Math.imul(C, J) | 0;
i = (i = i + Math.imul(C, Z) | 0) + Math.imul(N, J) | 0;
o = o + Math.imul(N, Z) | 0;
n = n + Math.imul(I, Q) | 0;
i = (i = i + Math.imul(I, ee) | 0) + Math.imul(O, Q) | 0;
o = o + Math.imul(O, ee) | 0;
n = n + Math.imul(x, re) | 0;
i = (i = i + Math.imul(x, ne) | 0) + Math.imul(k, re) | 0;
o = o + Math.imul(k, ne) | 0;
n = n + Math.imul(S, oe) | 0;
i = (i = i + Math.imul(S, se) | 0) + Math.imul(M, oe) | 0;
o = o + Math.imul(M, se) | 0;
n = n + Math.imul(_, fe) | 0;
i = (i = i + Math.imul(_, ce) | 0) + Math.imul(w, fe) | 0;
o = o + Math.imul(w, ce) | 0;
n = n + Math.imul(v, he) | 0;
i = (i = i + Math.imul(v, de) | 0) + Math.imul(y, he) | 0;
o = o + Math.imul(y, de) | 0;
var xe = (c + (n = n + Math.imul(p, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(p, be) | 0) + Math.imul(b, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(b, be) | 0) + (i >>> 13) | 0) + (xe >>> 26) | 0;
xe &= 67108863;
n = Math.imul(B, K);
i = (i = Math.imul(B, Y)) + Math.imul(U, K) | 0;
o = Math.imul(U, Y);
n = n + Math.imul(P, J) | 0;
i = (i = i + Math.imul(P, Z) | 0) + Math.imul(D, J) | 0;
o = o + Math.imul(D, Z) | 0;
n = n + Math.imul(C, Q) | 0;
i = (i = i + Math.imul(C, ee) | 0) + Math.imul(N, Q) | 0;
o = o + Math.imul(N, ee) | 0;
n = n + Math.imul(I, re) | 0;
i = (i = i + Math.imul(I, ne) | 0) + Math.imul(O, re) | 0;
o = o + Math.imul(O, ne) | 0;
n = n + Math.imul(x, oe) | 0;
i = (i = i + Math.imul(x, se) | 0) + Math.imul(k, oe) | 0;
o = o + Math.imul(k, se) | 0;
n = n + Math.imul(S, fe) | 0;
i = (i = i + Math.imul(S, ce) | 0) + Math.imul(M, fe) | 0;
o = o + Math.imul(M, ce) | 0;
n = n + Math.imul(_, he) | 0;
i = (i = i + Math.imul(_, de) | 0) + Math.imul(w, he) | 0;
o = o + Math.imul(w, de) | 0;
var ke = (c + (n = n + Math.imul(v, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(v, be) | 0) + Math.imul(y, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(y, be) | 0) + (i >>> 13) | 0) + (ke >>> 26) | 0;
ke &= 67108863;
n = Math.imul(B, J);
i = (i = Math.imul(B, Z)) + Math.imul(U, J) | 0;
o = Math.imul(U, Z);
n = n + Math.imul(P, Q) | 0;
i = (i = i + Math.imul(P, ee) | 0) + Math.imul(D, Q) | 0;
o = o + Math.imul(D, ee) | 0;
n = n + Math.imul(C, re) | 0;
i = (i = i + Math.imul(C, ne) | 0) + Math.imul(N, re) | 0;
o = o + Math.imul(N, ne) | 0;
n = n + Math.imul(I, oe) | 0;
i = (i = i + Math.imul(I, se) | 0) + Math.imul(O, oe) | 0;
o = o + Math.imul(O, se) | 0;
n = n + Math.imul(x, fe) | 0;
i = (i = i + Math.imul(x, ce) | 0) + Math.imul(k, fe) | 0;
o = o + Math.imul(k, ce) | 0;
n = n + Math.imul(S, he) | 0;
i = (i = i + Math.imul(S, de) | 0) + Math.imul(M, he) | 0;
o = o + Math.imul(M, de) | 0;
var Te = (c + (n = n + Math.imul(_, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(_, be) | 0) + Math.imul(w, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(w, be) | 0) + (i >>> 13) | 0) + (Te >>> 26) | 0;
Te &= 67108863;
n = Math.imul(B, Q);
i = (i = Math.imul(B, ee)) + Math.imul(U, Q) | 0;
o = Math.imul(U, ee);
n = n + Math.imul(P, re) | 0;
i = (i = i + Math.imul(P, ne) | 0) + Math.imul(D, re) | 0;
o = o + Math.imul(D, ne) | 0;
n = n + Math.imul(C, oe) | 0;
i = (i = i + Math.imul(C, se) | 0) + Math.imul(N, oe) | 0;
o = o + Math.imul(N, se) | 0;
n = n + Math.imul(I, fe) | 0;
i = (i = i + Math.imul(I, ce) | 0) + Math.imul(O, fe) | 0;
o = o + Math.imul(O, ce) | 0;
n = n + Math.imul(x, he) | 0;
i = (i = i + Math.imul(x, de) | 0) + Math.imul(k, he) | 0;
o = o + Math.imul(k, de) | 0;
var Ie = (c + (n = n + Math.imul(S, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(S, be) | 0) + Math.imul(M, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(M, be) | 0) + (i >>> 13) | 0) + (Ie >>> 26) | 0;
Ie &= 67108863;
n = Math.imul(B, re);
i = (i = Math.imul(B, ne)) + Math.imul(U, re) | 0;
o = Math.imul(U, ne);
n = n + Math.imul(P, oe) | 0;
i = (i = i + Math.imul(P, se) | 0) + Math.imul(D, oe) | 0;
o = o + Math.imul(D, se) | 0;
n = n + Math.imul(C, fe) | 0;
i = (i = i + Math.imul(C, ce) | 0) + Math.imul(N, fe) | 0;
o = o + Math.imul(N, ce) | 0;
n = n + Math.imul(I, he) | 0;
i = (i = i + Math.imul(I, de) | 0) + Math.imul(O, he) | 0;
o = o + Math.imul(O, de) | 0;
var Oe = (c + (n = n + Math.imul(x, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(x, be) | 0) + Math.imul(k, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(k, be) | 0) + (i >>> 13) | 0) + (Oe >>> 26) | 0;
Oe &= 67108863;
n = Math.imul(B, oe);
i = (i = Math.imul(B, se)) + Math.imul(U, oe) | 0;
o = Math.imul(U, se);
n = n + Math.imul(P, fe) | 0;
i = (i = i + Math.imul(P, ce) | 0) + Math.imul(D, fe) | 0;
o = o + Math.imul(D, ce) | 0;
n = n + Math.imul(C, he) | 0;
i = (i = i + Math.imul(C, de) | 0) + Math.imul(N, he) | 0;
o = o + Math.imul(N, de) | 0;
var Re = (c + (n = n + Math.imul(I, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(I, be) | 0) + Math.imul(O, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(O, be) | 0) + (i >>> 13) | 0) + (Re >>> 26) | 0;
Re &= 67108863;
n = Math.imul(B, fe);
i = (i = Math.imul(B, ce)) + Math.imul(U, fe) | 0;
o = Math.imul(U, ce);
n = n + Math.imul(P, he) | 0;
i = (i = i + Math.imul(P, de) | 0) + Math.imul(D, he) | 0;
o = o + Math.imul(D, de) | 0;
var Ce = (c + (n = n + Math.imul(C, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(C, be) | 0) + Math.imul(N, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(N, be) | 0) + (i >>> 13) | 0) + (Ce >>> 26) | 0;
Ce &= 67108863;
n = Math.imul(B, he);
i = (i = Math.imul(B, de)) + Math.imul(U, he) | 0;
o = Math.imul(U, de);
var Ne = (c + (n = n + Math.imul(P, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(P, be) | 0) + Math.imul(D, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(D, be) | 0) + (i >>> 13) | 0) + (Ne >>> 26) | 0;
Ne &= 67108863;
var je = (c + (n = Math.imul(B, pe)) | 0) + ((8191 & (i = (i = Math.imul(B, be)) + Math.imul(U, pe) | 0)) << 13) | 0;
c = ((o = Math.imul(U, be)) + (i >>> 13) | 0) + (je >>> 26) | 0;
je &= 67108863;
f[0] = me;
f[1] = ve;
f[2] = ye;
f[3] = ge;
f[4] = _e;
f[5] = we;
f[6] = Ee;
f[7] = Se;
f[8] = Me;
f[9] = Ae;
f[10] = xe;
f[11] = ke;
f[12] = Te;
f[13] = Ie;
f[14] = Oe;
f[15] = Re;
f[16] = Ce;
f[17] = Ne;
f[18] = je;
if (0 !== c) {
f[19] = c;
r.length++;
}
return r;
};
Math.imul || (b = p);
function m(e, t, r) {
r.negative = t.negative ^ e.negative;
r.length = e.length + t.length;
for (var n = 0, i = 0, o = 0; o < r.length - 1; o++) {
var s = i;
i = 0;
for (var a = 67108863 & n, f = Math.min(o, t.length - 1), c = Math.max(0, o - e.length + 1); c <= f; c++) {
var u = o - c, h = (0 | e.words[u]) * (0 | t.words[c]), d = 67108863 & h;
a = 67108863 & (d = d + a | 0);
i += (s = (s = s + (h / 67108864 | 0) | 0) + (d >>> 26) | 0) >>> 26;
s &= 67108863;
}
r.words[o] = a;
n = s;
s = i;
}
0 !== n ? r.words[o] = n : r.length--;
return r.strip();
}
function v(e, t, r) {
return new y().mulp(e, t, r);
}
o.prototype.mulTo = function(e, t) {
var r = this.length + e.length;
return 10 === this.length && 10 === e.length ? b(this, e, t) : r < 63 ? p(this, e, t) : r < 1024 ? m(this, e, t) : v(this, e, t);
};
function y(e, t) {
this.x = e;
this.y = t;
}
y.prototype.makeRBT = function(e) {
for (var t = new Array(e), r = o.prototype._countBits(e) - 1, n = 0; n < e; n++) t[n] = this.revBin(n, r, e);
return t;
};
y.prototype.revBin = function(e, t, r) {
if (0 === e || e === r - 1) return e;
for (var n = 0, i = 0; i < t; i++) {
n |= (1 & e) << t - i - 1;
e >>= 1;
}
return n;
};
y.prototype.permute = function(e, t, r, n, i, o) {
for (var s = 0; s < o; s++) {
n[s] = t[e[s]];
i[s] = r[e[s]];
}
};
y.prototype.transform = function(e, t, r, n, i, o) {
this.permute(o, e, t, r, n, i);
for (var s = 1; s < i; s <<= 1) for (var a = s << 1, f = Math.cos(2 * Math.PI / a), c = Math.sin(2 * Math.PI / a), u = 0; u < i; u += a) for (var h = f, d = c, l = 0; l < s; l++) {
var p = r[u + l], b = n[u + l], m = r[u + l + s], v = n[u + l + s], y = h * m - d * v;
v = h * v + d * m;
m = y;
r[u + l] = p + m;
n[u + l] = b + v;
r[u + l + s] = p - m;
n[u + l + s] = b - v;
if (l !== a) {
y = f * h - c * d;
d = f * d + c * h;
h = y;
}
}
};
y.prototype.guessLen13b = function(e, t) {
var r = 1 | Math.max(t, e), n = 1 & r, i = 0;
for (r = r / 2 | 0; r; r >>>= 1) i++;
return 1 << i + 1 + n;
};
y.prototype.conjugate = function(e, t, r) {
if (!(r <= 1)) for (var n = 0; n < r / 2; n++) {
var i = e[n];
e[n] = e[r - n - 1];
e[r - n - 1] = i;
i = t[n];
t[n] = -t[r - n - 1];
t[r - n - 1] = -i;
}
};
y.prototype.normalize13b = function(e, t) {
for (var r = 0, n = 0; n < t / 2; n++) {
var i = 8192 * Math.round(e[2 * n + 1] / t) + Math.round(e[2 * n] / t) + r;
e[n] = 67108863 & i;
r = i < 67108864 ? 0 : i / 67108864 | 0;
}
return e;
};
y.prototype.convert13b = function(e, t, r, i) {
for (var o = 0, s = 0; s < t; s++) {
o += 0 | e[s];
r[2 * s] = 8191 & o;
o >>>= 13;
r[2 * s + 1] = 8191 & o;
o >>>= 13;
}
for (s = 2 * t; s < i; ++s) r[s] = 0;
n(0 === o);
n(0 == (-8192 & o));
};
y.prototype.stub = function(e) {
for (var t = new Array(e), r = 0; r < e; r++) t[r] = 0;
return t;
};
y.prototype.mulp = function(e, t, r) {
var n = 2 * this.guessLen13b(e.length, t.length), i = this.makeRBT(n), o = this.stub(n), s = new Array(n), a = new Array(n), f = new Array(n), c = new Array(n), u = new Array(n), h = new Array(n), d = r.words;
d.length = n;
this.convert13b(e.words, e.length, s, n);
this.convert13b(t.words, t.length, c, n);
this.transform(s, o, a, f, n, i);
this.transform(c, o, u, h, n, i);
for (var l = 0; l < n; l++) {
var p = a[l] * u[l] - f[l] * h[l];
f[l] = a[l] * h[l] + f[l] * u[l];
a[l] = p;
}
this.conjugate(a, f, n);
this.transform(a, f, d, o, n, i);
this.conjugate(d, o, n);
this.normalize13b(d, n);
r.negative = e.negative ^ t.negative;
r.length = e.length + t.length;
return r.strip();
};
o.prototype.mul = function(e) {
var t = new o(null);
t.words = new Array(this.length + e.length);
return this.mulTo(e, t);
};
o.prototype.mulf = function(e) {
var t = new o(null);
t.words = new Array(this.length + e.length);
return v(this, e, t);
};
o.prototype.imul = function(e) {
return this.clone().mulTo(e, this);
};
o.prototype.imuln = function(e) {
n("number" == typeof e);
n(e < 67108864);
for (var t = 0, r = 0; r < this.length; r++) {
var i = (0 | this.words[r]) * e, o = (67108863 & i) + (67108863 & t);
t >>= 26;
t += i / 67108864 | 0;
t += o >>> 26;
this.words[r] = 67108863 & o;
}
if (0 !== t) {
this.words[r] = t;
this.length++;
}
return this;
};
o.prototype.muln = function(e) {
return this.clone().imuln(e);
};
o.prototype.sqr = function() {
return this.mul(this);
};
o.prototype.isqr = function() {
return this.imul(this.clone());
};
o.prototype.pow = function(e) {
var t = l(e);
if (0 === t.length) return new o(1);
for (var r = this, n = 0; n < t.length && 0 === t[n]; n++, r = r.sqr()) ;
if (++n < t.length) for (var i = r.sqr(); n < t.length; n++, i = i.sqr()) 0 !== t[n] && (r = r.mul(i));
return r;
};
o.prototype.iushln = function(e) {
n("number" == typeof e && e >= 0);
var t, r = e % 26, i = (e - r) / 26, o = 67108863 >>> 26 - r << 26 - r;
if (0 !== r) {
var s = 0;
for (t = 0; t < this.length; t++) {
var a = this.words[t] & o, f = (0 | this.words[t]) - a << r;
this.words[t] = f | s;
s = a >>> 26 - r;
}
if (s) {
this.words[t] = s;
this.length++;
}
}
if (0 !== i) {
for (t = this.length - 1; t >= 0; t--) this.words[t + i] = this.words[t];
for (t = 0; t < i; t++) this.words[t] = 0;
this.length += i;
}
return this.strip();
};
o.prototype.ishln = function(e) {
n(0 === this.negative);
return this.iushln(e);
};
o.prototype.iushrn = function(e, t, r) {
n("number" == typeof e && e >= 0);
var i;
i = t ? (t - t % 26) / 26 : 0;
var o = e % 26, s = Math.min((e - o) / 26, this.length), a = 67108863 ^ 67108863 >>> o << o, f = r;
i -= s;
i = Math.max(0, i);
if (f) {
for (var c = 0; c < s; c++) f.words[c] = this.words[c];
f.length = s;
}
if (0 === s) ; else if (this.length > s) {
this.length -= s;
for (c = 0; c < this.length; c++) this.words[c] = this.words[c + s];
} else {
this.words[0] = 0;
this.length = 1;
}
var u = 0;
for (c = this.length - 1; c >= 0 && (0 !== u || c >= i); c--) {
var h = 0 | this.words[c];
this.words[c] = u << 26 - o | h >>> o;
u = h & a;
}
f && 0 !== u && (f.words[f.length++] = u);
if (0 === this.length) {
this.words[0] = 0;
this.length = 1;
}
return this.strip();
};
o.prototype.ishrn = function(e, t, r) {
n(0 === this.negative);
return this.iushrn(e, t, r);
};
o.prototype.shln = function(e) {
return this.clone().ishln(e);
};
o.prototype.ushln = function(e) {
return this.clone().iushln(e);
};
o.prototype.shrn = function(e) {
return this.clone().ishrn(e);
};
o.prototype.ushrn = function(e) {
return this.clone().iushrn(e);
};
o.prototype.testn = function(e) {
n("number" == typeof e && e >= 0);
var t = e % 26, r = (e - t) / 26, i = 1 << t;
return !(this.length <= r || !(this.words[r] & i));
};
o.prototype.imaskn = function(e) {
n("number" == typeof e && e >= 0);
var t = e % 26, r = (e - t) / 26;
n(0 === this.negative, "imaskn works only with positive numbers");
if (this.length <= r) return this;
0 !== t && r++;
this.length = Math.min(r, this.length);
if (0 !== t) {
var i = 67108863 ^ 67108863 >>> t << t;
this.words[this.length - 1] &= i;
}
return this.strip();
};
o.prototype.maskn = function(e) {
return this.clone().imaskn(e);
};
o.prototype.iaddn = function(e) {
n("number" == typeof e);
n(e < 67108864);
if (e < 0) return this.isubn(-e);
if (0 !== this.negative) {
if (1 === this.length && (0 | this.words[0]) < e) {
this.words[0] = e - (0 | this.words[0]);
this.negative = 0;
return this;
}
this.negative = 0;
this.isubn(e);
this.negative = 1;
return this;
}
return this._iaddn(e);
};
o.prototype._iaddn = function(e) {
this.words[0] += e;
for (var t = 0; t < this.length && this.words[t] >= 67108864; t++) {
this.words[t] -= 67108864;
t === this.length - 1 ? this.words[t + 1] = 1 : this.words[t + 1]++;
}
this.length = Math.max(this.length, t + 1);
return this;
};
o.prototype.isubn = function(e) {
n("number" == typeof e);
n(e < 67108864);
if (e < 0) return this.iaddn(-e);
if (0 !== this.negative) {
this.negative = 0;
this.iaddn(e);
this.negative = 1;
return this;
}
this.words[0] -= e;
if (1 === this.length && this.words[0] < 0) {
this.words[0] = -this.words[0];
this.negative = 1;
} else for (var t = 0; t < this.length && this.words[t] < 0; t++) {
this.words[t] += 67108864;
this.words[t + 1] -= 1;
}
return this.strip();
};
o.prototype.addn = function(e) {
return this.clone().iaddn(e);
};
o.prototype.subn = function(e) {
return this.clone().isubn(e);
};
o.prototype.iabs = function() {
this.negative = 0;
return this;
};
o.prototype.abs = function() {
return this.clone().iabs();
};
o.prototype._ishlnsubmul = function(e, t, r) {
var i, o, s = e.length + r;
this._expand(s);
var a = 0;
for (i = 0; i < e.length; i++) {
o = (0 | this.words[i + r]) + a;
var f = (0 | e.words[i]) * t;
a = ((o -= 67108863 & f) >> 26) - (f / 67108864 | 0);
this.words[i + r] = 67108863 & o;
}
for (;i < this.length - r; i++) {
a = (o = (0 | this.words[i + r]) + a) >> 26;
this.words[i + r] = 67108863 & o;
}
if (0 === a) return this.strip();
n(-1 === a);
a = 0;
for (i = 0; i < this.length; i++) {
a = (o = -(0 | this.words[i]) + a) >> 26;
this.words[i] = 67108863 & o;
}
this.negative = 1;
return this.strip();
};
o.prototype._wordDiv = function(e, t) {
var r = (this.length, e.length), n = this.clone(), i = e, s = 0 | i.words[i.length - 1];
if (0 != (r = 26 - this._countBits(s))) {
i = i.ushln(r);
n.iushln(r);
s = 0 | i.words[i.length - 1];
}
var a, f = n.length - i.length;
if ("mod" !== t) {
(a = new o(null)).length = f + 1;
a.words = new Array(a.length);
for (var c = 0; c < a.length; c++) a.words[c] = 0;
}
var u = n.clone()._ishlnsubmul(i, 1, f);
if (0 === u.negative) {
n = u;
a && (a.words[f] = 1);
}
for (var h = f - 1; h >= 0; h--) {
var d = 67108864 * (0 | n.words[i.length + h]) + (0 | n.words[i.length + h - 1]);
d = Math.min(d / s | 0, 67108863);
n._ishlnsubmul(i, d, h);
for (;0 !== n.negative; ) {
d--;
n.negative = 0;
n._ishlnsubmul(i, 1, h);
n.isZero() || (n.negative ^= 1);
}
a && (a.words[h] = d);
}
a && a.strip();
n.strip();
"div" !== t && 0 !== r && n.iushrn(r);
return {
div: a || null,
mod: n
};
};
o.prototype.divmod = function(e, t, r) {
n(!e.isZero());
if (this.isZero()) return {
div: new o(0),
mod: new o(0)
};
var i, s, a;
if (0 !== this.negative && 0 === e.negative) {
a = this.neg().divmod(e, t);
"mod" !== t && (i = a.div.neg());
if ("div" !== t) {
s = a.mod.neg();
r && 0 !== s.negative && s.iadd(e);
}
return {
div: i,
mod: s
};
}
if (0 === this.negative && 0 !== e.negative) {
a = this.divmod(e.neg(), t);
"mod" !== t && (i = a.div.neg());
return {
div: i,
mod: a.mod
};
}
if (0 != (this.negative & e.negative)) {
a = this.neg().divmod(e.neg(), t);
if ("div" !== t) {
s = a.mod.neg();
r && 0 !== s.negative && s.isub(e);
}
return {
div: a.div,
mod: s
};
}
return e.length > this.length || this.cmp(e) < 0 ? {
div: new o(0),
mod: this
} : 1 === e.length ? "div" === t ? {
div: this.divn(e.words[0]),
mod: null
} : "mod" === t ? {
div: null,
mod: new o(this.modn(e.words[0]))
} : {
div: this.divn(e.words[0]),
mod: new o(this.modn(e.words[0]))
} : this._wordDiv(e, t);
};
o.prototype.div = function(e) {
return this.divmod(e, "div", !1).div;
};
o.prototype.mod = function(e) {
return this.divmod(e, "mod", !1).mod;
};
o.prototype.umod = function(e) {
return this.divmod(e, "mod", !0).mod;
};
o.prototype.divRound = function(e) {
var t = this.divmod(e);
if (t.mod.isZero()) return t.div;
var r = 0 !== t.div.negative ? t.mod.isub(e) : t.mod, n = e.ushrn(1), i = e.andln(1), o = r.cmp(n);
return o < 0 || 1 === i && 0 === o ? t.div : 0 !== t.div.negative ? t.div.isubn(1) : t.div.iaddn(1);
};
o.prototype.modn = function(e) {
n(e <= 67108863);
for (var t = (1 << 26) % e, r = 0, i = this.length - 1; i >= 0; i--) r = (t * r + (0 | this.words[i])) % e;
return r;
};
o.prototype.idivn = function(e) {
n(e <= 67108863);
for (var t = 0, r = this.length - 1; r >= 0; r--) {
var i = (0 | this.words[r]) + 67108864 * t;
this.words[r] = i / e | 0;
t = i % e;
}
return this.strip();
};
o.prototype.divn = function(e) {
return this.clone().idivn(e);
};
o.prototype.egcd = function(e) {
n(0 === e.negative);
n(!e.isZero());
var t = this, r = e.clone();
t = 0 !== t.negative ? t.umod(e) : t.clone();
for (var i = new o(1), s = new o(0), a = new o(0), f = new o(1), c = 0; t.isEven() && r.isEven(); ) {
t.iushrn(1);
r.iushrn(1);
++c;
}
for (var u = r.clone(), h = t.clone(); !t.isZero(); ) {
for (var d = 0, l = 1; 0 == (t.words[0] & l) && d < 26; ++d, l <<= 1) ;
if (d > 0) {
t.iushrn(d);
for (;d-- > 0; ) {
if (i.isOdd() || s.isOdd()) {
i.iadd(u);
s.isub(h);
}
i.iushrn(1);
s.iushrn(1);
}
}
for (var p = 0, b = 1; 0 == (r.words[0] & b) && p < 26; ++p, b <<= 1) ;
if (p > 0) {
r.iushrn(p);
for (;p-- > 0; ) {
if (a.isOdd() || f.isOdd()) {
a.iadd(u);
f.isub(h);
}
a.iushrn(1);
f.iushrn(1);
}
}
if (t.cmp(r) >= 0) {
t.isub(r);
i.isub(a);
s.isub(f);
} else {
r.isub(t);
a.isub(i);
f.isub(s);
}
}
return {
a: a,
b: f,
gcd: r.iushln(c)
};
};
o.prototype._invmp = function(e) {
n(0 === e.negative);
n(!e.isZero());
var t = this, r = e.clone();
t = 0 !== t.negative ? t.umod(e) : t.clone();
for (var i, s = new o(1), a = new o(0), f = r.clone(); t.cmpn(1) > 0 && r.cmpn(1) > 0; ) {
for (var c = 0, u = 1; 0 == (t.words[0] & u) && c < 26; ++c, u <<= 1) ;
if (c > 0) {
t.iushrn(c);
for (;c-- > 0; ) {
s.isOdd() && s.iadd(f);
s.iushrn(1);
}
}
for (var h = 0, d = 1; 0 == (r.words[0] & d) && h < 26; ++h, d <<= 1) ;
if (h > 0) {
r.iushrn(h);
for (;h-- > 0; ) {
a.isOdd() && a.iadd(f);
a.iushrn(1);
}
}
if (t.cmp(r) >= 0) {
t.isub(r);
s.isub(a);
} else {
r.isub(t);
a.isub(s);
}
}
(i = 0 === t.cmpn(1) ? s : a).cmpn(0) < 0 && i.iadd(e);
return i;
};
o.prototype.gcd = function(e) {
if (this.isZero()) return e.abs();
if (e.isZero()) return this.abs();
var t = this.clone(), r = e.clone();
t.negative = 0;
r.negative = 0;
for (var n = 0; t.isEven() && r.isEven(); n++) {
t.iushrn(1);
r.iushrn(1);
}
for (;;) {
for (;t.isEven(); ) t.iushrn(1);
for (;r.isEven(); ) r.iushrn(1);
var i = t.cmp(r);
if (i < 0) {
var o = t;
t = r;
r = o;
} else if (0 === i || 0 === r.cmpn(1)) break;
t.isub(r);
}
return r.iushln(n);
};
o.prototype.invm = function(e) {
return this.egcd(e).a.umod(e);
};
o.prototype.isEven = function() {
return 0 == (1 & this.words[0]);
};
o.prototype.isOdd = function() {
return 1 == (1 & this.words[0]);
};
o.prototype.andln = function(e) {
return this.words[0] & e;
};
o.prototype.bincn = function(e) {
n("number" == typeof e);
var t = e % 26, r = (e - t) / 26, i = 1 << t;
if (this.length <= r) {
this._expand(r + 1);
this.words[r] |= i;
return this;
}
for (var o = i, s = r; 0 !== o && s < this.length; s++) {
var a = 0 | this.words[s];
o = (a += o) >>> 26;
a &= 67108863;
this.words[s] = a;
}
if (0 !== o) {
this.words[s] = o;
this.length++;
}
return this;
};
o.prototype.isZero = function() {
return 1 === this.length && 0 === this.words[0];
};
o.prototype.cmpn = function(e) {
var t, r = e < 0;
if (0 !== this.negative && !r) return -1;
if (0 === this.negative && r) return 1;
this.strip();
if (this.length > 1) t = 1; else {
r && (e = -e);
n(e <= 67108863, "Number is too big");
var i = 0 | this.words[0];
t = i === e ? 0 : i < e ? -1 : 1;
}
return 0 !== this.negative ? 0 | -t : t;
};
o.prototype.cmp = function(e) {
if (0 !== this.negative && 0 === e.negative) return -1;
if (0 === this.negative && 0 !== e.negative) return 1;
var t = this.ucmp(e);
return 0 !== this.negative ? 0 | -t : t;
};
o.prototype.ucmp = function(e) {
if (this.length > e.length) return 1;
if (this.length < e.length) return -1;
for (var t = 0, r = this.length - 1; r >= 0; r--) {
var n = 0 | this.words[r], i = 0 | e.words[r];
if (n !== i) {
n < i ? t = -1 : n > i && (t = 1);
break;
}
}
return t;
};
o.prototype.gtn = function(e) {
return 1 === this.cmpn(e);
};
o.prototype.gt = function(e) {
return 1 === this.cmp(e);
};
o.prototype.gten = function(e) {
return this.cmpn(e) >= 0;
};
o.prototype.gte = function(e) {
return this.cmp(e) >= 0;
};
o.prototype.ltn = function(e) {
return -1 === this.cmpn(e);
};
o.prototype.lt = function(e) {
return -1 === this.cmp(e);
};
o.prototype.lten = function(e) {
return this.cmpn(e) <= 0;
};
o.prototype.lte = function(e) {
return this.cmp(e) <= 0;
};
o.prototype.eqn = function(e) {
return 0 === this.cmpn(e);
};
o.prototype.eq = function(e) {
return 0 === this.cmp(e);
};
o.red = function(e) {
return new A(e);
};
o.prototype.toRed = function(e) {
n(!this.red, "Already a number in reduction context");
n(0 === this.negative, "red works only with positives");
return e.convertTo(this)._forceRed(e);
};
o.prototype.fromRed = function() {
n(this.red, "fromRed works only with numbers in reduction context");
return this.red.convertFrom(this);
};
o.prototype._forceRed = function(e) {
this.red = e;
return this;
};
o.prototype.forceRed = function(e) {
n(!this.red, "Already a number in reduction context");
return this._forceRed(e);
};
o.prototype.redAdd = function(e) {
n(this.red, "redAdd works only with red numbers");
return this.red.add(this, e);
};
o.prototype.redIAdd = function(e) {
n(this.red, "redIAdd works only with red numbers");
return this.red.iadd(this, e);
};
o.prototype.redSub = function(e) {
n(this.red, "redSub works only with red numbers");
return this.red.sub(this, e);
};
o.prototype.redISub = function(e) {
n(this.red, "redISub works only with red numbers");
return this.red.isub(this, e);
};
o.prototype.redShl = function(e) {
n(this.red, "redShl works only with red numbers");
return this.red.shl(this, e);
};
o.prototype.redMul = function(e) {
n(this.red, "redMul works only with red numbers");
this.red._verify2(this, e);
return this.red.mul(this, e);
};
o.prototype.redIMul = function(e) {
n(this.red, "redMul works only with red numbers");
this.red._verify2(this, e);
return this.red.imul(this, e);
};
o.prototype.redSqr = function() {
n(this.red, "redSqr works only with red numbers");
this.red._verify1(this);
return this.red.sqr(this);
};
o.prototype.redISqr = function() {
n(this.red, "redISqr works only with red numbers");
this.red._verify1(this);
return this.red.isqr(this);
};
o.prototype.redSqrt = function() {
n(this.red, "redSqrt works only with red numbers");
this.red._verify1(this);
return this.red.sqrt(this);
};
o.prototype.redInvm = function() {
n(this.red, "redInvm works only with red numbers");
this.red._verify1(this);
return this.red.invm(this);
};
o.prototype.redNeg = function() {
n(this.red, "redNeg works only with red numbers");
this.red._verify1(this);
return this.red.neg(this);
};
o.prototype.redPow = function(e) {
n(this.red && !e.red, "redPow(normalNum)");
this.red._verify1(this);
return this.red.pow(this, e);
};
var g = {
k256: null,
p224: null,
p192: null,
p25519: null
};
function _(e, t) {
this.name = e;
this.p = new o(t, 16);
this.n = this.p.bitLength();
this.k = new o(1).iushln(this.n).isub(this.p);
this.tmp = this._tmp();
}
_.prototype._tmp = function() {
var e = new o(null);
e.words = new Array(Math.ceil(this.n / 13));
return e;
};
_.prototype.ireduce = function(e) {
var t, r = e;
do {
this.split(r, this.tmp);
t = (r = (r = this.imulK(r)).iadd(this.tmp)).bitLength();
} while (t > this.n);
var n = t < this.n ? -1 : r.ucmp(this.p);
if (0 === n) {
r.words[0] = 0;
r.length = 1;
} else n > 0 ? r.isub(this.p) : void 0 !== r.strip ? r.strip() : r._strip();
return r;
};
_.prototype.split = function(e, t) {
e.iushrn(this.n, 0, t);
};
_.prototype.imulK = function(e) {
return e.imul(this.k);
};
function w() {
_.call(this, "k256", "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe fffffc2f");
}
i(w, _);
w.prototype.split = function(e, t) {
for (var r = Math.min(e.length, 9), n = 0; n < r; n++) t.words[n] = e.words[n];
t.length = r;
if (e.length <= 9) {
e.words[0] = 0;
e.length = 1;
} else {
var i = e.words[9];
t.words[t.length++] = 4194303 & i;
for (n = 10; n < e.length; n++) {
var o = 0 | e.words[n];
e.words[n - 10] = (4194303 & o) << 4 | i >>> 22;
i = o;
}
i >>>= 22;
e.words[n - 10] = i;
0 === i && e.length > 10 ? e.length -= 10 : e.length -= 9;
}
};
w.prototype.imulK = function(e) {
e.words[e.length] = 0;
e.words[e.length + 1] = 0;
e.length += 2;
for (var t = 0, r = 0; r < e.length; r++) {
var n = 0 | e.words[r];
t += 977 * n;
e.words[r] = 67108863 & t;
t = 64 * n + (t / 67108864 | 0);
}
if (0 === e.words[e.length - 1]) {
e.length--;
0 === e.words[e.length - 1] && e.length--;
}
return e;
};
function E() {
_.call(this, "p224", "ffffffff ffffffff ffffffff ffffffff 00000000 00000000 00000001");
}
i(E, _);
function S() {
_.call(this, "p192", "ffffffff ffffffff ffffffff fffffffe ffffffff ffffffff");
}
i(S, _);
function M() {
_.call(this, "25519", "7fffffffffffffff ffffffffffffffff ffffffffffffffff ffffffffffffffed");
}
i(M, _);
M.prototype.imulK = function(e) {
for (var t = 0, r = 0; r < e.length; r++) {
var n = 19 * (0 | e.words[r]) + t, i = 67108863 & n;
n >>>= 26;
e.words[r] = i;
t = n;
}
0 !== t && (e.words[e.length++] = t);
return e;
};
o._prime = function(e) {
if (g[e]) return g[e];
var t;
if ("k256" === e) t = new w(); else if ("p224" === e) t = new E(); else if ("p192" === e) t = new S(); else {
if ("p25519" !== e) throw new Error("Unknown prime " + e);
t = new M();
}
g[e] = t;
return t;
};
function A(e) {
if ("string" == typeof e) {
var t = o._prime(e);
this.m = t.p;
this.prime = t;
} else {
n(e.gtn(1), "modulus must be greater than 1");
this.m = e;
this.prime = null;
}
}
A.prototype._verify1 = function(e) {
n(0 === e.negative, "red works only with positives");
n(e.red, "red works only with red numbers");
};
A.prototype._verify2 = function(e, t) {
n(0 == (e.negative | t.negative), "red works only with positives");
n(e.red && e.red === t.red, "red works only with red numbers");
};
A.prototype.imod = function(e) {
return this.prime ? this.prime.ireduce(e)._forceRed(this) : e.umod(this.m)._forceRed(this);
};
A.prototype.neg = function(e) {
return e.isZero() ? e.clone() : this.m.sub(e)._forceRed(this);
};
A.prototype.add = function(e, t) {
this._verify2(e, t);
var r = e.add(t);
r.cmp(this.m) >= 0 && r.isub(this.m);
return r._forceRed(this);
};
A.prototype.iadd = function(e, t) {
this._verify2(e, t);
var r = e.iadd(t);
r.cmp(this.m) >= 0 && r.isub(this.m);
return r;
};
A.prototype.sub = function(e, t) {
this._verify2(e, t);
var r = e.sub(t);
r.cmpn(0) < 0 && r.iadd(this.m);
return r._forceRed(this);
};
A.prototype.isub = function(e, t) {
this._verify2(e, t);
var r = e.isub(t);
r.cmpn(0) < 0 && r.iadd(this.m);
return r;
};
A.prototype.shl = function(e, t) {
this._verify1(e);
return this.imod(e.ushln(t));
};
A.prototype.imul = function(e, t) {
this._verify2(e, t);
return this.imod(e.imul(t));
};
A.prototype.mul = function(e, t) {
this._verify2(e, t);
return this.imod(e.mul(t));
};
A.prototype.isqr = function(e) {
return this.imul(e, e.clone());
};
A.prototype.sqr = function(e) {
return this.mul(e, e);
};
A.prototype.sqrt = function(e) {
if (e.isZero()) return e.clone();
var t = this.m.andln(3);
n(t % 2 == 1);
if (3 === t) {
var r = this.m.add(new o(1)).iushrn(2);
return this.pow(e, r);
}
for (var i = this.m.subn(1), s = 0; !i.isZero() && 0 === i.andln(1); ) {
s++;
i.iushrn(1);
}
n(!i.isZero());
var a = new o(1).toRed(this), f = a.redNeg(), c = this.m.subn(1).iushrn(1), u = this.m.bitLength();
u = new o(2 * u * u).toRed(this);
for (;0 !== this.pow(u, c).cmp(f); ) u.redIAdd(f);
for (var h = this.pow(u, i), d = this.pow(e, i.addn(1).iushrn(1)), l = this.pow(e, i), p = s; 0 !== l.cmp(a); ) {
for (var b = l, m = 0; 0 !== b.cmp(a); m++) b = b.redSqr();
n(m < p);
var v = this.pow(h, new o(1).iushln(p - m - 1));
d = d.redMul(v);
h = v.redSqr();
l = l.redMul(h);
p = m;
}
return d;
};
A.prototype.invm = function(e) {
var t = e._invmp(this.m);
if (0 !== t.negative) {
t.negative = 0;
return this.imod(t).redNeg();
}
return this.imod(t);
};
A.prototype.pow = function(e, t) {
if (t.isZero()) return new o(1).toRed(this);
if (0 === t.cmpn(1)) return e.clone();
var r = new Array(16);
r[0] = new o(1).toRed(this);
r[1] = e;
for (var n = 2; n < r.length; n++) r[n] = this.mul(r[n - 1], e);
var i = r[0], s = 0, a = 0, f = t.bitLength() % 26;
0 === f && (f = 26);
for (n = t.length - 1; n >= 0; n--) {
for (var c = t.words[n], u = f - 1; u >= 0; u--) {
var h = c >> u & 1;
i !== r[0] && (i = this.sqr(i));
if (0 !== h || 0 !== s) {
s <<= 1;
s |= h;
if (4 == ++a || 0 === n && 0 === u) {
i = this.mul(i, r[s]);
a = 0;
s = 0;
}
} else a = 0;
}
f = 26;
}
return i;
};
A.prototype.convertTo = function(e) {
var t = e.umod(this.m);
return t === e ? t.clone() : t;
};
A.prototype.convertFrom = function(e) {
var t = e.clone();
t.red = null;
return t;
};
o.mont = function(e) {
return new x(e);
};
function x(e) {
A.call(this, e);
this.shift = this.m.bitLength();
this.shift % 26 != 0 && (this.shift += 26 - this.shift % 26);
this.r = new o(1).iushln(this.shift);
this.r2 = this.imod(this.r.sqr());
this.rinv = this.r._invmp(this.m);
this.minv = this.rinv.mul(this.r).isubn(1).div(this.m);
this.minv = this.minv.umod(this.r);
this.minv = this.r.sub(this.minv);
}
i(x, A);
x.prototype.convertTo = function(e) {
return this.imod(e.ushln(this.shift));
};
x.prototype.convertFrom = function(e) {
var t = this.imod(e.mul(this.rinv));
t.red = null;
return t;
};
x.prototype.imul = function(e, t) {
if (e.isZero() || t.isZero()) {
e.words[0] = 0;
e.length = 1;
return e;
}
var r = e.imul(t), n = r.maskn(this.shift).mul(this.minv).imaskn(this.shift).mul(this.m), i = r.isub(n).iushrn(this.shift), o = i;
i.cmp(this.m) >= 0 ? o = i.isub(this.m) : i.cmpn(0) < 0 && (o = i.iadd(this.m));
return o._forceRed(this);
};
x.prototype.mul = function(e, t) {
if (e.isZero() || t.isZero()) return new o(0)._forceRed(this);
var r = e.mul(t), n = r.maskn(this.shift).mul(this.minv).imaskn(this.shift).mul(this.m), i = r.isub(n).iushrn(this.shift), s = i;
i.cmp(this.m) >= 0 ? s = i.isub(this.m) : i.cmpn(0) < 0 && (s = i.iadd(this.m));
return s._forceRed(this);
};
x.prototype.invm = function(e) {
return this.imod(e._invmp(this.m).mul(this.r2))._forceRed(this);
};
})("undefined" == typeof t || t, this);
}, {
buffer: 19
} ],
16: [ function(e, t, r) {
"use strict";
r.byteLength = function(e) {
var t = c(e), r = t[0], n = t[1];
return 3 * (r + n) / 4 - n;
};
r.toByteArray = function(e) {
var t, r, n = c(e), s = n[0], a = n[1], f = new o(u(0, s, a)), h = 0, d = a > 0 ? s - 4 : s;
for (r = 0; r < d; r += 4) {
t = i[e.charCodeAt(r)] << 18 | i[e.charCodeAt(r + 1)] << 12 | i[e.charCodeAt(r + 2)] << 6 | i[e.charCodeAt(r + 3)];
f[h++] = t >> 16 & 255;
f[h++] = t >> 8 & 255;
f[h++] = 255 & t;
}
if (2 === a) {
t = i[e.charCodeAt(r)] << 2 | i[e.charCodeAt(r + 1)] >> 4;
f[h++] = 255 & t;
}
if (1 === a) {
t = i[e.charCodeAt(r)] << 10 | i[e.charCodeAt(r + 1)] << 4 | i[e.charCodeAt(r + 2)] >> 2;
f[h++] = t >> 8 & 255;
f[h++] = 255 & t;
}
return f;
};
r.fromByteArray = function(e) {
for (var t, r = e.length, i = r % 3, o = [], s = 0, a = r - i; s < a; s += 16383) o.push(h(e, s, s + 16383 > a ? a : s + 16383));
if (1 === i) {
t = e[r - 1];
o.push(n[t >> 2] + n[t << 4 & 63] + "==");
} else if (2 === i) {
t = (e[r - 2] << 8) + e[r - 1];
o.push(n[t >> 10] + n[t >> 4 & 63] + n[t << 2 & 63] + "=");
}
return o.join("");
};
for (var n = [], i = [], o = "undefined" != typeof Uint8Array ? Uint8Array : Array, s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", a = 0, f = s.length; a < f; ++a) {
n[a] = s[a];
i[s.charCodeAt(a)] = a;
}
i["-".charCodeAt(0)] = 62;
i["_".charCodeAt(0)] = 63;
function c(e) {
var t = e.length;
if (t % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
var r = e.indexOf("=");
-1 === r && (r = t);
return [ r, r === t ? 0 : 4 - r % 4 ];
}
function u(e, t, r) {
return 3 * (t + r) / 4 - r;
}
function h(e, t, r) {
for (var i, o, s = [], a = t; a < r; a += 3) {
i = (e[a] << 16 & 16711680) + (e[a + 1] << 8 & 65280) + (255 & e[a + 2]);
s.push(n[(o = i) >> 18 & 63] + n[o >> 12 & 63] + n[o >> 6 & 63] + n[63 & o]);
}
return s.join("");
}
}, {} ],
17: [ function(e, t) {
(function(t, r) {
"use strict";
function n(e, t) {
if (!e) throw new Error(t || "Assertion failed");
}
function i(e, t) {
e.super_ = t;
var r = function() {};
r.prototype = t.prototype;
e.prototype = new r();
e.prototype.constructor = e;
}
function o(e, t, r) {
if (o.isBN(e)) return e;
this.negative = 0;
this.words = null;
this.length = 0;
this.red = null;
if (null !== e) {
if ("le" === t || "be" === t) {
r = t;
t = 10;
}
this._init(e || 0, t || 10, r || "be");
}
}
"object" == typeof t ? t.exports = o : r.BN = o;
o.BN = o;
o.wordSize = 26;
var s;
try {
s = "undefined" != typeof window && "undefined" != typeof window.Buffer ? window.Buffer : e("buffer").Buffer;
} catch (e) {}
o.isBN = function(e) {
return e instanceof o || null !== e && "object" == typeof e && e.constructor.wordSize === o.wordSize && Array.isArray(e.words);
};
o.max = function(e, t) {
return e.cmp(t) > 0 ? e : t;
};
o.min = function(e, t) {
return e.cmp(t) < 0 ? e : t;
};
o.prototype._init = function(e, t, r) {
if ("number" == typeof e) return this._initNumber(e, t, r);
if ("object" == typeof e) return this._initArray(e, t, r);
"hex" === t && (t = 16);
n(t === (0 | t) && t >= 2 && t <= 36);
var i = 0;
if ("-" === (e = e.toString().replace(/\s+/g, ""))[0]) {
i++;
this.negative = 1;
}
if (i < e.length) if (16 === t) this._parseHex(e, i, r); else {
this._parseBase(e, t, i);
"le" === r && this._initArray(this.toArray(), t, r);
}
};
o.prototype._initNumber = function(e, t, r) {
if (e < 0) {
this.negative = 1;
e = -e;
}
if (e < 67108864) {
this.words = [ 67108863 & e ];
this.length = 1;
} else if (e < 4503599627370496) {
this.words = [ 67108863 & e, e / 67108864 & 67108863 ];
this.length = 2;
} else {
n(e < 9007199254740992);
this.words = [ 67108863 & e, e / 67108864 & 67108863, 1 ];
this.length = 3;
}
"le" === r && this._initArray(this.toArray(), t, r);
};
o.prototype._initArray = function(e, t, r) {
n("number" == typeof e.length);
if (e.length <= 0) {
this.words = [ 0 ];
this.length = 1;
return this;
}
this.length = Math.ceil(e.length / 3);
this.words = new Array(this.length);
for (var i = 0; i < this.length; i++) this.words[i] = 0;
var o, s, a = 0;
if ("be" === r) for (i = e.length - 1, o = 0; i >= 0; i -= 3) {
s = e[i] | e[i - 1] << 8 | e[i - 2] << 16;
this.words[o] |= s << a & 67108863;
this.words[o + 1] = s >>> 26 - a & 67108863;
if ((a += 24) >= 26) {
a -= 26;
o++;
}
} else if ("le" === r) for (i = 0, o = 0; i < e.length; i += 3) {
s = e[i] | e[i + 1] << 8 | e[i + 2] << 16;
this.words[o] |= s << a & 67108863;
this.words[o + 1] = s >>> 26 - a & 67108863;
if ((a += 24) >= 26) {
a -= 26;
o++;
}
}
return this._strip();
};
function a(e, t) {
var r = e.charCodeAt(t);
if (r >= 48 && r <= 57) return r - 48;
if (r >= 65 && r <= 70) return r - 55;
if (r >= 97 && r <= 102) return r - 87;
n(!1, "Invalid character in " + e);
}
function f(e, t, r) {
var n = a(e, r);
r - 1 >= t && (n |= a(e, r - 1) << 4);
return n;
}
o.prototype._parseHex = function(e, t, r) {
this.length = Math.ceil((e.length - t) / 6);
this.words = new Array(this.length);
for (var n = 0; n < this.length; n++) this.words[n] = 0;
var i, o = 0, s = 0;
if ("be" === r) for (n = e.length - 1; n >= t; n -= 2) {
i = f(e, t, n) << o;
this.words[s] |= 67108863 & i;
if (o >= 18) {
o -= 18;
s += 1;
this.words[s] |= i >>> 26;
} else o += 8;
} else for (n = (e.length - t) % 2 == 0 ? t + 1 : t; n < e.length; n += 2) {
i = f(e, t, n) << o;
this.words[s] |= 67108863 & i;
if (o >= 18) {
o -= 18;
s += 1;
this.words[s] |= i >>> 26;
} else o += 8;
}
this._strip();
};
function c(e, t, r, i) {
for (var o = 0, s = 0, a = Math.min(e.length, r), f = t; f < a; f++) {
var c = e.charCodeAt(f) - 48;
o *= i;
s = c >= 49 ? c - 49 + 10 : c >= 17 ? c - 17 + 10 : c;
n(c >= 0 && s < i, "Invalid character");
o += s;
}
return o;
}
o.prototype._parseBase = function(e, t, r) {
this.words = [ 0 ];
this.length = 1;
for (var n = 0, i = 1; i <= 67108863; i *= t) n++;
n--;
i = i / t | 0;
for (var o = e.length - r, s = o % n, a = Math.min(o, o - s) + r, f = 0, u = r; u < a; u += n) {
f = c(e, u, u + n, t);
this.imuln(i);
this.words[0] + f < 67108864 ? this.words[0] += f : this._iaddn(f);
}
if (0 !== s) {
var h = 1;
f = c(e, u, e.length, t);
for (u = 0; u < s; u++) h *= t;
this.imuln(h);
this.words[0] + f < 67108864 ? this.words[0] += f : this._iaddn(f);
}
this._strip();
};
o.prototype.copy = function(e) {
e.words = new Array(this.length);
for (var t = 0; t < this.length; t++) e.words[t] = this.words[t];
e.length = this.length;
e.negative = this.negative;
e.red = this.red;
};
function u(e, t) {
e.words = t.words;
e.length = t.length;
e.negative = t.negative;
e.red = t.red;
}
o.prototype._move = function(e) {
u(e, this);
};
o.prototype.clone = function() {
var e = new o(null);
this.copy(e);
return e;
};
o.prototype._expand = function(e) {
for (;this.length < e; ) this.words[this.length++] = 0;
return this;
};
o.prototype._strip = function() {
for (;this.length > 1 && 0 === this.words[this.length - 1]; ) this.length--;
return this._normSign();
};
o.prototype._normSign = function() {
1 === this.length && 0 === this.words[0] && (this.negative = 0);
return this;
};
if ("undefined" != typeof Symbol && "function" == typeof Symbol.for) try {
o.prototype[Symbol.for("nodejs.util.inspect.custom")] = h;
} catch (e) {
o.prototype.inspect = h;
} else o.prototype.inspect = h;
function h() {
return (this.red ? "<BN-R: " : "<BN: ") + this.toString(16) + ">";
}
var d = [ "", "0", "00", "000", "0000", "00000", "000000", "0000000", "00000000", "000000000", "0000000000", "00000000000", "000000000000", "0000000000000", "00000000000000", "000000000000000", "0000000000000000", "00000000000000000", "000000000000000000", "0000000000000000000", "00000000000000000000", "000000000000000000000", "0000000000000000000000", "00000000000000000000000", "000000000000000000000000", "0000000000000000000000000" ], l = [ 0, 0, 25, 16, 12, 11, 10, 9, 8, 8, 7, 7, 7, 7, 6, 6, 6, 6, 6, 6, 6, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5 ], p = [ 0, 0, 33554432, 43046721, 16777216, 48828125, 60466176, 40353607, 16777216, 43046721, 1e7, 19487171, 35831808, 62748517, 7529536, 11390625, 16777216, 24137569, 34012224, 47045881, 64e6, 4084101, 5153632, 6436343, 7962624, 9765625, 11881376, 14348907, 17210368, 20511149, 243e5, 28629151, 33554432, 39135393, 45435424, 52521875, 60466176 ];
o.prototype.toString = function(e, t) {
t = 0 | t || 1;
var r;
if (16 === (e = e || 10) || "hex" === e) {
r = "";
for (var i = 0, o = 0, s = 0; s < this.length; s++) {
var a = this.words[s], f = (16777215 & (a << i | o)).toString(16);
r = 0 != (o = a >>> 24 - i & 16777215) || s !== this.length - 1 ? d[6 - f.length] + f + r : f + r;
if ((i += 2) >= 26) {
i -= 26;
s--;
}
}
0 !== o && (r = o.toString(16) + r);
for (;r.length % t != 0; ) r = "0" + r;
0 !== this.negative && (r = "-" + r);
return r;
}
if (e === (0 | e) && e >= 2 && e <= 36) {
var c = l[e], u = p[e];
r = "";
var h = this.clone();
h.negative = 0;
for (;!h.isZero(); ) {
var b = h.modrn(u).toString(e);
r = (h = h.idivn(u)).isZero() ? b + r : d[c - b.length] + b + r;
}
this.isZero() && (r = "0" + r);
for (;r.length % t != 0; ) r = "0" + r;
0 !== this.negative && (r = "-" + r);
return r;
}
n(!1, "Base should be between 2 and 36");
};
o.prototype.toNumber = function() {
var e = this.words[0];
2 === this.length ? e += 67108864 * this.words[1] : 3 === this.length && 1 === this.words[2] ? e += 4503599627370496 + 67108864 * this.words[1] : this.length > 2 && n(!1, "Number can only safely store up to 53 bits");
return 0 !== this.negative ? -e : e;
};
o.prototype.toJSON = function() {
return this.toString(16, 2);
};
s && (o.prototype.toBuffer = function(e, t) {
return this.toArrayLike(s, e, t);
});
o.prototype.toArray = function(e, t) {
return this.toArrayLike(Array, e, t);
};
var b = function(e, t) {
return e.allocUnsafe ? e.allocUnsafe(t) : new e(t);
};
o.prototype.toArrayLike = function(e, t, r) {
this._strip();
var i = this.byteLength(), o = r || Math.max(1, i);
n(i <= o, "byte array longer than desired length");
n(o > 0, "Requested array length <= 0");
var s = b(e, o);
this["_toArrayLike" + ("le" === t ? "LE" : "BE")](s, i);
return s;
};
o.prototype._toArrayLikeLE = function(e) {
for (var t = 0, r = 0, n = 0, i = 0; n < this.length; n++) {
var o = this.words[n] << i | r;
e[t++] = 255 & o;
t < e.length && (e[t++] = o >> 8 & 255);
t < e.length && (e[t++] = o >> 16 & 255);
if (6 === i) {
t < e.length && (e[t++] = o >> 24 & 255);
r = 0;
i = 0;
} else {
r = o >>> 24;
i += 2;
}
}
if (t < e.length) {
e[t++] = r;
for (;t < e.length; ) e[t++] = 0;
}
};
o.prototype._toArrayLikeBE = function(e) {
for (var t = e.length - 1, r = 0, n = 0, i = 0; n < this.length; n++) {
var o = this.words[n] << i | r;
e[t--] = 255 & o;
t >= 0 && (e[t--] = o >> 8 & 255);
t >= 0 && (e[t--] = o >> 16 & 255);
if (6 === i) {
t >= 0 && (e[t--] = o >> 24 & 255);
r = 0;
i = 0;
} else {
r = o >>> 24;
i += 2;
}
}
if (t >= 0) {
e[t--] = r;
for (;t >= 0; ) e[t--] = 0;
}
};
Math.clz32 ? o.prototype._countBits = function(e) {
return 32 - Math.clz32(e);
} : o.prototype._countBits = function(e) {
var t = e, r = 0;
if (t >= 4096) {
r += 13;
t >>>= 13;
}
if (t >= 64) {
r += 7;
t >>>= 7;
}
if (t >= 8) {
r += 4;
t >>>= 4;
}
if (t >= 2) {
r += 2;
t >>>= 2;
}
return r + t;
};
o.prototype._zeroBits = function(e) {
if (0 === e) return 26;
var t = e, r = 0;
if (0 == (8191 & t)) {
r += 13;
t >>>= 13;
}
if (0 == (127 & t)) {
r += 7;
t >>>= 7;
}
if (0 == (15 & t)) {
r += 4;
t >>>= 4;
}
if (0 == (3 & t)) {
r += 2;
t >>>= 2;
}
0 == (1 & t) && r++;
return r;
};
o.prototype.bitLength = function() {
var e = this.words[this.length - 1], t = this._countBits(e);
return 26 * (this.length - 1) + t;
};
function m(e) {
for (var t = new Array(e.bitLength()), r = 0; r < t.length; r++) {
var n = r / 26 | 0, i = r % 26;
t[r] = e.words[n] >>> i & 1;
}
return t;
}
o.prototype.zeroBits = function() {
if (this.isZero()) return 0;
for (var e = 0, t = 0; t < this.length; t++) {
var r = this._zeroBits(this.words[t]);
e += r;
if (26 !== r) break;
}
return e;
};
o.prototype.byteLength = function() {
return Math.ceil(this.bitLength() / 8);
};
o.prototype.toTwos = function(e) {
return 0 !== this.negative ? this.abs().inotn(e).iaddn(1) : this.clone();
};
o.prototype.fromTwos = function(e) {
return this.testn(e - 1) ? this.notn(e).iaddn(1).ineg() : this.clone();
};
o.prototype.isNeg = function() {
return 0 !== this.negative;
};
o.prototype.neg = function() {
return this.clone().ineg();
};
o.prototype.ineg = function() {
this.isZero() || (this.negative ^= 1);
return this;
};
o.prototype.iuor = function(e) {
for (;this.length < e.length; ) this.words[this.length++] = 0;
for (var t = 0; t < e.length; t++) this.words[t] = this.words[t] | e.words[t];
return this._strip();
};
o.prototype.ior = function(e) {
n(0 == (this.negative | e.negative));
return this.iuor(e);
};
o.prototype.or = function(e) {
return this.length > e.length ? this.clone().ior(e) : e.clone().ior(this);
};
o.prototype.uor = function(e) {
return this.length > e.length ? this.clone().iuor(e) : e.clone().iuor(this);
};
o.prototype.iuand = function(e) {
var t;
t = this.length > e.length ? e : this;
for (var r = 0; r < t.length; r++) this.words[r] = this.words[r] & e.words[r];
this.length = t.length;
return this._strip();
};
o.prototype.iand = function(e) {
n(0 == (this.negative | e.negative));
return this.iuand(e);
};
o.prototype.and = function(e) {
return this.length > e.length ? this.clone().iand(e) : e.clone().iand(this);
};
o.prototype.uand = function(e) {
return this.length > e.length ? this.clone().iuand(e) : e.clone().iuand(this);
};
o.prototype.iuxor = function(e) {
var t, r;
if (this.length > e.length) {
t = this;
r = e;
} else {
t = e;
r = this;
}
for (var n = 0; n < r.length; n++) this.words[n] = t.words[n] ^ r.words[n];
if (this !== t) for (;n < t.length; n++) this.words[n] = t.words[n];
this.length = t.length;
return this._strip();
};
o.prototype.ixor = function(e) {
n(0 == (this.negative | e.negative));
return this.iuxor(e);
};
o.prototype.xor = function(e) {
return this.length > e.length ? this.clone().ixor(e) : e.clone().ixor(this);
};
o.prototype.uxor = function(e) {
return this.length > e.length ? this.clone().iuxor(e) : e.clone().iuxor(this);
};
o.prototype.inotn = function(e) {
n("number" == typeof e && e >= 0);
var t = 0 | Math.ceil(e / 26), r = e % 26;
this._expand(t);
r > 0 && t--;
for (var i = 0; i < t; i++) this.words[i] = 67108863 & ~this.words[i];
r > 0 && (this.words[i] = ~this.words[i] & 67108863 >> 26 - r);
return this._strip();
};
o.prototype.notn = function(e) {
return this.clone().inotn(e);
};
o.prototype.setn = function(e, t) {
n("number" == typeof e && e >= 0);
var r = e / 26 | 0, i = e % 26;
this._expand(r + 1);
this.words[r] = t ? this.words[r] | 1 << i : this.words[r] & ~(1 << i);
return this._strip();
};
o.prototype.iadd = function(e) {
var t, r, n;
if (0 !== this.negative && 0 === e.negative) {
this.negative = 0;
t = this.isub(e);
this.negative ^= 1;
return this._normSign();
}
if (0 === this.negative && 0 !== e.negative) {
e.negative = 0;
t = this.isub(e);
e.negative = 1;
return t._normSign();
}
if (this.length > e.length) {
r = this;
n = e;
} else {
r = e;
n = this;
}
for (var i = 0, o = 0; o < n.length; o++) {
t = (0 | r.words[o]) + (0 | n.words[o]) + i;
this.words[o] = 67108863 & t;
i = t >>> 26;
}
for (;0 !== i && o < r.length; o++) {
t = (0 | r.words[o]) + i;
this.words[o] = 67108863 & t;
i = t >>> 26;
}
this.length = r.length;
if (0 !== i) {
this.words[this.length] = i;
this.length++;
} else if (r !== this) for (;o < r.length; o++) this.words[o] = r.words[o];
return this;
};
o.prototype.add = function(e) {
var t;
if (0 !== e.negative && 0 === this.negative) {
e.negative = 0;
t = this.sub(e);
e.negative ^= 1;
return t;
}
if (0 === e.negative && 0 !== this.negative) {
this.negative = 0;
t = e.sub(this);
this.negative = 1;
return t;
}
return this.length > e.length ? this.clone().iadd(e) : e.clone().iadd(this);
};
o.prototype.isub = function(e) {
if (0 !== e.negative) {
e.negative = 0;
var t = this.iadd(e);
e.negative = 1;
return t._normSign();
}
if (0 !== this.negative) {
this.negative = 0;
this.iadd(e);
this.negative = 1;
return this._normSign();
}
var r, n, i = this.cmp(e);
if (0 === i) {
this.negative = 0;
this.length = 1;
this.words[0] = 0;
return this;
}
if (i > 0) {
r = this;
n = e;
} else {
r = e;
n = this;
}
for (var o = 0, s = 0; s < n.length; s++) {
o = (t = (0 | r.words[s]) - (0 | n.words[s]) + o) >> 26;
this.words[s] = 67108863 & t;
}
for (;0 !== o && s < r.length; s++) {
o = (t = (0 | r.words[s]) + o) >> 26;
this.words[s] = 67108863 & t;
}
if (0 === o && s < r.length && r !== this) for (;s < r.length; s++) this.words[s] = r.words[s];
this.length = Math.max(this.length, s);
r !== this && (this.negative = 1);
return this._strip();
};
o.prototype.sub = function(e) {
return this.clone().isub(e);
};
function v(e, t, r) {
r.negative = t.negative ^ e.negative;
var n = e.length + t.length | 0;
r.length = n;
n = n - 1 | 0;
var i = 0 | e.words[0], o = 0 | t.words[0], s = i * o, a = 67108863 & s, f = s / 67108864 | 0;
r.words[0] = a;
for (var c = 1; c < n; c++) {
for (var u = f >>> 26, h = 67108863 & f, d = Math.min(c, t.length - 1), l = Math.max(0, c - e.length + 1); l <= d; l++) {
var p = c - l | 0;
u += (s = (i = 0 | e.words[p]) * (o = 0 | t.words[l]) + h) / 67108864 | 0;
h = 67108863 & s;
}
r.words[c] = 0 | h;
f = 0 | u;
}
0 !== f ? r.words[c] = 0 | f : r.length--;
return r._strip();
}
var y = function(e, t, r) {
var n, i, o, s = e.words, a = t.words, f = r.words, c = 0, u = 0 | s[0], h = 8191 & u, d = u >>> 13, l = 0 | s[1], p = 8191 & l, b = l >>> 13, m = 0 | s[2], v = 8191 & m, y = m >>> 13, g = 0 | s[3], _ = 8191 & g, w = g >>> 13, E = 0 | s[4], S = 8191 & E, M = E >>> 13, A = 0 | s[5], x = 8191 & A, k = A >>> 13, T = 0 | s[6], I = 8191 & T, O = T >>> 13, R = 0 | s[7], C = 8191 & R, N = R >>> 13, j = 0 | s[8], P = 8191 & j, D = j >>> 13, L = 0 | s[9], B = 8191 & L, U = L >>> 13, F = 0 | a[0], q = 8191 & F, V = F >>> 13, H = 0 | a[1], z = 8191 & H, G = H >>> 13, W = 0 | a[2], K = 8191 & W, Y = W >>> 13, X = 0 | a[3], J = 8191 & X, Z = X >>> 13, $ = 0 | a[4], Q = 8191 & $, ee = $ >>> 13, te = 0 | a[5], re = 8191 & te, ne = te >>> 13, ie = 0 | a[6], oe = 8191 & ie, se = ie >>> 13, ae = 0 | a[7], fe = 8191 & ae, ce = ae >>> 13, ue = 0 | a[8], he = 8191 & ue, de = ue >>> 13, le = 0 | a[9], pe = 8191 & le, be = le >>> 13;
r.negative = e.negative ^ t.negative;
r.length = 19;
var me = (c + (n = Math.imul(h, q)) | 0) + ((8191 & (i = (i = Math.imul(h, V)) + Math.imul(d, q) | 0)) << 13) | 0;
c = ((o = Math.imul(d, V)) + (i >>> 13) | 0) + (me >>> 26) | 0;
me &= 67108863;
n = Math.imul(p, q);
i = (i = Math.imul(p, V)) + Math.imul(b, q) | 0;
o = Math.imul(b, V);
var ve = (c + (n = n + Math.imul(h, z) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, G) | 0) + Math.imul(d, z) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, G) | 0) + (i >>> 13) | 0) + (ve >>> 26) | 0;
ve &= 67108863;
n = Math.imul(v, q);
i = (i = Math.imul(v, V)) + Math.imul(y, q) | 0;
o = Math.imul(y, V);
n = n + Math.imul(p, z) | 0;
i = (i = i + Math.imul(p, G) | 0) + Math.imul(b, z) | 0;
o = o + Math.imul(b, G) | 0;
var ye = (c + (n = n + Math.imul(h, K) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, Y) | 0) + Math.imul(d, K) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, Y) | 0) + (i >>> 13) | 0) + (ye >>> 26) | 0;
ye &= 67108863;
n = Math.imul(_, q);
i = (i = Math.imul(_, V)) + Math.imul(w, q) | 0;
o = Math.imul(w, V);
n = n + Math.imul(v, z) | 0;
i = (i = i + Math.imul(v, G) | 0) + Math.imul(y, z) | 0;
o = o + Math.imul(y, G) | 0;
n = n + Math.imul(p, K) | 0;
i = (i = i + Math.imul(p, Y) | 0) + Math.imul(b, K) | 0;
o = o + Math.imul(b, Y) | 0;
var ge = (c + (n = n + Math.imul(h, J) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, Z) | 0) + Math.imul(d, J) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, Z) | 0) + (i >>> 13) | 0) + (ge >>> 26) | 0;
ge &= 67108863;
n = Math.imul(S, q);
i = (i = Math.imul(S, V)) + Math.imul(M, q) | 0;
o = Math.imul(M, V);
n = n + Math.imul(_, z) | 0;
i = (i = i + Math.imul(_, G) | 0) + Math.imul(w, z) | 0;
o = o + Math.imul(w, G) | 0;
n = n + Math.imul(v, K) | 0;
i = (i = i + Math.imul(v, Y) | 0) + Math.imul(y, K) | 0;
o = o + Math.imul(y, Y) | 0;
n = n + Math.imul(p, J) | 0;
i = (i = i + Math.imul(p, Z) | 0) + Math.imul(b, J) | 0;
o = o + Math.imul(b, Z) | 0;
var _e = (c + (n = n + Math.imul(h, Q) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, ee) | 0) + Math.imul(d, Q) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, ee) | 0) + (i >>> 13) | 0) + (_e >>> 26) | 0;
_e &= 67108863;
n = Math.imul(x, q);
i = (i = Math.imul(x, V)) + Math.imul(k, q) | 0;
o = Math.imul(k, V);
n = n + Math.imul(S, z) | 0;
i = (i = i + Math.imul(S, G) | 0) + Math.imul(M, z) | 0;
o = o + Math.imul(M, G) | 0;
n = n + Math.imul(_, K) | 0;
i = (i = i + Math.imul(_, Y) | 0) + Math.imul(w, K) | 0;
o = o + Math.imul(w, Y) | 0;
n = n + Math.imul(v, J) | 0;
i = (i = i + Math.imul(v, Z) | 0) + Math.imul(y, J) | 0;
o = o + Math.imul(y, Z) | 0;
n = n + Math.imul(p, Q) | 0;
i = (i = i + Math.imul(p, ee) | 0) + Math.imul(b, Q) | 0;
o = o + Math.imul(b, ee) | 0;
var we = (c + (n = n + Math.imul(h, re) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, ne) | 0) + Math.imul(d, re) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, ne) | 0) + (i >>> 13) | 0) + (we >>> 26) | 0;
we &= 67108863;
n = Math.imul(I, q);
i = (i = Math.imul(I, V)) + Math.imul(O, q) | 0;
o = Math.imul(O, V);
n = n + Math.imul(x, z) | 0;
i = (i = i + Math.imul(x, G) | 0) + Math.imul(k, z) | 0;
o = o + Math.imul(k, G) | 0;
n = n + Math.imul(S, K) | 0;
i = (i = i + Math.imul(S, Y) | 0) + Math.imul(M, K) | 0;
o = o + Math.imul(M, Y) | 0;
n = n + Math.imul(_, J) | 0;
i = (i = i + Math.imul(_, Z) | 0) + Math.imul(w, J) | 0;
o = o + Math.imul(w, Z) | 0;
n = n + Math.imul(v, Q) | 0;
i = (i = i + Math.imul(v, ee) | 0) + Math.imul(y, Q) | 0;
o = o + Math.imul(y, ee) | 0;
n = n + Math.imul(p, re) | 0;
i = (i = i + Math.imul(p, ne) | 0) + Math.imul(b, re) | 0;
o = o + Math.imul(b, ne) | 0;
var Ee = (c + (n = n + Math.imul(h, oe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, se) | 0) + Math.imul(d, oe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, se) | 0) + (i >>> 13) | 0) + (Ee >>> 26) | 0;
Ee &= 67108863;
n = Math.imul(C, q);
i = (i = Math.imul(C, V)) + Math.imul(N, q) | 0;
o = Math.imul(N, V);
n = n + Math.imul(I, z) | 0;
i = (i = i + Math.imul(I, G) | 0) + Math.imul(O, z) | 0;
o = o + Math.imul(O, G) | 0;
n = n + Math.imul(x, K) | 0;
i = (i = i + Math.imul(x, Y) | 0) + Math.imul(k, K) | 0;
o = o + Math.imul(k, Y) | 0;
n = n + Math.imul(S, J) | 0;
i = (i = i + Math.imul(S, Z) | 0) + Math.imul(M, J) | 0;
o = o + Math.imul(M, Z) | 0;
n = n + Math.imul(_, Q) | 0;
i = (i = i + Math.imul(_, ee) | 0) + Math.imul(w, Q) | 0;
o = o + Math.imul(w, ee) | 0;
n = n + Math.imul(v, re) | 0;
i = (i = i + Math.imul(v, ne) | 0) + Math.imul(y, re) | 0;
o = o + Math.imul(y, ne) | 0;
n = n + Math.imul(p, oe) | 0;
i = (i = i + Math.imul(p, se) | 0) + Math.imul(b, oe) | 0;
o = o + Math.imul(b, se) | 0;
var Se = (c + (n = n + Math.imul(h, fe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, ce) | 0) + Math.imul(d, fe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, ce) | 0) + (i >>> 13) | 0) + (Se >>> 26) | 0;
Se &= 67108863;
n = Math.imul(P, q);
i = (i = Math.imul(P, V)) + Math.imul(D, q) | 0;
o = Math.imul(D, V);
n = n + Math.imul(C, z) | 0;
i = (i = i + Math.imul(C, G) | 0) + Math.imul(N, z) | 0;
o = o + Math.imul(N, G) | 0;
n = n + Math.imul(I, K) | 0;
i = (i = i + Math.imul(I, Y) | 0) + Math.imul(O, K) | 0;
o = o + Math.imul(O, Y) | 0;
n = n + Math.imul(x, J) | 0;
i = (i = i + Math.imul(x, Z) | 0) + Math.imul(k, J) | 0;
o = o + Math.imul(k, Z) | 0;
n = n + Math.imul(S, Q) | 0;
i = (i = i + Math.imul(S, ee) | 0) + Math.imul(M, Q) | 0;
o = o + Math.imul(M, ee) | 0;
n = n + Math.imul(_, re) | 0;
i = (i = i + Math.imul(_, ne) | 0) + Math.imul(w, re) | 0;
o = o + Math.imul(w, ne) | 0;
n = n + Math.imul(v, oe) | 0;
i = (i = i + Math.imul(v, se) | 0) + Math.imul(y, oe) | 0;
o = o + Math.imul(y, se) | 0;
n = n + Math.imul(p, fe) | 0;
i = (i = i + Math.imul(p, ce) | 0) + Math.imul(b, fe) | 0;
o = o + Math.imul(b, ce) | 0;
var Me = (c + (n = n + Math.imul(h, he) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, de) | 0) + Math.imul(d, he) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, de) | 0) + (i >>> 13) | 0) + (Me >>> 26) | 0;
Me &= 67108863;
n = Math.imul(B, q);
i = (i = Math.imul(B, V)) + Math.imul(U, q) | 0;
o = Math.imul(U, V);
n = n + Math.imul(P, z) | 0;
i = (i = i + Math.imul(P, G) | 0) + Math.imul(D, z) | 0;
o = o + Math.imul(D, G) | 0;
n = n + Math.imul(C, K) | 0;
i = (i = i + Math.imul(C, Y) | 0) + Math.imul(N, K) | 0;
o = o + Math.imul(N, Y) | 0;
n = n + Math.imul(I, J) | 0;
i = (i = i + Math.imul(I, Z) | 0) + Math.imul(O, J) | 0;
o = o + Math.imul(O, Z) | 0;
n = n + Math.imul(x, Q) | 0;
i = (i = i + Math.imul(x, ee) | 0) + Math.imul(k, Q) | 0;
o = o + Math.imul(k, ee) | 0;
n = n + Math.imul(S, re) | 0;
i = (i = i + Math.imul(S, ne) | 0) + Math.imul(M, re) | 0;
o = o + Math.imul(M, ne) | 0;
n = n + Math.imul(_, oe) | 0;
i = (i = i + Math.imul(_, se) | 0) + Math.imul(w, oe) | 0;
o = o + Math.imul(w, se) | 0;
n = n + Math.imul(v, fe) | 0;
i = (i = i + Math.imul(v, ce) | 0) + Math.imul(y, fe) | 0;
o = o + Math.imul(y, ce) | 0;
n = n + Math.imul(p, he) | 0;
i = (i = i + Math.imul(p, de) | 0) + Math.imul(b, he) | 0;
o = o + Math.imul(b, de) | 0;
var Ae = (c + (n = n + Math.imul(h, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(h, be) | 0) + Math.imul(d, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(d, be) | 0) + (i >>> 13) | 0) + (Ae >>> 26) | 0;
Ae &= 67108863;
n = Math.imul(B, z);
i = (i = Math.imul(B, G)) + Math.imul(U, z) | 0;
o = Math.imul(U, G);
n = n + Math.imul(P, K) | 0;
i = (i = i + Math.imul(P, Y) | 0) + Math.imul(D, K) | 0;
o = o + Math.imul(D, Y) | 0;
n = n + Math.imul(C, J) | 0;
i = (i = i + Math.imul(C, Z) | 0) + Math.imul(N, J) | 0;
o = o + Math.imul(N, Z) | 0;
n = n + Math.imul(I, Q) | 0;
i = (i = i + Math.imul(I, ee) | 0) + Math.imul(O, Q) | 0;
o = o + Math.imul(O, ee) | 0;
n = n + Math.imul(x, re) | 0;
i = (i = i + Math.imul(x, ne) | 0) + Math.imul(k, re) | 0;
o = o + Math.imul(k, ne) | 0;
n = n + Math.imul(S, oe) | 0;
i = (i = i + Math.imul(S, se) | 0) + Math.imul(M, oe) | 0;
o = o + Math.imul(M, se) | 0;
n = n + Math.imul(_, fe) | 0;
i = (i = i + Math.imul(_, ce) | 0) + Math.imul(w, fe) | 0;
o = o + Math.imul(w, ce) | 0;
n = n + Math.imul(v, he) | 0;
i = (i = i + Math.imul(v, de) | 0) + Math.imul(y, he) | 0;
o = o + Math.imul(y, de) | 0;
var xe = (c + (n = n + Math.imul(p, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(p, be) | 0) + Math.imul(b, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(b, be) | 0) + (i >>> 13) | 0) + (xe >>> 26) | 0;
xe &= 67108863;
n = Math.imul(B, K);
i = (i = Math.imul(B, Y)) + Math.imul(U, K) | 0;
o = Math.imul(U, Y);
n = n + Math.imul(P, J) | 0;
i = (i = i + Math.imul(P, Z) | 0) + Math.imul(D, J) | 0;
o = o + Math.imul(D, Z) | 0;
n = n + Math.imul(C, Q) | 0;
i = (i = i + Math.imul(C, ee) | 0) + Math.imul(N, Q) | 0;
o = o + Math.imul(N, ee) | 0;
n = n + Math.imul(I, re) | 0;
i = (i = i + Math.imul(I, ne) | 0) + Math.imul(O, re) | 0;
o = o + Math.imul(O, ne) | 0;
n = n + Math.imul(x, oe) | 0;
i = (i = i + Math.imul(x, se) | 0) + Math.imul(k, oe) | 0;
o = o + Math.imul(k, se) | 0;
n = n + Math.imul(S, fe) | 0;
i = (i = i + Math.imul(S, ce) | 0) + Math.imul(M, fe) | 0;
o = o + Math.imul(M, ce) | 0;
n = n + Math.imul(_, he) | 0;
i = (i = i + Math.imul(_, de) | 0) + Math.imul(w, he) | 0;
o = o + Math.imul(w, de) | 0;
var ke = (c + (n = n + Math.imul(v, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(v, be) | 0) + Math.imul(y, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(y, be) | 0) + (i >>> 13) | 0) + (ke >>> 26) | 0;
ke &= 67108863;
n = Math.imul(B, J);
i = (i = Math.imul(B, Z)) + Math.imul(U, J) | 0;
o = Math.imul(U, Z);
n = n + Math.imul(P, Q) | 0;
i = (i = i + Math.imul(P, ee) | 0) + Math.imul(D, Q) | 0;
o = o + Math.imul(D, ee) | 0;
n = n + Math.imul(C, re) | 0;
i = (i = i + Math.imul(C, ne) | 0) + Math.imul(N, re) | 0;
o = o + Math.imul(N, ne) | 0;
n = n + Math.imul(I, oe) | 0;
i = (i = i + Math.imul(I, se) | 0) + Math.imul(O, oe) | 0;
o = o + Math.imul(O, se) | 0;
n = n + Math.imul(x, fe) | 0;
i = (i = i + Math.imul(x, ce) | 0) + Math.imul(k, fe) | 0;
o = o + Math.imul(k, ce) | 0;
n = n + Math.imul(S, he) | 0;
i = (i = i + Math.imul(S, de) | 0) + Math.imul(M, he) | 0;
o = o + Math.imul(M, de) | 0;
var Te = (c + (n = n + Math.imul(_, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(_, be) | 0) + Math.imul(w, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(w, be) | 0) + (i >>> 13) | 0) + (Te >>> 26) | 0;
Te &= 67108863;
n = Math.imul(B, Q);
i = (i = Math.imul(B, ee)) + Math.imul(U, Q) | 0;
o = Math.imul(U, ee);
n = n + Math.imul(P, re) | 0;
i = (i = i + Math.imul(P, ne) | 0) + Math.imul(D, re) | 0;
o = o + Math.imul(D, ne) | 0;
n = n + Math.imul(C, oe) | 0;
i = (i = i + Math.imul(C, se) | 0) + Math.imul(N, oe) | 0;
o = o + Math.imul(N, se) | 0;
n = n + Math.imul(I, fe) | 0;
i = (i = i + Math.imul(I, ce) | 0) + Math.imul(O, fe) | 0;
o = o + Math.imul(O, ce) | 0;
n = n + Math.imul(x, he) | 0;
i = (i = i + Math.imul(x, de) | 0) + Math.imul(k, he) | 0;
o = o + Math.imul(k, de) | 0;
var Ie = (c + (n = n + Math.imul(S, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(S, be) | 0) + Math.imul(M, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(M, be) | 0) + (i >>> 13) | 0) + (Ie >>> 26) | 0;
Ie &= 67108863;
n = Math.imul(B, re);
i = (i = Math.imul(B, ne)) + Math.imul(U, re) | 0;
o = Math.imul(U, ne);
n = n + Math.imul(P, oe) | 0;
i = (i = i + Math.imul(P, se) | 0) + Math.imul(D, oe) | 0;
o = o + Math.imul(D, se) | 0;
n = n + Math.imul(C, fe) | 0;
i = (i = i + Math.imul(C, ce) | 0) + Math.imul(N, fe) | 0;
o = o + Math.imul(N, ce) | 0;
n = n + Math.imul(I, he) | 0;
i = (i = i + Math.imul(I, de) | 0) + Math.imul(O, he) | 0;
o = o + Math.imul(O, de) | 0;
var Oe = (c + (n = n + Math.imul(x, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(x, be) | 0) + Math.imul(k, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(k, be) | 0) + (i >>> 13) | 0) + (Oe >>> 26) | 0;
Oe &= 67108863;
n = Math.imul(B, oe);
i = (i = Math.imul(B, se)) + Math.imul(U, oe) | 0;
o = Math.imul(U, se);
n = n + Math.imul(P, fe) | 0;
i = (i = i + Math.imul(P, ce) | 0) + Math.imul(D, fe) | 0;
o = o + Math.imul(D, ce) | 0;
n = n + Math.imul(C, he) | 0;
i = (i = i + Math.imul(C, de) | 0) + Math.imul(N, he) | 0;
o = o + Math.imul(N, de) | 0;
var Re = (c + (n = n + Math.imul(I, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(I, be) | 0) + Math.imul(O, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(O, be) | 0) + (i >>> 13) | 0) + (Re >>> 26) | 0;
Re &= 67108863;
n = Math.imul(B, fe);
i = (i = Math.imul(B, ce)) + Math.imul(U, fe) | 0;
o = Math.imul(U, ce);
n = n + Math.imul(P, he) | 0;
i = (i = i + Math.imul(P, de) | 0) + Math.imul(D, he) | 0;
o = o + Math.imul(D, de) | 0;
var Ce = (c + (n = n + Math.imul(C, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(C, be) | 0) + Math.imul(N, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(N, be) | 0) + (i >>> 13) | 0) + (Ce >>> 26) | 0;
Ce &= 67108863;
n = Math.imul(B, he);
i = (i = Math.imul(B, de)) + Math.imul(U, he) | 0;
o = Math.imul(U, de);
var Ne = (c + (n = n + Math.imul(P, pe) | 0) | 0) + ((8191 & (i = (i = i + Math.imul(P, be) | 0) + Math.imul(D, pe) | 0)) << 13) | 0;
c = ((o = o + Math.imul(D, be) | 0) + (i >>> 13) | 0) + (Ne >>> 26) | 0;
Ne &= 67108863;
var je = (c + (n = Math.imul(B, pe)) | 0) + ((8191 & (i = (i = Math.imul(B, be)) + Math.imul(U, pe) | 0)) << 13) | 0;
c = ((o = Math.imul(U, be)) + (i >>> 13) | 0) + (je >>> 26) | 0;
je &= 67108863;
f[0] = me;
f[1] = ve;
f[2] = ye;
f[3] = ge;
f[4] = _e;
f[5] = we;
f[6] = Ee;
f[7] = Se;
f[8] = Me;
f[9] = Ae;
f[10] = xe;
f[11] = ke;
f[12] = Te;
f[13] = Ie;
f[14] = Oe;
f[15] = Re;
f[16] = Ce;
f[17] = Ne;
f[18] = je;
if (0 !== c) {
f[19] = c;
r.length++;
}
return r;
};
Math.imul || (y = v);
function g(e, t, r) {
r.negative = t.negative ^ e.negative;
r.length = e.length + t.length;
for (var n = 0, i = 0, o = 0; o < r.length - 1; o++) {
var s = i;
i = 0;
for (var a = 67108863 & n, f = Math.min(o, t.length - 1), c = Math.max(0, o - e.length + 1); c <= f; c++) {
var u = o - c, h = (0 | e.words[u]) * (0 | t.words[c]), d = 67108863 & h;
a = 67108863 & (d = d + a | 0);
i += (s = (s = s + (h / 67108864 | 0) | 0) + (d >>> 26) | 0) >>> 26;
s &= 67108863;
}
r.words[o] = a;
n = s;
s = i;
}
0 !== n ? r.words[o] = n : r.length--;
return r._strip();
}
function _(e, t, r) {
return g(e, t, r);
}
o.prototype.mulTo = function(e, t) {
var r = this.length + e.length;
return 10 === this.length && 10 === e.length ? y(this, e, t) : r < 63 ? v(this, e, t) : r < 1024 ? g(this, e, t) : _(this, e, t);
};
function w(e, t) {
this.x = e;
this.y = t;
}
w.prototype.makeRBT = function(e) {
for (var t = new Array(e), r = o.prototype._countBits(e) - 1, n = 0; n < e; n++) t[n] = this.revBin(n, r, e);
return t;
};
w.prototype.revBin = function(e, t, r) {
if (0 === e || e === r - 1) return e;
for (var n = 0, i = 0; i < t; i++) {
n |= (1 & e) << t - i - 1;
e >>= 1;
}
return n;
};
w.prototype.permute = function(e, t, r, n, i, o) {
for (var s = 0; s < o; s++) {
n[s] = t[e[s]];
i[s] = r[e[s]];
}
};
w.prototype.transform = function(e, t, r, n, i, o) {
this.permute(o, e, t, r, n, i);
for (var s = 1; s < i; s <<= 1) for (var a = s << 1, f = Math.cos(2 * Math.PI / a), c = Math.sin(2 * Math.PI / a), u = 0; u < i; u += a) for (var h = f, d = c, l = 0; l < s; l++) {
var p = r[u + l], b = n[u + l], m = r[u + l + s], v = n[u + l + s], y = h * m - d * v;
v = h * v + d * m;
m = y;
r[u + l] = p + m;
n[u + l] = b + v;
r[u + l + s] = p - m;
n[u + l + s] = b - v;
if (l !== a) {
y = f * h - c * d;
d = f * d + c * h;
h = y;
}
}
};
w.prototype.guessLen13b = function(e, t) {
var r = 1 | Math.max(t, e), n = 1 & r, i = 0;
for (r = r / 2 | 0; r; r >>>= 1) i++;
return 1 << i + 1 + n;
};
w.prototype.conjugate = function(e, t, r) {
if (!(r <= 1)) for (var n = 0; n < r / 2; n++) {
var i = e[n];
e[n] = e[r - n - 1];
e[r - n - 1] = i;
i = t[n];
t[n] = -t[r - n - 1];
t[r - n - 1] = -i;
}
};
w.prototype.normalize13b = function(e, t) {
for (var r = 0, n = 0; n < t / 2; n++) {
var i = 8192 * Math.round(e[2 * n + 1] / t) + Math.round(e[2 * n] / t) + r;
e[n] = 67108863 & i;
r = i < 67108864 ? 0 : i / 67108864 | 0;
}
return e;
};
w.prototype.convert13b = function(e, t, r, i) {
for (var o = 0, s = 0; s < t; s++) {
o += 0 | e[s];
r[2 * s] = 8191 & o;
o >>>= 13;
r[2 * s + 1] = 8191 & o;
o >>>= 13;
}
for (s = 2 * t; s < i; ++s) r[s] = 0;
n(0 === o);
n(0 == (-8192 & o));
};
w.prototype.stub = function(e) {
for (var t = new Array(e), r = 0; r < e; r++) t[r] = 0;
return t;
};
w.prototype.mulp = function(e, t, r) {
var n = 2 * this.guessLen13b(e.length, t.length), i = this.makeRBT(n), o = this.stub(n), s = new Array(n), a = new Array(n), f = new Array(n), c = new Array(n), u = new Array(n), h = new Array(n), d = r.words;
d.length = n;
this.convert13b(e.words, e.length, s, n);
this.convert13b(t.words, t.length, c, n);
this.transform(s, o, a, f, n, i);
this.transform(c, o, u, h, n, i);
for (var l = 0; l < n; l++) {
var p = a[l] * u[l] - f[l] * h[l];
f[l] = a[l] * h[l] + f[l] * u[l];
a[l] = p;
}
this.conjugate(a, f, n);
this.transform(a, f, d, o, n, i);
this.conjugate(d, o, n);
this.normalize13b(d, n);
r.negative = e.negative ^ t.negative;
r.length = e.length + t.length;
return r._strip();
};
o.prototype.mul = function(e) {
var t = new o(null);
t.words = new Array(this.length + e.length);
return this.mulTo(e, t);
};
o.prototype.mulf = function(e) {
var t = new o(null);
t.words = new Array(this.length + e.length);
return _(this, e, t);
};
o.prototype.imul = function(e) {
return this.clone().mulTo(e, this);
};
o.prototype.imuln = function(e) {
var t = e < 0;
t && (e = -e);
n("number" == typeof e);
n(e < 67108864);
for (var r = 0, i = 0; i < this.length; i++) {
var o = (0 | this.words[i]) * e, s = (67108863 & o) + (67108863 & r);
r >>= 26;
r += o / 67108864 | 0;
r += s >>> 26;
this.words[i] = 67108863 & s;
}
if (0 !== r) {
this.words[i] = r;
this.length++;
}
return t ? this.ineg() : this;
};
o.prototype.muln = function(e) {
return this.clone().imuln(e);
};
o.prototype.sqr = function() {
return this.mul(this);
};
o.prototype.isqr = function() {
return this.imul(this.clone());
};
o.prototype.pow = function(e) {
var t = m(e);
if (0 === t.length) return new o(1);
for (var r = this, n = 0; n < t.length && 0 === t[n]; n++, r = r.sqr()) ;
if (++n < t.length) for (var i = r.sqr(); n < t.length; n++, i = i.sqr()) 0 !== t[n] && (r = r.mul(i));
return r;
};
o.prototype.iushln = function(e) {
n("number" == typeof e && e >= 0);
var t, r = e % 26, i = (e - r) / 26, o = 67108863 >>> 26 - r << 26 - r;
if (0 !== r) {
var s = 0;
for (t = 0; t < this.length; t++) {
var a = this.words[t] & o, f = (0 | this.words[t]) - a << r;
this.words[t] = f | s;
s = a >>> 26 - r;
}
if (s) {
this.words[t] = s;
this.length++;
}
}
if (0 !== i) {
for (t = this.length - 1; t >= 0; t--) this.words[t + i] = this.words[t];
for (t = 0; t < i; t++) this.words[t] = 0;
this.length += i;
}
return this._strip();
};
o.prototype.ishln = function(e) {
n(0 === this.negative);
return this.iushln(e);
};
o.prototype.iushrn = function(e, t, r) {
n("number" == typeof e && e >= 0);
var i;
i = t ? (t - t % 26) / 26 : 0;
var o = e % 26, s = Math.min((e - o) / 26, this.length), a = 67108863 ^ 67108863 >>> o << o, f = r;
i -= s;
i = Math.max(0, i);
if (f) {
for (var c = 0; c < s; c++) f.words[c] = this.words[c];
f.length = s;
}
if (0 === s) ; else if (this.length > s) {
this.length -= s;
for (c = 0; c < this.length; c++) this.words[c] = this.words[c + s];
} else {
this.words[0] = 0;
this.length = 1;
}
var u = 0;
for (c = this.length - 1; c >= 0 && (0 !== u || c >= i); c--) {
var h = 0 | this.words[c];
this.words[c] = u << 26 - o | h >>> o;
u = h & a;
}
f && 0 !== u && (f.words[f.length++] = u);
if (0 === this.length) {
this.words[0] = 0;
this.length = 1;
}
return this._strip();
};
o.prototype.ishrn = function(e, t, r) {
n(0 === this.negative);
return this.iushrn(e, t, r);
};
o.prototype.shln = function(e) {
return this.clone().ishln(e);
};
o.prototype.ushln = function(e) {
return this.clone().iushln(e);
};
o.prototype.shrn = function(e) {
return this.clone().ishrn(e);
};
o.prototype.ushrn = function(e) {
return this.clone().iushrn(e);
};
o.prototype.testn = function(e) {
n("number" == typeof e && e >= 0);
var t = e % 26, r = (e - t) / 26, i = 1 << t;
return !(this.length <= r || !(this.words[r] & i));
};
o.prototype.imaskn = function(e) {
n("number" == typeof e && e >= 0);
var t = e % 26, r = (e - t) / 26;
n(0 === this.negative, "imaskn works only with positive numbers");
if (this.length <= r) return this;
0 !== t && r++;
this.length = Math.min(r, this.length);
if (0 !== t) {
var i = 67108863 ^ 67108863 >>> t << t;
this.words[this.length - 1] &= i;
}
return this._strip();
};
o.prototype.maskn = function(e) {
return this.clone().imaskn(e);
};
o.prototype.iaddn = function(e) {
n("number" == typeof e);
n(e < 67108864);
if (e < 0) return this.isubn(-e);
if (0 !== this.negative) {
if (1 === this.length && (0 | this.words[0]) <= e) {
this.words[0] = e - (0 | this.words[0]);
this.negative = 0;
return this;
}
this.negative = 0;
this.isubn(e);
this.negative = 1;
return this;
}
return this._iaddn(e);
};
o.prototype._iaddn = function(e) {
this.words[0] += e;
for (var t = 0; t < this.length && this.words[t] >= 67108864; t++) {
this.words[t] -= 67108864;
t === this.length - 1 ? this.words[t + 1] = 1 : this.words[t + 1]++;
}
this.length = Math.max(this.length, t + 1);
return this;
};
o.prototype.isubn = function(e) {
n("number" == typeof e);
n(e < 67108864);
if (e < 0) return this.iaddn(-e);
if (0 !== this.negative) {
this.negative = 0;
this.iaddn(e);
this.negative = 1;
return this;
}
this.words[0] -= e;
if (1 === this.length && this.words[0] < 0) {
this.words[0] = -this.words[0];
this.negative = 1;
} else for (var t = 0; t < this.length && this.words[t] < 0; t++) {
this.words[t] += 67108864;
this.words[t + 1] -= 1;
}
return this._strip();
};
o.prototype.addn = function(e) {
return this.clone().iaddn(e);
};
o.prototype.subn = function(e) {
return this.clone().isubn(e);
};
o.prototype.iabs = function() {
this.negative = 0;
return this;
};
o.prototype.abs = function() {
return this.clone().iabs();
};
o.prototype._ishlnsubmul = function(e, t, r) {
var i, o, s = e.length + r;
this._expand(s);
var a = 0;
for (i = 0; i < e.length; i++) {
o = (0 | this.words[i + r]) + a;
var f = (0 | e.words[i]) * t;
a = ((o -= 67108863 & f) >> 26) - (f / 67108864 | 0);
this.words[i + r] = 67108863 & o;
}
for (;i < this.length - r; i++) {
a = (o = (0 | this.words[i + r]) + a) >> 26;
this.words[i + r] = 67108863 & o;
}
if (0 === a) return this._strip();
n(-1 === a);
a = 0;
for (i = 0; i < this.length; i++) {
a = (o = -(0 | this.words[i]) + a) >> 26;
this.words[i] = 67108863 & o;
}
this.negative = 1;
return this._strip();
};
o.prototype._wordDiv = function(e, t) {
var r = (this.length, e.length), n = this.clone(), i = e, s = 0 | i.words[i.length - 1];
if (0 != (r = 26 - this._countBits(s))) {
i = i.ushln(r);
n.iushln(r);
s = 0 | i.words[i.length - 1];
}
var a, f = n.length - i.length;
if ("mod" !== t) {
(a = new o(null)).length = f + 1;
a.words = new Array(a.length);
for (var c = 0; c < a.length; c++) a.words[c] = 0;
}
var u = n.clone()._ishlnsubmul(i, 1, f);
if (0 === u.negative) {
n = u;
a && (a.words[f] = 1);
}
for (var h = f - 1; h >= 0; h--) {
var d = 67108864 * (0 | n.words[i.length + h]) + (0 | n.words[i.length + h - 1]);
d = Math.min(d / s | 0, 67108863);
n._ishlnsubmul(i, d, h);
for (;0 !== n.negative; ) {
d--;
n.negative = 0;
n._ishlnsubmul(i, 1, h);
n.isZero() || (n.negative ^= 1);
}
a && (a.words[h] = d);
}
a && a._strip();
n._strip();
"div" !== t && 0 !== r && n.iushrn(r);
return {
div: a || null,
mod: n
};
};
o.prototype.divmod = function(e, t, r) {
n(!e.isZero());
if (this.isZero()) return {
div: new o(0),
mod: new o(0)
};
var i, s, a;
if (0 !== this.negative && 0 === e.negative) {
a = this.neg().divmod(e, t);
"mod" !== t && (i = a.div.neg());
if ("div" !== t) {
s = a.mod.neg();
r && 0 !== s.negative && s.iadd(e);
}
return {
div: i,
mod: s
};
}
if (0 === this.negative && 0 !== e.negative) {
a = this.divmod(e.neg(), t);
"mod" !== t && (i = a.div.neg());
return {
div: i,
mod: a.mod
};
}
if (0 != (this.negative & e.negative)) {
a = this.neg().divmod(e.neg(), t);
if ("div" !== t) {
s = a.mod.neg();
r && 0 !== s.negative && s.isub(e);
}
return {
div: a.div,
mod: s
};
}
return e.length > this.length || this.cmp(e) < 0 ? {
div: new o(0),
mod: this
} : 1 === e.length ? "div" === t ? {
div: this.divn(e.words[0]),
mod: null
} : "mod" === t ? {
div: null,
mod: new o(this.modrn(e.words[0]))
} : {
div: this.divn(e.words[0]),
mod: new o(this.modrn(e.words[0]))
} : this._wordDiv(e, t);
};
o.prototype.div = function(e) {
return this.divmod(e, "div", !1).div;
};
o.prototype.mod = function(e) {
return this.divmod(e, "mod", !1).mod;
};
o.prototype.umod = function(e) {
return this.divmod(e, "mod", !0).mod;
};
o.prototype.divRound = function(e) {
var t = this.divmod(e);
if (t.mod.isZero()) return t.div;
var r = 0 !== t.div.negative ? t.mod.isub(e) : t.mod, n = e.ushrn(1), i = e.andln(1), o = r.cmp(n);
return o < 0 || 1 === i && 0 === o ? t.div : 0 !== t.div.negative ? t.div.isubn(1) : t.div.iaddn(1);
};
o.prototype.modrn = function(e) {
var t = e < 0;
t && (e = -e);
n(e <= 67108863);
for (var r = (1 << 26) % e, i = 0, o = this.length - 1; o >= 0; o--) i = (r * i + (0 | this.words[o])) % e;
return t ? -i : i;
};
o.prototype.modn = function(e) {
return this.modrn(e);
};
o.prototype.idivn = function(e) {
var t = e < 0;
t && (e = -e);
n(e <= 67108863);
for (var r = 0, i = this.length - 1; i >= 0; i--) {
var o = (0 | this.words[i]) + 67108864 * r;
this.words[i] = o / e | 0;
r = o % e;
}
this._strip();
return t ? this.ineg() : this;
};
o.prototype.divn = function(e) {
return this.clone().idivn(e);
};
o.prototype.egcd = function(e) {
n(0 === e.negative);
n(!e.isZero());
var t = this, r = e.clone();
t = 0 !== t.negative ? t.umod(e) : t.clone();
for (var i = new o(1), s = new o(0), a = new o(0), f = new o(1), c = 0; t.isEven() && r.isEven(); ) {
t.iushrn(1);
r.iushrn(1);
++c;
}
for (var u = r.clone(), h = t.clone(); !t.isZero(); ) {
for (var d = 0, l = 1; 0 == (t.words[0] & l) && d < 26; ++d, l <<= 1) ;
if (d > 0) {
t.iushrn(d);
for (;d-- > 0; ) {
if (i.isOdd() || s.isOdd()) {
i.iadd(u);
s.isub(h);
}
i.iushrn(1);
s.iushrn(1);
}
}
for (var p = 0, b = 1; 0 == (r.words[0] & b) && p < 26; ++p, b <<= 1) ;
if (p > 0) {
r.iushrn(p);
for (;p-- > 0; ) {
if (a.isOdd() || f.isOdd()) {
a.iadd(u);
f.isub(h);
}
a.iushrn(1);
f.iushrn(1);
}
}
if (t.cmp(r) >= 0) {
t.isub(r);
i.isub(a);
s.isub(f);
} else {
r.isub(t);
a.isub(i);
f.isub(s);
}
}
return {
a: a,
b: f,
gcd: r.iushln(c)
};
};
o.prototype._invmp = function(e) {
n(0 === e.negative);
n(!e.isZero());
var t = this, r = e.clone();
t = 0 !== t.negative ? t.umod(e) : t.clone();
for (var i, s = new o(1), a = new o(0), f = r.clone(); t.cmpn(1) > 0 && r.cmpn(1) > 0; ) {
for (var c = 0, u = 1; 0 == (t.words[0] & u) && c < 26; ++c, u <<= 1) ;
if (c > 0) {
t.iushrn(c);
for (;c-- > 0; ) {
s.isOdd() && s.iadd(f);
s.iushrn(1);
}
}
for (var h = 0, d = 1; 0 == (r.words[0] & d) && h < 26; ++h, d <<= 1) ;
if (h > 0) {
r.iushrn(h);
for (;h-- > 0; ) {
a.isOdd() && a.iadd(f);
a.iushrn(1);
}
}
if (t.cmp(r) >= 0) {
t.isub(r);
s.isub(a);
} else {
r.isub(t);
a.isub(s);
}
}
(i = 0 === t.cmpn(1) ? s : a).cmpn(0) < 0 && i.iadd(e);
return i;
};
o.prototype.gcd = function(e) {
if (this.isZero()) return e.abs();
if (e.isZero()) return this.abs();
var t = this.clone(), r = e.clone();
t.negative = 0;
r.negative = 0;
for (var n = 0; t.isEven() && r.isEven(); n++) {
t.iushrn(1);
r.iushrn(1);
}
for (;;) {
for (;t.isEven(); ) t.iushrn(1);
for (;r.isEven(); ) r.iushrn(1);
var i = t.cmp(r);
if (i < 0) {
var o = t;
t = r;
r = o;
} else if (0 === i || 0 === r.cmpn(1)) break;
t.isub(r);
}
return r.iushln(n);
};
o.prototype.invm = function(e) {
return this.egcd(e).a.umod(e);
};
o.prototype.isEven = function() {
return 0 == (1 & this.words[0]);
};
o.prototype.isOdd = function() {
return 1 == (1 & this.words[0]);
};
o.prototype.andln = function(e) {
return this.words[0] & e;
};
o.prototype.bincn = function(e) {
n("number" == typeof e);
var t = e % 26, r = (e - t) / 26, i = 1 << t;
if (this.length <= r) {
this._expand(r + 1);
this.words[r] |= i;
return this;
}
for (var o = i, s = r; 0 !== o && s < this.length; s++) {
var a = 0 | this.words[s];
o = (a += o) >>> 26;
a &= 67108863;
this.words[s] = a;
}
if (0 !== o) {
this.words[s] = o;
this.length++;
}
return this;
};
o.prototype.isZero = function() {
return 1 === this.length && 0 === this.words[0];
};
o.prototype.cmpn = function(e) {
var t, r = e < 0;
if (0 !== this.negative && !r) return -1;
if (0 === this.negative && r) return 1;
this._strip();
if (this.length > 1) t = 1; else {
r && (e = -e);
n(e <= 67108863, "Number is too big");
var i = 0 | this.words[0];
t = i === e ? 0 : i < e ? -1 : 1;
}
return 0 !== this.negative ? 0 | -t : t;
};
o.prototype.cmp = function(e) {
if (0 !== this.negative && 0 === e.negative) return -1;
if (0 === this.negative && 0 !== e.negative) return 1;
var t = this.ucmp(e);
return 0 !== this.negative ? 0 | -t : t;
};
o.prototype.ucmp = function(e) {
if (this.length > e.length) return 1;
if (this.length < e.length) return -1;
for (var t = 0, r = this.length - 1; r >= 0; r--) {
var n = 0 | this.words[r], i = 0 | e.words[r];
if (n !== i) {
n < i ? t = -1 : n > i && (t = 1);
break;
}
}
return t;
};
o.prototype.gtn = function(e) {
return 1 === this.cmpn(e);
};
o.prototype.gt = function(e) {
return 1 === this.cmp(e);
};
o.prototype.gten = function(e) {
return this.cmpn(e) >= 0;
};
o.prototype.gte = function(e) {
return this.cmp(e) >= 0;
};
o.prototype.ltn = function(e) {
return -1 === this.cmpn(e);
};
o.prototype.lt = function(e) {
return -1 === this.cmp(e);
};
o.prototype.lten = function(e) {
return this.cmpn(e) <= 0;
};
o.prototype.lte = function(e) {
return this.cmp(e) <= 0;
};
o.prototype.eqn = function(e) {
return 0 === this.cmpn(e);
};
o.prototype.eq = function(e) {
return 0 === this.cmp(e);
};
o.red = function(e) {
return new T(e);
};
o.prototype.toRed = function(e) {
n(!this.red, "Already a number in reduction context");
n(0 === this.negative, "red works only with positives");
return e.convertTo(this)._forceRed(e);
};
o.prototype.fromRed = function() {
n(this.red, "fromRed works only with numbers in reduction context");
return this.red.convertFrom(this);
};
o.prototype._forceRed = function(e) {
this.red = e;
return this;
};
o.prototype.forceRed = function(e) {
n(!this.red, "Already a number in reduction context");
return this._forceRed(e);
};
o.prototype.redAdd = function(e) {
n(this.red, "redAdd works only with red numbers");
return this.red.add(this, e);
};
o.prototype.redIAdd = function(e) {
n(this.red, "redIAdd works only with red numbers");
return this.red.iadd(this, e);
};
o.prototype.redSub = function(e) {
n(this.red, "redSub works only with red numbers");
return this.red.sub(this, e);
};
o.prototype.redISub = function(e) {
n(this.red, "redISub works only with red numbers");
return this.red.isub(this, e);
};
o.prototype.redShl = function(e) {
n(this.red, "redShl works only with red numbers");
return this.red.shl(this, e);
};
o.prototype.redMul = function(e) {
n(this.red, "redMul works only with red numbers");
this.red._verify2(this, e);
return this.red.mul(this, e);
};
o.prototype.redIMul = function(e) {
n(this.red, "redMul works only with red numbers");
this.red._verify2(this, e);
return this.red.imul(this, e);
};
o.prototype.redSqr = function() {
n(this.red, "redSqr works only with red numbers");
this.red._verify1(this);
return this.red.sqr(this);
};
o.prototype.redISqr = function() {
n(this.red, "redISqr works only with red numbers");
this.red._verify1(this);
return this.red.isqr(this);
};
o.prototype.redSqrt = function() {
n(this.red, "redSqrt works only with red numbers");
this.red._verify1(this);
return this.red.sqrt(this);
};
o.prototype.redInvm = function() {
n(this.red, "redInvm works only with red numbers");
this.red._verify1(this);
return this.red.invm(this);
};
o.prototype.redNeg = function() {
n(this.red, "redNeg works only with red numbers");
this.red._verify1(this);
return this.red.neg(this);
};
o.prototype.redPow = function(e) {
n(this.red && !e.red, "redPow(normalNum)");
this.red._verify1(this);
return this.red.pow(this, e);
};
var E = {
k256: null,
p224: null,
p192: null,
p25519: null
};
function S(e, t) {
this.name = e;
this.p = new o(t, 16);
this.n = this.p.bitLength();
this.k = new o(1).iushln(this.n).isub(this.p);
this.tmp = this._tmp();
}
S.prototype._tmp = function() {
var e = new o(null);
e.words = new Array(Math.ceil(this.n / 13));
return e;
};
S.prototype.ireduce = function(e) {
var t, r = e;
do {
this.split(r, this.tmp);
t = (r = (r = this.imulK(r)).iadd(this.tmp)).bitLength();
} while (t > this.n);
var n = t < this.n ? -1 : r.ucmp(this.p);
if (0 === n) {
r.words[0] = 0;
r.length = 1;
} else n > 0 ? r.isub(this.p) : void 0 !== r.strip ? r.strip() : r._strip();
return r;
};
S.prototype.split = function(e, t) {
e.iushrn(this.n, 0, t);
};
S.prototype.imulK = function(e) {
return e.imul(this.k);
};
function M() {
S.call(this, "k256", "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe fffffc2f");
}
i(M, S);
M.prototype.split = function(e, t) {
for (var r = Math.min(e.length, 9), n = 0; n < r; n++) t.words[n] = e.words[n];
t.length = r;
if (e.length <= 9) {
e.words[0] = 0;
e.length = 1;
} else {
var i = e.words[9];
t.words[t.length++] = 4194303 & i;
for (n = 10; n < e.length; n++) {
var o = 0 | e.words[n];
e.words[n - 10] = (4194303 & o) << 4 | i >>> 22;
i = o;
}
i >>>= 22;
e.words[n - 10] = i;
0 === i && e.length > 10 ? e.length -= 10 : e.length -= 9;
}
};
M.prototype.imulK = function(e) {
e.words[e.length] = 0;
e.words[e.length + 1] = 0;
e.length += 2;
for (var t = 0, r = 0; r < e.length; r++) {
var n = 0 | e.words[r];
t += 977 * n;
e.words[r] = 67108863 & t;
t = 64 * n + (t / 67108864 | 0);
}
if (0 === e.words[e.length - 1]) {
e.length--;
0 === e.words[e.length - 1] && e.length--;
}
return e;
};
function A() {
S.call(this, "p224", "ffffffff ffffffff ffffffff ffffffff 00000000 00000000 00000001");
}
i(A, S);
function x() {
S.call(this, "p192", "ffffffff ffffffff ffffffff fffffffe ffffffff ffffffff");
}
i(x, S);
function k() {
S.call(this, "25519", "7fffffffffffffff ffffffffffffffff ffffffffffffffff ffffffffffffffed");
}
i(k, S);
k.prototype.imulK = function(e) {
for (var t = 0, r = 0; r < e.length; r++) {
var n = 19 * (0 | e.words[r]) + t, i = 67108863 & n;
n >>>= 26;
e.words[r] = i;
t = n;
}
0 !== t && (e.words[e.length++] = t);
return e;
};
o._prime = function(e) {
if (E[e]) return E[e];
var t;
if ("k256" === e) t = new M(); else if ("p224" === e) t = new A(); else if ("p192" === e) t = new x(); else {
if ("p25519" !== e) throw new Error("Unknown prime " + e);
t = new k();
}
E[e] = t;
return t;
};
function T(e) {
if ("string" == typeof e) {
var t = o._prime(e);
this.m = t.p;
this.prime = t;
} else {
n(e.gtn(1), "modulus must be greater than 1");
this.m = e;
this.prime = null;
}
}
T.prototype._verify1 = function(e) {
n(0 === e.negative, "red works only with positives");
n(e.red, "red works only with red numbers");
};
T.prototype._verify2 = function(e, t) {
n(0 == (e.negative | t.negative), "red works only with positives");
n(e.red && e.red === t.red, "red works only with red numbers");
};
T.prototype.imod = function(e) {
if (this.prime) return this.prime.ireduce(e)._forceRed(this);
u(e, e.umod(this.m)._forceRed(this));
return e;
};
T.prototype.neg = function(e) {
return e.isZero() ? e.clone() : this.m.sub(e)._forceRed(this);
};
T.prototype.add = function(e, t) {
this._verify2(e, t);
var r = e.add(t);
r.cmp(this.m) >= 0 && r.isub(this.m);
return r._forceRed(this);
};
T.prototype.iadd = function(e, t) {
this._verify2(e, t);
var r = e.iadd(t);
r.cmp(this.m) >= 0 && r.isub(this.m);
return r;
};
T.prototype.sub = function(e, t) {
this._verify2(e, t);
var r = e.sub(t);
r.cmpn(0) < 0 && r.iadd(this.m);
return r._forceRed(this);
};
T.prototype.isub = function(e, t) {
this._verify2(e, t);
var r = e.isub(t);
r.cmpn(0) < 0 && r.iadd(this.m);
return r;
};
T.prototype.shl = function(e, t) {
this._verify1(e);
return this.imod(e.ushln(t));
};
T.prototype.imul = function(e, t) {
this._verify2(e, t);
return this.imod(e.imul(t));
};
T.prototype.mul = function(e, t) {
this._verify2(e, t);
return this.imod(e.mul(t));
};
T.prototype.isqr = function(e) {
return this.imul(e, e.clone());
};
T.prototype.sqr = function(e) {
return this.mul(e, e);
};
T.prototype.sqrt = function(e) {
if (e.isZero()) return e.clone();
var t = this.m.andln(3);
n(t % 2 == 1);
if (3 === t) {
var r = this.m.add(new o(1)).iushrn(2);
return this.pow(e, r);
}
for (var i = this.m.subn(1), s = 0; !i.isZero() && 0 === i.andln(1); ) {
s++;
i.iushrn(1);
}
n(!i.isZero());
var a = new o(1).toRed(this), f = a.redNeg(), c = this.m.subn(1).iushrn(1), u = this.m.bitLength();
u = new o(2 * u * u).toRed(this);
for (;0 !== this.pow(u, c).cmp(f); ) u.redIAdd(f);
for (var h = this.pow(u, i), d = this.pow(e, i.addn(1).iushrn(1)), l = this.pow(e, i), p = s; 0 !== l.cmp(a); ) {
for (var b = l, m = 0; 0 !== b.cmp(a); m++) b = b.redSqr();
n(m < p);
var v = this.pow(h, new o(1).iushln(p - m - 1));
d = d.redMul(v);
h = v.redSqr();
l = l.redMul(h);
p = m;
}
return d;
};
T.prototype.invm = function(e) {
var t = e._invmp(this.m);
if (0 !== t.negative) {
t.negative = 0;
return this.imod(t).redNeg();
}
return this.imod(t);
};
T.prototype.pow = function(e, t) {
if (t.isZero()) return new o(1).toRed(this);
if (0 === t.cmpn(1)) return e.clone();
var r = new Array(16);
r[0] = new o(1).toRed(this);
r[1] = e;
for (var n = 2; n < r.length; n++) r[n] = this.mul(r[n - 1], e);
var i = r[0], s = 0, a = 0, f = t.bitLength() % 26;
0 === f && (f = 26);
for (n = t.length - 1; n >= 0; n--) {
for (var c = t.words[n], u = f - 1; u >= 0; u--) {
var h = c >> u & 1;
i !== r[0] && (i = this.sqr(i));
if (0 !== h || 0 !== s) {
s <<= 1;
s |= h;
if (4 == ++a || 0 === n && 0 === u) {
i = this.mul(i, r[s]);
a = 0;
s = 0;
}
} else a = 0;
}
f = 26;
}
return i;
};
T.prototype.convertTo = function(e) {
var t = e.umod(this.m);
return t === e ? t.clone() : t;
};
T.prototype.convertFrom = function(e) {
var t = e.clone();
t.red = null;
return t;
};
o.mont = function(e) {
return new I(e);
};
function I(e) {
T.call(this, e);
this.shift = this.m.bitLength();
this.shift % 26 != 0 && (this.shift += 26 - this.shift % 26);
this.r = new o(1).iushln(this.shift);
this.r2 = this.imod(this.r.sqr());
this.rinv = this.r._invmp(this.m);
this.minv = this.rinv.mul(this.r).isubn(1).div(this.m);
this.minv = this.minv.umod(this.r);
this.minv = this.r.sub(this.minv);
}
i(I, T);
I.prototype.convertTo = function(e) {
return this.imod(e.ushln(this.shift));
};
I.prototype.convertFrom = function(e) {
var t = this.imod(e.mul(this.rinv));
t.red = null;
return t;
};
I.prototype.imul = function(e, t) {
if (e.isZero() || t.isZero()) {
e.words[0] = 0;
e.length = 1;
return e;
}
var r = e.imul(t), n = r.maskn(this.shift).mul(this.minv).imaskn(this.shift).mul(this.m), i = r.isub(n).iushrn(this.shift), o = i;
i.cmp(this.m) >= 0 ? o = i.isub(this.m) : i.cmpn(0) < 0 && (o = i.iadd(this.m));
return o._forceRed(this);
};
I.prototype.mul = function(e, t) {
if (e.isZero() || t.isZero()) return new o(0)._forceRed(this);
var r = e.mul(t), n = r.maskn(this.shift).mul(this.minv).imaskn(this.shift).mul(this.m), i = r.isub(n).iushrn(this.shift), s = i;
i.cmp(this.m) >= 0 ? s = i.isub(this.m) : i.cmpn(0) < 0 && (s = i.iadd(this.m));
return s._forceRed(this);
};
I.prototype.invm = function(e) {
return this.imod(e._invmp(this.m).mul(this.r2))._forceRed(this);
};
})("undefined" == typeof t || t, this);
}, {
buffer: 19
} ],
18: [ function(e, t) {
var r;
t.exports = function(e) {
r || (r = new n(null));
return r.generate(e);
};
function n(e) {
this.rand = e;
}
t.exports.Rand = n;
n.prototype.generate = function(e) {
return this._rand(e);
};
n.prototype._rand = function(e) {
if (this.rand.getBytes) return this.rand.getBytes(e);
for (var t = new Uint8Array(e), r = 0; r < t.length; r++) t[r] = this.rand.getByte();
return t;
};
if ("object" == typeof self) self.crypto && self.crypto.getRandomValues ? n.prototype._rand = function(e) {
var t = new Uint8Array(e);
self.crypto.getRandomValues(t);
return t;
} : self.msCrypto && self.msCrypto.getRandomValues ? n.prototype._rand = function(e) {
var t = new Uint8Array(e);
self.msCrypto.getRandomValues(t);
return t;
} : "object" == typeof window && (n.prototype._rand = function() {
throw new Error("Not implemented yet");
}); else try {
var i = e("crypto");
if ("function" != typeof i.randomBytes) throw new Error("Not supported");
n.prototype._rand = function(e) {
return i.randomBytes(e);
};
} catch (e) {}
}, {
crypto: 19
} ],
19: [ function() {}, {} ],
20: [ function(e, t) {
var r = e("safe-buffer").Buffer;
function n(e) {
r.isBuffer(e) || (e = r.from(e));
for (var t = e.length / 4 | 0, n = new Array(t), i = 0; i < t; i++) n[i] = e.readUInt32BE(4 * i);
return n;
}
function i(e) {
for (;0 < e.length; e++) e[0] = 0;
}
function o(e, t, r, n, i) {
for (var o, s, a, f, c = r[0], u = r[1], h = r[2], d = r[3], l = e[0] ^ t[0], p = e[1] ^ t[1], b = e[2] ^ t[2], m = e[3] ^ t[3], v = 4, y = 1; y < i; y++) {
o = c[l >>> 24] ^ u[p >>> 16 & 255] ^ h[b >>> 8 & 255] ^ d[255 & m] ^ t[v++];
s = c[p >>> 24] ^ u[b >>> 16 & 255] ^ h[m >>> 8 & 255] ^ d[255 & l] ^ t[v++];
a = c[b >>> 24] ^ u[m >>> 16 & 255] ^ h[l >>> 8 & 255] ^ d[255 & p] ^ t[v++];
f = c[m >>> 24] ^ u[l >>> 16 & 255] ^ h[p >>> 8 & 255] ^ d[255 & b] ^ t[v++];
l = o;
p = s;
b = a;
m = f;
}
o = (n[l >>> 24] << 24 | n[p >>> 16 & 255] << 16 | n[b >>> 8 & 255] << 8 | n[255 & m]) ^ t[v++];
s = (n[p >>> 24] << 24 | n[b >>> 16 & 255] << 16 | n[m >>> 8 & 255] << 8 | n[255 & l]) ^ t[v++];
a = (n[b >>> 24] << 24 | n[m >>> 16 & 255] << 16 | n[l >>> 8 & 255] << 8 | n[255 & p]) ^ t[v++];
f = (n[m >>> 24] << 24 | n[l >>> 16 & 255] << 16 | n[p >>> 8 & 255] << 8 | n[255 & b]) ^ t[v++];
return [ o >>>= 0, s >>>= 0, a >>>= 0, f >>>= 0 ];
}
var s = [ 0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54 ], a = function() {
for (var e = new Array(256), t = 0; t < 256; t++) e[t] = t < 128 ? t << 1 : t << 1 ^ 283;
for (var r = [], n = [], i = [ [], [], [], [] ], o = [ [], [], [], [] ], s = 0, a = 0, f = 0; f < 256; ++f) {
var c = a ^ a << 1 ^ a << 2 ^ a << 3 ^ a << 4;
c = c >>> 8 ^ 255 & c ^ 99;
r[s] = c;
n[c] = s;
var u = e[s], h = e[u], d = e[h], l = 257 * e[c] ^ 16843008 * c;
i[0][s] = l << 24 | l >>> 8;
i[1][s] = l << 16 | l >>> 16;
i[2][s] = l << 8 | l >>> 24;
i[3][s] = l;
l = 16843009 * d ^ 65537 * h ^ 257 * u ^ 16843008 * s;
o[0][c] = l << 24 | l >>> 8;
o[1][c] = l << 16 | l >>> 16;
o[2][c] = l << 8 | l >>> 24;
o[3][c] = l;
if (0 === s) s = a = 1; else {
s = u ^ e[e[e[d ^ u]]];
a ^= e[e[a]];
}
}
return {
SBOX: r,
INV_SBOX: n,
SUB_MIX: i,
INV_SUB_MIX: o
};
}();
function f(e) {
this._key = n(e);
this._reset();
}
f.blockSize = 16;
f.keySize = 32;
f.prototype.blockSize = f.blockSize;
f.prototype.keySize = f.keySize;
f.prototype._reset = function() {
for (var e = this._key, t = e.length, r = t + 6, n = 4 * (r + 1), i = [], o = 0; o < t; o++) i[o] = e[o];
for (o = t; o < n; o++) {
var f = i[o - 1];
if (o % t == 0) {
f = f << 8 | f >>> 24;
f = a.SBOX[f >>> 24] << 24 | a.SBOX[f >>> 16 & 255] << 16 | a.SBOX[f >>> 8 & 255] << 8 | a.SBOX[255 & f];
f ^= s[o / t | 0] << 24;
} else t > 6 && o % t == 4 && (f = a.SBOX[f >>> 24] << 24 | a.SBOX[f >>> 16 & 255] << 16 | a.SBOX[f >>> 8 & 255] << 8 | a.SBOX[255 & f]);
i[o] = i[o - t] ^ f;
}
for (var c = [], u = 0; u < n; u++) {
var h = n - u, d = i[h - (u % 4 ? 0 : 4)];
c[u] = u < 4 || h <= 4 ? d : a.INV_SUB_MIX[0][a.SBOX[d >>> 24]] ^ a.INV_SUB_MIX[1][a.SBOX[d >>> 16 & 255]] ^ a.INV_SUB_MIX[2][a.SBOX[d >>> 8 & 255]] ^ a.INV_SUB_MIX[3][a.SBOX[255 & d]];
}
this._nRounds = r;
this._keySchedule = i;
this._invKeySchedule = c;
};
f.prototype.encryptBlockRaw = function(e) {
return o(e = n(e), this._keySchedule, a.SUB_MIX, a.SBOX, this._nRounds);
};
f.prototype.encryptBlock = function(e) {
var t = this.encryptBlockRaw(e), n = r.allocUnsafe(16);
n.writeUInt32BE(t[0], 0);
n.writeUInt32BE(t[1], 4);
n.writeUInt32BE(t[2], 8);
n.writeUInt32BE(t[3], 12);
return n;
};
f.prototype.decryptBlock = function(e) {
var t = (e = n(e))[1];
e[1] = e[3];
e[3] = t;
var i = o(e, this._invKeySchedule, a.INV_SUB_MIX, a.INV_SBOX, this._nRounds), s = r.allocUnsafe(16);
s.writeUInt32BE(i[0], 0);
s.writeUInt32BE(i[3], 4);
s.writeUInt32BE(i[2], 8);
s.writeUInt32BE(i[1], 12);
return s;
};
f.prototype.scrub = function() {
i(this._keySchedule);
i(this._invKeySchedule);
i(this._key);
};
t.exports.AES = f;
}, {
"safe-buffer": 183
} ],
21: [ function(e, t) {
var r = e("./aes"), n = e("safe-buffer").Buffer, i = e("cipher-base"), o = e("inherits"), s = e("./ghash"), a = e("buffer-xor"), f = e("./incr32");
function c(e, t) {
var r = 0;
e.length !== t.length && r++;
for (var n = Math.min(e.length, t.length), i = 0; i < n; ++i) r += e[i] ^ t[i];
return r;
}
function u(e, t, r) {
if (12 === t.length) {
e._finID = n.concat([ t, n.from([ 0, 0, 0, 1 ]) ]);
return n.concat([ t, n.from([ 0, 0, 0, 2 ]) ]);
}
var i = new s(r), o = t.length, a = o % 16;
i.update(t);
if (a) {
a = 16 - a;
i.update(n.alloc(a, 0));
}
i.update(n.alloc(8, 0));
var c = 8 * o, u = n.alloc(8);
u.writeUIntBE(c, 0, 8);
i.update(u);
e._finID = i.state;
var h = n.from(e._finID);
f(h);
return h;
}
function h(e, t, o, a) {
i.call(this);
var f = n.alloc(4, 0);
this._cipher = new r.AES(t);
var c = this._cipher.encryptBlock(f);
this._ghash = new s(c);
o = u(this, o, c);
this._prev = n.from(o);
this._cache = n.allocUnsafe(0);
this._secCache = n.allocUnsafe(0);
this._decrypt = a;
this._alen = 0;
this._len = 0;
this._mode = e;
this._authTag = null;
this._called = !1;
}
o(h, i);
h.prototype._update = function(e) {
if (!this._called && this._alen) {
var t = 16 - this._alen % 16;
if (t < 16) {
t = n.alloc(t, 0);
this._ghash.update(t);
}
}
this._called = !0;
var r = this._mode.encrypt(this, e);
this._decrypt ? this._ghash.update(e) : this._ghash.update(r);
this._len += e.length;
return r;
};
h.prototype._final = function() {
if (this._decrypt && !this._authTag) throw new Error("Unsupported state or unable to authenticate data");
var e = a(this._ghash.final(8 * this._alen, 8 * this._len), this._cipher.encryptBlock(this._finID));
if (this._decrypt && c(e, this._authTag)) throw new Error("Unsupported state or unable to authenticate data");
this._authTag = e;
this._cipher.scrub();
};
h.prototype.getAuthTag = function() {
if (this._decrypt || !n.isBuffer(this._authTag)) throw new Error("Attempting to get auth tag in unsupported state");
return this._authTag;
};
h.prototype.setAuthTag = function(e) {
if (!this._decrypt) throw new Error("Attempting to set auth tag in unsupported state");
this._authTag = e;
};
h.prototype.setAAD = function(e) {
if (this._called) throw new Error("Attempting to set AAD in unsupported state");
this._ghash.update(e);
this._alen += e.length;
};
t.exports = h;
}, {
"./aes": 20,
"./ghash": 25,
"./incr32": 26,
"buffer-xor": 64,
"cipher-base": 67,
inherits: 138,
"safe-buffer": 183
} ],
22: [ function(e, t, r) {
var n = e("./encrypter"), i = e("./decrypter"), o = e("./modes/list.json");
r.createCipher = r.Cipher = n.createCipher;
r.createCipheriv = r.Cipheriv = n.createCipheriv;
r.createDecipher = r.Decipher = i.createDecipher;
r.createDecipheriv = r.Decipheriv = i.createDecipheriv;
r.listCiphers = r.getCiphers = function() {
return Object.keys(o);
};
}, {
"./decrypter": 23,
"./encrypter": 24,
"./modes/list.json": 34
} ],
23: [ function(e, t, r) {
var n = e("./authCipher"), i = e("safe-buffer").Buffer, o = e("./modes"), s = e("./streamCipher"), a = e("cipher-base"), f = e("./aes"), c = e("evp_bytestokey");
function u(e, t, r) {
a.call(this);
this._cache = new h();
this._last = void 0;
this._cipher = new f.AES(t);
this._prev = i.from(r);
this._mode = e;
this._autopadding = !0;
}
e("inherits")(u, a);
u.prototype._update = function(e) {
this._cache.add(e);
for (var t, r, n = []; t = this._cache.get(this._autopadding); ) {
r = this._mode.decrypt(this, t);
n.push(r);
}
return i.concat(n);
};
u.prototype._final = function() {
var e = this._cache.flush();
if (this._autopadding) return d(this._mode.decrypt(this, e));
if (e) throw new Error("data not multiple of block length");
};
u.prototype.setAutoPadding = function(e) {
this._autopadding = !!e;
return this;
};
function h() {
this.cache = i.allocUnsafe(0);
}
h.prototype.add = function(e) {
this.cache = i.concat([ this.cache, e ]);
};
h.prototype.get = function(e) {
var t;
if (e) {
if (this.cache.length > 16) {
t = this.cache.slice(0, 16);
this.cache = this.cache.slice(16);
return t;
}
} else if (this.cache.length >= 16) {
t = this.cache.slice(0, 16);
this.cache = this.cache.slice(16);
return t;
}
return null;
};
h.prototype.flush = function() {
if (this.cache.length) return this.cache;
};
function d(e) {
var t = e[15];
if (t < 1 || t > 16) throw new Error("unable to decrypt data");
for (var r = -1; ++r < t; ) if (e[r + (16 - t)] !== t) throw new Error("unable to decrypt data");
if (16 !== t) return e.slice(0, 16 - t);
}
function l(e, t, r) {
var a = o[e.toLowerCase()];
if (!a) throw new TypeError("invalid suite type");
"string" == typeof r && (r = i.from(r));
if ("GCM" !== a.mode && r.length !== a.iv) throw new TypeError("invalid iv length " + r.length);
"string" == typeof t && (t = i.from(t));
if (t.length !== a.key / 8) throw new TypeError("invalid key length " + t.length);
return "stream" === a.type ? new s(a.module, t, r, !0) : "auth" === a.type ? new n(a.module, t, r, !0) : new u(a.module, t, r);
}
r.createDecipher = function(e, t) {
var r = o[e.toLowerCase()];
if (!r) throw new TypeError("invalid suite type");
var n = c(t, !1, r.key, r.iv);
return l(e, n.key, n.iv);
};
r.createDecipheriv = l;
}, {
"./aes": 20,
"./authCipher": 21,
"./modes": 33,
"./streamCipher": 36,
"cipher-base": 67,
evp_bytestokey: 105,
inherits: 138,
"safe-buffer": 183
} ],
24: [ function(e, t, r) {
var n = e("./modes"), i = e("./authCipher"), o = e("safe-buffer").Buffer, s = e("./streamCipher"), a = e("cipher-base"), f = e("./aes"), c = e("evp_bytestokey");
function u(e, t, r) {
a.call(this);
this._cache = new d();
this._cipher = new f.AES(t);
this._prev = o.from(r);
this._mode = e;
this._autopadding = !0;
}
e("inherits")(u, a);
u.prototype._update = function(e) {
this._cache.add(e);
for (var t, r, n = []; t = this._cache.get(); ) {
r = this._mode.encrypt(this, t);
n.push(r);
}
return o.concat(n);
};
var h = o.alloc(16, 16);
u.prototype._final = function() {
var e = this._cache.flush();
if (this._autopadding) {
e = this._mode.encrypt(this, e);
this._cipher.scrub();
return e;
}
if (!e.equals(h)) {
this._cipher.scrub();
throw new Error("data not multiple of block length");
}
};
u.prototype.setAutoPadding = function(e) {
this._autopadding = !!e;
return this;
};
function d() {
this.cache = o.allocUnsafe(0);
}
d.prototype.add = function(e) {
this.cache = o.concat([ this.cache, e ]);
};
d.prototype.get = function() {
if (this.cache.length > 15) {
var e = this.cache.slice(0, 16);
this.cache = this.cache.slice(16);
return e;
}
return null;
};
d.prototype.flush = function() {
for (var e = 16 - this.cache.length, t = o.allocUnsafe(e), r = -1; ++r < e; ) t.writeUInt8(e, r);
return o.concat([ this.cache, t ]);
};
function l(e, t, r) {
var a = n[e.toLowerCase()];
if (!a) throw new TypeError("invalid suite type");
"string" == typeof t && (t = o.from(t));
if (t.length !== a.key / 8) throw new TypeError("invalid key length " + t.length);
"string" == typeof r && (r = o.from(r));
if ("GCM" !== a.mode && r.length !== a.iv) throw new TypeError("invalid iv length " + r.length);
return "stream" === a.type ? new s(a.module, t, r) : "auth" === a.type ? new i(a.module, t, r) : new u(a.module, t, r);
}
r.createCipheriv = l;
r.createCipher = function(e, t) {
var r = n[e.toLowerCase()];
if (!r) throw new TypeError("invalid suite type");
var i = c(t, !1, r.key, r.iv);
return l(e, i.key, i.iv);
};
}, {
"./aes": 20,
"./authCipher": 21,
"./modes": 33,
"./streamCipher": 36,
"cipher-base": 67,
evp_bytestokey: 105,
inherits: 138,
"safe-buffer": 183
} ],
25: [ function(e, t) {
var r = e("safe-buffer").Buffer, n = r.alloc(16, 0);
function i(e) {
var t = r.allocUnsafe(16);
t.writeUInt32BE(e[0] >>> 0, 0);
t.writeUInt32BE(e[1] >>> 0, 4);
t.writeUInt32BE(e[2] >>> 0, 8);
t.writeUInt32BE(e[3] >>> 0, 12);
return t;
}
function o(e) {
this.h = e;
this.state = r.alloc(16, 0);
this.cache = r.allocUnsafe(0);
}
o.prototype.ghash = function(e) {
for (var t = -1; ++t < e.length; ) this.state[t] ^= e[t];
this._multiply();
};
o.prototype._multiply = function() {
for (var e, t, r, n = [ (e = this.h).readUInt32BE(0), e.readUInt32BE(4), e.readUInt32BE(8), e.readUInt32BE(12) ], o = [ 0, 0, 0, 0 ], s = -1; ++s < 128; ) {
if (0 != (this.state[~~(s / 8)] & 1 << 7 - s % 8)) {
o[0] ^= n[0];
o[1] ^= n[1];
o[2] ^= n[2];
o[3] ^= n[3];
}
r = 0 != (1 & n[3]);
for (t = 3; t > 0; t--) n[t] = n[t] >>> 1 | (1 & n[t - 1]) << 31;
n[0] = n[0] >>> 1;
r && (n[0] = n[0] ^ 225 << 24);
}
this.state = i(o);
};
o.prototype.update = function(e) {
this.cache = r.concat([ this.cache, e ]);
for (var t; this.cache.length >= 16; ) {
t = this.cache.slice(0, 16);
this.cache = this.cache.slice(16);
this.ghash(t);
}
};
o.prototype.final = function(e, t) {
this.cache.length && this.ghash(r.concat([ this.cache, n ], 16));
this.ghash(i([ 0, e, 0, t ]));
return this.state;
};
t.exports = o;
}, {
"safe-buffer": 183
} ],
26: [ function(e, t) {
t.exports = function(e) {
for (var t, r = e.length; r--; ) {
if (255 !== (t = e.readUInt8(r))) {
t++;
e.writeUInt8(t, r);
break;
}
e.writeUInt8(0, r);
}
};
}, {} ],
27: [ function(e, t, r) {
var n = e("buffer-xor");
r.encrypt = function(e, t) {
var r = n(t, e._prev);
e._prev = e._cipher.encryptBlock(r);
return e._prev;
};
r.decrypt = function(e, t) {
var r = e._prev;
e._prev = t;
var i = e._cipher.decryptBlock(t);
return n(i, r);
};
}, {
"buffer-xor": 64
} ],
28: [ function(e, t, r) {
var n = e("safe-buffer").Buffer, i = e("buffer-xor");
function o(e, t, r) {
var o = t.length, s = i(t, e._cache);
e._cache = e._cache.slice(o);
e._prev = n.concat([ e._prev, r ? t : s ]);
return s;
}
r.encrypt = function(e, t, r) {
for (var i, s = n.allocUnsafe(0); t.length; ) {
if (0 === e._cache.length) {
e._cache = e._cipher.encryptBlock(e._prev);
e._prev = n.allocUnsafe(0);
}
if (!(e._cache.length <= t.length)) {
s = n.concat([ s, o(e, t, r) ]);
break;
}
i = e._cache.length;
s = n.concat([ s, o(e, t.slice(0, i), r) ]);
t = t.slice(i);
}
return s;
};
}, {
"buffer-xor": 64,
"safe-buffer": 183
} ],
29: [ function(e, t, r) {
var n = e("safe-buffer").Buffer;
function i(e, t, r) {
for (var n, i, s = -1, a = 0; ++s < 8; ) {
n = t & 1 << 7 - s ? 128 : 0;
a += (128 & (i = e._cipher.encryptBlock(e._prev)[0] ^ n)) >> s % 8;
e._prev = o(e._prev, r ? n : i);
}
return a;
}
function o(e, t) {
var r = e.length, i = -1, o = n.allocUnsafe(e.length);
e = n.concat([ e, n.from([ t ]) ]);
for (;++i < r; ) o[i] = e[i] << 1 | e[i + 1] >> 7;
return o;
}
r.encrypt = function(e, t, r) {
for (var o = t.length, s = n.allocUnsafe(o), a = -1; ++a < o; ) s[a] = i(e, t[a], r);
return s;
};
}, {
"safe-buffer": 183
} ],
30: [ function(e, t, r) {
var n = e("safe-buffer").Buffer;
function i(e, t, r) {
var i = e._cipher.encryptBlock(e._prev)[0] ^ t;
e._prev = n.concat([ e._prev.slice(1), n.from([ r ? t : i ]) ]);
return i;
}
r.encrypt = function(e, t, r) {
for (var o = t.length, s = n.allocUnsafe(o), a = -1; ++a < o; ) s[a] = i(e, t[a], r);
return s;
};
}, {
"safe-buffer": 183
} ],
31: [ function(e, t, r) {
var n = e("buffer-xor"), i = e("safe-buffer").Buffer, o = e("../incr32");
function s(e) {
var t = e._cipher.encryptBlockRaw(e._prev);
o(e._prev);
return t;
}
r.encrypt = function(e, t) {
var r = Math.ceil(t.length / 16), o = e._cache.length;
e._cache = i.concat([ e._cache, i.allocUnsafe(16 * r) ]);
for (var a = 0; a < r; a++) {
var f = s(e), c = o + 16 * a;
e._cache.writeUInt32BE(f[0], c + 0);
e._cache.writeUInt32BE(f[1], c + 4);
e._cache.writeUInt32BE(f[2], c + 8);
e._cache.writeUInt32BE(f[3], c + 12);
}
var u = e._cache.slice(0, t.length);
e._cache = e._cache.slice(t.length);
return n(t, u);
};
}, {
"../incr32": 26,
"buffer-xor": 64,
"safe-buffer": 183
} ],
32: [ function(e, t, r) {
r.encrypt = function(e, t) {
return e._cipher.encryptBlock(t);
};
r.decrypt = function(e, t) {
return e._cipher.decryptBlock(t);
};
}, {} ],
33: [ function(e, t) {
var r = {
ECB: e("./ecb"),
CBC: e("./cbc"),
CFB: e("./cfb"),
CFB8: e("./cfb8"),
CFB1: e("./cfb1"),
OFB: e("./ofb"),
CTR: e("./ctr"),
GCM: e("./ctr")
}, n = e("./list.json");
for (var i in n) n[i].module = r[n[i].mode];
t.exports = n;
}, {
"./cbc": 27,
"./cfb": 28,
"./cfb1": 29,
"./cfb8": 30,
"./ctr": 31,
"./ecb": 32,
"./list.json": 34,
"./ofb": 35
} ],
34: [ function(e, t) {
t.exports = {
"aes-128-ecb": {
cipher: "AES",
key: 128,
iv: 0,
mode: "ECB",
type: "block"
},
"aes-192-ecb": {
cipher: "AES",
key: 192,
iv: 0,
mode: "ECB",
type: "block"
},
"aes-256-ecb": {
cipher: "AES",
key: 256,
iv: 0,
mode: "ECB",
type: "block"
},
"aes-128-cbc": {
cipher: "AES",
key: 128,
iv: 16,
mode: "CBC",
type: "block"
},
"aes-192-cbc": {
cipher: "AES",
key: 192,
iv: 16,
mode: "CBC",
type: "block"
},
"aes-256-cbc": {
cipher: "AES",
key: 256,
iv: 16,
mode: "CBC",
type: "block"
},
aes128: {
cipher: "AES",
key: 128,
iv: 16,
mode: "CBC",
type: "block"
},
aes192: {
cipher: "AES",
key: 192,
iv: 16,
mode: "CBC",
type: "block"
},
aes256: {
cipher: "AES",
key: 256,
iv: 16,
mode: "CBC",
type: "block"
},
"aes-128-cfb": {
cipher: "AES",
key: 128,
iv: 16,
mode: "CFB",
type: "stream"
},
"aes-192-cfb": {
cipher: "AES",
key: 192,
iv: 16,
mode: "CFB",
type: "stream"
},
"aes-256-cfb": {
cipher: "AES",
key: 256,
iv: 16,
mode: "CFB",
type: "stream"
},
"aes-128-cfb8": {
cipher: "AES",
key: 128,
iv: 16,
mode: "CFB8",
type: "stream"
},
"aes-192-cfb8": {
cipher: "AES",
key: 192,
iv: 16,
mode: "CFB8",
type: "stream"
},
"aes-256-cfb8": {
cipher: "AES",
key: 256,
iv: 16,
mode: "CFB8",
type: "stream"
},
"aes-128-cfb1": {
cipher: "AES",
key: 128,
iv: 16,
mode: "CFB1",
type: "stream"
},
"aes-192-cfb1": {
cipher: "AES",
key: 192,
iv: 16,
mode: "CFB1",
type: "stream"
},
"aes-256-cfb1": {
cipher: "AES",
key: 256,
iv: 16,
mode: "CFB1",
type: "stream"
},
"aes-128-ofb": {
cipher: "AES",
key: 128,
iv: 16,
mode: "OFB",
type: "stream"
},
"aes-192-ofb": {
cipher: "AES",
key: 192,
iv: 16,
mode: "OFB",
type: "stream"
},
"aes-256-ofb": {
cipher: "AES",
key: 256,
iv: 16,
mode: "OFB",
type: "stream"
},
"aes-128-ctr": {
cipher: "AES",
key: 128,
iv: 16,
mode: "CTR",
type: "stream"
},
"aes-192-ctr": {
cipher: "AES",
key: 192,
iv: 16,
mode: "CTR",
type: "stream"
},
"aes-256-ctr": {
cipher: "AES",
key: 256,
iv: 16,
mode: "CTR",
type: "stream"
},
"aes-128-gcm": {
cipher: "AES",
key: 128,
iv: 12,
mode: "GCM",
type: "auth"
},
"aes-192-gcm": {
cipher: "AES",
key: 192,
iv: 12,
mode: "GCM",
type: "auth"
},
"aes-256-gcm": {
cipher: "AES",
key: 256,
iv: 12,
mode: "GCM",
type: "auth"
}
};
}, {} ],
35: [ function(e, t, r) {
(function(t) {
var n = e("buffer-xor");
function i(e) {
e._prev = e._cipher.encryptBlock(e._prev);
return e._prev;
}
r.encrypt = function(e, r) {
for (;e._cache.length < r.length; ) e._cache = t.concat([ e._cache, i(e) ]);
var o = e._cache.slice(0, r.length);
e._cache = e._cache.slice(r.length);
return n(r, o);
};
}).call(this, e("buffer").Buffer);
}, {
buffer: 65,
"buffer-xor": 64
} ],
36: [ function(e, t) {
var r = e("./aes"), n = e("safe-buffer").Buffer, i = e("cipher-base");
function o(e, t, o, s) {
i.call(this);
this._cipher = new r.AES(t);
this._prev = n.from(o);
this._cache = n.allocUnsafe(0);
this._secCache = n.allocUnsafe(0);
this._decrypt = s;
this._mode = e;
}
e("inherits")(o, i);
o.prototype._update = function(e) {
return this._mode.encrypt(this, e, this._decrypt);
};
o.prototype._final = function() {
this._cipher.scrub();
};
t.exports = o;
}, {
"./aes": 20,
"cipher-base": 67,
inherits: 138,
"safe-buffer": 183
} ],
37: [ function(e, t, r) {
var n = e("browserify-des"), i = e("browserify-aes/browser"), o = e("browserify-aes/modes"), s = e("browserify-des/modes"), a = e("evp_bytestokey");
function f(e, t, r) {
e = e.toLowerCase();
if (o[e]) return i.createCipheriv(e, t, r);
if (s[e]) return new n({
key: t,
iv: r,
mode: e
});
throw new TypeError("invalid suite type");
}
function c(e, t, r) {
e = e.toLowerCase();
if (o[e]) return i.createDecipheriv(e, t, r);
if (s[e]) return new n({
key: t,
iv: r,
mode: e,
decrypt: !0
});
throw new TypeError("invalid suite type");
}
r.createCipher = r.Cipher = function(e, t) {
e = e.toLowerCase();
var r, n;
if (o[e]) {
r = o[e].key;
n = o[e].iv;
} else {
if (!s[e]) throw new TypeError("invalid suite type");
r = 8 * s[e].key;
n = s[e].iv;
}
var i = a(t, !1, r, n);
return f(e, i.key, i.iv);
};
r.createCipheriv = r.Cipheriv = f;
r.createDecipher = r.Decipher = function(e, t) {
e = e.toLowerCase();
var r, n;
if (o[e]) {
r = o[e].key;
n = o[e].iv;
} else {
if (!s[e]) throw new TypeError("invalid suite type");
r = 8 * s[e].key;
n = s[e].iv;
}
var i = a(t, !1, r, n);
return c(e, i.key, i.iv);
};
r.createDecipheriv = r.Decipheriv = c;
r.listCiphers = r.getCiphers = function() {
return Object.keys(s).concat(i.getCiphers());
};
}, {
"browserify-aes/browser": 22,
"browserify-aes/modes": 33,
"browserify-des": 38,
"browserify-des/modes": 39,
evp_bytestokey: 105
} ],
38: [ function(e, t) {
var r = e("cipher-base"), n = e("des.js"), i = e("inherits"), o = e("safe-buffer").Buffer, s = {
"des-ede3-cbc": n.CBC.instantiate(n.EDE),
"des-ede3": n.EDE,
"des-ede-cbc": n.CBC.instantiate(n.EDE),
"des-ede": n.EDE,
"des-cbc": n.CBC.instantiate(n.DES),
"des-ecb": n.DES
};
s.des = s["des-cbc"];
s.des3 = s["des-ede3-cbc"];
t.exports = a;
i(a, r);
function a(e) {
r.call(this);
var t, n = e.mode.toLowerCase(), i = s[n];
t = e.decrypt ? "decrypt" : "encrypt";
var a = e.key;
o.isBuffer(a) || (a = o.from(a));
"des-ede" !== n && "des-ede-cbc" !== n || (a = o.concat([ a, a.slice(0, 8) ]));
var f = e.iv;
o.isBuffer(f) || (f = o.from(f));
this._des = i.create({
key: a,
iv: f,
type: t
});
}
a.prototype._update = function(e) {
return o.from(this._des.update(e));
};
a.prototype._final = function() {
return o.from(this._des.final());
};
}, {
"cipher-base": 67,
"des.js": 76,
inherits: 138,
"safe-buffer": 183
} ],
39: [ function(e, t, r) {
r["des-ecb"] = {
key: 8,
iv: 0
};
r["des-cbc"] = r.des = {
key: 8,
iv: 8
};
r["des-ede3-cbc"] = r.des3 = {
key: 24,
iv: 8
};
r["des-ede3"] = {
key: 24,
iv: 0
};
r["des-ede-cbc"] = {
key: 16,
iv: 8
};
r["des-ede"] = {
key: 16,
iv: 0
};
}, {} ],
40: [ function(e, t) {
(function(r) {
var n = e("bn.js"), i = e("randombytes");
function o(e) {
var t = s(e);
return {
blinder: t.toRed(n.mont(e.modulus)).redPow(new n(e.publicExponent)).fromRed(),
unblinder: t.invm(e.modulus)
};
}
function s(e) {
var t, r = e.modulus.byteLength();
do {
t = new n(i(r));
} while (t.cmp(e.modulus) >= 0 || !t.umod(e.prime1) || !t.umod(e.prime2));
return t;
}
function a(e, t) {
var i = o(t), s = t.modulus.byteLength(), a = new n(e).mul(i.blinder).umod(t.modulus), f = a.toRed(n.mont(t.prime1)), c = a.toRed(n.mont(t.prime2)), u = t.coefficient, h = t.prime1, d = t.prime2, l = f.redPow(t.exponent1).fromRed(), p = c.redPow(t.exponent2).fromRed(), b = l.isub(p).imul(u).umod(h).imul(d);
return p.iadd(b).imul(i.unblinder).umod(t.modulus).toArrayLike(r, "be", s);
}
a.getr = s;
t.exports = a;
}).call(this, e("buffer").Buffer);
}, {
"bn.js": 17,
buffer: 65,
randombytes: 165
} ],
41: [ function(e, t) {
t.exports = e("./browser/algorithms.json");
}, {
"./browser/algorithms.json": 42
} ],
42: [ function(e, t) {
t.exports = {
sha224WithRSAEncryption: {
sign: "rsa",
hash: "sha224",
id: "302d300d06096086480165030402040500041c"
},
"RSA-SHA224": {
sign: "ecdsa/rsa",
hash: "sha224",
id: "302d300d06096086480165030402040500041c"
},
sha256WithRSAEncryption: {
sign: "rsa",
hash: "sha256",
id: "3031300d060960864801650304020105000420"
},
"RSA-SHA256": {
sign: "ecdsa/rsa",
hash: "sha256",
id: "3031300d060960864801650304020105000420"
},
sha384WithRSAEncryption: {
sign: "rsa",
hash: "sha384",
id: "3041300d060960864801650304020205000430"
},
"RSA-SHA384": {
sign: "ecdsa/rsa",
hash: "sha384",
id: "3041300d060960864801650304020205000430"
},
sha512WithRSAEncryption: {
sign: "rsa",
hash: "sha512",
id: "3051300d060960864801650304020305000440"
},
"RSA-SHA512": {
sign: "ecdsa/rsa",
hash: "sha512",
id: "3051300d060960864801650304020305000440"
},
"RSA-SHA1": {
sign: "rsa",
hash: "sha1",
id: "3021300906052b0e03021a05000414"
},
"ecdsa-with-SHA1": {
sign: "ecdsa",
hash: "sha1",
id: ""
},
sha256: {
sign: "ecdsa",
hash: "sha256",
id: ""
},
sha224: {
sign: "ecdsa",
hash: "sha224",
id: ""
},
sha384: {
sign: "ecdsa",
hash: "sha384",
id: ""
},
sha512: {
sign: "ecdsa",
hash: "sha512",
id: ""
},
"DSA-SHA": {
sign: "dsa",
hash: "sha1",
id: ""
},
"DSA-SHA1": {
sign: "dsa",
hash: "sha1",
id: ""
},
DSA: {
sign: "dsa",
hash: "sha1",
id: ""
},
"DSA-WITH-SHA224": {
sign: "dsa",
hash: "sha224",
id: ""
},
"DSA-SHA224": {
sign: "dsa",
hash: "sha224",
id: ""
},
"DSA-WITH-SHA256": {
sign: "dsa",
hash: "sha256",
id: ""
},
"DSA-SHA256": {
sign: "dsa",
hash: "sha256",
id: ""
},
"DSA-WITH-SHA384": {
sign: "dsa",
hash: "sha384",
id: ""
},
"DSA-SHA384": {
sign: "dsa",
hash: "sha384",
id: ""
},
"DSA-WITH-SHA512": {
sign: "dsa",
hash: "sha512",
id: ""
},
"DSA-SHA512": {
sign: "dsa",
hash: "sha512",
id: ""
},
"DSA-RIPEMD160": {
sign: "dsa",
hash: "rmd160",
id: ""
},
ripemd160WithRSA: {
sign: "rsa",
hash: "rmd160",
id: "3021300906052b2403020105000414"
},
"RSA-RIPEMD160": {
sign: "rsa",
hash: "rmd160",
id: "3021300906052b2403020105000414"
},
md5WithRSAEncryption: {
sign: "rsa",
hash: "md5",
id: "3020300c06082a864886f70d020505000410"
},
"RSA-MD5": {
sign: "rsa",
hash: "md5",
id: "3020300c06082a864886f70d020505000410"
}
};
}, {} ],
43: [ function(e, t) {
t.exports = {
"1.3.132.0.10": "secp256k1",
"1.3.132.0.33": "p224",
"1.2.840.10045.3.1.1": "p192",
"1.2.840.10045.3.1.7": "p256",
"1.3.132.0.34": "p384",
"1.3.132.0.35": "p521"
};
}, {} ],
44: [ function(e, t) {
var r = e("safe-buffer").Buffer, n = e("create-hash"), i = e("readable-stream"), o = e("inherits"), s = e("./sign"), a = e("./verify"), f = e("./algorithms.json");
Object.keys(f).forEach(function(e) {
f[e].id = r.from(f[e].id, "hex");
f[e.toLowerCase()] = f[e];
});
function c(e) {
i.Writable.call(this);
var t = f[e];
if (!t) throw new Error("Unknown message digest");
this._hashType = t.hash;
this._hash = n(t.hash);
this._tag = t.id;
this._signType = t.sign;
}
o(c, i.Writable);
c.prototype._write = function(e, t, r) {
this._hash.update(e);
r();
};
c.prototype.update = function(e, t) {
"string" == typeof e && (e = r.from(e, t));
this._hash.update(e);
return this;
};
c.prototype.sign = function(e, t) {
this.end();
var r = this._hash.digest(), n = s(r, e, this._hashType, this._signType, this._tag);
return t ? n.toString(t) : n;
};
function u(e) {
i.Writable.call(this);
var t = f[e];
if (!t) throw new Error("Unknown message digest");
this._hash = n(t.hash);
this._tag = t.id;
this._signType = t.sign;
}
o(u, i.Writable);
u.prototype._write = function(e, t, r) {
this._hash.update(e);
r();
};
u.prototype.update = function(e, t) {
"string" == typeof e && (e = r.from(e, t));
this._hash.update(e);
return this;
};
u.prototype.verify = function(e, t, n) {
"string" == typeof t && (t = r.from(t, n));
this.end();
var i = this._hash.digest();
return a(t, i, e, this._signType, this._tag);
};
function h(e) {
return new c(e);
}
function d(e) {
return new u(e);
}
t.exports = {
Sign: h,
Verify: d,
createSign: h,
createVerify: d
};
}, {
"./algorithms.json": 42,
"./sign": 45,
"./verify": 46,
"create-hash": 71,
inherits: 138,
"readable-stream": 61,
"safe-buffer": 62
} ],
45: [ function(e, t) {
var r = e("safe-buffer").Buffer, n = e("create-hmac"), i = e("browserify-rsa"), o = e("elliptic").ec, s = e("bn.js"), a = e("parse-asn1"), f = e("./curves.json");
function c(e, t) {
var n = f[t.curve.join(".")];
if (!n) throw new Error("unknown curve " + t.curve.join("."));
var i = new o(n).keyFromPrivate(t.privateKey).sign(e);
return r.from(i.toDER());
}
function u(e, t, r) {
for (var n, i = t.params.priv_key, o = t.params.p, a = t.params.q, f = t.params.g, c = new s(0), u = l(e, a).mod(a), p = !1, v = d(i, a, e, r); !1 === p; ) {
c = m(f, n = b(a, v, r), o, a);
if (0 === (p = n.invm(a).imul(u.add(i.mul(c))).mod(a)).cmpn(0)) {
p = !1;
c = new s(0);
}
}
return h(c, p);
}
function h(e, t) {
e = e.toArray();
t = t.toArray();
128 & e[0] && (e = [ 0 ].concat(e));
128 & t[0] && (t = [ 0 ].concat(t));
var n = [ 48, e.length + t.length + 4, 2, e.length ];
n = n.concat(e, [ 2, t.length ], t);
return r.from(n);
}
function d(e, t, i, o) {
if ((e = r.from(e.toArray())).length < t.byteLength()) {
var s = r.alloc(t.byteLength() - e.length);
e = r.concat([ s, e ]);
}
var a = i.length, f = p(i, t), c = r.alloc(a);
c.fill(1);
var u = r.alloc(a);
u = n(o, u).update(c).update(r.from([ 0 ])).update(e).update(f).digest();
c = n(o, u).update(c).digest();
return {
k: u = n(o, u).update(c).update(r.from([ 1 ])).update(e).update(f).digest(),
v: c = n(o, u).update(c).digest()
};
}
function l(e, t) {
var r = new s(e), n = (e.length << 3) - t.bitLength();
n > 0 && r.ishrn(n);
return r;
}
function p(e, t) {
e = (e = l(e, t)).mod(t);
var n = r.from(e.toArray());
if (n.length < t.byteLength()) {
var i = r.alloc(t.byteLength() - n.length);
n = r.concat([ i, n ]);
}
return n;
}
function b(e, t, i) {
var o, s;
do {
o = r.alloc(0);
for (;8 * o.length < e.bitLength(); ) {
t.v = n(i, t.k).update(t.v).digest();
o = r.concat([ o, t.v ]);
}
s = l(o, e);
t.k = n(i, t.k).update(t.v).update(r.from([ 0 ])).digest();
t.v = n(i, t.k).update(t.v).digest();
} while (-1 !== s.cmp(e));
return s;
}
function m(e, t, r, n) {
return e.toRed(s.mont(r)).redPow(t).fromRed().mod(n);
}
t.exports = function(e, t, n, o, s) {
var f = a(t);
if (f.curve) {
if ("ecdsa" !== o && "ecdsa/rsa" !== o) throw new Error("wrong private key type");
return c(e, f);
}
if ("dsa" === f.type) {
if ("dsa" !== o) throw new Error("wrong private key type");
return u(e, f, n);
}
if ("rsa" !== o && "ecdsa/rsa" !== o) throw new Error("wrong private key type");
e = r.concat([ s, e ]);
for (var h = f.modulus.byteLength(), d = [ 0, 1 ]; e.length + d.length + 1 < h; ) d.push(255);
d.push(0);
for (var l = -1; ++l < e.length; ) d.push(e[l]);
return i(d, f);
};
t.exports.getKey = d;
t.exports.makeKey = b;
}, {
"./curves.json": 43,
"bn.js": 17,
"browserify-rsa": 40,
"create-hmac": 73,
elliptic: 87,
"parse-asn1": 149,
"safe-buffer": 62
} ],
46: [ function(e, t) {
var r = e("safe-buffer").Buffer, n = e("bn.js"), i = e("elliptic").ec, o = e("parse-asn1"), s = e("./curves.json");
function a(e, t, r) {
var n = s[r.data.algorithm.curve.join(".")];
if (!n) throw new Error("unknown curve " + r.data.algorithm.curve.join("."));
var o = new i(n), a = r.data.subjectPrivateKey.data;
return o.verify(t, e, a);
}
function f(e, t, r) {
var i = r.data.p, s = r.data.q, a = r.data.g, f = r.data.pub_key, u = o.signature.decode(e, "der"), h = u.s, d = u.r;
c(h, s);
c(d, s);
var l = n.mont(i), p = h.invm(s);
return 0 === a.toRed(l).redPow(new n(t).mul(p).mod(s)).fromRed().mul(f.toRed(l).redPow(d.mul(p).mod(s)).fromRed()).mod(i).mod(s).cmp(d);
}
function c(e, t) {
if (e.cmpn(0) <= 0) throw new Error("invalid sig");
if (e.cmp(t) >= t) throw new Error("invalid sig");
}
t.exports = function(e, t, i, s, c) {
var u = o(i);
if ("ec" === u.type) {
if ("ecdsa" !== s && "ecdsa/rsa" !== s) throw new Error("wrong public key type");
return a(e, t, u);
}
if ("dsa" === u.type) {
if ("dsa" !== s) throw new Error("wrong public key type");
return f(e, t, u);
}
if ("rsa" !== s && "ecdsa/rsa" !== s) throw new Error("wrong public key type");
t = r.concat([ c, t ]);
for (var h = u.modulus.byteLength(), d = [ 1 ], l = 0; t.length + d.length + 2 < h; ) {
d.push(255);
l++;
}
d.push(0);
for (var p = -1; ++p < t.length; ) d.push(t[p]);
d = r.from(d);
var b = n.mont(u.modulus);
e = (e = new n(e).toRed(b)).redPow(new n(u.publicExponent));
e = r.from(e.fromRed().toArray());
var m = l < 8 ? 1 : 0;
h = Math.min(e.length, d.length);
e.length !== d.length && (m = 1);
p = -1;
for (;++p < h; ) m |= e[p] ^ d[p];
return 0 === m;
};
}, {
"./curves.json": 43,
"bn.js": 17,
elliptic: 87,
"parse-asn1": 149,
"safe-buffer": 62
} ],
47: [ function(e, t) {
"use strict";
function r(e, t) {
e.prototype = Object.create(t.prototype);
e.prototype.constructor = e;
e.__proto__ = t;
}
var n = {};
function i(e, t, i) {
i || (i = Error);
function o(e, r, n) {
return "string" == typeof t ? t : t(e, r, n);
}
var s = function(e) {
r(t, e);
function t(t, r, n) {
return e.call(this, o(t, r, n)) || this;
}
return t;
}(i);
s.prototype.name = i.name;
s.prototype.code = e;
n[e] = s;
}
function o(e, t) {
if (Array.isArray(e)) {
var r = e.length;
e = e.map(function(e) {
return String(e);
});
return r > 2 ? "one of ".concat(t, " ").concat(e.slice(0, r - 1).join(", "), ", or ") + e[r - 1] : 2 === r ? "one of ".concat(t, " ").concat(e[0], " or ").concat(e[1]) : "of ".concat(t, " ").concat(e[0]);
}
return "of ".concat(t, " ").concat(String(e));
}
function s(e, t, r) {
(void 0 === r || r > e.length) && (r = e.length);
return e.substring(r - t.length, r) === t;
}
function a(e, t, r) {
"number" != typeof r && (r = 0);
return !(r + t.length > e.length) && -1 !== e.indexOf(t, r);
}
i("ERR_INVALID_OPT_VALUE", function(e, t) {
return 'The value "' + t + '" is invalid for option "' + e + '"';
}, TypeError);
i("ERR_INVALID_ARG_TYPE", function(e, t, r) {
var n, i;
if ("string" == typeof t && ("not ", "not " === t.substr(0, "not ".length))) {
n = "must not be";
t = t.replace(/^not /, "");
} else n = "must be";
if (s(e, " argument")) i = "The ".concat(e, " ").concat(n, " ").concat(o(t, "type")); else {
var f = a(e, ".") ? "property" : "argument";
i = 'The "'.concat(e, '" ').concat(f, " ").concat(n, " ").concat(o(t, "type"));
}
return i + ". Received type ".concat(typeof r);
}, TypeError);
i("ERR_STREAM_PUSH_AFTER_EOF", "stream.push() after EOF");
i("ERR_METHOD_NOT_IMPLEMENTED", function(e) {
return "The " + e + " method is not implemented";
});
i("ERR_STREAM_PREMATURE_CLOSE", "Premature close");
i("ERR_STREAM_DESTROYED", function(e) {
return "Cannot call " + e + " after a stream was destroyed";
});
i("ERR_MULTIPLE_CALLBACK", "Callback called multiple times");
i("ERR_STREAM_CANNOT_PIPE", "Cannot pipe, not readable");
i("ERR_STREAM_WRITE_AFTER_END", "write after end");
i("ERR_STREAM_NULL_VALUES", "May not write null values to stream", TypeError);
i("ERR_UNKNOWN_ENCODING", function(e) {
return "Unknown encoding: " + e;
}, TypeError);
i("ERR_STREAM_UNSHIFT_AFTER_END_EVENT", "stream.unshift() after end event");
t.exports.codes = n;
}, {} ],
48: [ function(e, t) {
(function(r) {
"use strict";
var n = Object.keys || function(e) {
var t = [];
for (var r in e) t.push(r);
return t;
};
t.exports = c;
var i = e("./_stream_readable"), o = e("./_stream_writable");
e("inherits")(c, i);
for (var s = n(o.prototype), a = 0; a < s.length; a++) {
var f = s[a];
c.prototype[f] || (c.prototype[f] = o.prototype[f]);
}
function c(e) {
if (!(this instanceof c)) return new c(e);
i.call(this, e);
o.call(this, e);
this.allowHalfOpen = !0;
if (e) {
!1 === e.readable && (this.readable = !1);
!1 === e.writable && (this.writable = !1);
if (!1 === e.allowHalfOpen) {
this.allowHalfOpen = !1;
this.once("end", u);
}
}
}
Object.defineProperty(c.prototype, "writableHighWaterMark", {
enumerable: !1,
get: function() {
return this._writableState.highWaterMark;
}
});
Object.defineProperty(c.prototype, "writableBuffer", {
enumerable: !1,
get: function() {
return this._writableState && this._writableState.getBuffer();
}
});
Object.defineProperty(c.prototype, "writableLength", {
enumerable: !1,
get: function() {
return this._writableState.length;
}
});
function u() {
this._writableState.ended || r.nextTick(h, this);
}
function h(e) {
e.end();
}
Object.defineProperty(c.prototype, "destroyed", {
enumerable: !1,
get: function() {
return void 0 !== this._readableState && void 0 !== this._writableState && this._readableState.destroyed && this._writableState.destroyed;
},
set: function(e) {
if (void 0 !== this._readableState && void 0 !== this._writableState) {
this._readableState.destroyed = e;
this._writableState.destroyed = e;
}
}
});
}).call(this, e("_process"));
}, {
"./_stream_readable": 50,
"./_stream_writable": 52,
_process: 157,
inherits: 138
} ],
49: [ function(e, t) {
"use strict";
t.exports = n;
var r = e("./_stream_transform");
e("inherits")(n, r);
function n(e) {
if (!(this instanceof n)) return new n(e);
r.call(this, e);
}
n.prototype._transform = function(e, t, r) {
r(null, e);
};
}, {
"./_stream_transform": 51,
inherits: 138
} ],
50: [ function(e, t) {
(function(r, n) {
"use strict";
t.exports = k;
var i;
k.ReadableState = x;
e("events").EventEmitter;
var o = function(e, t) {
return e.listeners(t).length;
}, s = e("./internal/streams/stream"), a = e("buffer").Buffer, f = n.Uint8Array || function() {};
function c(e) {
return a.from(e);
}
var u, h = e("util");
u = h && h.debuglog ? h.debuglog("stream") : function() {};
var d, l, p, b = e("./internal/streams/buffer_list"), m = e("./internal/streams/destroy"), v = e("./internal/streams/state").getHighWaterMark, y = e("../errors").codes, g = y.ERR_INVALID_ARG_TYPE, _ = y.ERR_STREAM_PUSH_AFTER_EOF, w = y.ERR_METHOD_NOT_IMPLEMENTED, E = y.ERR_STREAM_UNSHIFT_AFTER_END_EVENT;
e("inherits")(k, s);
var S = m.errorOrDestroy, M = [ "error", "close", "destroy", "pause", "resume" ];
function A(e, t, r) {
if ("function" == typeof e.prependListener) return e.prependListener(t, r);
e._events && e._events[t] ? Array.isArray(e._events[t]) ? e._events[t].unshift(r) : e._events[t] = [ r, e._events[t] ] : e.on(t, r);
}
function x(t, r, n) {
i = i || e("./_stream_duplex");
t = t || {};
"boolean" != typeof n && (n = r instanceof i);
this.objectMode = !!t.objectMode;
n && (this.objectMode = this.objectMode || !!t.readableObjectMode);
this.highWaterMark = v(this, t, "readableHighWaterMark", n);
this.buffer = new b();
this.length = 0;
this.pipes = null;
this.pipesCount = 0;
this.flowing = null;
this.ended = !1;
this.endEmitted = !1;
this.reading = !1;
this.sync = !0;
this.needReadable = !1;
this.emittedReadable = !1;
this.readableListening = !1;
this.resumeScheduled = !1;
this.paused = !0;
this.emitClose = !1 !== t.emitClose;
this.autoDestroy = !!t.autoDestroy;
this.destroyed = !1;
this.defaultEncoding = t.defaultEncoding || "utf8";
this.awaitDrain = 0;
this.readingMore = !1;
this.decoder = null;
this.encoding = null;
if (t.encoding) {
d || (d = e("string_decoder/").StringDecoder);
this.decoder = new d(t.encoding);
this.encoding = t.encoding;
}
}
function k(t) {
i = i || e("./_stream_duplex");
if (!(this instanceof k)) return new k(t);
var r = this instanceof i;
this._readableState = new x(t, this, r);
this.readable = !0;
if (t) {
"function" == typeof t.read && (this._read = t.read);
"function" == typeof t.destroy && (this._destroy = t.destroy);
}
s.call(this);
}
Object.defineProperty(k.prototype, "destroyed", {
enumerable: !1,
get: function() {
return void 0 !== this._readableState && this._readableState.destroyed;
},
set: function(e) {
this._readableState && (this._readableState.destroyed = e);
}
});
k.prototype.destroy = m.destroy;
k.prototype._undestroy = m.undestroy;
k.prototype._destroy = function(e, t) {
t(e);
};
k.prototype.push = function(e, t) {
var r, n = this._readableState;
if (n.objectMode) r = !0; else if ("string" == typeof e) {
if ((t = t || n.defaultEncoding) !== n.encoding) {
e = a.from(e, t);
t = "";
}
r = !0;
}
return T(this, e, t, !1, r);
};
k.prototype.unshift = function(e) {
return T(this, e, null, !0, !1);
};
function T(e, t, r, n, i) {
u("readableAddChunk", t);
var o = e._readableState;
if (null === t) {
o.reading = !1;
j(e, o);
} else {
var s;
i || (s = O(o, t));
if (s) S(e, s); else if (o.objectMode || t && t.length > 0) {
"string" == typeof t || o.objectMode || Object.getPrototypeOf(t) === a.prototype || (t = c(t));
if (n) o.endEmitted ? S(e, new E()) : I(e, o, t, !0); else if (o.ended) S(e, new _()); else {
if (o.destroyed) return !1;
o.reading = !1;
if (o.decoder && !r) {
t = o.decoder.write(t);
o.objectMode || 0 !== t.length ? I(e, o, t, !1) : L(e, o);
} else I(e, o, t, !1);
}
} else if (!n) {
o.reading = !1;
L(e, o);
}
}
return !o.ended && (o.length < o.highWaterMark || 0 === o.length);
}
function I(e, t, r, n) {
if (t.flowing && 0 === t.length && !t.sync) {
t.awaitDrain = 0;
e.emit("data", r);
} else {
t.length += t.objectMode ? 1 : r.length;
n ? t.buffer.unshift(r) : t.buffer.push(r);
t.needReadable && P(e);
}
L(e, t);
}
function O(e, t) {
var r, n;
(n = t, a.isBuffer(n) || n instanceof f) || "string" == typeof t || void 0 === t || e.objectMode || (r = new g("chunk", [ "string", "Buffer", "Uint8Array" ], t));
return r;
}
k.prototype.isPaused = function() {
return !1 === this._readableState.flowing;
};
k.prototype.setEncoding = function(t) {
d || (d = e("string_decoder/").StringDecoder);
var r = new d(t);
this._readableState.decoder = r;
this._readableState.encoding = this._readableState.decoder.encoding;
for (var n = this._readableState.buffer.head, i = ""; null !== n; ) {
i += r.write(n.data);
n = n.next;
}
this._readableState.buffer.clear();
"" !== i && this._readableState.buffer.push(i);
this._readableState.length = i.length;
return this;
};
var R = 1073741824;
function C(e) {
if (e >= R) e = R; else {
e--;
e |= e >>> 1;
e |= e >>> 2;
e |= e >>> 4;
e |= e >>> 8;
e |= e >>> 16;
e++;
}
return e;
}
function N(e, t) {
if (e <= 0 || 0 === t.length && t.ended) return 0;
if (t.objectMode) return 1;
if (e != e) return t.flowing && t.length ? t.buffer.head.data.length : t.length;
e > t.highWaterMark && (t.highWaterMark = C(e));
if (e <= t.length) return e;
if (!t.ended) {
t.needReadable = !0;
return 0;
}
return t.length;
}
k.prototype.read = function(e) {
u("read", e);
e = parseInt(e, 10);
var t = this._readableState, r = e;
0 !== e && (t.emittedReadable = !1);
if (0 === e && t.needReadable && ((0 !== t.highWaterMark ? t.length >= t.highWaterMark : t.length > 0) || t.ended)) {
u("read: emitReadable", t.length, t.ended);
0 === t.length && t.ended ? W(this) : P(this);
return null;
}
if (0 === (e = N(e, t)) && t.ended) {
0 === t.length && W(this);
return null;
}
var n, i = t.needReadable;
u("need readable", i);
(0 === t.length || t.length - e < t.highWaterMark) && u("length less than watermark", i = !0);
if (t.ended || t.reading) u("reading or ended", i = !1); else if (i) {
u("do read");
t.reading = !0;
t.sync = !0;
0 === t.length && (t.needReadable = !0);
this._read(t.highWaterMark);
t.sync = !1;
t.reading || (e = N(r, t));
}
if (null === (n = e > 0 ? G(e, t) : null)) {
t.needReadable = t.length <= t.highWaterMark;
e = 0;
} else {
t.length -= e;
t.awaitDrain = 0;
}
if (0 === t.length) {
t.ended || (t.needReadable = !0);
r !== e && t.ended && W(this);
}
null !== n && this.emit("data", n);
return n;
};
function j(e, t) {
u("onEofChunk");
if (!t.ended) {
if (t.decoder) {
var r = t.decoder.end();
if (r && r.length) {
t.buffer.push(r);
t.length += t.objectMode ? 1 : r.length;
}
}
t.ended = !0;
if (t.sync) P(e); else {
t.needReadable = !1;
if (!t.emittedReadable) {
t.emittedReadable = !0;
D(e);
}
}
}
}
function P(e) {
var t = e._readableState;
u("emitReadable", t.needReadable, t.emittedReadable);
t.needReadable = !1;
if (!t.emittedReadable) {
u("emitReadable", t.flowing);
t.emittedReadable = !0;
r.nextTick(D, e);
}
}
function D(e) {
var t = e._readableState;
u("emitReadable_", t.destroyed, t.length, t.ended);
if (!t.destroyed && (t.length || t.ended)) {
e.emit("readable");
t.emittedReadable = !1;
}
t.needReadable = !t.flowing && !t.ended && t.length <= t.highWaterMark;
z(e);
}
function L(e, t) {
if (!t.readingMore) {
t.readingMore = !0;
r.nextTick(B, e, t);
}
}
function B(e, t) {
for (;!t.reading && !t.ended && (t.length < t.highWaterMark || t.flowing && 0 === t.length); ) {
var r = t.length;
u("maybeReadMore read 0");
e.read(0);
if (r === t.length) break;
}
t.readingMore = !1;
}
k.prototype._read = function() {
S(this, new w("_read()"));
};
k.prototype.pipe = function(e, t) {
var n = this, i = this._readableState;
switch (i.pipesCount) {
case 0:
i.pipes = e;
break;

case 1:
i.pipes = [ i.pipes, e ];
break;

default:
i.pipes.push(e);
}
i.pipesCount += 1;
u("pipe count=%d opts=%j", i.pipesCount, t);
var s = t && !1 === t.end || e === r.stdout || e === r.stderr ? v : f;
i.endEmitted ? r.nextTick(s) : n.once("end", s);
e.on("unpipe", a);
function a(e, t) {
u("onunpipe");
if (e === n && t && !1 === t.hasUnpiped) {
t.hasUnpiped = !0;
d();
}
}
function f() {
u("onend");
e.end();
}
var c = U(n);
e.on("drain", c);
var h = !1;
function d() {
u("cleanup");
e.removeListener("close", b);
e.removeListener("finish", m);
e.removeListener("drain", c);
e.removeListener("error", p);
e.removeListener("unpipe", a);
n.removeListener("end", f);
n.removeListener("end", v);
n.removeListener("data", l);
h = !0;
!i.awaitDrain || e._writableState && !e._writableState.needDrain || c();
}
n.on("data", l);
function l(t) {
u("ondata");
var r = e.write(t);
u("dest.write", r);
if (!1 === r) {
if ((1 === i.pipesCount && i.pipes === e || i.pipesCount > 1 && -1 !== Y(i.pipes, e)) && !h) {
u("false write response, pause", i.awaitDrain);
i.awaitDrain++;
}
n.pause();
}
}
function p(t) {
u("onerror", t);
v();
e.removeListener("error", p);
0 === o(e, "error") && S(e, t);
}
A(e, "error", p);
function b() {
e.removeListener("finish", m);
v();
}
e.once("close", b);
function m() {
u("onfinish");
e.removeListener("close", b);
v();
}
e.once("finish", m);
function v() {
u("unpipe");
n.unpipe(e);
}
e.emit("pipe", n);
if (!i.flowing) {
u("pipe resume");
n.resume();
}
return e;
};
function U(e) {
return function() {
var t = e._readableState;
u("pipeOnDrain", t.awaitDrain);
t.awaitDrain && t.awaitDrain--;
if (0 === t.awaitDrain && o(e, "data")) {
t.flowing = !0;
z(e);
}
};
}
k.prototype.unpipe = function(e) {
var t = this._readableState, r = {
hasUnpiped: !1
};
if (0 === t.pipesCount) return this;
if (1 === t.pipesCount) {
if (e && e !== t.pipes) return this;
e || (e = t.pipes);
t.pipes = null;
t.pipesCount = 0;
t.flowing = !1;
e && e.emit("unpipe", this, r);
return this;
}
if (!e) {
var n = t.pipes, i = t.pipesCount;
t.pipes = null;
t.pipesCount = 0;
t.flowing = !1;
for (var o = 0; o < i; o++) n[o].emit("unpipe", this, {
hasUnpiped: !1
});
return this;
}
var s = Y(t.pipes, e);
if (-1 === s) return this;
t.pipes.splice(s, 1);
t.pipesCount -= 1;
1 === t.pipesCount && (t.pipes = t.pipes[0]);
e.emit("unpipe", this, r);
return this;
};
k.prototype.on = function(e, t) {
var n = s.prototype.on.call(this, e, t), i = this._readableState;
if ("data" === e) {
i.readableListening = this.listenerCount("readable") > 0;
!1 !== i.flowing && this.resume();
} else if ("readable" === e && !i.endEmitted && !i.readableListening) {
i.readableListening = i.needReadable = !0;
i.flowing = !1;
i.emittedReadable = !1;
u("on readable", i.length, i.reading);
i.length ? P(this) : i.reading || r.nextTick(q, this);
}
return n;
};
k.prototype.addListener = k.prototype.on;
k.prototype.removeListener = function(e, t) {
var n = s.prototype.removeListener.call(this, e, t);
"readable" === e && r.nextTick(F, this);
return n;
};
k.prototype.removeAllListeners = function(e) {
var t = s.prototype.removeAllListeners.apply(this, arguments);
"readable" !== e && void 0 !== e || r.nextTick(F, this);
return t;
};
function F(e) {
var t = e._readableState;
t.readableListening = e.listenerCount("readable") > 0;
t.resumeScheduled && !t.paused ? t.flowing = !0 : e.listenerCount("data") > 0 && e.resume();
}
function q(e) {
u("readable nexttick read 0");
e.read(0);
}
k.prototype.resume = function() {
var e = this._readableState;
if (!e.flowing) {
u("resume");
e.flowing = !e.readableListening;
V(this, e);
}
e.paused = !1;
return this;
};
function V(e, t) {
if (!t.resumeScheduled) {
t.resumeScheduled = !0;
r.nextTick(H, e, t);
}
}
function H(e, t) {
u("resume", t.reading);
t.reading || e.read(0);
t.resumeScheduled = !1;
e.emit("resume");
z(e);
t.flowing && !t.reading && e.read(0);
}
k.prototype.pause = function() {
u("call pause flowing=%j", this._readableState.flowing);
if (!1 !== this._readableState.flowing) {
u("pause");
this._readableState.flowing = !1;
this.emit("pause");
}
this._readableState.paused = !0;
return this;
};
function z(e) {
var t = e._readableState;
u("flow", t.flowing);
for (;t.flowing && null !== e.read(); ) ;
}
k.prototype.wrap = function(e) {
var t = this, r = this._readableState, n = !1;
e.on("end", function() {
u("wrapped end");
if (r.decoder && !r.ended) {
var e = r.decoder.end();
e && e.length && t.push(e);
}
t.push(null);
});
e.on("data", function(i) {
u("wrapped data");
r.decoder && (i = r.decoder.write(i));
if ((!r.objectMode || null != i) && (r.objectMode || i && i.length) && !t.push(i)) {
n = !0;
e.pause();
}
});
for (var i in e) void 0 === this[i] && "function" == typeof e[i] && (this[i] = function(t) {
return function() {
return e[t].apply(e, arguments);
};
}(i));
for (var o = 0; o < M.length; o++) e.on(M[o], this.emit.bind(this, M[o]));
this._read = function(t) {
u("wrapped _read", t);
if (n) {
n = !1;
e.resume();
}
};
return this;
};
"function" == typeof Symbol && (k.prototype[Symbol.asyncIterator] = function() {
void 0 === l && (l = e("./internal/streams/async_iterator"));
return l(this);
});
Object.defineProperty(k.prototype, "readableHighWaterMark", {
enumerable: !1,
get: function() {
return this._readableState.highWaterMark;
}
});
Object.defineProperty(k.prototype, "readableBuffer", {
enumerable: !1,
get: function() {
return this._readableState && this._readableState.buffer;
}
});
Object.defineProperty(k.prototype, "readableFlowing", {
enumerable: !1,
get: function() {
return this._readableState.flowing;
},
set: function(e) {
this._readableState && (this._readableState.flowing = e);
}
});
k._fromList = G;
Object.defineProperty(k.prototype, "readableLength", {
enumerable: !1,
get: function() {
return this._readableState.length;
}
});
function G(e, t) {
if (0 === t.length) return null;
var r;
if (t.objectMode) r = t.buffer.shift(); else if (!e || e >= t.length) {
r = t.decoder ? t.buffer.join("") : 1 === t.buffer.length ? t.buffer.first() : t.buffer.concat(t.length);
t.buffer.clear();
} else r = t.buffer.consume(e, t.decoder);
return r;
}
function W(e) {
var t = e._readableState;
u("endReadable", t.endEmitted);
if (!t.endEmitted) {
t.ended = !0;
r.nextTick(K, t, e);
}
}
function K(e, t) {
u("endReadableNT", e.endEmitted, e.length);
if (!e.endEmitted && 0 === e.length) {
e.endEmitted = !0;
t.readable = !1;
t.emit("end");
if (e.autoDestroy) {
var r = t._writableState;
(!r || r.autoDestroy && r.finished) && t.destroy();
}
}
}
"function" == typeof Symbol && (k.from = function(t, r) {
void 0 === p && (p = e("./internal/streams/from"));
return p(k, t, r);
});
function Y(e, t) {
for (var r = 0, n = e.length; r < n; r++) if (e[r] === t) return r;
return -1;
}
}).call(this, e("_process"), "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../errors": 47,
"./_stream_duplex": 48,
"./internal/streams/async_iterator": 53,
"./internal/streams/buffer_list": 54,
"./internal/streams/destroy": 55,
"./internal/streams/from": 57,
"./internal/streams/state": 59,
"./internal/streams/stream": 60,
_process: 157,
buffer: 65,
events: 104,
inherits: 138,
"string_decoder/": 63,
util: 19
} ],
51: [ function(e, t) {
"use strict";
t.exports = c;
var r = e("../errors").codes, n = r.ERR_METHOD_NOT_IMPLEMENTED, i = r.ERR_MULTIPLE_CALLBACK, o = r.ERR_TRANSFORM_ALREADY_TRANSFORMING, s = r.ERR_TRANSFORM_WITH_LENGTH_0, a = e("./_stream_duplex");
e("inherits")(c, a);
function f(e, t) {
var r = this._transformState;
r.transforming = !1;
var n = r.writecb;
if (null === n) return this.emit("error", new i());
r.writechunk = null;
r.writecb = null;
null != t && this.push(t);
n(e);
var o = this._readableState;
o.reading = !1;
(o.needReadable || o.length < o.highWaterMark) && this._read(o.highWaterMark);
}
function c(e) {
if (!(this instanceof c)) return new c(e);
a.call(this, e);
this._transformState = {
afterTransform: f.bind(this),
needTransform: !1,
transforming: !1,
writecb: null,
writechunk: null,
writeencoding: null
};
this._readableState.needReadable = !0;
this._readableState.sync = !1;
if (e) {
"function" == typeof e.transform && (this._transform = e.transform);
"function" == typeof e.flush && (this._flush = e.flush);
}
this.on("prefinish", u);
}
function u() {
var e = this;
"function" != typeof this._flush || this._readableState.destroyed ? h(this, null, null) : this._flush(function(t, r) {
h(e, t, r);
});
}
c.prototype.push = function(e, t) {
this._transformState.needTransform = !1;
return a.prototype.push.call(this, e, t);
};
c.prototype._transform = function(e, t, r) {
r(new n("_transform()"));
};
c.prototype._write = function(e, t, r) {
var n = this._transformState;
n.writecb = r;
n.writechunk = e;
n.writeencoding = t;
if (!n.transforming) {
var i = this._readableState;
(n.needTransform || i.needReadable || i.length < i.highWaterMark) && this._read(i.highWaterMark);
}
};
c.prototype._read = function() {
var e = this._transformState;
if (null === e.writechunk || e.transforming) e.needTransform = !0; else {
e.transforming = !0;
this._transform(e.writechunk, e.writeencoding, e.afterTransform);
}
};
c.prototype._destroy = function(e, t) {
a.prototype._destroy.call(this, e, function(e) {
t(e);
});
};
function h(e, t, r) {
if (t) return e.emit("error", t);
null != r && e.push(r);
if (e._writableState.length) throw new s();
if (e._transformState.transforming) throw new o();
return e.push(null);
}
}, {
"../errors": 47,
"./_stream_duplex": 48,
inherits: 138
} ],
52: [ function(e, t) {
(function(r, n) {
"use strict";
t.exports = x;
function i(e) {
var t = this;
this.next = null;
this.entry = null;
this.finish = function() {
H(t, e);
};
}
var o;
x.WritableState = A;
var s = {
deprecate: e("util-deprecate")
}, a = e("./internal/streams/stream"), f = e("buffer").Buffer, c = n.Uint8Array || function() {};
function u(e) {
return f.from(e);
}
var h, d = e("./internal/streams/destroy"), l = e("./internal/streams/state").getHighWaterMark, p = e("../errors").codes, b = p.ERR_INVALID_ARG_TYPE, m = p.ERR_METHOD_NOT_IMPLEMENTED, v = p.ERR_MULTIPLE_CALLBACK, y = p.ERR_STREAM_CANNOT_PIPE, g = p.ERR_STREAM_DESTROYED, _ = p.ERR_STREAM_NULL_VALUES, w = p.ERR_STREAM_WRITE_AFTER_END, E = p.ERR_UNKNOWN_ENCODING, S = d.errorOrDestroy;
e("inherits")(x, a);
function M() {}
function A(t, r, n) {
o = o || e("./_stream_duplex");
t = t || {};
"boolean" != typeof n && (n = r instanceof o);
this.objectMode = !!t.objectMode;
n && (this.objectMode = this.objectMode || !!t.writableObjectMode);
this.highWaterMark = l(this, t, "writableHighWaterMark", n);
this.finalCalled = !1;
this.needDrain = !1;
this.ending = !1;
this.ended = !1;
this.finished = !1;
this.destroyed = !1;
var s = !1 === t.decodeStrings;
this.decodeStrings = !s;
this.defaultEncoding = t.defaultEncoding || "utf8";
this.length = 0;
this.writing = !1;
this.corked = 0;
this.sync = !0;
this.bufferProcessing = !1;
this.onwrite = function(e) {
j(r, e);
};
this.writecb = null;
this.writelen = 0;
this.bufferedRequest = null;
this.lastBufferedRequest = null;
this.pendingcb = 0;
this.prefinished = !1;
this.errorEmitted = !1;
this.emitClose = !1 !== t.emitClose;
this.autoDestroy = !!t.autoDestroy;
this.bufferedRequestCount = 0;
this.corkedRequestsFree = new i(this);
}
A.prototype.getBuffer = function() {
for (var e = this.bufferedRequest, t = []; e; ) {
t.push(e);
e = e.next;
}
return t;
};
(function() {
try {
Object.defineProperty(A.prototype, "buffer", {
get: s.deprecate(function() {
return this.getBuffer();
}, "_writableState.buffer is deprecated. Use _writableState.getBuffer instead.", "DEP0003")
});
} catch (e) {}
})();
if ("function" == typeof Symbol && Symbol.hasInstance && "function" == typeof Function.prototype[Symbol.hasInstance]) {
h = Function.prototype[Symbol.hasInstance];
Object.defineProperty(x, Symbol.hasInstance, {
value: function(e) {
return !!h.call(this, e) || this === x && e && e._writableState instanceof A;
}
});
} else h = function(e) {
return e instanceof this;
};
function x(t) {
var r = this instanceof (o = o || e("./_stream_duplex"));
if (!r && !h.call(x, this)) return new x(t);
this._writableState = new A(t, this, r);
this.writable = !0;
if (t) {
"function" == typeof t.write && (this._write = t.write);
"function" == typeof t.writev && (this._writev = t.writev);
"function" == typeof t.destroy && (this._destroy = t.destroy);
"function" == typeof t.final && (this._final = t.final);
}
a.call(this);
}
x.prototype.pipe = function() {
S(this, new y());
};
function k(e, t) {
var n = new w();
S(e, n);
r.nextTick(t, n);
}
function T(e, t, n, i) {
var o;
null === n ? o = new _() : "string" == typeof n || t.objectMode || (o = new b("chunk", [ "string", "Buffer" ], n));
if (o) {
S(e, o);
r.nextTick(i, o);
return !1;
}
return !0;
}
x.prototype.write = function(e, t, r) {
var n, i = this._writableState, o = !1, s = !i.objectMode && (n = e, f.isBuffer(n) || n instanceof c);
s && !f.isBuffer(e) && (e = u(e));
if ("function" == typeof t) {
r = t;
t = null;
}
s ? t = "buffer" : t || (t = i.defaultEncoding);
"function" != typeof r && (r = M);
if (i.ending) k(this, r); else if (s || T(this, i, e, r)) {
i.pendingcb++;
o = O(this, i, s, e, t, r);
}
return o;
};
x.prototype.cork = function() {
this._writableState.corked++;
};
x.prototype.uncork = function() {
var e = this._writableState;
if (e.corked) {
e.corked--;
e.writing || e.corked || e.bufferProcessing || !e.bufferedRequest || L(this, e);
}
};
x.prototype.setDefaultEncoding = function(e) {
"string" == typeof e && (e = e.toLowerCase());
if (!([ "hex", "utf8", "utf-8", "ascii", "binary", "base64", "ucs2", "ucs-2", "utf16le", "utf-16le", "raw" ].indexOf((e + "").toLowerCase()) > -1)) throw new E(e);
this._writableState.defaultEncoding = e;
return this;
};
Object.defineProperty(x.prototype, "writableBuffer", {
enumerable: !1,
get: function() {
return this._writableState && this._writableState.getBuffer();
}
});
function I(e, t, r) {
e.objectMode || !1 === e.decodeStrings || "string" != typeof t || (t = f.from(t, r));
return t;
}
Object.defineProperty(x.prototype, "writableHighWaterMark", {
enumerable: !1,
get: function() {
return this._writableState.highWaterMark;
}
});
function O(e, t, r, n, i, o) {
if (!r) {
var s = I(t, n, i);
if (n !== s) {
r = !0;
i = "buffer";
n = s;
}
}
var a = t.objectMode ? 1 : n.length;
t.length += a;
var f = t.length < t.highWaterMark;
f || (t.needDrain = !0);
if (t.writing || t.corked) {
var c = t.lastBufferedRequest;
t.lastBufferedRequest = {
chunk: n,
encoding: i,
isBuf: r,
callback: o,
next: null
};
c ? c.next = t.lastBufferedRequest : t.bufferedRequest = t.lastBufferedRequest;
t.bufferedRequestCount += 1;
} else R(e, t, !1, a, n, i, o);
return f;
}
function R(e, t, r, n, i, o, s) {
t.writelen = n;
t.writecb = s;
t.writing = !0;
t.sync = !0;
t.destroyed ? t.onwrite(new g("write")) : r ? e._writev(i, t.onwrite) : e._write(i, o, t.onwrite);
t.sync = !1;
}
function C(e, t, n, i, o) {
--t.pendingcb;
if (n) {
r.nextTick(o, i);
r.nextTick(q, e, t);
e._writableState.errorEmitted = !0;
S(e, i);
} else {
o(i);
e._writableState.errorEmitted = !0;
S(e, i);
q(e, t);
}
}
function N(e) {
e.writing = !1;
e.writecb = null;
e.length -= e.writelen;
e.writelen = 0;
}
function j(e, t) {
var n = e._writableState, i = n.sync, o = n.writecb;
if ("function" != typeof o) throw new v();
N(n);
if (t) C(e, n, i, t, o); else {
var s = B(n) || e.destroyed;
s || n.corked || n.bufferProcessing || !n.bufferedRequest || L(e, n);
i ? r.nextTick(P, e, n, s, o) : P(e, n, s, o);
}
}
function P(e, t, r, n) {
r || D(e, t);
t.pendingcb--;
n();
q(e, t);
}
function D(e, t) {
if (0 === t.length && t.needDrain) {
t.needDrain = !1;
e.emit("drain");
}
}
function L(e, t) {
t.bufferProcessing = !0;
var r = t.bufferedRequest;
if (e._writev && r && r.next) {
var n = t.bufferedRequestCount, o = new Array(n), s = t.corkedRequestsFree;
s.entry = r;
for (var a = 0, f = !0; r; ) {
o[a] = r;
r.isBuf || (f = !1);
r = r.next;
a += 1;
}
o.allBuffers = f;
R(e, t, !0, t.length, o, "", s.finish);
t.pendingcb++;
t.lastBufferedRequest = null;
if (s.next) {
t.corkedRequestsFree = s.next;
s.next = null;
} else t.corkedRequestsFree = new i(t);
t.bufferedRequestCount = 0;
} else {
for (;r; ) {
var c = r.chunk, u = r.encoding, h = r.callback;
R(e, t, !1, t.objectMode ? 1 : c.length, c, u, h);
r = r.next;
t.bufferedRequestCount--;
if (t.writing) break;
}
null === r && (t.lastBufferedRequest = null);
}
t.bufferedRequest = r;
t.bufferProcessing = !1;
}
x.prototype._write = function(e, t, r) {
r(new m("_write()"));
};
x.prototype._writev = null;
x.prototype.end = function(e, t, r) {
var n = this._writableState;
if ("function" == typeof e) {
r = e;
e = null;
t = null;
} else if ("function" == typeof t) {
r = t;
t = null;
}
null != e && this.write(e, t);
if (n.corked) {
n.corked = 1;
this.uncork();
}
n.ending || V(this, n, r);
return this;
};
Object.defineProperty(x.prototype, "writableLength", {
enumerable: !1,
get: function() {
return this._writableState.length;
}
});
function B(e) {
return e.ending && 0 === e.length && null === e.bufferedRequest && !e.finished && !e.writing;
}
function U(e, t) {
e._final(function(r) {
t.pendingcb--;
r && S(e, r);
t.prefinished = !0;
e.emit("prefinish");
q(e, t);
});
}
function F(e, t) {
if (!t.prefinished && !t.finalCalled) if ("function" != typeof e._final || t.destroyed) {
t.prefinished = !0;
e.emit("prefinish");
} else {
t.pendingcb++;
t.finalCalled = !0;
r.nextTick(U, e, t);
}
}
function q(e, t) {
var r = B(t);
if (r) {
F(e, t);
if (0 === t.pendingcb) {
t.finished = !0;
e.emit("finish");
if (t.autoDestroy) {
var n = e._readableState;
(!n || n.autoDestroy && n.endEmitted) && e.destroy();
}
}
}
return r;
}
function V(e, t, n) {
t.ending = !0;
q(e, t);
n && (t.finished ? r.nextTick(n) : e.once("finish", n));
t.ended = !0;
e.writable = !1;
}
function H(e, t, r) {
var n = e.entry;
e.entry = null;
for (;n; ) {
var i = n.callback;
t.pendingcb--;
i(r);
n = n.next;
}
t.corkedRequestsFree.next = e;
}
Object.defineProperty(x.prototype, "destroyed", {
enumerable: !1,
get: function() {
return void 0 !== this._writableState && this._writableState.destroyed;
},
set: function(e) {
this._writableState && (this._writableState.destroyed = e);
}
});
x.prototype.destroy = d.destroy;
x.prototype._undestroy = d.undestroy;
x.prototype._destroy = function(e, t) {
t(e);
};
}).call(this, e("_process"), "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../errors": 47,
"./_stream_duplex": 48,
"./internal/streams/destroy": 55,
"./internal/streams/state": 59,
"./internal/streams/stream": 60,
_process: 157,
buffer: 65,
inherits: 138,
"util-deprecate": 195
} ],
53: [ function(e, t) {
(function(r) {
"use strict";
var n;
function i(e, t, r) {
t in e ? Object.defineProperty(e, t, {
value: r,
enumerable: !0,
configurable: !0,
writable: !0
}) : e[t] = r;
return e;
}
var o = e("./end-of-stream"), s = Symbol("lastResolve"), a = Symbol("lastReject"), f = Symbol("error"), c = Symbol("ended"), u = Symbol("lastPromise"), h = Symbol("handlePromise"), d = Symbol("stream");
function l(e, t) {
return {
value: e,
done: t
};
}
function p(e) {
var t = e[s];
if (null !== t) {
var r = e[d].read();
if (null !== r) {
e[u] = null;
e[s] = null;
e[a] = null;
t(l(r, !1));
}
}
}
function b(e) {
r.nextTick(p, e);
}
function m(e, t) {
return function(r, n) {
e.then(function() {
t[c] ? r(l(void 0, !0)) : t[h](r, n);
}, n);
};
}
var v = Object.getPrototypeOf(function() {}), y = Object.setPrototypeOf((i(n = {
get stream() {
return this[d];
},
next: function() {
var e = this, t = this[f];
if (null !== t) return Promise.reject(t);
if (this[c]) return Promise.resolve(l(void 0, !0));
if (this[d].destroyed) return new Promise(function(t, n) {
r.nextTick(function() {
e[f] ? n(e[f]) : t(l(void 0, !0));
});
});
var n, i = this[u];
if (i) n = new Promise(m(i, this)); else {
var o = this[d].read();
if (null !== o) return Promise.resolve(l(o, !1));
n = new Promise(this[h]);
}
this[u] = n;
return n;
}
}, Symbol.asyncIterator, function() {
return this;
}), i(n, "return", function() {
var e = this;
return new Promise(function(t, r) {
e[d].destroy(null, function(e) {
e ? r(e) : t(l(void 0, !0));
});
});
}), n), v);
t.exports = function(e) {
var t, r = Object.create(y, (i(t = {}, d, {
value: e,
writable: !0
}), i(t, s, {
value: null,
writable: !0
}), i(t, a, {
value: null,
writable: !0
}), i(t, f, {
value: null,
writable: !0
}), i(t, c, {
value: e._readableState.endEmitted,
writable: !0
}), i(t, h, {
value: function(e, t) {
var n = r[d].read();
if (n) {
r[u] = null;
r[s] = null;
r[a] = null;
e(l(n, !1));
} else {
r[s] = e;
r[a] = t;
}
},
writable: !0
}), t));
r[u] = null;
o(e, function(e) {
if (e && "ERR_STREAM_PREMATURE_CLOSE" !== e.code) {
var t = r[a];
if (null !== t) {
r[u] = null;
r[s] = null;
r[a] = null;
t(e);
}
r[f] = e;
} else {
var n = r[s];
if (null !== n) {
r[u] = null;
r[s] = null;
r[a] = null;
n(l(void 0, !0));
}
r[c] = !0;
}
});
e.on("readable", b.bind(null, r));
return r;
};
}).call(this, e("_process"));
}, {
"./end-of-stream": 56,
_process: 157
} ],
54: [ function(e, t) {
"use strict";
function r(e, t) {
var r = Object.keys(e);
if (Object.getOwnPropertySymbols) {
var n = Object.getOwnPropertySymbols(e);
t && (n = n.filter(function(t) {
return Object.getOwnPropertyDescriptor(e, t).enumerable;
}));
r.push.apply(r, n);
}
return r;
}
function n(e) {
for (var t = 1; t < arguments.length; t++) {
var n = null != arguments[t] ? arguments[t] : {};
t % 2 ? r(Object(n), !0).forEach(function(t) {
i(e, t, n[t]);
}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach(function(t) {
Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
});
}
return e;
}
function i(e, t, r) {
t in e ? Object.defineProperty(e, t, {
value: r,
enumerable: !0,
configurable: !0,
writable: !0
}) : e[t] = r;
return e;
}
function o(e, t) {
if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}
function s(e, t) {
for (var r = 0; r < t.length; r++) {
var n = t[r];
n.enumerable = n.enumerable || !1;
n.configurable = !0;
"value" in n && (n.writable = !0);
Object.defineProperty(e, n.key, n);
}
}
function a(e, t, r) {
t && s(e.prototype, t);
r && s(e, r);
return e;
}
var f = e("buffer").Buffer, c = e("util").inspect, u = c && c.custom || "inspect";
t.exports = function() {
function e() {
o(this, e);
this.head = null;
this.tail = null;
this.length = 0;
}
a(e, [ {
key: "push",
value: function(e) {
var t = {
data: e,
next: null
};
this.length > 0 ? this.tail.next = t : this.head = t;
this.tail = t;
++this.length;
}
}, {
key: "unshift",
value: function(e) {
var t = {
data: e,
next: this.head
};
0 === this.length && (this.tail = t);
this.head = t;
++this.length;
}
}, {
key: "shift",
value: function() {
if (0 !== this.length) {
var e = this.head.data;
1 === this.length ? this.head = this.tail = null : this.head = this.head.next;
--this.length;
return e;
}
}
}, {
key: "clear",
value: function() {
this.head = this.tail = null;
this.length = 0;
}
}, {
key: "join",
value: function(e) {
if (0 === this.length) return "";
for (var t = this.head, r = "" + t.data; t = t.next; ) r += e + t.data;
return r;
}
}, {
key: "concat",
value: function(e) {
if (0 === this.length) return f.alloc(0);
for (var t, r, n, i = f.allocUnsafe(e >>> 0), o = this.head, s = 0; o; ) {
t = o.data, r = i, n = s, f.prototype.copy.call(t, r, n);
s += o.data.length;
o = o.next;
}
return i;
}
}, {
key: "consume",
value: function(e, t) {
var r;
if (e < this.head.data.length) {
r = this.head.data.slice(0, e);
this.head.data = this.head.data.slice(e);
} else r = e === this.head.data.length ? this.shift() : t ? this._getString(e) : this._getBuffer(e);
return r;
}
}, {
key: "first",
value: function() {
return this.head.data;
}
}, {
key: "_getString",
value: function(e) {
var t = this.head, r = 1, n = t.data;
e -= n.length;
for (;t = t.next; ) {
var i = t.data, o = e > i.length ? i.length : e;
o === i.length ? n += i : n += i.slice(0, e);
if (0 == (e -= o)) {
if (o === i.length) {
++r;
t.next ? this.head = t.next : this.head = this.tail = null;
} else {
this.head = t;
t.data = i.slice(o);
}
break;
}
++r;
}
this.length -= r;
return n;
}
}, {
key: "_getBuffer",
value: function(e) {
var t = f.allocUnsafe(e), r = this.head, n = 1;
r.data.copy(t);
e -= r.data.length;
for (;r = r.next; ) {
var i = r.data, o = e > i.length ? i.length : e;
i.copy(t, t.length - e, 0, o);
if (0 == (e -= o)) {
if (o === i.length) {
++n;
r.next ? this.head = r.next : this.head = this.tail = null;
} else {
this.head = r;
r.data = i.slice(o);
}
break;
}
++n;
}
this.length -= n;
return t;
}
}, {
key: u,
value: function(e, t) {
return c(this, n({}, t, {
depth: 0,
customInspect: !1
}));
}
} ]);
return e;
}();
}, {
buffer: 65,
util: 19
} ],
55: [ function(e, t) {
(function(e) {
"use strict";
function r(e, t) {
i(e, t);
n(e);
}
function n(e) {
e._writableState && !e._writableState.emitClose || e._readableState && !e._readableState.emitClose || e.emit("close");
}
function i(e, t) {
e.emit("error", t);
}
t.exports = {
destroy: function(t, o) {
var s = this, a = this._readableState && this._readableState.destroyed, f = this._writableState && this._writableState.destroyed;
if (a || f) {
if (o) o(t); else if (t) if (this._writableState) {
if (!this._writableState.errorEmitted) {
this._writableState.errorEmitted = !0;
e.nextTick(i, this, t);
}
} else e.nextTick(i, this, t);
return this;
}
this._readableState && (this._readableState.destroyed = !0);
this._writableState && (this._writableState.destroyed = !0);
this._destroy(t || null, function(t) {
if (!o && t) if (s._writableState) if (s._writableState.errorEmitted) e.nextTick(n, s); else {
s._writableState.errorEmitted = !0;
e.nextTick(r, s, t);
} else e.nextTick(r, s, t); else if (o) {
e.nextTick(n, s);
o(t);
} else e.nextTick(n, s);
});
return this;
},
undestroy: function() {
if (this._readableState) {
this._readableState.destroyed = !1;
this._readableState.reading = !1;
this._readableState.ended = !1;
this._readableState.endEmitted = !1;
}
if (this._writableState) {
this._writableState.destroyed = !1;
this._writableState.ended = !1;
this._writableState.ending = !1;
this._writableState.finalCalled = !1;
this._writableState.prefinished = !1;
this._writableState.finished = !1;
this._writableState.errorEmitted = !1;
}
},
errorOrDestroy: function(e, t) {
var r = e._readableState, n = e._writableState;
r && r.autoDestroy || n && n.autoDestroy ? e.destroy(t) : e.emit("error", t);
}
};
}).call(this, e("_process"));
}, {
_process: 157
} ],
56: [ function(e, t) {
"use strict";
var r = e("../../../errors").codes.ERR_STREAM_PREMATURE_CLOSE;
function n(e) {
var t = !1;
return function() {
if (!t) {
t = !0;
for (var r = arguments.length, n = new Array(r), i = 0; i < r; i++) n[i] = arguments[i];
e.apply(this, n);
}
};
}
function i() {}
function o(e) {
return e.setHeader && "function" == typeof e.abort;
}
t.exports = function e(t, s, a) {
if ("function" == typeof s) return e(t, null, s);
s || (s = {});
a = n(a || i);
var f = s.readable || !1 !== s.readable && t.readable, c = s.writable || !1 !== s.writable && t.writable, u = function() {
t.writable || d();
}, h = t._writableState && t._writableState.finished, d = function() {
c = !1;
h = !0;
f || a.call(t);
}, l = t._readableState && t._readableState.endEmitted, p = function() {
f = !1;
l = !0;
c || a.call(t);
}, b = function(e) {
a.call(t, e);
}, m = function() {
var e;
if (f && !l) {
t._readableState && t._readableState.ended || (e = new r());
return a.call(t, e);
}
if (c && !h) {
t._writableState && t._writableState.ended || (e = new r());
return a.call(t, e);
}
}, v = function() {
t.req.on("finish", d);
};
if (o(t)) {
t.on("complete", d);
t.on("abort", m);
t.req ? v() : t.on("request", v);
} else if (c && !t._writableState) {
t.on("end", u);
t.on("close", u);
}
t.on("end", p);
t.on("finish", d);
!1 !== s.error && t.on("error", b);
t.on("close", m);
return function() {
t.removeListener("complete", d);
t.removeListener("abort", m);
t.removeListener("request", v);
t.req && t.req.removeListener("finish", d);
t.removeListener("end", u);
t.removeListener("close", u);
t.removeListener("finish", d);
t.removeListener("end", p);
t.removeListener("error", b);
t.removeListener("close", m);
};
};
}, {
"../../../errors": 47
} ],
57: [ function(e, t) {
t.exports = function() {
throw new Error("Readable.from is not available in the browser");
};
}, {} ],
58: [ function(e, t) {
"use strict";
var r;
function n(e) {
var t = !1;
return function() {
if (!t) {
t = !0;
e.apply(void 0, arguments);
}
};
}
var i = e("../../../errors").codes, o = i.ERR_MISSING_ARGS, s = i.ERR_STREAM_DESTROYED;
function a(e) {
if (e) throw e;
}
function f(e) {
return e.setHeader && "function" == typeof e.abort;
}
function c(t, i, o, a) {
a = n(a);
var c = !1;
t.on("close", function() {
c = !0;
});
void 0 === r && (r = e("./end-of-stream"));
r(t, {
readable: i,
writable: o
}, function(e) {
if (e) return a(e);
c = !0;
a();
});
var u = !1;
return function(e) {
if (!c && !u) {
u = !0;
if (f(t)) return t.abort();
if ("function" == typeof t.destroy) return t.destroy();
a(e || new s("pipe"));
}
};
}
function u(e) {
e();
}
function h(e, t) {
return e.pipe(t);
}
function d(e) {
return e.length ? "function" != typeof e[e.length - 1] ? a : e.pop() : a;
}
t.exports = function() {
for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++) t[r] = arguments[r];
var n, i = d(t);
Array.isArray(t[0]) && (t = t[0]);
if (t.length < 2) throw new o("streams");
var s = t.map(function(e, r) {
var o = r < t.length - 1;
return c(e, o, r > 0, function(e) {
n || (n = e);
e && s.forEach(u);
if (!o) {
s.forEach(u);
i(n);
}
});
});
return t.reduce(h);
};
}, {
"../../../errors": 47,
"./end-of-stream": 56
} ],
59: [ function(e, t) {
"use strict";
var r = e("../../../errors").codes.ERR_INVALID_OPT_VALUE;
function n(e, t, r) {
return null != e.highWaterMark ? e.highWaterMark : t ? e[r] : null;
}
t.exports = {
getHighWaterMark: function(e, t, i, o) {
var s = n(t, o, i);
if (null != s) {
if (!isFinite(s) || Math.floor(s) !== s || s < 0) throw new r(o ? i : "highWaterMark", s);
return Math.floor(s);
}
return e.objectMode ? 16 : 16384;
}
};
}, {
"../../../errors": 47
} ],
60: [ function(e, t) {
t.exports = e("events").EventEmitter;
}, {
events: 104
} ],
61: [ function(e, t, r) {
(r = t.exports = e("./lib/_stream_readable.js")).Stream = r;
r.Readable = r;
r.Writable = e("./lib/_stream_writable.js");
r.Duplex = e("./lib/_stream_duplex.js");
r.Transform = e("./lib/_stream_transform.js");
r.PassThrough = e("./lib/_stream_passthrough.js");
r.finished = e("./lib/internal/streams/end-of-stream.js");
r.pipeline = e("./lib/internal/streams/pipeline.js");
}, {
"./lib/_stream_duplex.js": 48,
"./lib/_stream_passthrough.js": 49,
"./lib/_stream_readable.js": 50,
"./lib/_stream_transform.js": 51,
"./lib/_stream_writable.js": 52,
"./lib/internal/streams/end-of-stream.js": 56,
"./lib/internal/streams/pipeline.js": 58
} ],
62: [ function(e, t, r) {
var n = e("buffer"), i = n.Buffer;
function o(e, t) {
for (var r in e) t[r] = e[r];
}
if (i.from && i.alloc && i.allocUnsafe && i.allocUnsafeSlow) t.exports = n; else {
o(n, r);
r.Buffer = s;
}
function s(e, t, r) {
return i(e, t, r);
}
s.prototype = Object.create(i.prototype);
o(i, s);
s.from = function(e, t, r) {
if ("number" == typeof e) throw new TypeError("Argument must not be a number");
return i(e, t, r);
};
s.alloc = function(e, t, r) {
if ("number" != typeof e) throw new TypeError("Argument must be a number");
var n = i(e);
void 0 !== t ? "string" == typeof r ? n.fill(t, r) : n.fill(t) : n.fill(0);
return n;
};
s.allocUnsafe = function(e) {
if ("number" != typeof e) throw new TypeError("Argument must be a number");
return i(e);
};
s.allocUnsafeSlow = function(e) {
if ("number" != typeof e) throw new TypeError("Argument must be a number");
return n.SlowBuffer(e);
};
}, {
buffer: 65
} ],
63: [ function(e, t, r) {
"use strict";
var n = e("safe-buffer").Buffer, i = n.isEncoding || function(e) {
switch ((e = "" + e) && e.toLowerCase()) {
case "hex":
case "utf8":
case "utf-8":
case "ascii":
case "binary":
case "base64":
case "ucs2":
case "ucs-2":
case "utf16le":
case "utf-16le":
case "raw":
return !0;

default:
return !1;
}
};
function o(e) {
if (!e) return "utf8";
for (var t; ;) switch (e) {
case "utf8":
case "utf-8":
return "utf8";

case "ucs2":
case "ucs-2":
case "utf16le":
case "utf-16le":
return "utf16le";

case "latin1":
case "binary":
return "latin1";

case "base64":
case "ascii":
case "hex":
return e;

default:
if (t) return;
e = ("" + e).toLowerCase();
t = !0;
}
}
function s(e) {
var t = o(e);
if ("string" != typeof t && (n.isEncoding === i || !i(e))) throw new Error("Unknown encoding: " + e);
return t || e;
}
r.StringDecoder = a;
function a(e) {
this.encoding = s(e);
var t;
switch (this.encoding) {
case "utf16le":
this.text = d;
this.end = l;
t = 4;
break;

case "utf8":
this.fillLast = h;
t = 4;
break;

case "base64":
this.text = p;
this.end = b;
t = 3;
break;

default:
this.write = m;
this.end = v;
return;
}
this.lastNeed = 0;
this.lastTotal = 0;
this.lastChar = n.allocUnsafe(t);
}
a.prototype.write = function(e) {
if (0 === e.length) return "";
var t, r;
if (this.lastNeed) {
if (void 0 === (t = this.fillLast(e))) return "";
r = this.lastNeed;
this.lastNeed = 0;
} else r = 0;
return r < e.length ? t ? t + this.text(e, r) : this.text(e, r) : t || "";
};
a.prototype.end = function(e) {
var t = e && e.length ? this.write(e) : "";
return this.lastNeed ? t + "�" : t;
};
a.prototype.text = function(e, t) {
var r = c(this, e, t);
if (!this.lastNeed) return e.toString("utf8", t);
this.lastTotal = r;
var n = e.length - (r - this.lastNeed);
e.copy(this.lastChar, 0, n);
return e.toString("utf8", t, n);
};
a.prototype.fillLast = function(e) {
if (this.lastNeed <= e.length) {
e.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed);
return this.lastChar.toString(this.encoding, 0, this.lastTotal);
}
e.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, e.length);
this.lastNeed -= e.length;
};
function f(e) {
return e <= 127 ? 0 : e >> 5 == 6 ? 2 : e >> 4 == 14 ? 3 : e >> 3 == 30 ? 4 : e >> 6 == 2 ? -1 : -2;
}
function c(e, t, r) {
var n = t.length - 1;
if (n < r) return 0;
var i = f(t[n]);
if (i >= 0) {
i > 0 && (e.lastNeed = i - 1);
return i;
}
if (--n < r || -2 === i) return 0;
if ((i = f(t[n])) >= 0) {
i > 0 && (e.lastNeed = i - 2);
return i;
}
if (--n < r || -2 === i) return 0;
if ((i = f(t[n])) >= 0) {
i > 0 && (2 === i ? i = 0 : e.lastNeed = i - 3);
return i;
}
return 0;
}
function u(e, t) {
if (128 != (192 & t[0])) {
e.lastNeed = 0;
return "�";
}
if (e.lastNeed > 1 && t.length > 1) {
if (128 != (192 & t[1])) {
e.lastNeed = 1;
return "�";
}
if (e.lastNeed > 2 && t.length > 2 && 128 != (192 & t[2])) {
e.lastNeed = 2;
return "�";
}
}
}
function h(e) {
var t = this.lastTotal - this.lastNeed, r = u(this, e);
if (void 0 !== r) return r;
if (this.lastNeed <= e.length) {
e.copy(this.lastChar, t, 0, this.lastNeed);
return this.lastChar.toString(this.encoding, 0, this.lastTotal);
}
e.copy(this.lastChar, t, 0, e.length);
this.lastNeed -= e.length;
}
function d(e, t) {
if ((e.length - t) % 2 == 0) {
var r = e.toString("utf16le", t);
if (r) {
var n = r.charCodeAt(r.length - 1);
if (n >= 55296 && n <= 56319) {
this.lastNeed = 2;
this.lastTotal = 4;
this.lastChar[0] = e[e.length - 2];
this.lastChar[1] = e[e.length - 1];
return r.slice(0, -1);
}
}
return r;
}
this.lastNeed = 1;
this.lastTotal = 2;
this.lastChar[0] = e[e.length - 1];
return e.toString("utf16le", t, e.length - 1);
}
function l(e) {
var t = e && e.length ? this.write(e) : "";
if (this.lastNeed) {
var r = this.lastTotal - this.lastNeed;
return t + this.lastChar.toString("utf16le", 0, r);
}
return t;
}
function p(e, t) {
var r = (e.length - t) % 3;
if (0 === r) return e.toString("base64", t);
this.lastNeed = 3 - r;
this.lastTotal = 3;
if (1 === r) this.lastChar[0] = e[e.length - 1]; else {
this.lastChar[0] = e[e.length - 2];
this.lastChar[1] = e[e.length - 1];
}
return e.toString("base64", t, e.length - r);
}
function b(e) {
var t = e && e.length ? this.write(e) : "";
return this.lastNeed ? t + this.lastChar.toString("base64", 0, 3 - this.lastNeed) : t;
}
function m(e) {
return e.toString(this.encoding);
}
function v(e) {
return e && e.length ? this.write(e) : "";
}
}, {
"safe-buffer": 62
} ],
64: [ function(e, t) {
(function(e) {
t.exports = function(t, r) {
for (var n = Math.min(t.length, r.length), i = new e(n), o = 0; o < n; ++o) i[o] = t[o] ^ r[o];
return i;
};
}).call(this, e("buffer").Buffer);
}, {
buffer: 65
} ],
65: [ function(e, t, r) {
(function(t) {
"use strict";
var n = e("base64-js"), i = e("ieee754"), o = e("isarray");
r.Buffer = f;
r.SlowBuffer = function(e) {
+e != e && (e = 0);
return f.alloc(+e);
};
r.INSPECT_MAX_BYTES = 50;
f.TYPED_ARRAY_SUPPORT = void 0 !== t.TYPED_ARRAY_SUPPORT ? t.TYPED_ARRAY_SUPPORT : function() {
try {
var e = new Uint8Array(1);
e.__proto__ = {
__proto__: Uint8Array.prototype,
foo: function() {
return 42;
}
};
return 42 === e.foo() && "function" == typeof e.subarray && 0 === e.subarray(1, 1).byteLength;
} catch (e) {
return !1;
}
}();
r.kMaxLength = s();
function s() {
return f.TYPED_ARRAY_SUPPORT ? 2147483647 : 1073741823;
}
function a(e, t) {
if (s() < t) throw new RangeError("Invalid typed array length");
if (f.TYPED_ARRAY_SUPPORT) (e = new Uint8Array(t)).__proto__ = f.prototype; else {
null === e && (e = new f(t));
e.length = t;
}
return e;
}
function f(e, t, r) {
if (!(f.TYPED_ARRAY_SUPPORT || this instanceof f)) return new f(e, t, r);
if ("number" == typeof e) {
if ("string" == typeof t) throw new Error("If encoding is specified then the first argument must be a string");
return d(this, e);
}
return c(this, e, t, r);
}
f.poolSize = 8192;
f._augment = function(e) {
e.__proto__ = f.prototype;
return e;
};
function c(e, t, r, n) {
if ("number" == typeof t) throw new TypeError('"value" argument must not be a number');
return "undefined" != typeof ArrayBuffer && t instanceof ArrayBuffer ? b(e, t, r, n) : "string" == typeof t ? l(e, t, r) : m(e, t);
}
f.from = function(e, t, r) {
return c(null, e, t, r);
};
if (f.TYPED_ARRAY_SUPPORT) {
f.prototype.__proto__ = Uint8Array.prototype;
f.__proto__ = Uint8Array;
"undefined" != typeof Symbol && Symbol.species && f[Symbol.species] === f && Object.defineProperty(f, Symbol.species, {
value: null,
configurable: !0
});
}
function u(e) {
if ("number" != typeof e) throw new TypeError('"size" argument must be a number');
if (e < 0) throw new RangeError('"size" argument must not be negative');
}
function h(e, t, r, n) {
u(t);
return t <= 0 ? a(e, t) : void 0 !== r ? "string" == typeof n ? a(e, t).fill(r, n) : a(e, t).fill(r) : a(e, t);
}
f.alloc = function(e, t, r) {
return h(null, e, t, r);
};
function d(e, t) {
u(t);
e = a(e, t < 0 ? 0 : 0 | v(t));
if (!f.TYPED_ARRAY_SUPPORT) for (var r = 0; r < t; ++r) e[r] = 0;
return e;
}
f.allocUnsafe = function(e) {
return d(null, e);
};
f.allocUnsafeSlow = function(e) {
return d(null, e);
};
function l(e, t, r) {
"string" == typeof r && "" !== r || (r = "utf8");
if (!f.isEncoding(r)) throw new TypeError('"encoding" must be a valid string encoding');
var n = 0 | y(t, r), i = (e = a(e, n)).write(t, r);
i !== n && (e = e.slice(0, i));
return e;
}
function p(e, t) {
var r = t.length < 0 ? 0 : 0 | v(t.length);
e = a(e, r);
for (var n = 0; n < r; n += 1) e[n] = 255 & t[n];
return e;
}
function b(e, t, r, n) {
t.byteLength;
if (r < 0 || t.byteLength < r) throw new RangeError("'offset' is out of bounds");
if (t.byteLength < r + (n || 0)) throw new RangeError("'length' is out of bounds");
t = void 0 === r && void 0 === n ? new Uint8Array(t) : void 0 === n ? new Uint8Array(t, r) : new Uint8Array(t, r, n);
f.TYPED_ARRAY_SUPPORT ? (e = t).__proto__ = f.prototype : e = p(e, t);
return e;
}
function m(e, t) {
if (f.isBuffer(t)) {
var r = 0 | v(t.length);
if (0 === (e = a(e, r)).length) return e;
t.copy(e, 0, 0, r);
return e;
}
if (t) {
if ("undefined" != typeof ArrayBuffer && t.buffer instanceof ArrayBuffer || "length" in t) return "number" != typeof t.length || (n = t.length) != n ? a(e, 0) : p(e, t);
if ("Buffer" === t.type && o(t.data)) return p(e, t.data);
}
var n;
throw new TypeError("First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.");
}
function v(e) {
if (e >= s()) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + s().toString(16) + " bytes");
return 0 | e;
}
f.isBuffer = function(e) {
return !(null == e || !e._isBuffer);
};
f.compare = function(e, t) {
if (!f.isBuffer(e) || !f.isBuffer(t)) throw new TypeError("Arguments must be Buffers");
if (e === t) return 0;
for (var r = e.length, n = t.length, i = 0, o = Math.min(r, n); i < o; ++i) if (e[i] !== t[i]) {
r = e[i];
n = t[i];
break;
}
return r < n ? -1 : n < r ? 1 : 0;
};
f.isEncoding = function(e) {
switch (String(e).toLowerCase()) {
case "hex":
case "utf8":
case "utf-8":
case "ascii":
case "latin1":
case "binary":
case "base64":
case "ucs2":
case "ucs-2":
case "utf16le":
case "utf-16le":
return !0;

default:
return !1;
}
};
f.concat = function(e, t) {
if (!o(e)) throw new TypeError('"list" argument must be an Array of Buffers');
if (0 === e.length) return f.alloc(0);
var r;
if (void 0 === t) {
t = 0;
for (r = 0; r < e.length; ++r) t += e[r].length;
}
var n = f.allocUnsafe(t), i = 0;
for (r = 0; r < e.length; ++r) {
var s = e[r];
if (!f.isBuffer(s)) throw new TypeError('"list" argument must be an Array of Buffers');
s.copy(n, i);
i += s.length;
}
return n;
};
function y(e, t) {
if (f.isBuffer(e)) return e.length;
if ("undefined" != typeof ArrayBuffer && "function" == typeof ArrayBuffer.isView && (ArrayBuffer.isView(e) || e instanceof ArrayBuffer)) return e.byteLength;
"string" != typeof e && (e = "" + e);
var r = e.length;
if (0 === r) return 0;
for (var n = !1; ;) switch (t) {
case "ascii":
case "latin1":
case "binary":
return r;

case "utf8":
case "utf-8":
case void 0:
return K(e).length;

case "ucs2":
case "ucs-2":
case "utf16le":
case "utf-16le":
return 2 * r;

case "hex":
return r >>> 1;

case "base64":
return J(e).length;

default:
if (n) return K(e).length;
t = ("" + t).toLowerCase();
n = !0;
}
}
f.byteLength = y;
function g(e, t, r) {
var n = !1;
(void 0 === t || t < 0) && (t = 0);
if (t > this.length) return "";
(void 0 === r || r > this.length) && (r = this.length);
if (r <= 0) return "";
if ((r >>>= 0) <= (t >>>= 0)) return "";
e || (e = "utf8");
for (;;) switch (e) {
case "hex":
return P(this, t, r);

case "utf8":
case "utf-8":
return O(this, t, r);

case "ascii":
return N(this, t, r);

case "latin1":
case "binary":
return j(this, t, r);

case "base64":
return I(this, t, r);

case "ucs2":
case "ucs-2":
case "utf16le":
case "utf-16le":
return D(this, t, r);

default:
if (n) throw new TypeError("Unknown encoding: " + e);
e = (e + "").toLowerCase();
n = !0;
}
}
f.prototype._isBuffer = !0;
function _(e, t, r) {
var n = e[t];
e[t] = e[r];
e[r] = n;
}
f.prototype.swap16 = function() {
var e = this.length;
if (e % 2 != 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
for (var t = 0; t < e; t += 2) _(this, t, t + 1);
return this;
};
f.prototype.swap32 = function() {
var e = this.length;
if (e % 4 != 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
for (var t = 0; t < e; t += 4) {
_(this, t, t + 3);
_(this, t + 1, t + 2);
}
return this;
};
f.prototype.swap64 = function() {
var e = this.length;
if (e % 8 != 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
for (var t = 0; t < e; t += 8) {
_(this, t, t + 7);
_(this, t + 1, t + 6);
_(this, t + 2, t + 5);
_(this, t + 3, t + 4);
}
return this;
};
f.prototype.toString = function() {
var e = 0 | this.length;
return 0 === e ? "" : 0 === arguments.length ? O(this, 0, e) : g.apply(this, arguments);
};
f.prototype.equals = function(e) {
if (!f.isBuffer(e)) throw new TypeError("Argument must be a Buffer");
return this === e || 0 === f.compare(this, e);
};
f.prototype.inspect = function() {
var e = "", t = r.INSPECT_MAX_BYTES;
if (this.length > 0) {
e = this.toString("hex", 0, t).match(/.{2}/g).join(" ");
this.length > t && (e += " ... ");
}
return "<Buffer " + e + ">";
};
f.prototype.compare = function(e, t, r, n, i) {
if (!f.isBuffer(e)) throw new TypeError("Argument must be a Buffer");
void 0 === t && (t = 0);
void 0 === r && (r = e ? e.length : 0);
void 0 === n && (n = 0);
void 0 === i && (i = this.length);
if (t < 0 || r > e.length || n < 0 || i > this.length) throw new RangeError("out of range index");
if (n >= i && t >= r) return 0;
if (n >= i) return -1;
if (t >= r) return 1;
if (this === e) return 0;
for (var o = (i >>>= 0) - (n >>>= 0), s = (r >>>= 0) - (t >>>= 0), a = Math.min(o, s), c = this.slice(n, i), u = e.slice(t, r), h = 0; h < a; ++h) if (c[h] !== u[h]) {
o = c[h];
s = u[h];
break;
}
return o < s ? -1 : s < o ? 1 : 0;
};
function w(e, t, r, n, i) {
if (0 === e.length) return -1;
if ("string" == typeof r) {
n = r;
r = 0;
} else r > 2147483647 ? r = 2147483647 : r < -2147483648 && (r = -2147483648);
r = +r;
isNaN(r) && (r = i ? 0 : e.length - 1);
r < 0 && (r = e.length + r);
if (r >= e.length) {
if (i) return -1;
r = e.length - 1;
} else if (r < 0) {
if (!i) return -1;
r = 0;
}
"string" == typeof t && (t = f.from(t, n));
if (f.isBuffer(t)) return 0 === t.length ? -1 : E(e, t, r, n, i);
if ("number" == typeof t) {
t &= 255;
return f.TYPED_ARRAY_SUPPORT && "function" == typeof Uint8Array.prototype.indexOf ? i ? Uint8Array.prototype.indexOf.call(e, t, r) : Uint8Array.prototype.lastIndexOf.call(e, t, r) : E(e, [ t ], r, n, i);
}
throw new TypeError("val must be string, number or Buffer");
}
function E(e, t, r, n, i) {
var o, s = 1, a = e.length, f = t.length;
if (void 0 !== n && ("ucs2" === (n = String(n).toLowerCase()) || "ucs-2" === n || "utf16le" === n || "utf-16le" === n)) {
if (e.length < 2 || t.length < 2) return -1;
s = 2;
a /= 2;
f /= 2;
r /= 2;
}
function c(e, t) {
return 1 === s ? e[t] : e.readUInt16BE(t * s);
}
if (i) {
var u = -1;
for (o = r; o < a; o++) if (c(e, o) === c(t, -1 === u ? 0 : o - u)) {
-1 === u && (u = o);
if (o - u + 1 === f) return u * s;
} else {
-1 !== u && (o -= o - u);
u = -1;
}
} else {
r + f > a && (r = a - f);
for (o = r; o >= 0; o--) {
for (var h = !0, d = 0; d < f; d++) if (c(e, o + d) !== c(t, d)) {
h = !1;
break;
}
if (h) return o;
}
}
return -1;
}
f.prototype.includes = function(e, t, r) {
return -1 !== this.indexOf(e, t, r);
};
f.prototype.indexOf = function(e, t, r) {
return w(this, e, t, r, !0);
};
f.prototype.lastIndexOf = function(e, t, r) {
return w(this, e, t, r, !1);
};
function S(e, t, r, n) {
r = Number(r) || 0;
var i = e.length - r;
n ? (n = Number(n)) > i && (n = i) : n = i;
var o = t.length;
if (o % 2 != 0) throw new TypeError("Invalid hex string");
n > o / 2 && (n = o / 2);
for (var s = 0; s < n; ++s) {
var a = parseInt(t.substr(2 * s, 2), 16);
if (isNaN(a)) return s;
e[r + s] = a;
}
return s;
}
function M(e, t, r, n) {
return Z(K(t, e.length - r), e, r, n);
}
function A(e, t, r, n) {
return Z(Y(t), e, r, n);
}
function x(e, t, r, n) {
return A(e, t, r, n);
}
function k(e, t, r, n) {
return Z(J(t), e, r, n);
}
function T(e, t, r, n) {
return Z(X(t, e.length - r), e, r, n);
}
f.prototype.write = function(e, t, r, n) {
if (void 0 === t) {
n = "utf8";
r = this.length;
t = 0;
} else if (void 0 === r && "string" == typeof t) {
n = t;
r = this.length;
t = 0;
} else {
if (!isFinite(t)) throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
t |= 0;
if (isFinite(r)) {
r |= 0;
void 0 === n && (n = "utf8");
} else {
n = r;
r = void 0;
}
}
var i = this.length - t;
(void 0 === r || r > i) && (r = i);
if (e.length > 0 && (r < 0 || t < 0) || t > this.length) throw new RangeError("Attempt to write outside buffer bounds");
n || (n = "utf8");
for (var o = !1; ;) switch (n) {
case "hex":
return S(this, e, t, r);

case "utf8":
case "utf-8":
return M(this, e, t, r);

case "ascii":
return A(this, e, t, r);

case "latin1":
case "binary":
return x(this, e, t, r);

case "base64":
return k(this, e, t, r);

case "ucs2":
case "ucs-2":
case "utf16le":
case "utf-16le":
return T(this, e, t, r);

default:
if (o) throw new TypeError("Unknown encoding: " + n);
n = ("" + n).toLowerCase();
o = !0;
}
};
f.prototype.toJSON = function() {
return {
type: "Buffer",
data: Array.prototype.slice.call(this._arr || this, 0)
};
};
function I(e, t, r) {
return 0 === t && r === e.length ? n.fromByteArray(e) : n.fromByteArray(e.slice(t, r));
}
function O(e, t, r) {
r = Math.min(e.length, r);
for (var n = [], i = t; i < r; ) {
var o = e[i], s = null, a = o > 239 ? 4 : o > 223 ? 3 : o > 191 ? 2 : 1;
if (i + a <= r) {
var f, c, u, h;
switch (a) {
case 1:
o < 128 && (s = o);
break;

case 2:
128 == (192 & (f = e[i + 1])) && (h = (31 & o) << 6 | 63 & f) > 127 && (s = h);
break;

case 3:
f = e[i + 1];
c = e[i + 2];
128 == (192 & f) && 128 == (192 & c) && (h = (15 & o) << 12 | (63 & f) << 6 | 63 & c) > 2047 && (h < 55296 || h > 57343) && (s = h);
break;

case 4:
f = e[i + 1];
c = e[i + 2];
u = e[i + 3];
128 == (192 & f) && 128 == (192 & c) && 128 == (192 & u) && (h = (15 & o) << 18 | (63 & f) << 12 | (63 & c) << 6 | 63 & u) > 65535 && h < 1114112 && (s = h);
}
}
if (null === s) {
s = 65533;
a = 1;
} else if (s > 65535) {
s -= 65536;
n.push(s >>> 10 & 1023 | 55296);
s = 56320 | 1023 & s;
}
n.push(s);
i += a;
}
return C(n);
}
var R = 4096;
function C(e) {
var t = e.length;
if (t <= R) return String.fromCharCode.apply(String, e);
for (var r = "", n = 0; n < t; ) r += String.fromCharCode.apply(String, e.slice(n, n += R));
return r;
}
function N(e, t, r) {
var n = "";
r = Math.min(e.length, r);
for (var i = t; i < r; ++i) n += String.fromCharCode(127 & e[i]);
return n;
}
function j(e, t, r) {
var n = "";
r = Math.min(e.length, r);
for (var i = t; i < r; ++i) n += String.fromCharCode(e[i]);
return n;
}
function P(e, t, r) {
var n, i = e.length;
(!t || t < 0) && (t = 0);
(!r || r < 0 || r > i) && (r = i);
for (var o = "", s = t; s < r; ++s) o += (n = e[s]) < 16 ? "0" + n.toString(16) : n.toString(16);
return o;
}
function D(e, t, r) {
for (var n = e.slice(t, r), i = "", o = 0; o < n.length; o += 2) i += String.fromCharCode(n[o] + 256 * n[o + 1]);
return i;
}
f.prototype.slice = function(e, t) {
var r, n = this.length;
(e = ~~e) < 0 ? (e += n) < 0 && (e = 0) : e > n && (e = n);
(t = void 0 === t ? n : ~~t) < 0 ? (t += n) < 0 && (t = 0) : t > n && (t = n);
t < e && (t = e);
if (f.TYPED_ARRAY_SUPPORT) (r = this.subarray(e, t)).__proto__ = f.prototype; else {
var i = t - e;
r = new f(i, void 0);
for (var o = 0; o < i; ++o) r[o] = this[o + e];
}
return r;
};
function L(e, t, r) {
if (e % 1 != 0 || e < 0) throw new RangeError("offset is not uint");
if (e + t > r) throw new RangeError("Trying to access beyond buffer length");
}
f.prototype.readUIntLE = function(e, t, r) {
e |= 0;
t |= 0;
r || L(e, t, this.length);
for (var n = this[e], i = 1, o = 0; ++o < t && (i *= 256); ) n += this[e + o] * i;
return n;
};
f.prototype.readUIntBE = function(e, t, r) {
e |= 0;
t |= 0;
r || L(e, t, this.length);
for (var n = this[e + --t], i = 1; t > 0 && (i *= 256); ) n += this[e + --t] * i;
return n;
};
f.prototype.readUInt8 = function(e, t) {
t || L(e, 1, this.length);
return this[e];
};
f.prototype.readUInt16LE = function(e, t) {
t || L(e, 2, this.length);
return this[e] | this[e + 1] << 8;
};
f.prototype.readUInt16BE = function(e, t) {
t || L(e, 2, this.length);
return this[e] << 8 | this[e + 1];
};
f.prototype.readUInt32LE = function(e, t) {
t || L(e, 4, this.length);
return (this[e] | this[e + 1] << 8 | this[e + 2] << 16) + 16777216 * this[e + 3];
};
f.prototype.readUInt32BE = function(e, t) {
t || L(e, 4, this.length);
return 16777216 * this[e] + (this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3]);
};
f.prototype.readIntLE = function(e, t, r) {
e |= 0;
t |= 0;
r || L(e, t, this.length);
for (var n = this[e], i = 1, o = 0; ++o < t && (i *= 256); ) n += this[e + o] * i;
n >= (i *= 128) && (n -= Math.pow(2, 8 * t));
return n;
};
f.prototype.readIntBE = function(e, t, r) {
e |= 0;
t |= 0;
r || L(e, t, this.length);
for (var n = t, i = 1, o = this[e + --n]; n > 0 && (i *= 256); ) o += this[e + --n] * i;
o >= (i *= 128) && (o -= Math.pow(2, 8 * t));
return o;
};
f.prototype.readInt8 = function(e, t) {
t || L(e, 1, this.length);
return 128 & this[e] ? -1 * (255 - this[e] + 1) : this[e];
};
f.prototype.readInt16LE = function(e, t) {
t || L(e, 2, this.length);
var r = this[e] | this[e + 1] << 8;
return 32768 & r ? 4294901760 | r : r;
};
f.prototype.readInt16BE = function(e, t) {
t || L(e, 2, this.length);
var r = this[e + 1] | this[e] << 8;
return 32768 & r ? 4294901760 | r : r;
};
f.prototype.readInt32LE = function(e, t) {
t || L(e, 4, this.length);
return this[e] | this[e + 1] << 8 | this[e + 2] << 16 | this[e + 3] << 24;
};
f.prototype.readInt32BE = function(e, t) {
t || L(e, 4, this.length);
return this[e] << 24 | this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3];
};
f.prototype.readFloatLE = function(e, t) {
t || L(e, 4, this.length);
return i.read(this, e, !0, 23, 4);
};
f.prototype.readFloatBE = function(e, t) {
t || L(e, 4, this.length);
return i.read(this, e, !1, 23, 4);
};
f.prototype.readDoubleLE = function(e, t) {
t || L(e, 8, this.length);
return i.read(this, e, !0, 52, 8);
};
f.prototype.readDoubleBE = function(e, t) {
t || L(e, 8, this.length);
return i.read(this, e, !1, 52, 8);
};
function B(e, t, r, n, i, o) {
if (!f.isBuffer(e)) throw new TypeError('"buffer" argument must be a Buffer instance');
if (t > i || t < o) throw new RangeError('"value" argument is out of bounds');
if (r + n > e.length) throw new RangeError("Index out of range");
}
f.prototype.writeUIntLE = function(e, t, r, n) {
e = +e;
t |= 0;
r |= 0;
n || B(this, e, t, r, Math.pow(2, 8 * r) - 1, 0);
var i = 1, o = 0;
this[t] = 255 & e;
for (;++o < r && (i *= 256); ) this[t + o] = e / i & 255;
return t + r;
};
f.prototype.writeUIntBE = function(e, t, r, n) {
e = +e;
t |= 0;
r |= 0;
n || B(this, e, t, r, Math.pow(2, 8 * r) - 1, 0);
var i = r - 1, o = 1;
this[t + i] = 255 & e;
for (;--i >= 0 && (o *= 256); ) this[t + i] = e / o & 255;
return t + r;
};
f.prototype.writeUInt8 = function(e, t, r) {
e = +e;
t |= 0;
r || B(this, e, t, 1, 255, 0);
f.TYPED_ARRAY_SUPPORT || (e = Math.floor(e));
this[t] = 255 & e;
return t + 1;
};
function U(e, t, r, n) {
t < 0 && (t = 65535 + t + 1);
for (var i = 0, o = Math.min(e.length - r, 2); i < o; ++i) e[r + i] = (t & 255 << 8 * (n ? i : 1 - i)) >>> 8 * (n ? i : 1 - i);
}
f.prototype.writeUInt16LE = function(e, t, r) {
e = +e;
t |= 0;
r || B(this, e, t, 2, 65535, 0);
if (f.TYPED_ARRAY_SUPPORT) {
this[t] = 255 & e;
this[t + 1] = e >>> 8;
} else U(this, e, t, !0);
return t + 2;
};
f.prototype.writeUInt16BE = function(e, t, r) {
e = +e;
t |= 0;
r || B(this, e, t, 2, 65535, 0);
if (f.TYPED_ARRAY_SUPPORT) {
this[t] = e >>> 8;
this[t + 1] = 255 & e;
} else U(this, e, t, !1);
return t + 2;
};
function F(e, t, r, n) {
t < 0 && (t = 4294967295 + t + 1);
for (var i = 0, o = Math.min(e.length - r, 4); i < o; ++i) e[r + i] = t >>> 8 * (n ? i : 3 - i) & 255;
}
f.prototype.writeUInt32LE = function(e, t, r) {
e = +e;
t |= 0;
r || B(this, e, t, 4, 4294967295, 0);
if (f.TYPED_ARRAY_SUPPORT) {
this[t + 3] = e >>> 24;
this[t + 2] = e >>> 16;
this[t + 1] = e >>> 8;
this[t] = 255 & e;
} else F(this, e, t, !0);
return t + 4;
};
f.prototype.writeUInt32BE = function(e, t, r) {
e = +e;
t |= 0;
r || B(this, e, t, 4, 4294967295, 0);
if (f.TYPED_ARRAY_SUPPORT) {
this[t] = e >>> 24;
this[t + 1] = e >>> 16;
this[t + 2] = e >>> 8;
this[t + 3] = 255 & e;
} else F(this, e, t, !1);
return t + 4;
};
f.prototype.writeIntLE = function(e, t, r, n) {
e = +e;
t |= 0;
if (!n) {
var i = Math.pow(2, 8 * r - 1);
B(this, e, t, r, i - 1, -i);
}
var o = 0, s = 1, a = 0;
this[t] = 255 & e;
for (;++o < r && (s *= 256); ) {
e < 0 && 0 === a && 0 !== this[t + o - 1] && (a = 1);
this[t + o] = (e / s >> 0) - a & 255;
}
return t + r;
};
f.prototype.writeIntBE = function(e, t, r, n) {
e = +e;
t |= 0;
if (!n) {
var i = Math.pow(2, 8 * r - 1);
B(this, e, t, r, i - 1, -i);
}
var o = r - 1, s = 1, a = 0;
this[t + o] = 255 & e;
for (;--o >= 0 && (s *= 256); ) {
e < 0 && 0 === a && 0 !== this[t + o + 1] && (a = 1);
this[t + o] = (e / s >> 0) - a & 255;
}
return t + r;
};
f.prototype.writeInt8 = function(e, t, r) {
e = +e;
t |= 0;
r || B(this, e, t, 1, 127, -128);
f.TYPED_ARRAY_SUPPORT || (e = Math.floor(e));
e < 0 && (e = 255 + e + 1);
this[t] = 255 & e;
return t + 1;
};
f.prototype.writeInt16LE = function(e, t, r) {
e = +e;
t |= 0;
r || B(this, e, t, 2, 32767, -32768);
if (f.TYPED_ARRAY_SUPPORT) {
this[t] = 255 & e;
this[t + 1] = e >>> 8;
} else U(this, e, t, !0);
return t + 2;
};
f.prototype.writeInt16BE = function(e, t, r) {
e = +e;
t |= 0;
r || B(this, e, t, 2, 32767, -32768);
if (f.TYPED_ARRAY_SUPPORT) {
this[t] = e >>> 8;
this[t + 1] = 255 & e;
} else U(this, e, t, !1);
return t + 2;
};
f.prototype.writeInt32LE = function(e, t, r) {
e = +e;
t |= 0;
r || B(this, e, t, 4, 2147483647, -2147483648);
if (f.TYPED_ARRAY_SUPPORT) {
this[t] = 255 & e;
this[t + 1] = e >>> 8;
this[t + 2] = e >>> 16;
this[t + 3] = e >>> 24;
} else F(this, e, t, !0);
return t + 4;
};
f.prototype.writeInt32BE = function(e, t, r) {
e = +e;
t |= 0;
r || B(this, e, t, 4, 2147483647, -2147483648);
e < 0 && (e = 4294967295 + e + 1);
if (f.TYPED_ARRAY_SUPPORT) {
this[t] = e >>> 24;
this[t + 1] = e >>> 16;
this[t + 2] = e >>> 8;
this[t + 3] = 255 & e;
} else F(this, e, t, !1);
return t + 4;
};
function q(e, t, r, n) {
if (r + n > e.length) throw new RangeError("Index out of range");
if (r < 0) throw new RangeError("Index out of range");
}
function V(e, t, r, n, o) {
o || q(e, 0, r, 4);
i.write(e, t, r, n, 23, 4);
return r + 4;
}
f.prototype.writeFloatLE = function(e, t, r) {
return V(this, e, t, !0, r);
};
f.prototype.writeFloatBE = function(e, t, r) {
return V(this, e, t, !1, r);
};
function H(e, t, r, n, o) {
o || q(e, 0, r, 8);
i.write(e, t, r, n, 52, 8);
return r + 8;
}
f.prototype.writeDoubleLE = function(e, t, r) {
return H(this, e, t, !0, r);
};
f.prototype.writeDoubleBE = function(e, t, r) {
return H(this, e, t, !1, r);
};
f.prototype.copy = function(e, t, r, n) {
r || (r = 0);
n || 0 === n || (n = this.length);
t >= e.length && (t = e.length);
t || (t = 0);
n > 0 && n < r && (n = r);
if (n === r) return 0;
if (0 === e.length || 0 === this.length) return 0;
if (t < 0) throw new RangeError("targetStart out of bounds");
if (r < 0 || r >= this.length) throw new RangeError("sourceStart out of bounds");
if (n < 0) throw new RangeError("sourceEnd out of bounds");
n > this.length && (n = this.length);
e.length - t < n - r && (n = e.length - t + r);
var i, o = n - r;
if (this === e && r < t && t < n) for (i = o - 1; i >= 0; --i) e[i + t] = this[i + r]; else if (o < 1e3 || !f.TYPED_ARRAY_SUPPORT) for (i = 0; i < o; ++i) e[i + t] = this[i + r]; else Uint8Array.prototype.set.call(e, this.subarray(r, r + o), t);
return o;
};
f.prototype.fill = function(e, t, r, n) {
if ("string" == typeof e) {
if ("string" == typeof t) {
n = t;
t = 0;
r = this.length;
} else if ("string" == typeof r) {
n = r;
r = this.length;
}
if (1 === e.length) {
var i = e.charCodeAt(0);
i < 256 && (e = i);
}
if (void 0 !== n && "string" != typeof n) throw new TypeError("encoding must be a string");
if ("string" == typeof n && !f.isEncoding(n)) throw new TypeError("Unknown encoding: " + n);
} else "number" == typeof e && (e &= 255);
if (t < 0 || this.length < t || this.length < r) throw new RangeError("Out of range index");
if (r <= t) return this;
t >>>= 0;
r = void 0 === r ? this.length : r >>> 0;
e || (e = 0);
var o;
if ("number" == typeof e) for (o = t; o < r; ++o) this[o] = e; else {
var s = f.isBuffer(e) ? e : K(new f(e, n).toString()), a = s.length;
for (o = 0; o < r - t; ++o) this[o + t] = s[o % a];
}
return this;
};
var z = /[^+\/0-9A-Za-z-_]/g;
function G(e) {
if ((e = W(e).replace(z, "")).length < 2) return "";
for (;e.length % 4 != 0; ) e += "=";
return e;
}
function W(e) {
return e.trim ? e.trim() : e.replace(/^\s+|\s+$/g, "");
}
function K(e, t) {
t = t || Infinity;
for (var r, n = e.length, i = null, o = [], s = 0; s < n; ++s) {
if ((r = e.charCodeAt(s)) > 55295 && r < 57344) {
if (!i) {
if (r > 56319) {
(t -= 3) > -1 && o.push(239, 191, 189);
continue;
}
if (s + 1 === n) {
(t -= 3) > -1 && o.push(239, 191, 189);
continue;
}
i = r;
continue;
}
if (r < 56320) {
(t -= 3) > -1 && o.push(239, 191, 189);
i = r;
continue;
}
r = 65536 + (i - 55296 << 10 | r - 56320);
} else i && (t -= 3) > -1 && o.push(239, 191, 189);
i = null;
if (r < 128) {
if ((t -= 1) < 0) break;
o.push(r);
} else if (r < 2048) {
if ((t -= 2) < 0) break;
o.push(r >> 6 | 192, 63 & r | 128);
} else if (r < 65536) {
if ((t -= 3) < 0) break;
o.push(r >> 12 | 224, r >> 6 & 63 | 128, 63 & r | 128);
} else {
if (!(r < 1114112)) throw new Error("Invalid code point");
if ((t -= 4) < 0) break;
o.push(r >> 18 | 240, r >> 12 & 63 | 128, r >> 6 & 63 | 128, 63 & r | 128);
}
}
return o;
}
function Y(e) {
for (var t = [], r = 0; r < e.length; ++r) t.push(255 & e.charCodeAt(r));
return t;
}
function X(e, t) {
for (var r, n, i, o = [], s = 0; s < e.length && !((t -= 2) < 0); ++s) {
n = (r = e.charCodeAt(s)) >> 8;
i = r % 256;
o.push(i);
o.push(n);
}
return o;
}
function J(e) {
return n.toByteArray(G(e));
}
function Z(e, t, r, n) {
for (var i = 0; i < n && !(i + r >= t.length || i >= e.length); ++i) t[i + r] = e[i];
return i;
}
}).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"base64-js": 16,
ieee754: 137,
isarray: 66
} ],
66: [ function(e, t) {
var r = {}.toString;
t.exports = Array.isArray || function(e) {
return "[object Array]" == r.call(e);
};
}, {} ],
67: [ function(e, t) {
var r = e("safe-buffer").Buffer, n = e("stream").Transform, i = e("string_decoder").StringDecoder;
function o(e) {
n.call(this);
this.hashMode = "string" == typeof e;
this.hashMode ? this[e] = this._finalOrDigest : this.final = this._finalOrDigest;
if (this._final) {
this.__final = this._final;
this._final = null;
}
this._decoder = null;
this._encoding = null;
}
e("inherits")(o, n);
o.prototype.update = function(e, t, n) {
"string" == typeof e && (e = r.from(e, t));
var i = this._update(e);
if (this.hashMode) return this;
n && (i = this._toString(i, n));
return i;
};
o.prototype.setAutoPadding = function() {};
o.prototype.getAuthTag = function() {
throw new Error("trying to get auth tag in unsupported state");
};
o.prototype.setAuthTag = function() {
throw new Error("trying to set auth tag in unsupported state");
};
o.prototype.setAAD = function() {
throw new Error("trying to set aad in unsupported state");
};
o.prototype._transform = function(e, t, r) {
var n;
try {
this.hashMode ? this._update(e) : this.push(this._update(e));
} catch (e) {
n = e;
} finally {
r(n);
}
};
o.prototype._flush = function(e) {
var t;
try {
this.push(this.__final());
} catch (e) {
t = e;
}
e(t);
};
o.prototype._finalOrDigest = function(e) {
var t = this.__final() || r.alloc(0);
e && (t = this._toString(t, e, !0));
return t;
};
o.prototype._toString = function(e, t, r) {
if (!this._decoder) {
this._decoder = new i(t);
this._encoding = t;
}
if (this._encoding !== t) throw new Error("can't switch encodings");
var n = this._decoder.write(e);
r && (n += this._decoder.end());
return n;
};
t.exports = o;
}, {
inherits: 138,
"safe-buffer": 183,
stream: 193,
string_decoder: 194
} ],
68: [ function(e, t, r) {
(function(e) {
r.isArray = function(e) {
return Array.isArray ? Array.isArray(e) : "[object Array]" === t(e);
};
r.isBoolean = function(e) {
return "boolean" == typeof e;
};
r.isNull = function(e) {
return null === e;
};
r.isNullOrUndefined = function(e) {
return null == e;
};
r.isNumber = function(e) {
return "number" == typeof e;
};
r.isString = function(e) {
return "string" == typeof e;
};
r.isSymbol = function(e) {
return "symbol" == typeof e;
};
r.isUndefined = function(e) {
return void 0 === e;
};
r.isRegExp = function(e) {
return "[object RegExp]" === t(e);
};
r.isObject = function(e) {
return "object" == typeof e && null !== e;
};
r.isDate = function(e) {
return "[object Date]" === t(e);
};
r.isError = function(e) {
return "[object Error]" === t(e) || e instanceof Error;
};
r.isFunction = function(e) {
return "function" == typeof e;
};
r.isPrimitive = function(e) {
return null === e || "boolean" == typeof e || "number" == typeof e || "string" == typeof e || "symbol" == typeof e || "undefined" == typeof e;
};
r.isBuffer = e.isBuffer;
function t(e) {
return Object.prototype.toString.call(e);
}
}).call(this, {
isBuffer: e("../../is-buffer/index.js")
});
}, {
"../../is-buffer/index.js": 139
} ],
69: [ function(e, t) {
(function(r) {
var n = e("elliptic"), i = e("bn.js");
t.exports = function(e) {
return new s(e);
};
var o = {
secp256k1: {
name: "secp256k1",
byteLength: 32
},
secp224r1: {
name: "p224",
byteLength: 28
},
prime256v1: {
name: "p256",
byteLength: 32
},
prime192v1: {
name: "p192",
byteLength: 24
},
ed25519: {
name: "ed25519",
byteLength: 32
},
secp384r1: {
name: "p384",
byteLength: 48
},
secp521r1: {
name: "p521",
byteLength: 66
}
};
o.p224 = o.secp224r1;
o.p256 = o.secp256r1 = o.prime256v1;
o.p192 = o.secp192r1 = o.prime192v1;
o.p384 = o.secp384r1;
o.p521 = o.secp521r1;
function s(e) {
this.curveType = o[e];
this.curveType || (this.curveType = {
name: e
});
this.curve = new n.ec(this.curveType.name);
this.keys = void 0;
}
s.prototype.generateKeys = function(e, t) {
this.keys = this.curve.genKeyPair();
return this.getPublicKey(e, t);
};
s.prototype.computeSecret = function(e, t, n) {
t = t || "utf8";
r.isBuffer(e) || (e = new r(e, t));
return a(this.curve.keyFromPublic(e).getPublic().mul(this.keys.getPrivate()).getX(), n, this.curveType.byteLength);
};
s.prototype.getPublicKey = function(e, t) {
var r = this.keys.getPublic("compressed" === t, !0);
"hybrid" === t && (r[r.length - 1] % 2 ? r[0] = 7 : r[0] = 6);
return a(r, e);
};
s.prototype.getPrivateKey = function(e) {
return a(this.keys.getPrivate(), e);
};
s.prototype.setPublicKey = function(e, t) {
t = t || "utf8";
r.isBuffer(e) || (e = new r(e, t));
this.keys._importPublic(e);
return this;
};
s.prototype.setPrivateKey = function(e, t) {
t = t || "utf8";
r.isBuffer(e) || (e = new r(e, t));
var n = new i(e);
n = n.toString(16);
this.keys = this.curve.genKeyPair();
this.keys._importPrivate(n);
return this;
};
function a(e, t, n) {
Array.isArray(e) || (e = e.toArray());
var i = new r(e);
if (n && i.length < n) {
var o = new r(n - i.length);
o.fill(0);
i = r.concat([ o, i ]);
}
return t ? i.toString(t) : i;
}
}).call(this, e("buffer").Buffer);
}, {
"bn.js": 70,
buffer: 65,
elliptic: 87
} ],
70: [ function(e, t, r) {
arguments[4][15][0].apply(r, arguments);
}, {
buffer: 19,
dup: 15
} ],
71: [ function(e, t) {
"use strict";
var r = e("inherits"), n = e("md5.js"), i = e("ripemd160"), o = e("sha.js"), s = e("cipher-base");
function a(e) {
s.call(this, "digest");
this._hash = e;
}
r(a, s);
a.prototype._update = function(e) {
this._hash.update(e);
};
a.prototype._final = function() {
return this._hash.digest();
};
t.exports = function(e) {
return "md5" === (e = e.toLowerCase()) ? new n() : "rmd160" === e || "ripemd160" === e ? new i() : new a(o(e));
};
}, {
"cipher-base": 67,
inherits: 138,
"md5.js": 140,
ripemd160: 182,
"sha.js": 186
} ],
72: [ function(e, t) {
var r = e("md5.js");
t.exports = function(e) {
return new r().update(e).digest();
};
}, {
"md5.js": 140
} ],
73: [ function(e, t) {
"use strict";
var r = e("inherits"), n = e("./legacy"), i = e("cipher-base"), o = e("safe-buffer").Buffer, s = e("create-hash/md5"), a = e("ripemd160"), f = e("sha.js"), c = o.alloc(128);
function u(e, t) {
i.call(this, "digest");
"string" == typeof t && (t = o.from(t));
var r = "sha512" === e || "sha384" === e ? 128 : 64;
this._alg = e;
this._key = t;
t.length > r ? t = ("rmd160" === e ? new a() : f(e)).update(t).digest() : t.length < r && (t = o.concat([ t, c ], r));
for (var n = this._ipad = o.allocUnsafe(r), s = this._opad = o.allocUnsafe(r), u = 0; u < r; u++) {
n[u] = 54 ^ t[u];
s[u] = 92 ^ t[u];
}
this._hash = "rmd160" === e ? new a() : f(e);
this._hash.update(n);
}
r(u, i);
u.prototype._update = function(e) {
this._hash.update(e);
};
u.prototype._final = function() {
var e = this._hash.digest();
return ("rmd160" === this._alg ? new a() : f(this._alg)).update(this._opad).update(e).digest();
};
t.exports = function(e, t) {
return "rmd160" === (e = e.toLowerCase()) || "ripemd160" === e ? new u("rmd160", t) : "md5" === e ? new n(s, t) : new u(e, t);
};
}, {
"./legacy": 74,
"cipher-base": 67,
"create-hash/md5": 72,
inherits: 138,
ripemd160: 182,
"safe-buffer": 183,
"sha.js": 186
} ],
74: [ function(e, t) {
"use strict";
var r = e("inherits"), n = e("safe-buffer").Buffer, i = e("cipher-base"), o = n.alloc(128), s = 64;
function a(e, t) {
i.call(this, "digest");
"string" == typeof t && (t = n.from(t));
this._alg = e;
this._key = t;
t.length > s ? t = e(t) : t.length < s && (t = n.concat([ t, o ], s));
for (var r = this._ipad = n.allocUnsafe(s), a = this._opad = n.allocUnsafe(s), f = 0; f < s; f++) {
r[f] = 54 ^ t[f];
a[f] = 92 ^ t[f];
}
this._hash = [ r ];
}
r(a, i);
a.prototype._update = function(e) {
this._hash.push(e);
};
a.prototype._final = function() {
var e = this._alg(n.concat(this._hash));
return this._alg(n.concat([ this._opad, e ]));
};
t.exports = a;
}, {
"cipher-base": 67,
inherits: 138,
"safe-buffer": 183
} ],
75: [ function(e, t, r) {
"use strict";
r.randomBytes = r.rng = r.pseudoRandomBytes = r.prng = e("randombytes");
r.createHash = r.Hash = e("create-hash");
r.createHmac = r.Hmac = e("create-hmac");
var n = e("browserify-sign/algos"), i = Object.keys(n), o = [ "sha1", "sha224", "sha256", "sha384", "sha512", "md5", "rmd160" ].concat(i);
r.getHashes = function() {
return o;
};
var s = e("pbkdf2");
r.pbkdf2 = s.pbkdf2;
r.pbkdf2Sync = s.pbkdf2Sync;
var a = e("browserify-cipher");
r.Cipher = a.Cipher;
r.createCipher = a.createCipher;
r.Cipheriv = a.Cipheriv;
r.createCipheriv = a.createCipheriv;
r.Decipher = a.Decipher;
r.createDecipher = a.createDecipher;
r.Decipheriv = a.Decipheriv;
r.createDecipheriv = a.createDecipheriv;
r.getCiphers = a.getCiphers;
r.listCiphers = a.listCiphers;
var f = e("diffie-hellman");
r.DiffieHellmanGroup = f.DiffieHellmanGroup;
r.createDiffieHellmanGroup = f.createDiffieHellmanGroup;
r.getDiffieHellman = f.getDiffieHellman;
r.createDiffieHellman = f.createDiffieHellman;
r.DiffieHellman = f.DiffieHellman;
var c = e("browserify-sign");
r.createSign = c.createSign;
r.Sign = c.Sign;
r.createVerify = c.createVerify;
r.Verify = c.Verify;
r.createECDH = e("create-ecdh");
var u = e("public-encrypt");
r.publicEncrypt = u.publicEncrypt;
r.privateEncrypt = u.privateEncrypt;
r.publicDecrypt = u.publicDecrypt;
r.privateDecrypt = u.privateDecrypt;
var h = e("randomfill");
r.randomFill = h.randomFill;
r.randomFillSync = h.randomFillSync;
r.createCredentials = function() {
throw new Error([ "sorry, createCredentials is not implemented yet", "we accept pull requests", "https://github.com/crypto-browserify/crypto-browserify" ].join("\n"));
};
r.constants = {
DH_CHECK_P_NOT_SAFE_PRIME: 2,
DH_CHECK_P_NOT_PRIME: 1,
DH_UNABLE_TO_CHECK_GENERATOR: 4,
DH_NOT_SUITABLE_GENERATOR: 8,
NPN_ENABLED: 1,
ALPN_ENABLED: 1,
RSA_PKCS1_PADDING: 1,
RSA_SSLV23_PADDING: 2,
RSA_NO_PADDING: 3,
RSA_PKCS1_OAEP_PADDING: 4,
RSA_X931_PADDING: 5,
RSA_PKCS1_PSS_PADDING: 6,
POINT_CONVERSION_COMPRESSED: 2,
POINT_CONVERSION_UNCOMPRESSED: 4,
POINT_CONVERSION_HYBRID: 6
};
}, {
"browserify-cipher": 37,
"browserify-sign": 44,
"browserify-sign/algos": 41,
"create-ecdh": 69,
"create-hash": 71,
"create-hmac": 73,
"diffie-hellman": 82,
pbkdf2: 150,
"public-encrypt": 158,
randombytes: 165,
randomfill: 166
} ],
76: [ function(e, t, r) {
"use strict";
r.utils = e("./des/utils");
r.Cipher = e("./des/cipher");
r.DES = e("./des/des");
r.CBC = e("./des/cbc");
r.EDE = e("./des/ede");
}, {
"./des/cbc": 77,
"./des/cipher": 78,
"./des/des": 79,
"./des/ede": 80,
"./des/utils": 81
} ],
77: [ function(e, t, r) {
"use strict";
var n = e("minimalistic-assert"), i = e("inherits"), o = {};
function s(e) {
n.equal(e.length, 8, "Invalid IV length");
this.iv = new Array(8);
for (var t = 0; t < this.iv.length; t++) this.iv[t] = e[t];
}
r.instantiate = function(e) {
function t(t) {
e.call(this, t);
this._cbcInit();
}
i(t, e);
for (var r = Object.keys(o), n = 0; n < r.length; n++) {
var s = r[n];
t.prototype[s] = o[s];
}
t.create = function(e) {
return new t(e);
};
return t;
};
o._cbcInit = function() {
var e = new s(this.options.iv);
this._cbcState = e;
};
o._update = function(e, t, r, n) {
var i = this._cbcState, o = this.constructor.super_.prototype, s = i.iv;
if ("encrypt" === this.type) {
for (var a = 0; a < this.blockSize; a++) s[a] ^= e[t + a];
o._update.call(this, s, 0, r, n);
for (a = 0; a < this.blockSize; a++) s[a] = r[n + a];
} else {
o._update.call(this, e, t, r, n);
for (a = 0; a < this.blockSize; a++) r[n + a] ^= s[a];
for (a = 0; a < this.blockSize; a++) s[a] = e[t + a];
}
};
}, {
inherits: 138,
"minimalistic-assert": 143
} ],
78: [ function(e, t) {
"use strict";
var r = e("minimalistic-assert");
function n(e) {
this.options = e;
this.type = this.options.type;
this.blockSize = 8;
this._init();
this.buffer = new Array(this.blockSize);
this.bufferOff = 0;
}
t.exports = n;
n.prototype._init = function() {};
n.prototype.update = function(e) {
return 0 === e.length ? [] : "decrypt" === this.type ? this._updateDecrypt(e) : this._updateEncrypt(e);
};
n.prototype._buffer = function(e, t) {
for (var r = Math.min(this.buffer.length - this.bufferOff, e.length - t), n = 0; n < r; n++) this.buffer[this.bufferOff + n] = e[t + n];
this.bufferOff += r;
return r;
};
n.prototype._flushBuffer = function(e, t) {
this._update(this.buffer, 0, e, t);
this.bufferOff = 0;
return this.blockSize;
};
n.prototype._updateEncrypt = function(e) {
var t = 0, r = 0, n = (this.bufferOff + e.length) / this.blockSize | 0, i = new Array(n * this.blockSize);
if (0 !== this.bufferOff) {
t += this._buffer(e, t);
this.bufferOff === this.buffer.length && (r += this._flushBuffer(i, r));
}
for (var o = e.length - (e.length - t) % this.blockSize; t < o; t += this.blockSize) {
this._update(e, t, i, r);
r += this.blockSize;
}
for (;t < e.length; t++, this.bufferOff++) this.buffer[this.bufferOff] = e[t];
return i;
};
n.prototype._updateDecrypt = function(e) {
for (var t = 0, r = 0, n = Math.ceil((this.bufferOff + e.length) / this.blockSize) - 1, i = new Array(n * this.blockSize); n > 0; n--) {
t += this._buffer(e, t);
r += this._flushBuffer(i, r);
}
t += this._buffer(e, t);
return i;
};
n.prototype.final = function(e) {
var t, r;
e && (t = this.update(e));
r = "encrypt" === this.type ? this._finalEncrypt() : this._finalDecrypt();
return t ? t.concat(r) : r;
};
n.prototype._pad = function(e, t) {
if (0 === t) return !1;
for (;t < e.length; ) e[t++] = 0;
return !0;
};
n.prototype._finalEncrypt = function() {
if (!this._pad(this.buffer, this.bufferOff)) return [];
var e = new Array(this.blockSize);
this._update(this.buffer, 0, e, 0);
return e;
};
n.prototype._unpad = function(e) {
return e;
};
n.prototype._finalDecrypt = function() {
r.equal(this.bufferOff, this.blockSize, "Not enough data to decrypt");
var e = new Array(this.blockSize);
this._flushBuffer(e, 0);
return this._unpad(e);
};
}, {
"minimalistic-assert": 143
} ],
79: [ function(e, t) {
"use strict";
var r = e("minimalistic-assert"), n = e("inherits"), i = e("./utils"), o = e("./cipher");
function s() {
this.tmp = new Array(2);
this.keys = null;
}
function a(e) {
o.call(this, e);
var t = new s();
this._desState = t;
this.deriveKeys(t, e.key);
}
n(a, o);
t.exports = a;
a.create = function(e) {
return new a(e);
};
var f = [ 1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1 ];
a.prototype.deriveKeys = function(e, t) {
e.keys = new Array(32);
r.equal(t.length, this.blockSize, "Invalid key length");
var n = i.readUInt32BE(t, 0), o = i.readUInt32BE(t, 4);
i.pc1(n, o, e.tmp, 0);
n = e.tmp[0];
o = e.tmp[1];
for (var s = 0; s < e.keys.length; s += 2) {
var a = f[s >>> 1];
n = i.r28shl(n, a);
o = i.r28shl(o, a);
i.pc2(n, o, e.keys, s);
}
};
a.prototype._update = function(e, t, r, n) {
var o = this._desState, s = i.readUInt32BE(e, t), a = i.readUInt32BE(e, t + 4);
i.ip(s, a, o.tmp, 0);
s = o.tmp[0];
a = o.tmp[1];
"encrypt" === this.type ? this._encrypt(o, s, a, o.tmp, 0) : this._decrypt(o, s, a, o.tmp, 0);
s = o.tmp[0];
a = o.tmp[1];
i.writeUInt32BE(r, s, n);
i.writeUInt32BE(r, a, n + 4);
};
a.prototype._pad = function(e, t) {
for (var r = e.length - t, n = t; n < e.length; n++) e[n] = r;
return !0;
};
a.prototype._unpad = function(e) {
for (var t = e[e.length - 1], n = e.length - t; n < e.length; n++) r.equal(e[n], t);
return e.slice(0, e.length - t);
};
a.prototype._encrypt = function(e, t, r, n, o) {
for (var s = t, a = r, f = 0; f < e.keys.length; f += 2) {
var c = e.keys[f], u = e.keys[f + 1];
i.expand(a, e.tmp, 0);
c ^= e.tmp[0];
u ^= e.tmp[1];
var h = i.substitute(c, u), d = a;
a = (s ^ i.permute(h)) >>> 0;
s = d;
}
i.rip(a, s, n, o);
};
a.prototype._decrypt = function(e, t, r, n, o) {
for (var s = r, a = t, f = e.keys.length - 2; f >= 0; f -= 2) {
var c = e.keys[f], u = e.keys[f + 1];
i.expand(s, e.tmp, 0);
c ^= e.tmp[0];
u ^= e.tmp[1];
var h = i.substitute(c, u), d = s;
s = (a ^ i.permute(h)) >>> 0;
a = d;
}
i.rip(s, a, n, o);
};
}, {
"./cipher": 78,
"./utils": 81,
inherits: 138,
"minimalistic-assert": 143
} ],
80: [ function(e, t) {
"use strict";
var r = e("minimalistic-assert"), n = e("inherits"), i = e("./cipher"), o = e("./des");
function s(e, t) {
r.equal(t.length, 24, "Invalid key length");
var n = t.slice(0, 8), i = t.slice(8, 16), s = t.slice(16, 24);
this.ciphers = "encrypt" === e ? [ o.create({
type: "encrypt",
key: n
}), o.create({
type: "decrypt",
key: i
}), o.create({
type: "encrypt",
key: s
}) ] : [ o.create({
type: "decrypt",
key: s
}), o.create({
type: "encrypt",
key: i
}), o.create({
type: "decrypt",
key: n
}) ];
}
function a(e) {
i.call(this, e);
var t = new s(this.type, this.options.key);
this._edeState = t;
}
n(a, i);
t.exports = a;
a.create = function(e) {
return new a(e);
};
a.prototype._update = function(e, t, r, n) {
var i = this._edeState;
i.ciphers[0]._update(e, t, r, n);
i.ciphers[1]._update(r, n, r, n);
i.ciphers[2]._update(r, n, r, n);
};
a.prototype._pad = o.prototype._pad;
a.prototype._unpad = o.prototype._unpad;
}, {
"./cipher": 78,
"./des": 79,
inherits: 138,
"minimalistic-assert": 143
} ],
81: [ function(e, t, r) {
"use strict";
r.readUInt32BE = function(e, t) {
return (e[0 + t] << 24 | e[1 + t] << 16 | e[2 + t] << 8 | e[3 + t]) >>> 0;
};
r.writeUInt32BE = function(e, t, r) {
e[0 + r] = t >>> 24;
e[1 + r] = t >>> 16 & 255;
e[2 + r] = t >>> 8 & 255;
e[3 + r] = 255 & t;
};
r.ip = function(e, t, r, n) {
for (var i = 0, o = 0, s = 6; s >= 0; s -= 2) {
for (var a = 0; a <= 24; a += 8) {
i <<= 1;
i |= t >>> a + s & 1;
}
for (a = 0; a <= 24; a += 8) {
i <<= 1;
i |= e >>> a + s & 1;
}
}
for (s = 6; s >= 0; s -= 2) {
for (a = 1; a <= 25; a += 8) {
o <<= 1;
o |= t >>> a + s & 1;
}
for (a = 1; a <= 25; a += 8) {
o <<= 1;
o |= e >>> a + s & 1;
}
}
r[n + 0] = i >>> 0;
r[n + 1] = o >>> 0;
};
r.rip = function(e, t, r, n) {
for (var i = 0, o = 0, s = 0; s < 4; s++) for (var a = 24; a >= 0; a -= 8) {
i <<= 1;
i |= t >>> a + s & 1;
i <<= 1;
i |= e >>> a + s & 1;
}
for (s = 4; s < 8; s++) for (a = 24; a >= 0; a -= 8) {
o <<= 1;
o |= t >>> a + s & 1;
o <<= 1;
o |= e >>> a + s & 1;
}
r[n + 0] = i >>> 0;
r[n + 1] = o >>> 0;
};
r.pc1 = function(e, t, r, n) {
for (var i = 0, o = 0, s = 7; s >= 5; s--) {
for (var a = 0; a <= 24; a += 8) {
i <<= 1;
i |= t >> a + s & 1;
}
for (a = 0; a <= 24; a += 8) {
i <<= 1;
i |= e >> a + s & 1;
}
}
for (a = 0; a <= 24; a += 8) {
i <<= 1;
i |= t >> a + s & 1;
}
for (s = 1; s <= 3; s++) {
for (a = 0; a <= 24; a += 8) {
o <<= 1;
o |= t >> a + s & 1;
}
for (a = 0; a <= 24; a += 8) {
o <<= 1;
o |= e >> a + s & 1;
}
}
for (a = 0; a <= 24; a += 8) {
o <<= 1;
o |= e >> a + s & 1;
}
r[n + 0] = i >>> 0;
r[n + 1] = o >>> 0;
};
r.r28shl = function(e, t) {
return e << t & 268435455 | e >>> 28 - t;
};
var n = [ 14, 11, 17, 4, 27, 23, 25, 0, 13, 22, 7, 18, 5, 9, 16, 24, 2, 20, 12, 21, 1, 8, 15, 26, 15, 4, 25, 19, 9, 1, 26, 16, 5, 11, 23, 8, 12, 7, 17, 0, 22, 3, 10, 14, 6, 20, 27, 24 ];
r.pc2 = function(e, t, r, i) {
for (var o = 0, s = 0, a = n.length >>> 1, f = 0; f < a; f++) {
o <<= 1;
o |= e >>> n[f] & 1;
}
for (f = a; f < n.length; f++) {
s <<= 1;
s |= t >>> n[f] & 1;
}
r[i + 0] = o >>> 0;
r[i + 1] = s >>> 0;
};
r.expand = function(e, t, r) {
var n = 0, i = 0;
n = (1 & e) << 5 | e >>> 27;
for (var o = 23; o >= 15; o -= 4) {
n <<= 6;
n |= e >>> o & 63;
}
for (o = 11; o >= 3; o -= 4) {
i |= e >>> o & 63;
i <<= 6;
}
i |= (31 & e) << 1 | e >>> 31;
t[r + 0] = n >>> 0;
t[r + 1] = i >>> 0;
};
var i = [ 14, 0, 4, 15, 13, 7, 1, 4, 2, 14, 15, 2, 11, 13, 8, 1, 3, 10, 10, 6, 6, 12, 12, 11, 5, 9, 9, 5, 0, 3, 7, 8, 4, 15, 1, 12, 14, 8, 8, 2, 13, 4, 6, 9, 2, 1, 11, 7, 15, 5, 12, 11, 9, 3, 7, 14, 3, 10, 10, 0, 5, 6, 0, 13, 15, 3, 1, 13, 8, 4, 14, 7, 6, 15, 11, 2, 3, 8, 4, 14, 9, 12, 7, 0, 2, 1, 13, 10, 12, 6, 0, 9, 5, 11, 10, 5, 0, 13, 14, 8, 7, 10, 11, 1, 10, 3, 4, 15, 13, 4, 1, 2, 5, 11, 8, 6, 12, 7, 6, 12, 9, 0, 3, 5, 2, 14, 15, 9, 10, 13, 0, 7, 9, 0, 14, 9, 6, 3, 3, 4, 15, 6, 5, 10, 1, 2, 13, 8, 12, 5, 7, 14, 11, 12, 4, 11, 2, 15, 8, 1, 13, 1, 6, 10, 4, 13, 9, 0, 8, 6, 15, 9, 3, 8, 0, 7, 11, 4, 1, 15, 2, 14, 12, 3, 5, 11, 10, 5, 14, 2, 7, 12, 7, 13, 13, 8, 14, 11, 3, 5, 0, 6, 6, 15, 9, 0, 10, 3, 1, 4, 2, 7, 8, 2, 5, 12, 11, 1, 12, 10, 4, 14, 15, 9, 10, 3, 6, 15, 9, 0, 0, 6, 12, 10, 11, 1, 7, 13, 13, 8, 15, 9, 1, 4, 3, 5, 14, 11, 5, 12, 2, 7, 8, 2, 4, 14, 2, 14, 12, 11, 4, 2, 1, 12, 7, 4, 10, 7, 11, 13, 6, 1, 8, 5, 5, 0, 3, 15, 15, 10, 13, 3, 0, 9, 14, 8, 9, 6, 4, 11, 2, 8, 1, 12, 11, 7, 10, 1, 13, 14, 7, 2, 8, 13, 15, 6, 9, 15, 12, 0, 5, 9, 6, 10, 3, 4, 0, 5, 14, 3, 12, 10, 1, 15, 10, 4, 15, 2, 9, 7, 2, 12, 6, 9, 8, 5, 0, 6, 13, 1, 3, 13, 4, 14, 14, 0, 7, 11, 5, 3, 11, 8, 9, 4, 14, 3, 15, 2, 5, 12, 2, 9, 8, 5, 12, 15, 3, 10, 7, 11, 0, 14, 4, 1, 10, 7, 1, 6, 13, 0, 11, 8, 6, 13, 4, 13, 11, 0, 2, 11, 14, 7, 15, 4, 0, 9, 8, 1, 13, 10, 3, 14, 12, 3, 9, 5, 7, 12, 5, 2, 10, 15, 6, 8, 1, 6, 1, 6, 4, 11, 11, 13, 13, 8, 12, 1, 3, 4, 7, 10, 14, 7, 10, 9, 15, 5, 6, 0, 8, 15, 0, 14, 5, 2, 9, 3, 2, 12, 13, 1, 2, 15, 8, 13, 4, 8, 6, 10, 15, 3, 11, 7, 1, 4, 10, 12, 9, 5, 3, 6, 14, 11, 5, 0, 0, 14, 12, 9, 7, 2, 7, 2, 11, 1, 4, 14, 1, 7, 9, 4, 12, 10, 14, 8, 2, 13, 0, 15, 6, 12, 10, 9, 13, 0, 15, 3, 3, 5, 5, 6, 8, 11 ];
r.substitute = function(e, t) {
for (var r = 0, n = 0; n < 4; n++) {
r <<= 4;
r |= i[64 * n + (e >>> 18 - 6 * n & 63)];
}
for (n = 0; n < 4; n++) {
r <<= 4;
r |= i[256 + 64 * n + (t >>> 18 - 6 * n & 63)];
}
return r >>> 0;
};
var o = [ 16, 25, 12, 11, 3, 20, 4, 15, 31, 17, 9, 6, 27, 14, 1, 22, 30, 24, 8, 18, 0, 5, 29, 23, 13, 19, 2, 26, 10, 21, 28, 7 ];
r.permute = function(e) {
for (var t = 0, r = 0; r < o.length; r++) {
t <<= 1;
t |= e >>> o[r] & 1;
}
return t >>> 0;
};
r.padSplit = function(e, t, r) {
for (var n = e.toString(2); n.length < t; ) n = "0" + n;
for (var i = [], o = 0; o < t; o += r) i.push(n.slice(o, o + r));
return i.join(" ");
};
}, {} ],
82: [ function(e, t, r) {
(function(t) {
var n = e("./lib/generatePrime"), i = e("./lib/primes.json"), o = e("./lib/dh"), s = {
binary: !0,
hex: !0,
base64: !0
};
r.DiffieHellmanGroup = r.createDiffieHellmanGroup = r.getDiffieHellman = function(e) {
var r = new t(i[e].prime, "hex"), n = new t(i[e].gen, "hex");
return new o(r, n);
};
r.createDiffieHellman = r.DiffieHellman = function e(r, i, a, f) {
if (t.isBuffer(i) || void 0 === s[i]) return e(r, "binary", i, a);
i = i || "binary";
f = f || "binary";
a = a || new t([ 2 ]);
t.isBuffer(a) || (a = new t(a, f));
if ("number" == typeof r) return new o(n(r, a), a, !0);
t.isBuffer(r) || (r = new t(r, i));
return new o(r, a, !0);
};
}).call(this, e("buffer").Buffer);
}, {
"./lib/dh": 83,
"./lib/generatePrime": 84,
"./lib/primes.json": 85,
buffer: 65
} ],
83: [ function(e, t) {
(function(r) {
var n = e("bn.js"), i = new (e("miller-rabin"))(), o = new n(24), s = new n(11), a = new n(10), f = new n(3), c = new n(7), u = e("./generatePrime"), h = e("randombytes");
t.exports = m;
function d(e, t) {
t = t || "utf8";
r.isBuffer(e) || (e = new r(e, t));
this._pub = new n(e);
return this;
}
function l(e, t) {
t = t || "utf8";
r.isBuffer(e) || (e = new r(e, t));
this._priv = new n(e);
return this;
}
var p = {};
function b(e, t) {
var r = t.toString("hex"), n = [ r, e.toString(16) ].join("_");
if (n in p) return p[n];
var h, d = 0;
if (e.isEven() || !u.simpleSieve || !u.fermatTest(e) || !i.test(e)) {
d += 1;
d += "02" === r || "05" === r ? 8 : 4;
p[n] = d;
return d;
}
i.test(e.shrn(1)) || (d += 2);
switch (r) {
case "02":
e.mod(o).cmp(s) && (d += 8);
break;

case "05":
(h = e.mod(a)).cmp(f) && h.cmp(c) && (d += 8);
break;

default:
d += 4;
}
p[n] = d;
return d;
}
function m(e, t, r) {
this.setGenerator(t);
this.__prime = new n(e);
this._prime = n.mont(this.__prime);
this._primeLen = e.length;
this._pub = void 0;
this._priv = void 0;
this._primeCode = void 0;
if (r) {
this.setPublicKey = d;
this.setPrivateKey = l;
} else this._primeCode = 8;
}
Object.defineProperty(m.prototype, "verifyError", {
enumerable: !0,
get: function() {
"number" != typeof this._primeCode && (this._primeCode = b(this.__prime, this.__gen));
return this._primeCode;
}
});
m.prototype.generateKeys = function() {
this._priv || (this._priv = new n(h(this._primeLen)));
this._pub = this._gen.toRed(this._prime).redPow(this._priv).fromRed();
return this.getPublicKey();
};
m.prototype.computeSecret = function(e) {
var t = (e = (e = new n(e)).toRed(this._prime)).redPow(this._priv).fromRed(), i = new r(t.toArray()), o = this.getPrime();
if (i.length < o.length) {
var s = new r(o.length - i.length);
s.fill(0);
i = r.concat([ s, i ]);
}
return i;
};
m.prototype.getPublicKey = function(e) {
return v(this._pub, e);
};
m.prototype.getPrivateKey = function(e) {
return v(this._priv, e);
};
m.prototype.getPrime = function(e) {
return v(this.__prime, e);
};
m.prototype.getGenerator = function(e) {
return v(this._gen, e);
};
m.prototype.setGenerator = function(e, t) {
t = t || "utf8";
r.isBuffer(e) || (e = new r(e, t));
this.__gen = e;
this._gen = new n(e);
return this;
};
function v(e, t) {
var n = new r(e.toArray());
return t ? n.toString(t) : n;
}
}).call(this, e("buffer").Buffer);
}, {
"./generatePrime": 84,
"bn.js": 86,
buffer: 65,
"miller-rabin": 141,
randombytes: 165
} ],
84: [ function(e, t) {
var r = e("randombytes");
t.exports = v;
v.simpleSieve = b;
v.fermatTest = m;
var n = e("bn.js"), i = new n(24), o = new (e("miller-rabin"))(), s = new n(1), a = new n(2), f = new n(5), c = (new n(16), 
new n(8), new n(10)), u = new n(3), h = (new n(7), new n(11)), d = new n(4), l = (new n(12), 
null);
function p() {
if (null !== l) return l;
var e = [];
e[0] = 2;
for (var t = 1, r = 3; r < 1048576; r += 2) {
for (var n = Math.ceil(Math.sqrt(r)), i = 0; i < t && e[i] <= n && r % e[i] != 0; i++) ;
t !== i && e[i] <= n || (e[t++] = r);
}
l = e;
return e;
}
function b(e) {
for (var t = p(), r = 0; r < t.length; r++) if (0 === e.modn(t[r])) return 0 === e.cmpn(t[r]);
return !0;
}
function m(e) {
var t = n.mont(e);
return 0 === a.toRed(t).redPow(e.subn(1)).fromRed().cmpn(1);
}
function v(e, t) {
if (e < 16) return new n(2 === t || 5 === t ? [ 140, 123 ] : [ 140, 39 ]);
t = new n(t);
for (var l, p; ;) {
l = new n(r(Math.ceil(e / 8)));
for (;l.bitLength() > e; ) l.ishrn(1);
l.isEven() && l.iadd(s);
l.testn(1) || l.iadd(a);
if (t.cmp(a)) {
if (!t.cmp(f)) for (;l.mod(c).cmp(u); ) l.iadd(d);
} else for (;l.mod(i).cmp(h); ) l.iadd(d);
if (b(p = l.shrn(1)) && b(l) && m(p) && m(l) && o.test(p) && o.test(l)) return l;
}
}
}, {
"bn.js": 86,
"miller-rabin": 141,
randombytes: 165
} ],
85: [ function(e, t) {
t.exports = {
modp1: {
gen: "02",
prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a63a3620ffffffffffffffff"
},
modp2: {
gen: "02",
prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece65381ffffffffffffffff"
},
modp5: {
gen: "02",
prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca237327ffffffffffffffff"
},
modp14: {
gen: "02",
prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aacaa68ffffffffffffffff"
},
modp15: {
gen: "02",
prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aaac42dad33170d04507a33a85521abdf1cba64ecfb850458dbef0a8aea71575d060c7db3970f85a6e1e4c7abf5ae8cdb0933d71e8c94e04a25619dcee3d2261ad2ee6bf12ffa06d98a0864d87602733ec86a64521f2b18177b200cbbe117577a615d6c770988c0bad946e208e24fa074e5ab3143db5bfce0fd108e4b82d120a93ad2caffffffffffffffff"
},
modp16: {
gen: "02",
prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aaac42dad33170d04507a33a85521abdf1cba64ecfb850458dbef0a8aea71575d060c7db3970f85a6e1e4c7abf5ae8cdb0933d71e8c94e04a25619dcee3d2261ad2ee6bf12ffa06d98a0864d87602733ec86a64521f2b18177b200cbbe117577a615d6c770988c0bad946e208e24fa074e5ab3143db5bfce0fd108e4b82d120a92108011a723c12a787e6d788719a10bdba5b2699c327186af4e23c1a946834b6150bda2583e9ca2ad44ce8dbbbc2db04de8ef92e8efc141fbecaa6287c59474e6bc05d99b2964fa090c3a2233ba186515be7ed1f612970cee2d7afb81bdd762170481cd0069127d5b05aa993b4ea988d8fddc186ffb7dc90a6c08f4df435c934063199ffffffffffffffff"
},
modp17: {
gen: "02",
prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aaac42dad33170d04507a33a85521abdf1cba64ecfb850458dbef0a8aea71575d060c7db3970f85a6e1e4c7abf5ae8cdb0933d71e8c94e04a25619dcee3d2261ad2ee6bf12ffa06d98a0864d87602733ec86a64521f2b18177b200cbbe117577a615d6c770988c0bad946e208e24fa074e5ab3143db5bfce0fd108e4b82d120a92108011a723c12a787e6d788719a10bdba5b2699c327186af4e23c1a946834b6150bda2583e9ca2ad44ce8dbbbc2db04de8ef92e8efc141fbecaa6287c59474e6bc05d99b2964fa090c3a2233ba186515be7ed1f612970cee2d7afb81bdd762170481cd0069127d5b05aa993b4ea988d8fddc186ffb7dc90a6c08f4df435c93402849236c3fab4d27c7026c1d4dcb2602646dec9751e763dba37bdf8ff9406ad9e530ee5db382f413001aeb06a53ed9027d831179727b0865a8918da3edbebcf9b14ed44ce6cbaced4bb1bdb7f1447e6cc254b332051512bd7af426fb8f401378cd2bf5983ca01c64b92ecf032ea15d1721d03f482d7ce6e74fef6d55e702f46980c82b5a84031900b1c9e59e7c97fbec7e8f323a97a7e36cc88be0f1d45b7ff585ac54bd407b22b4154aacc8f6d7ebf48e1d814cc5ed20f8037e0a79715eef29be32806a1d58bb7c5da76f550aa3d8a1fbff0eb19ccb1a313d55cda56c9ec2ef29632387fe8d76e3c0468043e8f663f4860ee12bf2d5b0b7474d6e694f91e6dcc4024ffffffffffffffff"
},
modp18: {
gen: "02",
prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aaac42dad33170d04507a33a85521abdf1cba64ecfb850458dbef0a8aea71575d060c7db3970f85a6e1e4c7abf5ae8cdb0933d71e8c94e04a25619dcee3d2261ad2ee6bf12ffa06d98a0864d87602733ec86a64521f2b18177b200cbbe117577a615d6c770988c0bad946e208e24fa074e5ab3143db5bfce0fd108e4b82d120a92108011a723c12a787e6d788719a10bdba5b2699c327186af4e23c1a946834b6150bda2583e9ca2ad44ce8dbbbc2db04de8ef92e8efc141fbecaa6287c59474e6bc05d99b2964fa090c3a2233ba186515be7ed1f612970cee2d7afb81bdd762170481cd0069127d5b05aa993b4ea988d8fddc186ffb7dc90a6c08f4df435c93402849236c3fab4d27c7026c1d4dcb2602646dec9751e763dba37bdf8ff9406ad9e530ee5db382f413001aeb06a53ed9027d831179727b0865a8918da3edbebcf9b14ed44ce6cbaced4bb1bdb7f1447e6cc254b332051512bd7af426fb8f401378cd2bf5983ca01c64b92ecf032ea15d1721d03f482d7ce6e74fef6d55e702f46980c82b5a84031900b1c9e59e7c97fbec7e8f323a97a7e36cc88be0f1d45b7ff585ac54bd407b22b4154aacc8f6d7ebf48e1d814cc5ed20f8037e0a79715eef29be32806a1d58bb7c5da76f550aa3d8a1fbff0eb19ccb1a313d55cda56c9ec2ef29632387fe8d76e3c0468043e8f663f4860ee12bf2d5b0b7474d6e694f91e6dbe115974a3926f12fee5e438777cb6a932df8cd8bec4d073b931ba3bc832b68d9dd300741fa7bf8afc47ed2576f6936ba424663aab639c5ae4f5683423b4742bf1c978238f16cbe39d652de3fdb8befc848ad922222e04a4037c0713eb57a81a23f0c73473fc646cea306b4bcbc8862f8385ddfa9d4b7fa2c087e879683303ed5bdd3a062b3cf5b3a278a66d2a13f83f44f82ddf310ee074ab6a364597e899a0255dc164f31cc50846851df9ab48195ded7ea1b1d510bd7ee74d73faf36bc31ecfa268359046f4eb879f924009438b481c6cd7889a002ed5ee382bc9190da6fc026e479558e4475677e9aa9e3050e2765694dfc81f56e880b96e7160c980dd98edd3dfffffffffffffffff"
}
};
}, {} ],
86: [ function(e, t, r) {
arguments[4][15][0].apply(r, arguments);
}, {
buffer: 19,
dup: 15
} ],
87: [ function(e, t, r) {
"use strict";
var n = r;
n.version = e("../package.json").version;
n.utils = e("./elliptic/utils");
n.rand = e("brorand");
n.curve = e("./elliptic/curve");
n.curves = e("./elliptic/curves");
n.ec = e("./elliptic/ec");
n.eddsa = e("./elliptic/eddsa");
}, {
"../package.json": 103,
"./elliptic/curve": 90,
"./elliptic/curves": 93,
"./elliptic/ec": 94,
"./elliptic/eddsa": 97,
"./elliptic/utils": 101,
brorand: 18
} ],
88: [ function(e, t) {
"use strict";
var r = e("bn.js"), n = e("../utils"), i = n.getNAF, o = n.getJSF, s = n.assert;
function a(e, t) {
this.type = e;
this.p = new r(t.p, 16);
this.red = t.prime ? r.red(t.prime) : r.mont(this.p);
this.zero = new r(0).toRed(this.red);
this.one = new r(1).toRed(this.red);
this.two = new r(2).toRed(this.red);
this.n = t.n && new r(t.n, 16);
this.g = t.g && this.pointFromJSON(t.g, t.gRed);
this._wnafT1 = new Array(4);
this._wnafT2 = new Array(4);
this._wnafT3 = new Array(4);
this._wnafT4 = new Array(4);
this._bitLength = this.n ? this.n.bitLength() : 0;
var n = this.n && this.p.div(this.n);
if (!n || n.cmpn(100) > 0) this.redN = null; else {
this._maxwellTrick = !0;
this.redN = this.n.toRed(this.red);
}
}
t.exports = a;
a.prototype.point = function() {
throw new Error("Not implemented");
};
a.prototype.validate = function() {
throw new Error("Not implemented");
};
a.prototype._fixedNafMul = function(e, t) {
s(e.precomputed);
var r = e._getDoubles(), n = i(t, 1, this._bitLength), o = (1 << r.step + 1) - (r.step % 2 == 0 ? 2 : 1);
o /= 3;
var a, f, c = [];
for (a = 0; a < n.length; a += r.step) {
f = 0;
for (var u = a + r.step - 1; u >= a; u--) f = (f << 1) + n[u];
c.push(f);
}
for (var h = this.jpoint(null, null, null), d = this.jpoint(null, null, null), l = o; l > 0; l--) {
for (a = 0; a < c.length; a++) (f = c[a]) === l ? d = d.mixedAdd(r.points[a]) : f === -l && (d = d.mixedAdd(r.points[a].neg()));
h = h.add(d);
}
return h.toP();
};
a.prototype._wnafMul = function(e, t) {
var r = 4, n = e._getNAFPoints(r);
r = n.wnd;
for (var o = n.points, a = i(t, r, this._bitLength), f = this.jpoint(null, null, null), c = a.length - 1; c >= 0; c--) {
for (var u = 0; c >= 0 && 0 === a[c]; c--) u++;
c >= 0 && u++;
f = f.dblp(u);
if (c < 0) break;
var h = a[c];
s(0 !== h);
f = "affine" === e.type ? h > 0 ? f.mixedAdd(o[h - 1 >> 1]) : f.mixedAdd(o[-h - 1 >> 1].neg()) : h > 0 ? f.add(o[h - 1 >> 1]) : f.add(o[-h - 1 >> 1].neg());
}
return "affine" === e.type ? f.toP() : f;
};
a.prototype._wnafMulAdd = function(e, t, r, n, s) {
var a, f, c, u = this._wnafT1, h = this._wnafT2, d = this._wnafT3, l = 0;
for (a = 0; a < n; a++) {
var p = (c = t[a])._getNAFPoints(e);
u[a] = p.wnd;
h[a] = p.points;
}
for (a = n - 1; a >= 1; a -= 2) {
var b = a - 1, m = a;
if (1 === u[b] && 1 === u[m]) {
var v = [ t[b], null, null, t[m] ];
if (0 === t[b].y.cmp(t[m].y)) {
v[1] = t[b].add(t[m]);
v[2] = t[b].toJ().mixedAdd(t[m].neg());
} else if (0 === t[b].y.cmp(t[m].y.redNeg())) {
v[1] = t[b].toJ().mixedAdd(t[m]);
v[2] = t[b].add(t[m].neg());
} else {
v[1] = t[b].toJ().mixedAdd(t[m]);
v[2] = t[b].toJ().mixedAdd(t[m].neg());
}
var y = [ -3, -1, -5, -7, 0, 7, 5, 1, 3 ], g = o(r[b], r[m]);
l = Math.max(g[0].length, l);
d[b] = new Array(l);
d[m] = new Array(l);
for (f = 0; f < l; f++) {
var _ = 0 | g[0][f], w = 0 | g[1][f];
d[b][f] = y[3 * (_ + 1) + (w + 1)];
d[m][f] = 0;
h[b] = v;
}
} else {
d[b] = i(r[b], u[b], this._bitLength);
d[m] = i(r[m], u[m], this._bitLength);
l = Math.max(d[b].length, l);
l = Math.max(d[m].length, l);
}
}
var E = this.jpoint(null, null, null), S = this._wnafT4;
for (a = l; a >= 0; a--) {
for (var M = 0; a >= 0; ) {
var A = !0;
for (f = 0; f < n; f++) {
S[f] = 0 | d[f][a];
0 !== S[f] && (A = !1);
}
if (!A) break;
M++;
a--;
}
a >= 0 && M++;
E = E.dblp(M);
if (a < 0) break;
for (f = 0; f < n; f++) {
var x = S[f];
if (0 !== x) {
x > 0 ? c = h[f][x - 1 >> 1] : x < 0 && (c = h[f][-x - 1 >> 1].neg());
E = "affine" === c.type ? E.mixedAdd(c) : E.add(c);
}
}
}
for (a = 0; a < n; a++) h[a] = null;
return s ? E : E.toP();
};
function f(e, t) {
this.curve = e;
this.type = t;
this.precomputed = null;
}
a.BasePoint = f;
f.prototype.eq = function() {
throw new Error("Not implemented");
};
f.prototype.validate = function() {
return this.curve.validate(this);
};
a.prototype.decodePoint = function(e, t) {
e = n.toArray(e, t);
var r = this.p.byteLength();
if ((4 === e[0] || 6 === e[0] || 7 === e[0]) && e.length - 1 == 2 * r) {
6 === e[0] ? s(e[e.length - 1] % 2 == 0) : 7 === e[0] && s(e[e.length - 1] % 2 == 1);
return this.point(e.slice(1, 1 + r), e.slice(1 + r, 1 + 2 * r));
}
if ((2 === e[0] || 3 === e[0]) && e.length - 1 === r) return this.pointFromX(e.slice(1, 1 + r), 3 === e[0]);
throw new Error("Unknown point format");
};
f.prototype.encodeCompressed = function(e) {
return this.encode(e, !0);
};
f.prototype._encode = function(e) {
var t = this.curve.p.byteLength(), r = this.getX().toArray("be", t);
return e ? [ this.getY().isEven() ? 2 : 3 ].concat(r) : [ 4 ].concat(r, this.getY().toArray("be", t));
};
f.prototype.encode = function(e, t) {
return n.encode(this._encode(t), e);
};
f.prototype.precompute = function(e) {
if (this.precomputed) return this;
var t = {
doubles: null,
naf: null,
beta: null
};
t.naf = this._getNAFPoints(8);
t.doubles = this._getDoubles(4, e);
t.beta = this._getBeta();
this.precomputed = t;
return this;
};
f.prototype._hasDoubles = function(e) {
if (!this.precomputed) return !1;
var t = this.precomputed.doubles;
return !!t && t.points.length >= Math.ceil((e.bitLength() + 1) / t.step);
};
f.prototype._getDoubles = function(e, t) {
if (this.precomputed && this.precomputed.doubles) return this.precomputed.doubles;
for (var r = [ this ], n = this, i = 0; i < t; i += e) {
for (var o = 0; o < e; o++) n = n.dbl();
r.push(n);
}
return {
step: e,
points: r
};
};
f.prototype._getNAFPoints = function(e) {
if (this.precomputed && this.precomputed.naf) return this.precomputed.naf;
for (var t = [ this ], r = (1 << e) - 1, n = 1 === r ? null : this.dbl(), i = 1; i < r; i++) t[i] = t[i - 1].add(n);
return {
wnd: e,
points: t
};
};
f.prototype._getBeta = function() {
return null;
};
f.prototype.dblp = function(e) {
for (var t = this, r = 0; r < e; r++) t = t.dbl();
return t;
};
}, {
"../utils": 101,
"bn.js": 102
} ],
89: [ function(e, t) {
"use strict";
var r = e("../utils"), n = e("bn.js"), i = e("inherits"), o = e("./base"), s = r.assert;
function a(e) {
this.twisted = 1 != (0 | e.a);
this.mOneA = this.twisted && -1 == (0 | e.a);
this.extended = this.mOneA;
o.call(this, "edwards", e);
this.a = new n(e.a, 16).umod(this.red.m);
this.a = this.a.toRed(this.red);
this.c = new n(e.c, 16).toRed(this.red);
this.c2 = this.c.redSqr();
this.d = new n(e.d, 16).toRed(this.red);
this.dd = this.d.redAdd(this.d);
s(!this.twisted || 0 === this.c.fromRed().cmpn(1));
this.oneC = 1 == (0 | e.c);
}
i(a, o);
t.exports = a;
a.prototype._mulA = function(e) {
return this.mOneA ? e.redNeg() : this.a.redMul(e);
};
a.prototype._mulC = function(e) {
return this.oneC ? e : this.c.redMul(e);
};
a.prototype.jpoint = function(e, t, r, n) {
return this.point(e, t, r, n);
};
a.prototype.pointFromX = function(e, t) {
(e = new n(e, 16)).red || (e = e.toRed(this.red));
var r = e.redSqr(), i = this.c2.redSub(this.a.redMul(r)), o = this.one.redSub(this.c2.redMul(this.d).redMul(r)), s = i.redMul(o.redInvm()), a = s.redSqrt();
if (0 !== a.redSqr().redSub(s).cmp(this.zero)) throw new Error("invalid point");
var f = a.fromRed().isOdd();
(t && !f || !t && f) && (a = a.redNeg());
return this.point(e, a);
};
a.prototype.pointFromY = function(e, t) {
(e = new n(e, 16)).red || (e = e.toRed(this.red));
var r = e.redSqr(), i = r.redSub(this.c2), o = r.redMul(this.d).redMul(this.c2).redSub(this.a), s = i.redMul(o.redInvm());
if (0 === s.cmp(this.zero)) {
if (t) throw new Error("invalid point");
return this.point(this.zero, e);
}
var a = s.redSqrt();
if (0 !== a.redSqr().redSub(s).cmp(this.zero)) throw new Error("invalid point");
a.fromRed().isOdd() !== t && (a = a.redNeg());
return this.point(a, e);
};
a.prototype.validate = function(e) {
if (e.isInfinity()) return !0;
e.normalize();
var t = e.x.redSqr(), r = e.y.redSqr(), n = t.redMul(this.a).redAdd(r), i = this.c2.redMul(this.one.redAdd(this.d.redMul(t).redMul(r)));
return 0 === n.cmp(i);
};
function f(e, t, r, i, s) {
o.BasePoint.call(this, e, "projective");
if (null === t && null === r && null === i) {
this.x = this.curve.zero;
this.y = this.curve.one;
this.z = this.curve.one;
this.t = this.curve.zero;
this.zOne = !0;
} else {
this.x = new n(t, 16);
this.y = new n(r, 16);
this.z = i ? new n(i, 16) : this.curve.one;
this.t = s && new n(s, 16);
this.x.red || (this.x = this.x.toRed(this.curve.red));
this.y.red || (this.y = this.y.toRed(this.curve.red));
this.z.red || (this.z = this.z.toRed(this.curve.red));
this.t && !this.t.red && (this.t = this.t.toRed(this.curve.red));
this.zOne = this.z === this.curve.one;
if (this.curve.extended && !this.t) {
this.t = this.x.redMul(this.y);
this.zOne || (this.t = this.t.redMul(this.z.redInvm()));
}
}
}
i(f, o.BasePoint);
a.prototype.pointFromJSON = function(e) {
return f.fromJSON(this, e);
};
a.prototype.point = function(e, t, r, n) {
return new f(this, e, t, r, n);
};
f.fromJSON = function(e, t) {
return new f(e, t[0], t[1], t[2]);
};
f.prototype.inspect = function() {
return this.isInfinity() ? "<EC Point Infinity>" : "<EC Point x: " + this.x.fromRed().toString(16, 2) + " y: " + this.y.fromRed().toString(16, 2) + " z: " + this.z.fromRed().toString(16, 2) + ">";
};
f.prototype.isInfinity = function() {
return 0 === this.x.cmpn(0) && (0 === this.y.cmp(this.z) || this.zOne && 0 === this.y.cmp(this.curve.c));
};
f.prototype._extDbl = function() {
var e = this.x.redSqr(), t = this.y.redSqr(), r = this.z.redSqr();
r = r.redIAdd(r);
var n = this.curve._mulA(e), i = this.x.redAdd(this.y).redSqr().redISub(e).redISub(t), o = n.redAdd(t), s = o.redSub(r), a = n.redSub(t), f = i.redMul(s), c = o.redMul(a), u = i.redMul(a), h = s.redMul(o);
return this.curve.point(f, c, h, u);
};
f.prototype._projDbl = function() {
var e, t, r, n, i, o, s = this.x.redAdd(this.y).redSqr(), a = this.x.redSqr(), f = this.y.redSqr();
if (this.curve.twisted) {
var c = (n = this.curve._mulA(a)).redAdd(f);
if (this.zOne) {
e = s.redSub(a).redSub(f).redMul(c.redSub(this.curve.two));
t = c.redMul(n.redSub(f));
r = c.redSqr().redSub(c).redSub(c);
} else {
i = this.z.redSqr();
o = c.redSub(i).redISub(i);
e = s.redSub(a).redISub(f).redMul(o);
t = c.redMul(n.redSub(f));
r = c.redMul(o);
}
} else {
n = a.redAdd(f);
i = this.curve._mulC(this.z).redSqr();
o = n.redSub(i).redSub(i);
e = this.curve._mulC(s.redISub(n)).redMul(o);
t = this.curve._mulC(n).redMul(a.redISub(f));
r = n.redMul(o);
}
return this.curve.point(e, t, r);
};
f.prototype.dbl = function() {
return this.isInfinity() ? this : this.curve.extended ? this._extDbl() : this._projDbl();
};
f.prototype._extAdd = function(e) {
var t = this.y.redSub(this.x).redMul(e.y.redSub(e.x)), r = this.y.redAdd(this.x).redMul(e.y.redAdd(e.x)), n = this.t.redMul(this.curve.dd).redMul(e.t), i = this.z.redMul(e.z.redAdd(e.z)), o = r.redSub(t), s = i.redSub(n), a = i.redAdd(n), f = r.redAdd(t), c = o.redMul(s), u = a.redMul(f), h = o.redMul(f), d = s.redMul(a);
return this.curve.point(c, u, d, h);
};
f.prototype._projAdd = function(e) {
var t, r, n = this.z.redMul(e.z), i = n.redSqr(), o = this.x.redMul(e.x), s = this.y.redMul(e.y), a = this.curve.d.redMul(o).redMul(s), f = i.redSub(a), c = i.redAdd(a), u = this.x.redAdd(this.y).redMul(e.x.redAdd(e.y)).redISub(o).redISub(s), h = n.redMul(f).redMul(u);
if (this.curve.twisted) {
t = n.redMul(c).redMul(s.redSub(this.curve._mulA(o)));
r = f.redMul(c);
} else {
t = n.redMul(c).redMul(s.redSub(o));
r = this.curve._mulC(f).redMul(c);
}
return this.curve.point(h, t, r);
};
f.prototype.add = function(e) {
return this.isInfinity() ? e : e.isInfinity() ? this : this.curve.extended ? this._extAdd(e) : this._projAdd(e);
};
f.prototype.mul = function(e) {
return this._hasDoubles(e) ? this.curve._fixedNafMul(this, e) : this.curve._wnafMul(this, e);
};
f.prototype.mulAdd = function(e, t, r) {
return this.curve._wnafMulAdd(1, [ this, t ], [ e, r ], 2, !1);
};
f.prototype.jmulAdd = function(e, t, r) {
return this.curve._wnafMulAdd(1, [ this, t ], [ e, r ], 2, !0);
};
f.prototype.normalize = function() {
if (this.zOne) return this;
var e = this.z.redInvm();
this.x = this.x.redMul(e);
this.y = this.y.redMul(e);
this.t && (this.t = this.t.redMul(e));
this.z = this.curve.one;
this.zOne = !0;
return this;
};
f.prototype.neg = function() {
return this.curve.point(this.x.redNeg(), this.y, this.z, this.t && this.t.redNeg());
};
f.prototype.getX = function() {
this.normalize();
return this.x.fromRed();
};
f.prototype.getY = function() {
this.normalize();
return this.y.fromRed();
};
f.prototype.eq = function(e) {
return this === e || 0 === this.getX().cmp(e.getX()) && 0 === this.getY().cmp(e.getY());
};
f.prototype.eqXToP = function(e) {
var t = e.toRed(this.curve.red).redMul(this.z);
if (0 === this.x.cmp(t)) return !0;
for (var r = e.clone(), n = this.curve.redN.redMul(this.z); ;) {
r.iadd(this.curve.n);
if (r.cmp(this.curve.p) >= 0) return !1;
t.redIAdd(n);
if (0 === this.x.cmp(t)) return !0;
}
};
f.prototype.toP = f.prototype.normalize;
f.prototype.mixedAdd = f.prototype.add;
}, {
"../utils": 101,
"./base": 88,
"bn.js": 102,
inherits: 138
} ],
90: [ function(e, t, r) {
"use strict";
var n = r;
n.base = e("./base");
n.short = e("./short");
n.mont = e("./mont");
n.edwards = e("./edwards");
}, {
"./base": 88,
"./edwards": 89,
"./mont": 91,
"./short": 92
} ],
91: [ function(e, t) {
"use strict";
var r = e("bn.js"), n = e("inherits"), i = e("./base"), o = e("../utils");
function s(e) {
i.call(this, "mont", e);
this.a = new r(e.a, 16).toRed(this.red);
this.b = new r(e.b, 16).toRed(this.red);
this.i4 = new r(4).toRed(this.red).redInvm();
this.two = new r(2).toRed(this.red);
this.a24 = this.i4.redMul(this.a.redAdd(this.two));
}
n(s, i);
t.exports = s;
s.prototype.validate = function(e) {
var t = e.normalize().x, r = t.redSqr(), n = r.redMul(t).redAdd(r.redMul(this.a)).redAdd(t);
return 0 === n.redSqrt().redSqr().cmp(n);
};
function a(e, t, n) {
i.BasePoint.call(this, e, "projective");
if (null === t && null === n) {
this.x = this.curve.one;
this.z = this.curve.zero;
} else {
this.x = new r(t, 16);
this.z = new r(n, 16);
this.x.red || (this.x = this.x.toRed(this.curve.red));
this.z.red || (this.z = this.z.toRed(this.curve.red));
}
}
n(a, i.BasePoint);
s.prototype.decodePoint = function(e, t) {
return this.point(o.toArray(e, t), 1);
};
s.prototype.point = function(e, t) {
return new a(this, e, t);
};
s.prototype.pointFromJSON = function(e) {
return a.fromJSON(this, e);
};
a.prototype.precompute = function() {};
a.prototype._encode = function() {
return this.getX().toArray("be", this.curve.p.byteLength());
};
a.fromJSON = function(e, t) {
return new a(e, t[0], t[1] || e.one);
};
a.prototype.inspect = function() {
return this.isInfinity() ? "<EC Point Infinity>" : "<EC Point x: " + this.x.fromRed().toString(16, 2) + " z: " + this.z.fromRed().toString(16, 2) + ">";
};
a.prototype.isInfinity = function() {
return 0 === this.z.cmpn(0);
};
a.prototype.dbl = function() {
var e = this.x.redAdd(this.z).redSqr(), t = this.x.redSub(this.z).redSqr(), r = e.redSub(t), n = e.redMul(t), i = r.redMul(t.redAdd(this.curve.a24.redMul(r)));
return this.curve.point(n, i);
};
a.prototype.add = function() {
throw new Error("Not supported on Montgomery curve");
};
a.prototype.diffAdd = function(e, t) {
var r = this.x.redAdd(this.z), n = this.x.redSub(this.z), i = e.x.redAdd(e.z), o = e.x.redSub(e.z).redMul(r), s = i.redMul(n), a = t.z.redMul(o.redAdd(s).redSqr()), f = t.x.redMul(o.redISub(s).redSqr());
return this.curve.point(a, f);
};
a.prototype.mul = function(e) {
for (var t = e.clone(), r = this, n = this.curve.point(null, null), i = []; 0 !== t.cmpn(0); t.iushrn(1)) i.push(t.andln(1));
for (var o = i.length - 1; o >= 0; o--) if (0 === i[o]) {
r = r.diffAdd(n, this);
n = n.dbl();
} else {
n = r.diffAdd(n, this);
r = r.dbl();
}
return n;
};
a.prototype.mulAdd = function() {
throw new Error("Not supported on Montgomery curve");
};
a.prototype.jumlAdd = function() {
throw new Error("Not supported on Montgomery curve");
};
a.prototype.eq = function(e) {
return 0 === this.getX().cmp(e.getX());
};
a.prototype.normalize = function() {
this.x = this.x.redMul(this.z.redInvm());
this.z = this.curve.one;
return this;
};
a.prototype.getX = function() {
this.normalize();
return this.x.fromRed();
};
}, {
"../utils": 101,
"./base": 88,
"bn.js": 102,
inherits: 138
} ],
92: [ function(e, t) {
"use strict";
var r = e("../utils"), n = e("bn.js"), i = e("inherits"), o = e("./base"), s = r.assert;
function a(e) {
o.call(this, "short", e);
this.a = new n(e.a, 16).toRed(this.red);
this.b = new n(e.b, 16).toRed(this.red);
this.tinv = this.two.redInvm();
this.zeroA = 0 === this.a.fromRed().cmpn(0);
this.threeA = 0 === this.a.fromRed().sub(this.p).cmpn(-3);
this.endo = this._getEndomorphism(e);
this._endoWnafT1 = new Array(4);
this._endoWnafT2 = new Array(4);
}
i(a, o);
t.exports = a;
a.prototype._getEndomorphism = function(e) {
if (this.zeroA && this.g && this.n && 1 === this.p.modn(3)) {
var t, r;
if (e.beta) t = new n(e.beta, 16).toRed(this.red); else {
var i = this._getEndoRoots(this.p);
t = (t = i[0].cmp(i[1]) < 0 ? i[0] : i[1]).toRed(this.red);
}
if (e.lambda) r = new n(e.lambda, 16); else {
var o = this._getEndoRoots(this.n);
if (0 === this.g.mul(o[0]).x.cmp(this.g.x.redMul(t))) r = o[0]; else {
r = o[1];
s(0 === this.g.mul(r).x.cmp(this.g.x.redMul(t)));
}
}
return {
beta: t,
lambda: r,
basis: e.basis ? e.basis.map(function(e) {
return {
a: new n(e.a, 16),
b: new n(e.b, 16)
};
}) : this._getEndoBasis(r)
};
}
};
a.prototype._getEndoRoots = function(e) {
var t = e === this.p ? this.red : n.mont(e), r = new n(2).toRed(t).redInvm(), i = r.redNeg(), o = new n(3).toRed(t).redNeg().redSqrt().redMul(r);
return [ i.redAdd(o).fromRed(), i.redSub(o).fromRed() ];
};
a.prototype._getEndoBasis = function(e) {
for (var t, r, i, o, s, a, f, c, u, h = this.n.ushrn(Math.floor(this.n.bitLength() / 2)), d = e, l = this.n.clone(), p = new n(1), b = new n(0), m = new n(0), v = new n(1), y = 0; 0 !== d.cmpn(0); ) {
var g = l.div(d);
c = l.sub(g.mul(d));
u = m.sub(g.mul(p));
var _ = v.sub(g.mul(b));
if (!i && c.cmp(h) < 0) {
t = f.neg();
r = p;
i = c.neg();
o = u;
} else if (i && 2 == ++y) break;
f = c;
l = d;
d = c;
m = p;
p = u;
v = b;
b = _;
}
s = c.neg();
a = u;
var w = i.sqr().add(o.sqr());
if (s.sqr().add(a.sqr()).cmp(w) >= 0) {
s = t;
a = r;
}
if (i.negative) {
i = i.neg();
o = o.neg();
}
if (s.negative) {
s = s.neg();
a = a.neg();
}
return [ {
a: i,
b: o
}, {
a: s,
b: a
} ];
};
a.prototype._endoSplit = function(e) {
var t = this.endo.basis, r = t[0], n = t[1], i = n.b.mul(e).divRound(this.n), o = r.b.neg().mul(e).divRound(this.n), s = i.mul(r.a), a = o.mul(n.a), f = i.mul(r.b), c = o.mul(n.b);
return {
k1: e.sub(s).sub(a),
k2: f.add(c).neg()
};
};
a.prototype.pointFromX = function(e, t) {
(e = new n(e, 16)).red || (e = e.toRed(this.red));
var r = e.redSqr().redMul(e).redIAdd(e.redMul(this.a)).redIAdd(this.b), i = r.redSqrt();
if (0 !== i.redSqr().redSub(r).cmp(this.zero)) throw new Error("invalid point");
var o = i.fromRed().isOdd();
(t && !o || !t && o) && (i = i.redNeg());
return this.point(e, i);
};
a.prototype.validate = function(e) {
if (e.inf) return !0;
var t = e.x, r = e.y, n = this.a.redMul(t), i = t.redSqr().redMul(t).redIAdd(n).redIAdd(this.b);
return 0 === r.redSqr().redISub(i).cmpn(0);
};
a.prototype._endoWnafMulAdd = function(e, t, r) {
for (var n = this._endoWnafT1, i = this._endoWnafT2, o = 0; o < e.length; o++) {
var s = this._endoSplit(t[o]), a = e[o], f = a._getBeta();
if (s.k1.negative) {
s.k1.ineg();
a = a.neg(!0);
}
if (s.k2.negative) {
s.k2.ineg();
f = f.neg(!0);
}
n[2 * o] = a;
n[2 * o + 1] = f;
i[2 * o] = s.k1;
i[2 * o + 1] = s.k2;
}
for (var c = this._wnafMulAdd(1, n, i, 2 * o, r), u = 0; u < 2 * o; u++) {
n[u] = null;
i[u] = null;
}
return c;
};
function f(e, t, r, i) {
o.BasePoint.call(this, e, "affine");
if (null === t && null === r) {
this.x = null;
this.y = null;
this.inf = !0;
} else {
this.x = new n(t, 16);
this.y = new n(r, 16);
if (i) {
this.x.forceRed(this.curve.red);
this.y.forceRed(this.curve.red);
}
this.x.red || (this.x = this.x.toRed(this.curve.red));
this.y.red || (this.y = this.y.toRed(this.curve.red));
this.inf = !1;
}
}
i(f, o.BasePoint);
a.prototype.point = function(e, t, r) {
return new f(this, e, t, r);
};
a.prototype.pointFromJSON = function(e, t) {
return f.fromJSON(this, e, t);
};
f.prototype._getBeta = function() {
if (this.curve.endo) {
var e = this.precomputed;
if (e && e.beta) return e.beta;
var t = this.curve.point(this.x.redMul(this.curve.endo.beta), this.y);
if (e) {
var r = this.curve, n = function(e) {
return r.point(e.x.redMul(r.endo.beta), e.y);
};
e.beta = t;
t.precomputed = {
beta: null,
naf: e.naf && {
wnd: e.naf.wnd,
points: e.naf.points.map(n)
},
doubles: e.doubles && {
step: e.doubles.step,
points: e.doubles.points.map(n)
}
};
}
return t;
}
};
f.prototype.toJSON = function() {
return this.precomputed ? [ this.x, this.y, this.precomputed && {
doubles: this.precomputed.doubles && {
step: this.precomputed.doubles.step,
points: this.precomputed.doubles.points.slice(1)
},
naf: this.precomputed.naf && {
wnd: this.precomputed.naf.wnd,
points: this.precomputed.naf.points.slice(1)
}
} ] : [ this.x, this.y ];
};
f.fromJSON = function(e, t, r) {
"string" == typeof t && (t = JSON.parse(t));
var n = e.point(t[0], t[1], r);
if (!t[2]) return n;
function i(t) {
return e.point(t[0], t[1], r);
}
var o = t[2];
n.precomputed = {
beta: null,
doubles: o.doubles && {
step: o.doubles.step,
points: [ n ].concat(o.doubles.points.map(i))
},
naf: o.naf && {
wnd: o.naf.wnd,
points: [ n ].concat(o.naf.points.map(i))
}
};
return n;
};
f.prototype.inspect = function() {
return this.isInfinity() ? "<EC Point Infinity>" : "<EC Point x: " + this.x.fromRed().toString(16, 2) + " y: " + this.y.fromRed().toString(16, 2) + ">";
};
f.prototype.isInfinity = function() {
return this.inf;
};
f.prototype.add = function(e) {
if (this.inf) return e;
if (e.inf) return this;
if (this.eq(e)) return this.dbl();
if (this.neg().eq(e)) return this.curve.point(null, null);
if (0 === this.x.cmp(e.x)) return this.curve.point(null, null);
var t = this.y.redSub(e.y);
0 !== t.cmpn(0) && (t = t.redMul(this.x.redSub(e.x).redInvm()));
var r = t.redSqr().redISub(this.x).redISub(e.x), n = t.redMul(this.x.redSub(r)).redISub(this.y);
return this.curve.point(r, n);
};
f.prototype.dbl = function() {
if (this.inf) return this;
var e = this.y.redAdd(this.y);
if (0 === e.cmpn(0)) return this.curve.point(null, null);
var t = this.curve.a, r = this.x.redSqr(), n = e.redInvm(), i = r.redAdd(r).redIAdd(r).redIAdd(t).redMul(n), o = i.redSqr().redISub(this.x.redAdd(this.x)), s = i.redMul(this.x.redSub(o)).redISub(this.y);
return this.curve.point(o, s);
};
f.prototype.getX = function() {
return this.x.fromRed();
};
f.prototype.getY = function() {
return this.y.fromRed();
};
f.prototype.mul = function(e) {
e = new n(e, 16);
return this.isInfinity() ? this : this._hasDoubles(e) ? this.curve._fixedNafMul(this, e) : this.curve.endo ? this.curve._endoWnafMulAdd([ this ], [ e ]) : this.curve._wnafMul(this, e);
};
f.prototype.mulAdd = function(e, t, r) {
var n = [ this, t ], i = [ e, r ];
return this.curve.endo ? this.curve._endoWnafMulAdd(n, i) : this.curve._wnafMulAdd(1, n, i, 2);
};
f.prototype.jmulAdd = function(e, t, r) {
var n = [ this, t ], i = [ e, r ];
return this.curve.endo ? this.curve._endoWnafMulAdd(n, i, !0) : this.curve._wnafMulAdd(1, n, i, 2, !0);
};
f.prototype.eq = function(e) {
return this === e || this.inf === e.inf && (this.inf || 0 === this.x.cmp(e.x) && 0 === this.y.cmp(e.y));
};
f.prototype.neg = function(e) {
if (this.inf) return this;
var t = this.curve.point(this.x, this.y.redNeg());
if (e && this.precomputed) {
var r = this.precomputed, n = function(e) {
return e.neg();
};
t.precomputed = {
naf: r.naf && {
wnd: r.naf.wnd,
points: r.naf.points.map(n)
},
doubles: r.doubles && {
step: r.doubles.step,
points: r.doubles.points.map(n)
}
};
}
return t;
};
f.prototype.toJ = function() {
return this.inf ? this.curve.jpoint(null, null, null) : this.curve.jpoint(this.x, this.y, this.curve.one);
};
function c(e, t, r, i) {
o.BasePoint.call(this, e, "jacobian");
if (null === t && null === r && null === i) {
this.x = this.curve.one;
this.y = this.curve.one;
this.z = new n(0);
} else {
this.x = new n(t, 16);
this.y = new n(r, 16);
this.z = new n(i, 16);
}
this.x.red || (this.x = this.x.toRed(this.curve.red));
this.y.red || (this.y = this.y.toRed(this.curve.red));
this.z.red || (this.z = this.z.toRed(this.curve.red));
this.zOne = this.z === this.curve.one;
}
i(c, o.BasePoint);
a.prototype.jpoint = function(e, t, r) {
return new c(this, e, t, r);
};
c.prototype.toP = function() {
if (this.isInfinity()) return this.curve.point(null, null);
var e = this.z.redInvm(), t = e.redSqr(), r = this.x.redMul(t), n = this.y.redMul(t).redMul(e);
return this.curve.point(r, n);
};
c.prototype.neg = function() {
return this.curve.jpoint(this.x, this.y.redNeg(), this.z);
};
c.prototype.add = function(e) {
if (this.isInfinity()) return e;
if (e.isInfinity()) return this;
var t = e.z.redSqr(), r = this.z.redSqr(), n = this.x.redMul(t), i = e.x.redMul(r), o = this.y.redMul(t.redMul(e.z)), s = e.y.redMul(r.redMul(this.z)), a = n.redSub(i), f = o.redSub(s);
if (0 === a.cmpn(0)) return 0 !== f.cmpn(0) ? this.curve.jpoint(null, null, null) : this.dbl();
var c = a.redSqr(), u = c.redMul(a), h = n.redMul(c), d = f.redSqr().redIAdd(u).redISub(h).redISub(h), l = f.redMul(h.redISub(d)).redISub(o.redMul(u)), p = this.z.redMul(e.z).redMul(a);
return this.curve.jpoint(d, l, p);
};
c.prototype.mixedAdd = function(e) {
if (this.isInfinity()) return e.toJ();
if (e.isInfinity()) return this;
var t = this.z.redSqr(), r = this.x, n = e.x.redMul(t), i = this.y, o = e.y.redMul(t).redMul(this.z), s = r.redSub(n), a = i.redSub(o);
if (0 === s.cmpn(0)) return 0 !== a.cmpn(0) ? this.curve.jpoint(null, null, null) : this.dbl();
var f = s.redSqr(), c = f.redMul(s), u = r.redMul(f), h = a.redSqr().redIAdd(c).redISub(u).redISub(u), d = a.redMul(u.redISub(h)).redISub(i.redMul(c)), l = this.z.redMul(s);
return this.curve.jpoint(h, d, l);
};
c.prototype.dblp = function(e) {
if (0 === e) return this;
if (this.isInfinity()) return this;
if (!e) return this.dbl();
var t;
if (this.curve.zeroA || this.curve.threeA) {
var r = this;
for (t = 0; t < e; t++) r = r.dbl();
return r;
}
var n = this.curve.a, i = this.curve.tinv, o = this.x, s = this.y, a = this.z, f = a.redSqr().redSqr(), c = s.redAdd(s);
for (t = 0; t < e; t++) {
var u = o.redSqr(), h = c.redSqr(), d = h.redSqr(), l = u.redAdd(u).redIAdd(u).redIAdd(n.redMul(f)), p = o.redMul(h), b = l.redSqr().redISub(p.redAdd(p)), m = p.redISub(b), v = l.redMul(m);
v = v.redIAdd(v).redISub(d);
var y = c.redMul(a);
t + 1 < e && (f = f.redMul(d));
o = b;
a = y;
c = v;
}
return this.curve.jpoint(o, c.redMul(i), a);
};
c.prototype.dbl = function() {
return this.isInfinity() ? this : this.curve.zeroA ? this._zeroDbl() : this.curve.threeA ? this._threeDbl() : this._dbl();
};
c.prototype._zeroDbl = function() {
var e, t, r;
if (this.zOne) {
var n = this.x.redSqr(), i = this.y.redSqr(), o = i.redSqr(), s = this.x.redAdd(i).redSqr().redISub(n).redISub(o);
s = s.redIAdd(s);
var a = n.redAdd(n).redIAdd(n), f = a.redSqr().redISub(s).redISub(s), c = o.redIAdd(o);
c = (c = c.redIAdd(c)).redIAdd(c);
e = f;
t = a.redMul(s.redISub(f)).redISub(c);
r = this.y.redAdd(this.y);
} else {
var u = this.x.redSqr(), h = this.y.redSqr(), d = h.redSqr(), l = this.x.redAdd(h).redSqr().redISub(u).redISub(d);
l = l.redIAdd(l);
var p = u.redAdd(u).redIAdd(u), b = p.redSqr(), m = d.redIAdd(d);
m = (m = m.redIAdd(m)).redIAdd(m);
e = b.redISub(l).redISub(l);
t = p.redMul(l.redISub(e)).redISub(m);
r = (r = this.y.redMul(this.z)).redIAdd(r);
}
return this.curve.jpoint(e, t, r);
};
c.prototype._threeDbl = function() {
var e, t, r;
if (this.zOne) {
var n = this.x.redSqr(), i = this.y.redSqr(), o = i.redSqr(), s = this.x.redAdd(i).redSqr().redISub(n).redISub(o);
s = s.redIAdd(s);
var a = n.redAdd(n).redIAdd(n).redIAdd(this.curve.a), f = a.redSqr().redISub(s).redISub(s);
e = f;
var c = o.redIAdd(o);
c = (c = c.redIAdd(c)).redIAdd(c);
t = a.redMul(s.redISub(f)).redISub(c);
r = this.y.redAdd(this.y);
} else {
var u = this.z.redSqr(), h = this.y.redSqr(), d = this.x.redMul(h), l = this.x.redSub(u).redMul(this.x.redAdd(u));
l = l.redAdd(l).redIAdd(l);
var p = d.redIAdd(d), b = (p = p.redIAdd(p)).redAdd(p);
e = l.redSqr().redISub(b);
r = this.y.redAdd(this.z).redSqr().redISub(h).redISub(u);
var m = h.redSqr();
m = (m = (m = m.redIAdd(m)).redIAdd(m)).redIAdd(m);
t = l.redMul(p.redISub(e)).redISub(m);
}
return this.curve.jpoint(e, t, r);
};
c.prototype._dbl = function() {
var e = this.curve.a, t = this.x, r = this.y, n = this.z, i = n.redSqr().redSqr(), o = t.redSqr(), s = r.redSqr(), a = o.redAdd(o).redIAdd(o).redIAdd(e.redMul(i)), f = t.redAdd(t), c = (f = f.redIAdd(f)).redMul(s), u = a.redSqr().redISub(c.redAdd(c)), h = c.redISub(u), d = s.redSqr();
d = (d = (d = d.redIAdd(d)).redIAdd(d)).redIAdd(d);
var l = a.redMul(h).redISub(d), p = r.redAdd(r).redMul(n);
return this.curve.jpoint(u, l, p);
};
c.prototype.trpl = function() {
if (!this.curve.zeroA) return this.dbl().add(this);
var e = this.x.redSqr(), t = this.y.redSqr(), r = this.z.redSqr(), n = t.redSqr(), i = e.redAdd(e).redIAdd(e), o = i.redSqr(), s = this.x.redAdd(t).redSqr().redISub(e).redISub(n), a = (s = (s = (s = s.redIAdd(s)).redAdd(s).redIAdd(s)).redISub(o)).redSqr(), f = n.redIAdd(n);
f = (f = (f = f.redIAdd(f)).redIAdd(f)).redIAdd(f);
var c = i.redIAdd(s).redSqr().redISub(o).redISub(a).redISub(f), u = t.redMul(c);
u = (u = u.redIAdd(u)).redIAdd(u);
var h = this.x.redMul(a).redISub(u);
h = (h = h.redIAdd(h)).redIAdd(h);
var d = this.y.redMul(c.redMul(f.redISub(c)).redISub(s.redMul(a)));
d = (d = (d = d.redIAdd(d)).redIAdd(d)).redIAdd(d);
var l = this.z.redAdd(s).redSqr().redISub(r).redISub(a);
return this.curve.jpoint(h, d, l);
};
c.prototype.mul = function(e, t) {
e = new n(e, t);
return this.curve._wnafMul(this, e);
};
c.prototype.eq = function(e) {
if ("affine" === e.type) return this.eq(e.toJ());
if (this === e) return !0;
var t = this.z.redSqr(), r = e.z.redSqr();
if (0 !== this.x.redMul(r).redISub(e.x.redMul(t)).cmpn(0)) return !1;
var n = t.redMul(this.z), i = r.redMul(e.z);
return 0 === this.y.redMul(i).redISub(e.y.redMul(n)).cmpn(0);
};
c.prototype.eqXToP = function(e) {
var t = this.z.redSqr(), r = e.toRed(this.curve.red).redMul(t);
if (0 === this.x.cmp(r)) return !0;
for (var n = e.clone(), i = this.curve.redN.redMul(t); ;) {
n.iadd(this.curve.n);
if (n.cmp(this.curve.p) >= 0) return !1;
r.redIAdd(i);
if (0 === this.x.cmp(r)) return !0;
}
};
c.prototype.inspect = function() {
return this.isInfinity() ? "<EC JPoint Infinity>" : "<EC JPoint x: " + this.x.toString(16, 2) + " y: " + this.y.toString(16, 2) + " z: " + this.z.toString(16, 2) + ">";
};
c.prototype.isInfinity = function() {
return 0 === this.z.cmpn(0);
};
}, {
"../utils": 101,
"./base": 88,
"bn.js": 102,
inherits: 138
} ],
93: [ function(e, t, r) {
"use strict";
var n, i = r, o = e("hash.js"), s = e("./curve"), a = e("./utils").assert;
function f(e) {
"short" === e.type ? this.curve = new s.short(e) : "edwards" === e.type ? this.curve = new s.edwards(e) : this.curve = new s.mont(e);
this.g = this.curve.g;
this.n = this.curve.n;
this.hash = e.hash;
a(this.g.validate(), "Invalid curve");
a(this.g.mul(this.n).isInfinity(), "Invalid curve, G*N != O");
}
i.PresetCurve = f;
function c(e, t) {
Object.defineProperty(i, e, {
configurable: !0,
enumerable: !0,
get: function() {
var r = new f(t);
Object.defineProperty(i, e, {
configurable: !0,
enumerable: !0,
value: r
});
return r;
}
});
}
c("p192", {
type: "short",
prime: "p192",
p: "ffffffff ffffffff ffffffff fffffffe ffffffff ffffffff",
a: "ffffffff ffffffff ffffffff fffffffe ffffffff fffffffc",
b: "64210519 e59c80e7 0fa7e9ab 72243049 feb8deec c146b9b1",
n: "ffffffff ffffffff ffffffff 99def836 146bc9b1 b4d22831",
hash: o.sha256,
gRed: !1,
g: [ "188da80e b03090f6 7cbf20eb 43a18800 f4ff0afd 82ff1012", "07192b95 ffc8da78 631011ed 6b24cdd5 73f977a1 1e794811" ]
});
c("p224", {
type: "short",
prime: "p224",
p: "ffffffff ffffffff ffffffff ffffffff 00000000 00000000 00000001",
a: "ffffffff ffffffff ffffffff fffffffe ffffffff ffffffff fffffffe",
b: "b4050a85 0c04b3ab f5413256 5044b0b7 d7bfd8ba 270b3943 2355ffb4",
n: "ffffffff ffffffff ffffffff ffff16a2 e0b8f03e 13dd2945 5c5c2a3d",
hash: o.sha256,
gRed: !1,
g: [ "b70e0cbd 6bb4bf7f 321390b9 4a03c1d3 56c21122 343280d6 115c1d21", "bd376388 b5f723fb 4c22dfe6 cd4375a0 5a074764 44d58199 85007e34" ]
});
c("p256", {
type: "short",
prime: null,
p: "ffffffff 00000001 00000000 00000000 00000000 ffffffff ffffffff ffffffff",
a: "ffffffff 00000001 00000000 00000000 00000000 ffffffff ffffffff fffffffc",
b: "5ac635d8 aa3a93e7 b3ebbd55 769886bc 651d06b0 cc53b0f6 3bce3c3e 27d2604b",
n: "ffffffff 00000000 ffffffff ffffffff bce6faad a7179e84 f3b9cac2 fc632551",
hash: o.sha256,
gRed: !1,
g: [ "6b17d1f2 e12c4247 f8bce6e5 63a440f2 77037d81 2deb33a0 f4a13945 d898c296", "4fe342e2 fe1a7f9b 8ee7eb4a 7c0f9e16 2bce3357 6b315ece cbb64068 37bf51f5" ]
});
c("p384", {
type: "short",
prime: null,
p: "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe ffffffff 00000000 00000000 ffffffff",
a: "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe ffffffff 00000000 00000000 fffffffc",
b: "b3312fa7 e23ee7e4 988e056b e3f82d19 181d9c6e fe814112 0314088f 5013875a c656398d 8a2ed19d 2a85c8ed d3ec2aef",
n: "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff c7634d81 f4372ddf 581a0db2 48b0a77a ecec196a ccc52973",
hash: o.sha384,
gRed: !1,
g: [ "aa87ca22 be8b0537 8eb1c71e f320ad74 6e1d3b62 8ba79b98 59f741e0 82542a38 5502f25d bf55296c 3a545e38 72760ab7", "3617de4a 96262c6f 5d9e98bf 9292dc29 f8f41dbd 289a147c e9da3113 b5f0b8c0 0a60b1ce 1d7e819d 7a431d7c 90ea0e5f" ]
});
c("p521", {
type: "short",
prime: null,
p: "000001ff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff",
a: "000001ff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffc",
b: "00000051 953eb961 8e1c9a1f 929a21a0 b68540ee a2da725b 99b315f3 b8b48991 8ef109e1 56193951 ec7e937b 1652c0bd 3bb1bf07 3573df88 3d2c34f1 ef451fd4 6b503f00",
n: "000001ff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffa 51868783 bf2f966b 7fcc0148 f709a5d0 3bb5c9b8 899c47ae bb6fb71e 91386409",
hash: o.sha512,
gRed: !1,
g: [ "000000c6 858e06b7 0404e9cd 9e3ecb66 2395b442 9c648139 053fb521 f828af60 6b4d3dba a14b5e77 efe75928 fe1dc127 a2ffa8de 3348b3c1 856a429b f97e7e31 c2e5bd66", "00000118 39296a78 9a3bc004 5c8a5fb4 2c7d1bd9 98f54449 579b4468 17afbd17 273e662c 97ee7299 5ef42640 c550b901 3fad0761 353c7086 a272c240 88be9476 9fd16650" ]
});
c("curve25519", {
type: "mont",
prime: "p25519",
p: "7fffffffffffffff ffffffffffffffff ffffffffffffffff ffffffffffffffed",
a: "76d06",
b: "1",
n: "1000000000000000 0000000000000000 14def9dea2f79cd6 5812631a5cf5d3ed",
hash: o.sha256,
gRed: !1,
g: [ "9" ]
});
c("ed25519", {
type: "edwards",
prime: "p25519",
p: "7fffffffffffffff ffffffffffffffff ffffffffffffffff ffffffffffffffed",
a: "-1",
c: "1",
d: "52036cee2b6ffe73 8cc740797779e898 00700a4d4141d8ab 75eb4dca135978a3",
n: "1000000000000000 0000000000000000 14def9dea2f79cd6 5812631a5cf5d3ed",
hash: o.sha256,
gRed: !1,
g: [ "216936d3cd6e53fec0a4e231fdd6dc5c692cc7609525a7b2c9562d608f25d51a", "6666666666666666666666666666666666666666666666666666666666666658" ]
});
try {
n = e("./precomputed/secp256k1");
} catch (e) {
n = void 0;
}
c("secp256k1", {
type: "short",
prime: "k256",
p: "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe fffffc2f",
a: "0",
b: "7",
n: "ffffffff ffffffff ffffffff fffffffe baaedce6 af48a03b bfd25e8c d0364141",
h: "1",
hash: o.sha256,
beta: "7ae96a2b657c07106e64479eac3434e99cf0497512f58995c1396c28719501ee",
lambda: "5363ad4cc05c30e0a5261c028812645a122e22ea20816678df02967c1b23bd72",
basis: [ {
a: "3086d221a7d46bcde86c90e49284eb15",
b: "-e4437ed6010e88286f547fa90abfe4c3"
}, {
a: "114ca50f7a8e2f3f657c1108d9d44cfd8",
b: "3086d221a7d46bcde86c90e49284eb15"
} ],
gRed: !1,
g: [ "79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798", "483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8", n ]
});
}, {
"./curve": 90,
"./precomputed/secp256k1": 100,
"./utils": 101,
"hash.js": 124
} ],
94: [ function(e, t) {
"use strict";
var r = e("bn.js"), n = e("hmac-drbg"), i = e("../utils"), o = e("../curves"), s = e("brorand"), a = i.assert, f = e("./key"), c = e("./signature");
function u(e) {
if (!(this instanceof u)) return new u(e);
if ("string" == typeof e) {
a(Object.prototype.hasOwnProperty.call(o, e), "Unknown curve " + e);
e = o[e];
}
e instanceof o.PresetCurve && (e = {
curve: e
});
this.curve = e.curve.curve;
this.n = this.curve.n;
this.nh = this.n.ushrn(1);
this.g = this.curve.g;
this.g = e.curve.g;
this.g.precompute(e.curve.n.bitLength() + 1);
this.hash = e.hash || e.curve.hash;
}
t.exports = u;
u.prototype.keyPair = function(e) {
return new f(this, e);
};
u.prototype.keyFromPrivate = function(e, t) {
return f.fromPrivate(this, e, t);
};
u.prototype.keyFromPublic = function(e, t) {
return f.fromPublic(this, e, t);
};
u.prototype.genKeyPair = function(e) {
e || (e = {});
for (var t = new n({
hash: this.hash,
pers: e.pers,
persEnc: e.persEnc || "utf8",
entropy: e.entropy || s(this.hash.hmacStrength),
entropyEnc: e.entropy && e.entropyEnc || "utf8",
nonce: this.n.toArray()
}), i = this.n.byteLength(), o = this.n.sub(new r(2)); ;) {
var a = new r(t.generate(i));
if (!(a.cmp(o) > 0)) {
a.iaddn(1);
return this.keyFromPrivate(a);
}
}
};
u.prototype._truncateToN = function(e, t) {
var r = 8 * e.byteLength() - this.n.bitLength();
r > 0 && (e = e.ushrn(r));
return !t && e.cmp(this.n) >= 0 ? e.sub(this.n) : e;
};
u.prototype.sign = function(e, t, i, o) {
if ("object" == typeof i) {
o = i;
i = null;
}
o || (o = {});
t = this.keyFromPrivate(t, i);
e = this._truncateToN(new r(e, 16));
for (var s = this.n.byteLength(), a = t.getPrivate().toArray("be", s), f = e.toArray("be", s), u = new n({
hash: this.hash,
entropy: a,
nonce: f,
pers: o.pers,
persEnc: o.persEnc || "utf8"
}), h = this.n.sub(new r(1)), d = 0; ;d++) {
var l = o.k ? o.k(d) : new r(u.generate(this.n.byteLength()));
if (!((l = this._truncateToN(l, !0)).cmpn(1) <= 0 || l.cmp(h) >= 0)) {
var p = this.g.mul(l);
if (!p.isInfinity()) {
var b = p.getX(), m = b.umod(this.n);
if (0 !== m.cmpn(0)) {
var v = l.invm(this.n).mul(m.mul(t.getPrivate()).iadd(e));
if (0 !== (v = v.umod(this.n)).cmpn(0)) {
var y = (p.getY().isOdd() ? 1 : 0) | (0 !== b.cmp(m) ? 2 : 0);
if (o.canonical && v.cmp(this.nh) > 0) {
v = this.n.sub(v);
y ^= 1;
}
return new c({
r: m,
s: v,
recoveryParam: y
});
}
}
}
}
}
};
u.prototype.verify = function(e, t, n, i) {
e = this._truncateToN(new r(e, 16));
n = this.keyFromPublic(n, i);
var o = (t = new c(t, "hex")).r, s = t.s;
if (o.cmpn(1) < 0 || o.cmp(this.n) >= 0) return !1;
if (s.cmpn(1) < 0 || s.cmp(this.n) >= 0) return !1;
var a, f = s.invm(this.n), u = f.mul(e).umod(this.n), h = f.mul(o).umod(this.n);
return this.curve._maxwellTrick ? !(a = this.g.jmulAdd(u, n.getPublic(), h)).isInfinity() && a.eqXToP(o) : !(a = this.g.mulAdd(u, n.getPublic(), h)).isInfinity() && 0 === a.getX().umod(this.n).cmp(o);
};
u.prototype.recoverPubKey = function(e, t, n, i) {
a((3 & n) === n, "The recovery param is more than two bits");
t = new c(t, i);
var o = this.n, s = new r(e), f = t.r, u = t.s, h = 1 & n, d = n >> 1;
if (f.cmp(this.curve.p.umod(this.curve.n)) >= 0 && d) throw new Error("Unable to find sencond key candinate");
f = d ? this.curve.pointFromX(f.add(this.curve.n), h) : this.curve.pointFromX(f, h);
var l = t.r.invm(o), p = o.sub(s).mul(l).umod(o), b = u.mul(l).umod(o);
return this.g.mulAdd(p, f, b);
};
u.prototype.getKeyRecoveryParam = function(e, t, r, n) {
if (null !== (t = new c(t, n)).recoveryParam) return t.recoveryParam;
for (var i = 0; i < 4; i++) {
var o;
try {
o = this.recoverPubKey(e, t, i);
} catch (e) {
continue;
}
if (o.eq(r)) return i;
}
throw new Error("Unable to find valid recovery factor");
};
}, {
"../curves": 93,
"../utils": 101,
"./key": 95,
"./signature": 96,
"bn.js": 102,
brorand: 18,
"hmac-drbg": 136
} ],
95: [ function(e, t) {
"use strict";
var r = e("bn.js"), n = e("../utils").assert;
function i(e, t) {
this.ec = e;
this.priv = null;
this.pub = null;
t.priv && this._importPrivate(t.priv, t.privEnc);
t.pub && this._importPublic(t.pub, t.pubEnc);
}
t.exports = i;
i.fromPublic = function(e, t, r) {
return t instanceof i ? t : new i(e, {
pub: t,
pubEnc: r
});
};
i.fromPrivate = function(e, t, r) {
return t instanceof i ? t : new i(e, {
priv: t,
privEnc: r
});
};
i.prototype.validate = function() {
var e = this.getPublic();
return e.isInfinity() ? {
result: !1,
reason: "Invalid public key"
} : e.validate() ? e.mul(this.ec.curve.n).isInfinity() ? {
result: !0,
reason: null
} : {
result: !1,
reason: "Public key * N != O"
} : {
result: !1,
reason: "Public key is not a point"
};
};
i.prototype.getPublic = function(e, t) {
if ("string" == typeof e) {
t = e;
e = null;
}
this.pub || (this.pub = this.ec.g.mul(this.priv));
return t ? this.pub.encode(t, e) : this.pub;
};
i.prototype.getPrivate = function(e) {
return "hex" === e ? this.priv.toString(16, 2) : this.priv;
};
i.prototype._importPrivate = function(e, t) {
this.priv = new r(e, t || 16);
this.priv = this.priv.umod(this.ec.curve.n);
};
i.prototype._importPublic = function(e, t) {
if (e.x || e.y) {
"mont" === this.ec.curve.type ? n(e.x, "Need x coordinate") : "short" !== this.ec.curve.type && "edwards" !== this.ec.curve.type || n(e.x && e.y, "Need both x and y coordinate");
this.pub = this.ec.curve.point(e.x, e.y);
} else this.pub = this.ec.curve.decodePoint(e, t);
};
i.prototype.derive = function(e) {
e.validate() || n(e.validate(), "public point not validated");
return e.mul(this.priv).getX();
};
i.prototype.sign = function(e, t, r) {
return this.ec.sign(e, this, t, r);
};
i.prototype.verify = function(e, t) {
return this.ec.verify(e, t, this);
};
i.prototype.inspect = function() {
return "<Key priv: " + (this.priv && this.priv.toString(16, 2)) + " pub: " + (this.pub && this.pub.inspect()) + " >";
};
}, {
"../utils": 101,
"bn.js": 102
} ],
96: [ function(e, t) {
"use strict";
var r = e("bn.js"), n = e("../utils"), i = n.assert;
function o(e, t) {
if (e instanceof o) return e;
if (!this._importDER(e, t)) {
i(e.r && e.s, "Signature without r or s");
this.r = new r(e.r, 16);
this.s = new r(e.s, 16);
void 0 === e.recoveryParam ? this.recoveryParam = null : this.recoveryParam = e.recoveryParam;
}
}
t.exports = o;
function s() {
this.place = 0;
}
function a(e, t) {
var r = e[t.place++];
if (!(128 & r)) return r;
var n = 15 & r;
if (0 === n || n > 4) return !1;
for (var i = 0, o = 0, s = t.place; o < n; o++, s++) {
i <<= 8;
i |= e[s];
i >>>= 0;
}
if (i <= 127) return !1;
t.place = s;
return i;
}
function f(e) {
for (var t = 0, r = e.length - 1; !e[t] && !(128 & e[t + 1]) && t < r; ) t++;
return 0 === t ? e : e.slice(t);
}
o.prototype._importDER = function(e, t) {
e = n.toArray(e, t);
var i = new s();
if (48 !== e[i.place++]) return !1;
var o = a(e, i);
if (!1 === o) return !1;
if (o + i.place !== e.length) return !1;
if (2 !== e[i.place++]) return !1;
var f = a(e, i);
if (!1 === f) return !1;
var c = e.slice(i.place, f + i.place);
i.place += f;
if (2 !== e[i.place++]) return !1;
var u = a(e, i);
if (!1 === u) return !1;
if (e.length !== u + i.place) return !1;
var h = e.slice(i.place, u + i.place);
if (0 === c[0]) {
if (!(128 & c[1])) return !1;
c = c.slice(1);
}
if (0 === h[0]) {
if (!(128 & h[1])) return !1;
h = h.slice(1);
}
this.r = new r(c);
this.s = new r(h);
this.recoveryParam = null;
return !0;
};
function c(e, t) {
if (t < 128) e.push(t); else {
var r = 1 + (Math.log(t) / Math.LN2 >>> 3);
e.push(128 | r);
for (;--r; ) e.push(t >>> (r << 3) & 255);
e.push(t);
}
}
o.prototype.toDER = function(e) {
var t = this.r.toArray(), r = this.s.toArray();
128 & t[0] && (t = [ 0 ].concat(t));
128 & r[0] && (r = [ 0 ].concat(r));
t = f(t);
r = f(r);
for (;!(r[0] || 128 & r[1]); ) r = r.slice(1);
var i = [ 2 ];
c(i, t.length);
(i = i.concat(t)).push(2);
c(i, r.length);
var o = i.concat(r), s = [ 48 ];
c(s, o.length);
s = s.concat(o);
return n.encode(s, e);
};
}, {
"../utils": 101,
"bn.js": 102
} ],
97: [ function(e, t) {
"use strict";
var r = e("hash.js"), n = e("../curves"), i = e("../utils"), o = i.assert, s = i.parseBytes, a = e("./key"), f = e("./signature");
function c(e) {
o("ed25519" === e, "only tested with ed25519 so far");
if (!(this instanceof c)) return new c(e);
e = n[e].curve;
this.curve = e;
this.g = e.g;
this.g.precompute(e.n.bitLength() + 1);
this.pointClass = e.point().constructor;
this.encodingLength = Math.ceil(e.n.bitLength() / 8);
this.hash = r.sha512;
}
t.exports = c;
c.prototype.sign = function(e, t) {
e = s(e);
var r = this.keyFromSecret(t), n = this.hashInt(r.messagePrefix(), e), i = this.g.mul(n), o = this.encodePoint(i), a = this.hashInt(o, r.pubBytes(), e).mul(r.priv()), f = n.add(a).umod(this.curve.n);
return this.makeSignature({
R: i,
S: f,
Rencoded: o
});
};
c.prototype.verify = function(e, t, r) {
e = s(e);
t = this.makeSignature(t);
var n = this.keyFromPublic(r), i = this.hashInt(t.Rencoded(), n.pubBytes(), e), o = this.g.mul(t.S());
return t.R().add(n.pub().mul(i)).eq(o);
};
c.prototype.hashInt = function() {
for (var e = this.hash(), t = 0; t < arguments.length; t++) e.update(arguments[t]);
return i.intFromLE(e.digest()).umod(this.curve.n);
};
c.prototype.keyFromPublic = function(e) {
return a.fromPublic(this, e);
};
c.prototype.keyFromSecret = function(e) {
return a.fromSecret(this, e);
};
c.prototype.makeSignature = function(e) {
return e instanceof f ? e : new f(this, e);
};
c.prototype.encodePoint = function(e) {
var t = e.getY().toArray("le", this.encodingLength);
t[this.encodingLength - 1] |= e.getX().isOdd() ? 128 : 0;
return t;
};
c.prototype.decodePoint = function(e) {
var t = (e = i.parseBytes(e)).length - 1, r = e.slice(0, t).concat(-129 & e[t]), n = 0 != (128 & e[t]), o = i.intFromLE(r);
return this.curve.pointFromY(o, n);
};
c.prototype.encodeInt = function(e) {
return e.toArray("le", this.encodingLength);
};
c.prototype.decodeInt = function(e) {
return i.intFromLE(e);
};
c.prototype.isPoint = function(e) {
return e instanceof this.pointClass;
};
}, {
"../curves": 93,
"../utils": 101,
"./key": 98,
"./signature": 99,
"hash.js": 124
} ],
98: [ function(e, t) {
"use strict";
var r = e("../utils"), n = r.assert, i = r.parseBytes, o = r.cachedProperty;
function s(e, t) {
this.eddsa = e;
this._secret = i(t.secret);
e.isPoint(t.pub) ? this._pub = t.pub : this._pubBytes = i(t.pub);
}
s.fromPublic = function(e, t) {
return t instanceof s ? t : new s(e, {
pub: t
});
};
s.fromSecret = function(e, t) {
return t instanceof s ? t : new s(e, {
secret: t
});
};
s.prototype.secret = function() {
return this._secret;
};
o(s, "pubBytes", function() {
return this.eddsa.encodePoint(this.pub());
});
o(s, "pub", function() {
return this._pubBytes ? this.eddsa.decodePoint(this._pubBytes) : this.eddsa.g.mul(this.priv());
});
o(s, "privBytes", function() {
var e = this.eddsa, t = this.hash(), r = e.encodingLength - 1, n = t.slice(0, e.encodingLength);
n[0] &= 248;
n[r] &= 127;
n[r] |= 64;
return n;
});
o(s, "priv", function() {
return this.eddsa.decodeInt(this.privBytes());
});
o(s, "hash", function() {
return this.eddsa.hash().update(this.secret()).digest();
});
o(s, "messagePrefix", function() {
return this.hash().slice(this.eddsa.encodingLength);
});
s.prototype.sign = function(e) {
n(this._secret, "KeyPair can only verify");
return this.eddsa.sign(e, this);
};
s.prototype.verify = function(e, t) {
return this.eddsa.verify(e, t, this);
};
s.prototype.getSecret = function(e) {
n(this._secret, "KeyPair is public only");
return r.encode(this.secret(), e);
};
s.prototype.getPublic = function(e) {
return r.encode(this.pubBytes(), e);
};
t.exports = s;
}, {
"../utils": 101
} ],
99: [ function(e, t) {
"use strict";
var r = e("bn.js"), n = e("../utils"), i = n.assert, o = n.cachedProperty, s = n.parseBytes;
function a(e, t) {
this.eddsa = e;
"object" != typeof t && (t = s(t));
Array.isArray(t) && (t = {
R: t.slice(0, e.encodingLength),
S: t.slice(e.encodingLength)
});
i(t.R && t.S, "Signature without R or S");
e.isPoint(t.R) && (this._R = t.R);
t.S instanceof r && (this._S = t.S);
this._Rencoded = Array.isArray(t.R) ? t.R : t.Rencoded;
this._Sencoded = Array.isArray(t.S) ? t.S : t.Sencoded;
}
o(a, "S", function() {
return this.eddsa.decodeInt(this.Sencoded());
});
o(a, "R", function() {
return this.eddsa.decodePoint(this.Rencoded());
});
o(a, "Rencoded", function() {
return this.eddsa.encodePoint(this.R());
});
o(a, "Sencoded", function() {
return this.eddsa.encodeInt(this.S());
});
a.prototype.toBytes = function() {
return this.Rencoded().concat(this.Sencoded());
};
a.prototype.toHex = function() {
return n.encode(this.toBytes(), "hex").toUpperCase();
};
t.exports = a;
}, {
"../utils": 101,
"bn.js": 102
} ],
100: [ function(e, t) {
t.exports = {
doubles: {
step: 4,
points: [ [ "e60fce93b59e9ec53011aabc21c23e97b2a31369b87a5ae9c44ee89e2a6dec0a", "f7e3507399e595929db99f34f57937101296891e44d23f0be1f32cce69616821" ], [ "8282263212c609d9ea2a6e3e172de238d8c39cabd5ac1ca10646e23fd5f51508", "11f8a8098557dfe45e8256e830b60ace62d613ac2f7b17bed31b6eaff6e26caf" ], [ "175e159f728b865a72f99cc6c6fc846de0b93833fd2222ed73fce5b551e5b739", "d3506e0d9e3c79eba4ef97a51ff71f5eacb5955add24345c6efa6ffee9fed695" ], [ "363d90d447b00c9c99ceac05b6262ee053441c7e55552ffe526bad8f83ff4640", "4e273adfc732221953b445397f3363145b9a89008199ecb62003c7f3bee9de9" ], [ "8b4b5f165df3c2be8c6244b5b745638843e4a781a15bcd1b69f79a55dffdf80c", "4aad0a6f68d308b4b3fbd7813ab0da04f9e336546162ee56b3eff0c65fd4fd36" ], [ "723cbaa6e5db996d6bf771c00bd548c7b700dbffa6c0e77bcb6115925232fcda", "96e867b5595cc498a921137488824d6e2660a0653779494801dc069d9eb39f5f" ], [ "eebfa4d493bebf98ba5feec812c2d3b50947961237a919839a533eca0e7dd7fa", "5d9a8ca3970ef0f269ee7edaf178089d9ae4cdc3a711f712ddfd4fdae1de8999" ], [ "100f44da696e71672791d0a09b7bde459f1215a29b3c03bfefd7835b39a48db0", "cdd9e13192a00b772ec8f3300c090666b7ff4a18ff5195ac0fbd5cd62bc65a09" ], [ "e1031be262c7ed1b1dc9227a4a04c017a77f8d4464f3b3852c8acde6e534fd2d", "9d7061928940405e6bb6a4176597535af292dd419e1ced79a44f18f29456a00d" ], [ "feea6cae46d55b530ac2839f143bd7ec5cf8b266a41d6af52d5e688d9094696d", "e57c6b6c97dce1bab06e4e12bf3ecd5c981c8957cc41442d3155debf18090088" ], [ "da67a91d91049cdcb367be4be6ffca3cfeed657d808583de33fa978bc1ec6cb1", "9bacaa35481642bc41f463f7ec9780e5dec7adc508f740a17e9ea8e27a68be1d" ], [ "53904faa0b334cdda6e000935ef22151ec08d0f7bb11069f57545ccc1a37b7c0", "5bc087d0bc80106d88c9eccac20d3c1c13999981e14434699dcb096b022771c8" ], [ "8e7bcd0bd35983a7719cca7764ca906779b53a043a9b8bcaeff959f43ad86047", "10b7770b2a3da4b3940310420ca9514579e88e2e47fd68b3ea10047e8460372a" ], [ "385eed34c1cdff21e6d0818689b81bde71a7f4f18397e6690a841e1599c43862", "283bebc3e8ea23f56701de19e9ebf4576b304eec2086dc8cc0458fe5542e5453" ], [ "6f9d9b803ecf191637c73a4413dfa180fddf84a5947fbc9c606ed86c3fac3a7", "7c80c68e603059ba69b8e2a30e45c4d47ea4dd2f5c281002d86890603a842160" ], [ "3322d401243c4e2582a2147c104d6ecbf774d163db0f5e5313b7e0e742d0e6bd", "56e70797e9664ef5bfb019bc4ddaf9b72805f63ea2873af624f3a2e96c28b2a0" ], [ "85672c7d2de0b7da2bd1770d89665868741b3f9af7643397721d74d28134ab83", "7c481b9b5b43b2eb6374049bfa62c2e5e77f17fcc5298f44c8e3094f790313a6" ], [ "948bf809b1988a46b06c9f1919413b10f9226c60f668832ffd959af60c82a0a", "53a562856dcb6646dc6b74c5d1c3418c6d4dff08c97cd2bed4cb7f88d8c8e589" ], [ "6260ce7f461801c34f067ce0f02873a8f1b0e44dfc69752accecd819f38fd8e8", "bc2da82b6fa5b571a7f09049776a1ef7ecd292238051c198c1a84e95b2b4ae17" ], [ "e5037de0afc1d8d43d8348414bbf4103043ec8f575bfdc432953cc8d2037fa2d", "4571534baa94d3b5f9f98d09fb990bddbd5f5b03ec481f10e0e5dc841d755bda" ], [ "e06372b0f4a207adf5ea905e8f1771b4e7e8dbd1c6a6c5b725866a0ae4fce725", "7a908974bce18cfe12a27bb2ad5a488cd7484a7787104870b27034f94eee31dd" ], [ "213c7a715cd5d45358d0bbf9dc0ce02204b10bdde2a3f58540ad6908d0559754", "4b6dad0b5ae462507013ad06245ba190bb4850f5f36a7eeddff2c27534b458f2" ], [ "4e7c272a7af4b34e8dbb9352a5419a87e2838c70adc62cddf0cc3a3b08fbd53c", "17749c766c9d0b18e16fd09f6def681b530b9614bff7dd33e0b3941817dcaae6" ], [ "fea74e3dbe778b1b10f238ad61686aa5c76e3db2be43057632427e2840fb27b6", "6e0568db9b0b13297cf674deccb6af93126b596b973f7b77701d3db7f23cb96f" ], [ "76e64113f677cf0e10a2570d599968d31544e179b760432952c02a4417bdde39", "c90ddf8dee4e95cf577066d70681f0d35e2a33d2b56d2032b4b1752d1901ac01" ], [ "c738c56b03b2abe1e8281baa743f8f9a8f7cc643df26cbee3ab150242bcbb891", "893fb578951ad2537f718f2eacbfbbbb82314eef7880cfe917e735d9699a84c3" ], [ "d895626548b65b81e264c7637c972877d1d72e5f3a925014372e9f6588f6c14b", "febfaa38f2bc7eae728ec60818c340eb03428d632bb067e179363ed75d7d991f" ], [ "b8da94032a957518eb0f6433571e8761ceffc73693e84edd49150a564f676e03", "2804dfa44805a1e4d7c99cc9762808b092cc584d95ff3b511488e4e74efdf6e7" ], [ "e80fea14441fb33a7d8adab9475d7fab2019effb5156a792f1a11778e3c0df5d", "eed1de7f638e00771e89768ca3ca94472d155e80af322ea9fcb4291b6ac9ec78" ], [ "a301697bdfcd704313ba48e51d567543f2a182031efd6915ddc07bbcc4e16070", "7370f91cfb67e4f5081809fa25d40f9b1735dbf7c0a11a130c0d1a041e177ea1" ], [ "90ad85b389d6b936463f9d0512678de208cc330b11307fffab7ac63e3fb04ed4", "e507a3620a38261affdcbd9427222b839aefabe1582894d991d4d48cb6ef150" ], [ "8f68b9d2f63b5f339239c1ad981f162ee88c5678723ea3351b7b444c9ec4c0da", "662a9f2dba063986de1d90c2b6be215dbbea2cfe95510bfdf23cbf79501fff82" ], [ "e4f3fb0176af85d65ff99ff9198c36091f48e86503681e3e6686fd5053231e11", "1e63633ad0ef4f1c1661a6d0ea02b7286cc7e74ec951d1c9822c38576feb73bc" ], [ "8c00fa9b18ebf331eb961537a45a4266c7034f2f0d4e1d0716fb6eae20eae29e", "efa47267fea521a1a9dc343a3736c974c2fadafa81e36c54e7d2a4c66702414b" ], [ "e7a26ce69dd4829f3e10cec0a9e98ed3143d084f308b92c0997fddfc60cb3e41", "2a758e300fa7984b471b006a1aafbb18d0a6b2c0420e83e20e8a9421cf2cfd51" ], [ "b6459e0ee3662ec8d23540c223bcbdc571cbcb967d79424f3cf29eb3de6b80ef", "67c876d06f3e06de1dadf16e5661db3c4b3ae6d48e35b2ff30bf0b61a71ba45" ], [ "d68a80c8280bb840793234aa118f06231d6f1fc67e73c5a5deda0f5b496943e8", "db8ba9fff4b586d00c4b1f9177b0e28b5b0e7b8f7845295a294c84266b133120" ], [ "324aed7df65c804252dc0270907a30b09612aeb973449cea4095980fc28d3d5d", "648a365774b61f2ff130c0c35aec1f4f19213b0c7e332843967224af96ab7c84" ], [ "4df9c14919cde61f6d51dfdbe5fee5dceec4143ba8d1ca888e8bd373fd054c96", "35ec51092d8728050974c23a1d85d4b5d506cdc288490192ebac06cad10d5d" ], [ "9c3919a84a474870faed8a9c1cc66021523489054d7f0308cbfc99c8ac1f98cd", "ddb84f0f4a4ddd57584f044bf260e641905326f76c64c8e6be7e5e03d4fc599d" ], [ "6057170b1dd12fdf8de05f281d8e06bb91e1493a8b91d4cc5a21382120a959e5", "9a1af0b26a6a4807add9a2daf71df262465152bc3ee24c65e899be932385a2a8" ], [ "a576df8e23a08411421439a4518da31880cef0fba7d4df12b1a6973eecb94266", "40a6bf20e76640b2c92b97afe58cd82c432e10a7f514d9f3ee8be11ae1b28ec8" ], [ "7778a78c28dec3e30a05fe9629de8c38bb30d1f5cf9a3a208f763889be58ad71", "34626d9ab5a5b22ff7098e12f2ff580087b38411ff24ac563b513fc1fd9f43ac" ], [ "928955ee637a84463729fd30e7afd2ed5f96274e5ad7e5cb09eda9c06d903ac", "c25621003d3f42a827b78a13093a95eeac3d26efa8a8d83fc5180e935bcd091f" ], [ "85d0fef3ec6db109399064f3a0e3b2855645b4a907ad354527aae75163d82751", "1f03648413a38c0be29d496e582cf5663e8751e96877331582c237a24eb1f962" ], [ "ff2b0dce97eece97c1c9b6041798b85dfdfb6d8882da20308f5404824526087e", "493d13fef524ba188af4c4dc54d07936c7b7ed6fb90e2ceb2c951e01f0c29907" ], [ "827fbbe4b1e880ea9ed2b2e6301b212b57f1ee148cd6dd28780e5e2cf856e241", "c60f9c923c727b0b71bef2c67d1d12687ff7a63186903166d605b68baec293ec" ], [ "eaa649f21f51bdbae7be4ae34ce6e5217a58fdce7f47f9aa7f3b58fa2120e2b3", "be3279ed5bbbb03ac69a80f89879aa5a01a6b965f13f7e59d47a5305ba5ad93d" ], [ "e4a42d43c5cf169d9391df6decf42ee541b6d8f0c9a137401e23632dda34d24f", "4d9f92e716d1c73526fc99ccfb8ad34ce886eedfa8d8e4f13a7f7131deba9414" ], [ "1ec80fef360cbdd954160fadab352b6b92b53576a88fea4947173b9d4300bf19", "aeefe93756b5340d2f3a4958a7abbf5e0146e77f6295a07b671cdc1cc107cefd" ], [ "146a778c04670c2f91b00af4680dfa8bce3490717d58ba889ddb5928366642be", "b318e0ec3354028add669827f9d4b2870aaa971d2f7e5ed1d0b297483d83efd0" ], [ "fa50c0f61d22e5f07e3acebb1aa07b128d0012209a28b9776d76a8793180eef9", "6b84c6922397eba9b72cd2872281a68a5e683293a57a213b38cd8d7d3f4f2811" ], [ "da1d61d0ca721a11b1a5bf6b7d88e8421a288ab5d5bba5220e53d32b5f067ec2", "8157f55a7c99306c79c0766161c91e2966a73899d279b48a655fba0f1ad836f1" ], [ "a8e282ff0c9706907215ff98e8fd416615311de0446f1e062a73b0610d064e13", "7f97355b8db81c09abfb7f3c5b2515888b679a3e50dd6bd6cef7c73111f4cc0c" ], [ "174a53b9c9a285872d39e56e6913cab15d59b1fa512508c022f382de8319497c", "ccc9dc37abfc9c1657b4155f2c47f9e6646b3a1d8cb9854383da13ac079afa73" ], [ "959396981943785c3d3e57edf5018cdbe039e730e4918b3d884fdff09475b7ba", "2e7e552888c331dd8ba0386a4b9cd6849c653f64c8709385e9b8abf87524f2fd" ], [ "d2a63a50ae401e56d645a1153b109a8fcca0a43d561fba2dbb51340c9d82b151", "e82d86fb6443fcb7565aee58b2948220a70f750af484ca52d4142174dcf89405" ], [ "64587e2335471eb890ee7896d7cfdc866bacbdbd3839317b3436f9b45617e073", "d99fcdd5bf6902e2ae96dd6447c299a185b90a39133aeab358299e5e9faf6589" ], [ "8481bde0e4e4d885b3a546d3e549de042f0aa6cea250e7fd358d6c86dd45e458", "38ee7b8cba5404dd84a25bf39cecb2ca900a79c42b262e556d64b1b59779057e" ], [ "13464a57a78102aa62b6979ae817f4637ffcfed3c4b1ce30bcd6303f6caf666b", "69be159004614580ef7e433453ccb0ca48f300a81d0942e13f495a907f6ecc27" ], [ "bc4a9df5b713fe2e9aef430bcc1dc97a0cd9ccede2f28588cada3a0d2d83f366", "d3a81ca6e785c06383937adf4b798caa6e8a9fbfa547b16d758d666581f33c1" ], [ "8c28a97bf8298bc0d23d8c749452a32e694b65e30a9472a3954ab30fe5324caa", "40a30463a3305193378fedf31f7cc0eb7ae784f0451cb9459e71dc73cbef9482" ], [ "8ea9666139527a8c1dd94ce4f071fd23c8b350c5a4bb33748c4ba111faccae0", "620efabbc8ee2782e24e7c0cfb95c5d735b783be9cf0f8e955af34a30e62b945" ], [ "dd3625faef5ba06074669716bbd3788d89bdde815959968092f76cc4eb9a9787", "7a188fa3520e30d461da2501045731ca941461982883395937f68d00c644a573" ], [ "f710d79d9eb962297e4f6232b40e8f7feb2bc63814614d692c12de752408221e", "ea98e67232d3b3295d3b535532115ccac8612c721851617526ae47a9c77bfc82" ] ]
},
naf: {
wnd: 7,
points: [ [ "f9308a019258c31049344f85f89d5229b531c845836f99b08601f113bce036f9", "388f7b0f632de8140fe337e62a37f3566500a99934c2231b6cb9fd7584b8e672" ], [ "2f8bde4d1a07209355b4a7250a5c5128e88b84bddc619ab7cba8d569b240efe4", "d8ac222636e5e3d6d4dba9dda6c9c426f788271bab0d6840dca87d3aa6ac62d6" ], [ "5cbdf0646e5db4eaa398f365f2ea7a0e3d419b7e0330e39ce92bddedcac4f9bc", "6aebca40ba255960a3178d6d861a54dba813d0b813fde7b5a5082628087264da" ], [ "acd484e2f0c7f65309ad178a9f559abde09796974c57e714c35f110dfc27ccbe", "cc338921b0a7d9fd64380971763b61e9add888a4375f8e0f05cc262ac64f9c37" ], [ "774ae7f858a9411e5ef4246b70c65aac5649980be5c17891bbec17895da008cb", "d984a032eb6b5e190243dd56d7b7b365372db1e2dff9d6a8301d74c9c953c61b" ], [ "f28773c2d975288bc7d1d205c3748651b075fbc6610e58cddeeddf8f19405aa8", "ab0902e8d880a89758212eb65cdaf473a1a06da521fa91f29b5cb52db03ed81" ], [ "d7924d4f7d43ea965a465ae3095ff41131e5946f3c85f79e44adbcf8e27e080e", "581e2872a86c72a683842ec228cc6defea40af2bd896d3a5c504dc9ff6a26b58" ], [ "defdea4cdb677750a420fee807eacf21eb9898ae79b9768766e4faa04a2d4a34", "4211ab0694635168e997b0ead2a93daeced1f4a04a95c0f6cfb199f69e56eb77" ], [ "2b4ea0a797a443d293ef5cff444f4979f06acfebd7e86d277475656138385b6c", "85e89bc037945d93b343083b5a1c86131a01f60c50269763b570c854e5c09b7a" ], [ "352bbf4a4cdd12564f93fa332ce333301d9ad40271f8107181340aef25be59d5", "321eb4075348f534d59c18259dda3e1f4a1b3b2e71b1039c67bd3d8bcf81998c" ], [ "2fa2104d6b38d11b0230010559879124e42ab8dfeff5ff29dc9cdadd4ecacc3f", "2de1068295dd865b64569335bd5dd80181d70ecfc882648423ba76b532b7d67" ], [ "9248279b09b4d68dab21a9b066edda83263c3d84e09572e269ca0cd7f5453714", "73016f7bf234aade5d1aa71bdea2b1ff3fc0de2a887912ffe54a32ce97cb3402" ], [ "daed4f2be3a8bf278e70132fb0beb7522f570e144bf615c07e996d443dee8729", "a69dce4a7d6c98e8d4a1aca87ef8d7003f83c230f3afa726ab40e52290be1c55" ], [ "c44d12c7065d812e8acf28d7cbb19f9011ecd9e9fdf281b0e6a3b5e87d22e7db", "2119a460ce326cdc76c45926c982fdac0e106e861edf61c5a039063f0e0e6482" ], [ "6a245bf6dc698504c89a20cfded60853152b695336c28063b61c65cbd269e6b4", "e022cf42c2bd4a708b3f5126f16a24ad8b33ba48d0423b6efd5e6348100d8a82" ], [ "1697ffa6fd9de627c077e3d2fe541084ce13300b0bec1146f95ae57f0d0bd6a5", "b9c398f186806f5d27561506e4557433a2cf15009e498ae7adee9d63d01b2396" ], [ "605bdb019981718b986d0f07e834cb0d9deb8360ffb7f61df982345ef27a7479", "2972d2de4f8d20681a78d93ec96fe23c26bfae84fb14db43b01e1e9056b8c49" ], [ "62d14dab4150bf497402fdc45a215e10dcb01c354959b10cfe31c7e9d87ff33d", "80fc06bd8cc5b01098088a1950eed0db01aa132967ab472235f5642483b25eaf" ], [ "80c60ad0040f27dade5b4b06c408e56b2c50e9f56b9b8b425e555c2f86308b6f", "1c38303f1cc5c30f26e66bad7fe72f70a65eed4cbe7024eb1aa01f56430bd57a" ], [ "7a9375ad6167ad54aa74c6348cc54d344cc5dc9487d847049d5eabb0fa03c8fb", "d0e3fa9eca8726909559e0d79269046bdc59ea10c70ce2b02d499ec224dc7f7" ], [ "d528ecd9b696b54c907a9ed045447a79bb408ec39b68df504bb51f459bc3ffc9", "eecf41253136e5f99966f21881fd656ebc4345405c520dbc063465b521409933" ], [ "49370a4b5f43412ea25f514e8ecdad05266115e4a7ecb1387231808f8b45963", "758f3f41afd6ed428b3081b0512fd62a54c3f3afbb5b6764b653052a12949c9a" ], [ "77f230936ee88cbbd73df930d64702ef881d811e0e1498e2f1c13eb1fc345d74", "958ef42a7886b6400a08266e9ba1b37896c95330d97077cbbe8eb3c7671c60d6" ], [ "f2dac991cc4ce4b9ea44887e5c7c0bce58c80074ab9d4dbaeb28531b7739f530", "e0dedc9b3b2f8dad4da1f32dec2531df9eb5fbeb0598e4fd1a117dba703a3c37" ], [ "463b3d9f662621fb1b4be8fbbe2520125a216cdfc9dae3debcba4850c690d45b", "5ed430d78c296c3543114306dd8622d7c622e27c970a1de31cb377b01af7307e" ], [ "f16f804244e46e2a09232d4aff3b59976b98fac14328a2d1a32496b49998f247", "cedabd9b82203f7e13d206fcdf4e33d92a6c53c26e5cce26d6579962c4e31df6" ], [ "caf754272dc84563b0352b7a14311af55d245315ace27c65369e15f7151d41d1", "cb474660ef35f5f2a41b643fa5e460575f4fa9b7962232a5c32f908318a04476" ], [ "2600ca4b282cb986f85d0f1709979d8b44a09c07cb86d7c124497bc86f082120", "4119b88753c15bd6a693b03fcddbb45d5ac6be74ab5f0ef44b0be9475a7e4b40" ], [ "7635ca72d7e8432c338ec53cd12220bc01c48685e24f7dc8c602a7746998e435", "91b649609489d613d1d5e590f78e6d74ecfc061d57048bad9e76f302c5b9c61" ], [ "754e3239f325570cdbbf4a87deee8a66b7f2b33479d468fbc1a50743bf56cc18", "673fb86e5bda30fb3cd0ed304ea49a023ee33d0197a695d0c5d98093c536683" ], [ "e3e6bd1071a1e96aff57859c82d570f0330800661d1c952f9fe2694691d9b9e8", "59c9e0bba394e76f40c0aa58379a3cb6a5a2283993e90c4167002af4920e37f5" ], [ "186b483d056a033826ae73d88f732985c4ccb1f32ba35f4b4cc47fdcf04aa6eb", "3b952d32c67cf77e2e17446e204180ab21fb8090895138b4a4a797f86e80888b" ], [ "df9d70a6b9876ce544c98561f4be4f725442e6d2b737d9c91a8321724ce0963f", "55eb2dafd84d6ccd5f862b785dc39d4ab157222720ef9da217b8c45cf2ba2417" ], [ "5edd5cc23c51e87a497ca815d5dce0f8ab52554f849ed8995de64c5f34ce7143", "efae9c8dbc14130661e8cec030c89ad0c13c66c0d17a2905cdc706ab7399a868" ], [ "290798c2b6476830da12fe02287e9e777aa3fba1c355b17a722d362f84614fba", "e38da76dcd440621988d00bcf79af25d5b29c094db2a23146d003afd41943e7a" ], [ "af3c423a95d9f5b3054754efa150ac39cd29552fe360257362dfdecef4053b45", "f98a3fd831eb2b749a93b0e6f35cfb40c8cd5aa667a15581bc2feded498fd9c6" ], [ "766dbb24d134e745cccaa28c99bf274906bb66b26dcf98df8d2fed50d884249a", "744b1152eacbe5e38dcc887980da38b897584a65fa06cedd2c924f97cbac5996" ], [ "59dbf46f8c94759ba21277c33784f41645f7b44f6c596a58ce92e666191abe3e", "c534ad44175fbc300f4ea6ce648309a042ce739a7919798cd85e216c4a307f6e" ], [ "f13ada95103c4537305e691e74e9a4a8dd647e711a95e73cb62dc6018cfd87b8", "e13817b44ee14de663bf4bc808341f326949e21a6a75c2570778419bdaf5733d" ], [ "7754b4fa0e8aced06d4167a2c59cca4cda1869c06ebadfb6488550015a88522c", "30e93e864e669d82224b967c3020b8fa8d1e4e350b6cbcc537a48b57841163a2" ], [ "948dcadf5990e048aa3874d46abef9d701858f95de8041d2a6828c99e2262519", "e491a42537f6e597d5d28a3224b1bc25df9154efbd2ef1d2cbba2cae5347d57e" ], [ "7962414450c76c1689c7b48f8202ec37fb224cf5ac0bfa1570328a8a3d7c77ab", "100b610ec4ffb4760d5c1fc133ef6f6b12507a051f04ac5760afa5b29db83437" ], [ "3514087834964b54b15b160644d915485a16977225b8847bb0dd085137ec47ca", "ef0afbb2056205448e1652c48e8127fc6039e77c15c2378b7e7d15a0de293311" ], [ "d3cc30ad6b483e4bc79ce2c9dd8bc54993e947eb8df787b442943d3f7b527eaf", "8b378a22d827278d89c5e9be8f9508ae3c2ad46290358630afb34db04eede0a4" ], [ "1624d84780732860ce1c78fcbfefe08b2b29823db913f6493975ba0ff4847610", "68651cf9b6da903e0914448c6cd9d4ca896878f5282be4c8cc06e2a404078575" ], [ "733ce80da955a8a26902c95633e62a985192474b5af207da6df7b4fd5fc61cd4", "f5435a2bd2badf7d485a4d8b8db9fcce3e1ef8e0201e4578c54673bc1dc5ea1d" ], [ "15d9441254945064cf1a1c33bbd3b49f8966c5092171e699ef258dfab81c045c", "d56eb30b69463e7234f5137b73b84177434800bacebfc685fc37bbe9efe4070d" ], [ "a1d0fcf2ec9de675b612136e5ce70d271c21417c9d2b8aaaac138599d0717940", "edd77f50bcb5a3cab2e90737309667f2641462a54070f3d519212d39c197a629" ], [ "e22fbe15c0af8ccc5780c0735f84dbe9a790badee8245c06c7ca37331cb36980", "a855babad5cd60c88b430a69f53a1a7a38289154964799be43d06d77d31da06" ], [ "311091dd9860e8e20ee13473c1155f5f69635e394704eaa74009452246cfa9b3", "66db656f87d1f04fffd1f04788c06830871ec5a64feee685bd80f0b1286d8374" ], [ "34c1fd04d301be89b31c0442d3e6ac24883928b45a9340781867d4232ec2dbdf", "9414685e97b1b5954bd46f730174136d57f1ceeb487443dc5321857ba73abee" ], [ "f219ea5d6b54701c1c14de5b557eb42a8d13f3abbcd08affcc2a5e6b049b8d63", "4cb95957e83d40b0f73af4544cccf6b1f4b08d3c07b27fb8d8c2962a400766d1" ], [ "d7b8740f74a8fbaab1f683db8f45de26543a5490bca627087236912469a0b448", "fa77968128d9c92ee1010f337ad4717eff15db5ed3c049b3411e0315eaa4593b" ], [ "32d31c222f8f6f0ef86f7c98d3a3335ead5bcd32abdd94289fe4d3091aa824bf", "5f3032f5892156e39ccd3d7915b9e1da2e6dac9e6f26e961118d14b8462e1661" ], [ "7461f371914ab32671045a155d9831ea8793d77cd59592c4340f86cbc18347b5", "8ec0ba238b96bec0cbdddcae0aa442542eee1ff50c986ea6b39847b3cc092ff6" ], [ "ee079adb1df1860074356a25aa38206a6d716b2c3e67453d287698bad7b2b2d6", "8dc2412aafe3be5c4c5f37e0ecc5f9f6a446989af04c4e25ebaac479ec1c8c1e" ], [ "16ec93e447ec83f0467b18302ee620f7e65de331874c9dc72bfd8616ba9da6b5", "5e4631150e62fb40d0e8c2a7ca5804a39d58186a50e497139626778e25b0674d" ], [ "eaa5f980c245f6f038978290afa70b6bd8855897f98b6aa485b96065d537bd99", "f65f5d3e292c2e0819a528391c994624d784869d7e6ea67fb18041024edc07dc" ], [ "78c9407544ac132692ee1910a02439958ae04877151342ea96c4b6b35a49f51", "f3e0319169eb9b85d5404795539a5e68fa1fbd583c064d2462b675f194a3ddb4" ], [ "494f4be219a1a77016dcd838431aea0001cdc8ae7a6fc688726578d9702857a5", "42242a969283a5f339ba7f075e36ba2af925ce30d767ed6e55f4b031880d562c" ], [ "a598a8030da6d86c6bc7f2f5144ea549d28211ea58faa70ebf4c1e665c1fe9b5", "204b5d6f84822c307e4b4a7140737aec23fc63b65b35f86a10026dbd2d864e6b" ], [ "c41916365abb2b5d09192f5f2dbeafec208f020f12570a184dbadc3e58595997", "4f14351d0087efa49d245b328984989d5caf9450f34bfc0ed16e96b58fa9913" ], [ "841d6063a586fa475a724604da03bc5b92a2e0d2e0a36acfe4c73a5514742881", "73867f59c0659e81904f9a1c7543698e62562d6744c169ce7a36de01a8d6154" ], [ "5e95bb399a6971d376026947f89bde2f282b33810928be4ded112ac4d70e20d5", "39f23f366809085beebfc71181313775a99c9aed7d8ba38b161384c746012865" ], [ "36e4641a53948fd476c39f8a99fd974e5ec07564b5315d8bf99471bca0ef2f66", "d2424b1b1abe4eb8164227b085c9aa9456ea13493fd563e06fd51cf5694c78fc" ], [ "336581ea7bfbbb290c191a2f507a41cf5643842170e914faeab27c2c579f726", "ead12168595fe1be99252129b6e56b3391f7ab1410cd1e0ef3dcdcabd2fda224" ], [ "8ab89816dadfd6b6a1f2634fcf00ec8403781025ed6890c4849742706bd43ede", "6fdcef09f2f6d0a044e654aef624136f503d459c3e89845858a47a9129cdd24e" ], [ "1e33f1a746c9c5778133344d9299fcaa20b0938e8acff2544bb40284b8c5fb94", "60660257dd11b3aa9c8ed618d24edff2306d320f1d03010e33a7d2057f3b3b6" ], [ "85b7c1dcb3cec1b7ee7f30ded79dd20a0ed1f4cc18cbcfcfa410361fd8f08f31", "3d98a9cdd026dd43f39048f25a8847f4fcafad1895d7a633c6fed3c35e999511" ], [ "29df9fbd8d9e46509275f4b125d6d45d7fbe9a3b878a7af872a2800661ac5f51", "b4c4fe99c775a606e2d8862179139ffda61dc861c019e55cd2876eb2a27d84b" ], [ "a0b1cae06b0a847a3fea6e671aaf8adfdfe58ca2f768105c8082b2e449fce252", "ae434102edde0958ec4b19d917a6a28e6b72da1834aff0e650f049503a296cf2" ], [ "4e8ceafb9b3e9a136dc7ff67e840295b499dfb3b2133e4ba113f2e4c0e121e5", "cf2174118c8b6d7a4b48f6d534ce5c79422c086a63460502b827ce62a326683c" ], [ "d24a44e047e19b6f5afb81c7ca2f69080a5076689a010919f42725c2b789a33b", "6fb8d5591b466f8fc63db50f1c0f1c69013f996887b8244d2cdec417afea8fa3" ], [ "ea01606a7a6c9cdd249fdfcfacb99584001edd28abbab77b5104e98e8e3b35d4", "322af4908c7312b0cfbfe369f7a7b3cdb7d4494bc2823700cfd652188a3ea98d" ], [ "af8addbf2b661c8a6c6328655eb96651252007d8c5ea31be4ad196de8ce2131f", "6749e67c029b85f52a034eafd096836b2520818680e26ac8f3dfbcdb71749700" ], [ "e3ae1974566ca06cc516d47e0fb165a674a3dabcfca15e722f0e3450f45889", "2aeabe7e4531510116217f07bf4d07300de97e4874f81f533420a72eeb0bd6a4" ], [ "591ee355313d99721cf6993ffed1e3e301993ff3ed258802075ea8ced397e246", "b0ea558a113c30bea60fc4775460c7901ff0b053d25ca2bdeee98f1a4be5d196" ], [ "11396d55fda54c49f19aa97318d8da61fa8584e47b084945077cf03255b52984", "998c74a8cd45ac01289d5833a7beb4744ff536b01b257be4c5767bea93ea57a4" ], [ "3c5d2a1ba39c5a1790000738c9e0c40b8dcdfd5468754b6405540157e017aa7a", "b2284279995a34e2f9d4de7396fc18b80f9b8b9fdd270f6661f79ca4c81bd257" ], [ "cc8704b8a60a0defa3a99a7299f2e9c3fbc395afb04ac078425ef8a1793cc030", "bdd46039feed17881d1e0862db347f8cf395b74fc4bcdc4e940b74e3ac1f1b13" ], [ "c533e4f7ea8555aacd9777ac5cad29b97dd4defccc53ee7ea204119b2889b197", "6f0a256bc5efdf429a2fb6242f1a43a2d9b925bb4a4b3a26bb8e0f45eb596096" ], [ "c14f8f2ccb27d6f109f6d08d03cc96a69ba8c34eec07bbcf566d48e33da6593", "c359d6923bb398f7fd4473e16fe1c28475b740dd098075e6c0e8649113dc3a38" ], [ "a6cbc3046bc6a450bac24789fa17115a4c9739ed75f8f21ce441f72e0b90e6ef", "21ae7f4680e889bb130619e2c0f95a360ceb573c70603139862afd617fa9b9f" ], [ "347d6d9a02c48927ebfb86c1359b1caf130a3c0267d11ce6344b39f99d43cc38", "60ea7f61a353524d1c987f6ecec92f086d565ab687870cb12689ff1e31c74448" ], [ "da6545d2181db8d983f7dcb375ef5866d47c67b1bf31c8cf855ef7437b72656a", "49b96715ab6878a79e78f07ce5680c5d6673051b4935bd897fea824b77dc208a" ], [ "c40747cc9d012cb1a13b8148309c6de7ec25d6945d657146b9d5994b8feb1111", "5ca560753be2a12fc6de6caf2cb489565db936156b9514e1bb5e83037e0fa2d4" ], [ "4e42c8ec82c99798ccf3a610be870e78338c7f713348bd34c8203ef4037f3502", "7571d74ee5e0fb92a7a8b33a07783341a5492144cc54bcc40a94473693606437" ], [ "3775ab7089bc6af823aba2e1af70b236d251cadb0c86743287522a1b3b0dedea", "be52d107bcfa09d8bcb9736a828cfa7fac8db17bf7a76a2c42ad961409018cf7" ], [ "cee31cbf7e34ec379d94fb814d3d775ad954595d1314ba8846959e3e82f74e26", "8fd64a14c06b589c26b947ae2bcf6bfa0149ef0be14ed4d80f448a01c43b1c6d" ], [ "b4f9eaea09b6917619f6ea6a4eb5464efddb58fd45b1ebefcdc1a01d08b47986", "39e5c9925b5a54b07433a4f18c61726f8bb131c012ca542eb24a8ac07200682a" ], [ "d4263dfc3d2df923a0179a48966d30ce84e2515afc3dccc1b77907792ebcc60e", "62dfaf07a0f78feb30e30d6295853ce189e127760ad6cf7fae164e122a208d54" ], [ "48457524820fa65a4f8d35eb6930857c0032acc0a4a2de422233eeda897612c4", "25a748ab367979d98733c38a1fa1c2e7dc6cc07db2d60a9ae7a76aaa49bd0f77" ], [ "dfeeef1881101f2cb11644f3a2afdfc2045e19919152923f367a1767c11cceda", "ecfb7056cf1de042f9420bab396793c0c390bde74b4bbdff16a83ae09a9a7517" ], [ "6d7ef6b17543f8373c573f44e1f389835d89bcbc6062ced36c82df83b8fae859", "cd450ec335438986dfefa10c57fea9bcc521a0959b2d80bbf74b190dca712d10" ], [ "e75605d59102a5a2684500d3b991f2e3f3c88b93225547035af25af66e04541f", "f5c54754a8f71ee540b9b48728473e314f729ac5308b06938360990e2bfad125" ], [ "eb98660f4c4dfaa06a2be453d5020bc99a0c2e60abe388457dd43fefb1ed620c", "6cb9a8876d9cb8520609af3add26cd20a0a7cd8a9411131ce85f44100099223e" ], [ "13e87b027d8514d35939f2e6892b19922154596941888336dc3563e3b8dba942", "fef5a3c68059a6dec5d624114bf1e91aac2b9da568d6abeb2570d55646b8adf1" ], [ "ee163026e9fd6fe017c38f06a5be6fc125424b371ce2708e7bf4491691e5764a", "1acb250f255dd61c43d94ccc670d0f58f49ae3fa15b96623e5430da0ad6c62b2" ], [ "b268f5ef9ad51e4d78de3a750c2dc89b1e626d43505867999932e5db33af3d80", "5f310d4b3c99b9ebb19f77d41c1dee018cf0d34fd4191614003e945a1216e423" ], [ "ff07f3118a9df035e9fad85eb6c7bfe42b02f01ca99ceea3bf7ffdba93c4750d", "438136d603e858a3a5c440c38eccbaddc1d2942114e2eddd4740d098ced1f0d8" ], [ "8d8b9855c7c052a34146fd20ffb658bea4b9f69e0d825ebec16e8c3ce2b526a1", "cdb559eedc2d79f926baf44fb84ea4d44bcf50fee51d7ceb30e2e7f463036758" ], [ "52db0b5384dfbf05bfa9d472d7ae26dfe4b851ceca91b1eba54263180da32b63", "c3b997d050ee5d423ebaf66a6db9f57b3180c902875679de924b69d84a7b375" ], [ "e62f9490d3d51da6395efd24e80919cc7d0f29c3f3fa48c6fff543becbd43352", "6d89ad7ba4876b0b22c2ca280c682862f342c8591f1daf5170e07bfd9ccafa7d" ], [ "7f30ea2476b399b4957509c88f77d0191afa2ff5cb7b14fd6d8e7d65aaab1193", "ca5ef7d4b231c94c3b15389a5f6311e9daff7bb67b103e9880ef4bff637acaec" ], [ "5098ff1e1d9f14fb46a210fada6c903fef0fb7b4a1dd1d9ac60a0361800b7a00", "9731141d81fc8f8084d37c6e7542006b3ee1b40d60dfe5362a5b132fd17ddc0" ], [ "32b78c7de9ee512a72895be6b9cbefa6e2f3c4ccce445c96b9f2c81e2778ad58", "ee1849f513df71e32efc3896ee28260c73bb80547ae2275ba497237794c8753c" ], [ "e2cb74fddc8e9fbcd076eef2a7c72b0ce37d50f08269dfc074b581550547a4f7", "d3aa2ed71c9dd2247a62df062736eb0baddea9e36122d2be8641abcb005cc4a4" ], [ "8438447566d4d7bedadc299496ab357426009a35f235cb141be0d99cd10ae3a8", "c4e1020916980a4da5d01ac5e6ad330734ef0d7906631c4f2390426b2edd791f" ], [ "4162d488b89402039b584c6fc6c308870587d9c46f660b878ab65c82c711d67e", "67163e903236289f776f22c25fb8a3afc1732f2b84b4e95dbda47ae5a0852649" ], [ "3fad3fa84caf0f34f0f89bfd2dcf54fc175d767aec3e50684f3ba4a4bf5f683d", "cd1bc7cb6cc407bb2f0ca647c718a730cf71872e7d0d2a53fa20efcdfe61826" ], [ "674f2600a3007a00568c1a7ce05d0816c1fb84bf1370798f1c69532faeb1a86b", "299d21f9413f33b3edf43b257004580b70db57da0b182259e09eecc69e0d38a5" ], [ "d32f4da54ade74abb81b815ad1fb3b263d82d6c692714bcff87d29bd5ee9f08f", "f9429e738b8e53b968e99016c059707782e14f4535359d582fc416910b3eea87" ], [ "30e4e670435385556e593657135845d36fbb6931f72b08cb1ed954f1e3ce3ff6", "462f9bce619898638499350113bbc9b10a878d35da70740dc695a559eb88db7b" ], [ "be2062003c51cc3004682904330e4dee7f3dcd10b01e580bf1971b04d4cad297", "62188bc49d61e5428573d48a74e1c655b1c61090905682a0d5558ed72dccb9bc" ], [ "93144423ace3451ed29e0fb9ac2af211cb6e84a601df5993c419859fff5df04a", "7c10dfb164c3425f5c71a3f9d7992038f1065224f72bb9d1d902a6d13037b47c" ], [ "b015f8044f5fcbdcf21ca26d6c34fb8197829205c7b7d2a7cb66418c157b112c", "ab8c1e086d04e813744a655b2df8d5f83b3cdc6faa3088c1d3aea1454e3a1d5f" ], [ "d5e9e1da649d97d89e4868117a465a3a4f8a18de57a140d36b3f2af341a21b52", "4cb04437f391ed73111a13cc1d4dd0db1693465c2240480d8955e8592f27447a" ], [ "d3ae41047dd7ca065dbf8ed77b992439983005cd72e16d6f996a5316d36966bb", "bd1aeb21ad22ebb22a10f0303417c6d964f8cdd7df0aca614b10dc14d125ac46" ], [ "463e2763d885f958fc66cdd22800f0a487197d0a82e377b49f80af87c897b065", "bfefacdb0e5d0fd7df3a311a94de062b26b80c61fbc97508b79992671ef7ca7f" ], [ "7985fdfd127c0567c6f53ec1bb63ec3158e597c40bfe747c83cddfc910641917", "603c12daf3d9862ef2b25fe1de289aed24ed291e0ec6708703a5bd567f32ed03" ], [ "74a1ad6b5f76e39db2dd249410eac7f99e74c59cb83d2d0ed5ff1543da7703e9", "cc6157ef18c9c63cd6193d83631bbea0093e0968942e8c33d5737fd790e0db08" ], [ "30682a50703375f602d416664ba19b7fc9bab42c72747463a71d0896b22f6da3", "553e04f6b018b4fa6c8f39e7f311d3176290d0e0f19ca73f17714d9977a22ff8" ], [ "9e2158f0d7c0d5f26c3791efefa79597654e7a2b2464f52b1ee6c1347769ef57", "712fcdd1b9053f09003a3481fa7762e9ffd7c8ef35a38509e2fbf2629008373" ], [ "176e26989a43c9cfeba4029c202538c28172e566e3c4fce7322857f3be327d66", "ed8cc9d04b29eb877d270b4878dc43c19aefd31f4eee09ee7b47834c1fa4b1c3" ], [ "75d46efea3771e6e68abb89a13ad747ecf1892393dfc4f1b7004788c50374da8", "9852390a99507679fd0b86fd2b39a868d7efc22151346e1a3ca4726586a6bed8" ], [ "809a20c67d64900ffb698c4c825f6d5f2310fb0451c869345b7319f645605721", "9e994980d9917e22b76b061927fa04143d096ccc54963e6a5ebfa5f3f8e286c1" ], [ "1b38903a43f7f114ed4500b4eac7083fdefece1cf29c63528d563446f972c180", "4036edc931a60ae889353f77fd53de4a2708b26b6f5da72ad3394119daf408f9" ] ]
}
};
}, {} ],
101: [ function(e, t, r) {
"use strict";
var n = r, i = e("bn.js"), o = e("minimalistic-assert"), s = e("minimalistic-crypto-utils");
n.assert = o;
n.toArray = s.toArray;
n.zero2 = s.zero2;
n.toHex = s.toHex;
n.encode = s.encode;
n.getNAF = function(e, t, r) {
var n = new Array(Math.max(e.bitLength(), r) + 1);
n.fill(0);
for (var i = 1 << t + 1, o = e.clone(), s = 0; s < n.length; s++) {
var a, f = o.andln(i - 1);
if (o.isOdd()) {
a = f > (i >> 1) - 1 ? (i >> 1) - f : f;
o.isubn(a);
} else a = 0;
n[s] = a;
o.iushrn(1);
}
return n;
};
n.getJSF = function(e, t) {
var r = [ [], [] ];
e = e.clone();
t = t.clone();
for (var n, i = 0, o = 0; e.cmpn(-i) > 0 || t.cmpn(-o) > 0; ) {
var s, a, f = e.andln(3) + i & 3, c = t.andln(3) + o & 3;
3 === f && (f = -1);
3 === c && (c = -1);
s = 0 == (1 & f) ? 0 : 3 != (n = e.andln(7) + i & 7) && 5 !== n || 2 !== c ? f : -f;
r[0].push(s);
a = 0 == (1 & c) ? 0 : 3 != (n = t.andln(7) + o & 7) && 5 !== n || 2 !== f ? c : -c;
r[1].push(a);
2 * i === s + 1 && (i = 1 - i);
2 * o === a + 1 && (o = 1 - o);
e.iushrn(1);
t.iushrn(1);
}
return r;
};
n.cachedProperty = function(e, t, r) {
var n = "_" + t;
e.prototype[t] = function() {
return void 0 !== this[n] ? this[n] : this[n] = r.call(this);
};
};
n.parseBytes = function(e) {
return "string" == typeof e ? n.toArray(e, "hex") : e;
};
n.intFromLE = function(e) {
return new i(e, "hex", "le");
};
}, {
"bn.js": 102,
"minimalistic-assert": 143,
"minimalistic-crypto-utils": 144
} ],
102: [ function(e, t, r) {
arguments[4][15][0].apply(r, arguments);
}, {
buffer: 19,
dup: 15
} ],
103: [ function(e, t) {
t.exports = {
_from: "elliptic@^6.5.3",
_id: "elliptic@6.5.4",
_inBundle: !1,
_integrity: "sha512-iLhC6ULemrljPZb+QutR5TQGB+pdW6KGD5RSegS+8sorOZT+rdQFbsQFJgvN3eRqNALqJer4oQ16YvJHlU8hzQ==",
_location: "/elliptic",
_phantomChildren: {},
_requested: {
type: "range",
registry: !0,
raw: "elliptic@^6.5.3",
name: "elliptic",
escapedName: "elliptic",
rawSpec: "^6.5.3",
saveSpec: null,
fetchSpec: "^6.5.3"
},
_requiredBy: [ "/browserify-sign", "/create-ecdh" ],
_resolved: "https://registry.npmjs.org/elliptic/-/elliptic-6.5.4.tgz",
_shasum: "da37cebd31e79a1367e941b592ed1fbebd58abbb",
_spec: "elliptic@^6.5.3",
_where: "C:\\Users\\nantas\\fireball-x\\fireball_2.4.5\\dist\\resources\\app\\node_modules\\browserify-sign",
author: {
name: "Fedor Indutny",
email: "fedor@indutny.com"
},
bugs: {
url: "https://github.com/indutny/elliptic/issues"
},
bundleDependencies: !1,
dependencies: {
"bn.js": "^4.11.9",
brorand: "^1.1.0",
"hash.js": "^1.0.0",
"hmac-drbg": "^1.0.1",
inherits: "^2.0.4",
"minimalistic-assert": "^1.0.1",
"minimalistic-crypto-utils": "^1.0.1"
},
deprecated: !1,
description: "EC cryptography",
devDependencies: {
brfs: "^2.0.2",
coveralls: "^3.1.0",
eslint: "^7.6.0",
grunt: "^1.2.1",
"grunt-browserify": "^5.3.0",
"grunt-cli": "^1.3.2",
"grunt-contrib-connect": "^3.0.0",
"grunt-contrib-copy": "^1.0.0",
"grunt-contrib-uglify": "^5.0.0",
"grunt-mocha-istanbul": "^5.0.2",
"grunt-saucelabs": "^9.0.1",
istanbul: "^0.4.5",
mocha: "^8.0.1"
},
files: [ "lib" ],
homepage: "https://github.com/indutny/elliptic",
keywords: [ "EC", "Elliptic", "curve", "Cryptography" ],
license: "MIT",
main: "lib/elliptic.js",
name: "elliptic",
repository: {
type: "git",
url: "git+ssh://git@github.com/indutny/elliptic.git"
},
scripts: {
lint: "eslint lib test",
"lint:fix": "npm run lint -- --fix",
test: "npm run lint && npm run unit",
unit: "istanbul test _mocha --reporter=spec test/index.js",
version: "grunt dist && git add dist/"
},
version: "6.5.4"
};
}, {} ],
104: [ function(e, t) {
function r() {
this._events = this._events || {};
this._maxListeners = this._maxListeners || void 0;
}
t.exports = r;
r.EventEmitter = r;
r.prototype._events = void 0;
r.prototype._maxListeners = void 0;
r.defaultMaxListeners = 10;
r.prototype.setMaxListeners = function(e) {
if (!(t = e, "number" == typeof t) || e < 0 || isNaN(e)) throw TypeError("n must be a positive number");
var t;
this._maxListeners = e;
return this;
};
r.prototype.emit = function(e) {
var t, r, s, a, f, c;
this._events || (this._events = {});
if ("error" === e && (!this._events.error || i(this._events.error) && !this._events.error.length)) {
if ((t = arguments[1]) instanceof Error) throw t;
var u = new Error('Uncaught, unspecified "error" event. (' + t + ")");
u.context = t;
throw u;
}
if (o(r = this._events[e])) return !1;
if (n(r)) switch (arguments.length) {
case 1:
r.call(this);
break;

case 2:
r.call(this, arguments[1]);
break;

case 3:
r.call(this, arguments[1], arguments[2]);
break;

default:
a = Array.prototype.slice.call(arguments, 1);
r.apply(this, a);
} else if (i(r)) {
a = Array.prototype.slice.call(arguments, 1);
s = (c = r.slice()).length;
for (f = 0; f < s; f++) c[f].apply(this, a);
}
return !0;
};
r.prototype.addListener = function(e, t) {
var s;
if (!n(t)) throw TypeError("listener must be a function");
this._events || (this._events = {});
this._events.newListener && this.emit("newListener", e, n(t.listener) ? t.listener : t);
this._events[e] ? i(this._events[e]) ? this._events[e].push(t) : this._events[e] = [ this._events[e], t ] : this._events[e] = t;
if (i(this._events[e]) && !this._events[e].warned && (s = o(this._maxListeners) ? r.defaultMaxListeners : this._maxListeners) && s > 0 && this._events[e].length > s) {
this._events[e].warned = !0;
console.error("(node) warning: possible EventEmitter memory leak detected. %d listeners added. Use emitter.setMaxListeners() to increase limit.", this._events[e].length);
"function" == typeof console.trace && console.trace();
}
return this;
};
r.prototype.on = r.prototype.addListener;
r.prototype.once = function(e, t) {
if (!n(t)) throw TypeError("listener must be a function");
var r = !1;
function i() {
this.removeListener(e, i);
if (!r) {
r = !0;
t.apply(this, arguments);
}
}
i.listener = t;
this.on(e, i);
return this;
};
r.prototype.removeListener = function(e, t) {
var r, o, s, a;
if (!n(t)) throw TypeError("listener must be a function");
if (!this._events || !this._events[e]) return this;
s = (r = this._events[e]).length;
o = -1;
if (r === t || n(r.listener) && r.listener === t) {
delete this._events[e];
this._events.removeListener && this.emit("removeListener", e, t);
} else if (i(r)) {
for (a = s; a-- > 0; ) if (r[a] === t || r[a].listener && r[a].listener === t) {
o = a;
break;
}
if (o < 0) return this;
if (1 === r.length) {
r.length = 0;
delete this._events[e];
} else r.splice(o, 1);
this._events.removeListener && this.emit("removeListener", e, t);
}
return this;
};
r.prototype.removeAllListeners = function(e) {
var t, r;
if (!this._events) return this;
if (!this._events.removeListener) {
0 === arguments.length ? this._events = {} : this._events[e] && delete this._events[e];
return this;
}
if (0 === arguments.length) {
for (t in this._events) "removeListener" !== t && this.removeAllListeners(t);
this.removeAllListeners("removeListener");
this._events = {};
return this;
}
if (n(r = this._events[e])) this.removeListener(e, r); else if (r) for (;r.length; ) this.removeListener(e, r[r.length - 1]);
delete this._events[e];
return this;
};
r.prototype.listeners = function(e) {
return this._events && this._events[e] ? n(this._events[e]) ? [ this._events[e] ] : this._events[e].slice() : [];
};
r.prototype.listenerCount = function(e) {
if (this._events) {
var t = this._events[e];
if (n(t)) return 1;
if (t) return t.length;
}
return 0;
};
r.listenerCount = function(e, t) {
return e.listenerCount(t);
};
function n(e) {
return "function" == typeof e;
}
function i(e) {
return "object" == typeof e && null !== e;
}
function o(e) {
return void 0 === e;
}
}, {} ],
105: [ function(e, t) {
var r = e("safe-buffer").Buffer, n = e("md5.js");
t.exports = function(e, t, i, o) {
r.isBuffer(e) || (e = r.from(e, "binary"));
if (t) {
r.isBuffer(t) || (t = r.from(t, "binary"));
if (8 !== t.length) throw new RangeError("salt should be Buffer with 8 byte length");
}
for (var s = i / 8, a = r.alloc(s), f = r.alloc(o || 0), c = r.alloc(0); s > 0 || o > 0; ) {
var u = new n();
u.update(c);
u.update(e);
t && u.update(t);
c = u.digest();
var h = 0;
if (s > 0) {
var d = a.length - s;
h = Math.min(s, c.length);
c.copy(a, d, 0, h);
s -= h;
}
if (h < c.length && o > 0) {
var l = f.length - o, p = Math.min(o, c.length - h);
c.copy(f, l, h, h + p);
o -= p;
}
}
c.fill(0);
return {
key: a,
iv: f
};
};
}, {
"md5.js": 140,
"safe-buffer": 183
} ],
106: [ function(e, t) {
"use strict";
var r = e("safe-buffer").Buffer, n = e("readable-stream").Transform;
function i(e, t) {
if (!r.isBuffer(e) && "string" != typeof e) throw new TypeError(t + " must be a string or a buffer");
}
function o(e) {
n.call(this);
this._block = r.allocUnsafe(e);
this._blockSize = e;
this._blockOffset = 0;
this._length = [ 0, 0, 0, 0 ];
this._finalized = !1;
}
e("inherits")(o, n);
o.prototype._transform = function(e, t, r) {
var n = null;
try {
this.update(e, t);
} catch (e) {
n = e;
}
r(n);
};
o.prototype._flush = function(e) {
var t = null;
try {
this.push(this.digest());
} catch (e) {
t = e;
}
e(t);
};
o.prototype.update = function(e, t) {
i(e, "Data");
if (this._finalized) throw new Error("Digest already called");
r.isBuffer(e) || (e = r.from(e, t));
for (var n = this._block, o = 0; this._blockOffset + e.length - o >= this._blockSize; ) {
for (var s = this._blockOffset; s < this._blockSize; ) n[s++] = e[o++];
this._update();
this._blockOffset = 0;
}
for (;o < e.length; ) n[this._blockOffset++] = e[o++];
for (var a = 0, f = 8 * e.length; f > 0; ++a) {
this._length[a] += f;
(f = this._length[a] / 4294967296 | 0) > 0 && (this._length[a] -= 4294967296 * f);
}
return this;
};
o.prototype._update = function() {
throw new Error("_update is not implemented");
};
o.prototype.digest = function(e) {
if (this._finalized) throw new Error("Digest already called");
this._finalized = !0;
var t = this._digest();
void 0 !== e && (t = t.toString(e));
this._block.fill(0);
this._blockOffset = 0;
for (var r = 0; r < 4; ++r) this._length[r] = 0;
return t;
};
o.prototype._digest = function() {
throw new Error("_digest is not implemented");
};
t.exports = o;
}, {
inherits: 138,
"readable-stream": 121,
"safe-buffer": 122
} ],
107: [ function(e, t, r) {
arguments[4][47][0].apply(r, arguments);
}, {
dup: 47
} ],
108: [ function(e, t, r) {
arguments[4][48][0].apply(r, arguments);
}, {
"./_stream_readable": 110,
"./_stream_writable": 112,
_process: 157,
dup: 48,
inherits: 138
} ],
109: [ function(e, t, r) {
arguments[4][49][0].apply(r, arguments);
}, {
"./_stream_transform": 111,
dup: 49,
inherits: 138
} ],
110: [ function(e, t, r) {
arguments[4][50][0].apply(r, arguments);
}, {
"../errors": 107,
"./_stream_duplex": 108,
"./internal/streams/async_iterator": 113,
"./internal/streams/buffer_list": 114,
"./internal/streams/destroy": 115,
"./internal/streams/from": 117,
"./internal/streams/state": 119,
"./internal/streams/stream": 120,
_process: 157,
buffer: 65,
dup: 50,
events: 104,
inherits: 138,
"string_decoder/": 123,
util: 19
} ],
111: [ function(e, t, r) {
arguments[4][51][0].apply(r, arguments);
}, {
"../errors": 107,
"./_stream_duplex": 108,
dup: 51,
inherits: 138
} ],
112: [ function(e, t, r) {
arguments[4][52][0].apply(r, arguments);
}, {
"../errors": 107,
"./_stream_duplex": 108,
"./internal/streams/destroy": 115,
"./internal/streams/state": 119,
"./internal/streams/stream": 120,
_process: 157,
buffer: 65,
dup: 52,
inherits: 138,
"util-deprecate": 195
} ],
113: [ function(e, t, r) {
arguments[4][53][0].apply(r, arguments);
}, {
"./end-of-stream": 116,
_process: 157,
dup: 53
} ],
114: [ function(e, t, r) {
arguments[4][54][0].apply(r, arguments);
}, {
buffer: 65,
dup: 54,
util: 19
} ],
115: [ function(e, t, r) {
arguments[4][55][0].apply(r, arguments);
}, {
_process: 157,
dup: 55
} ],
116: [ function(e, t, r) {
arguments[4][56][0].apply(r, arguments);
}, {
"../../../errors": 107,
dup: 56
} ],
117: [ function(e, t, r) {
arguments[4][57][0].apply(r, arguments);
}, {
dup: 57
} ],
118: [ function(e, t, r) {
arguments[4][58][0].apply(r, arguments);
}, {
"../../../errors": 107,
"./end-of-stream": 116,
dup: 58
} ],
119: [ function(e, t, r) {
arguments[4][59][0].apply(r, arguments);
}, {
"../../../errors": 107,
dup: 59
} ],
120: [ function(e, t, r) {
arguments[4][60][0].apply(r, arguments);
}, {
dup: 60,
events: 104
} ],
121: [ function(e, t, r) {
arguments[4][61][0].apply(r, arguments);
}, {
"./lib/_stream_duplex.js": 108,
"./lib/_stream_passthrough.js": 109,
"./lib/_stream_readable.js": 110,
"./lib/_stream_transform.js": 111,
"./lib/_stream_writable.js": 112,
"./lib/internal/streams/end-of-stream.js": 116,
"./lib/internal/streams/pipeline.js": 118,
dup: 61
} ],
122: [ function(e, t, r) {
arguments[4][62][0].apply(r, arguments);
}, {
buffer: 65,
dup: 62
} ],
123: [ function(e, t, r) {
arguments[4][63][0].apply(r, arguments);
}, {
dup: 63,
"safe-buffer": 122
} ],
124: [ function(e, t, r) {
var n = r;
n.utils = e("./hash/utils");
n.common = e("./hash/common");
n.sha = e("./hash/sha");
n.ripemd = e("./hash/ripemd");
n.hmac = e("./hash/hmac");
n.sha1 = n.sha.sha1;
n.sha256 = n.sha.sha256;
n.sha224 = n.sha.sha224;
n.sha384 = n.sha.sha384;
n.sha512 = n.sha.sha512;
n.ripemd160 = n.ripemd.ripemd160;
}, {
"./hash/common": 125,
"./hash/hmac": 126,
"./hash/ripemd": 127,
"./hash/sha": 128,
"./hash/utils": 135
} ],
125: [ function(e, t, r) {
"use strict";
var n = e("./utils"), i = e("minimalistic-assert");
function o() {
this.pending = null;
this.pendingTotal = 0;
this.blockSize = this.constructor.blockSize;
this.outSize = this.constructor.outSize;
this.hmacStrength = this.constructor.hmacStrength;
this.padLength = this.constructor.padLength / 8;
this.endian = "big";
this._delta8 = this.blockSize / 8;
this._delta32 = this.blockSize / 32;
}
r.BlockHash = o;
o.prototype.update = function(e, t) {
e = n.toArray(e, t);
this.pending ? this.pending = this.pending.concat(e) : this.pending = e;
this.pendingTotal += e.length;
if (this.pending.length >= this._delta8) {
var r = (e = this.pending).length % this._delta8;
this.pending = e.slice(e.length - r, e.length);
0 === this.pending.length && (this.pending = null);
e = n.join32(e, 0, e.length - r, this.endian);
for (var i = 0; i < e.length; i += this._delta32) this._update(e, i, i + this._delta32);
}
return this;
};
o.prototype.digest = function(e) {
this.update(this._pad());
i(null === this.pending);
return this._digest(e);
};
o.prototype._pad = function() {
var e = this.pendingTotal, t = this._delta8, r = t - (e + this.padLength) % t, n = new Array(r + this.padLength);
n[0] = 128;
for (var i = 1; i < r; i++) n[i] = 0;
e <<= 3;
if ("big" === this.endian) {
for (var o = 8; o < this.padLength; o++) n[i++] = 0;
n[i++] = 0;
n[i++] = 0;
n[i++] = 0;
n[i++] = 0;
n[i++] = e >>> 24 & 255;
n[i++] = e >>> 16 & 255;
n[i++] = e >>> 8 & 255;
n[i++] = 255 & e;
} else {
n[i++] = 255 & e;
n[i++] = e >>> 8 & 255;
n[i++] = e >>> 16 & 255;
n[i++] = e >>> 24 & 255;
n[i++] = 0;
n[i++] = 0;
n[i++] = 0;
n[i++] = 0;
for (o = 8; o < this.padLength; o++) n[i++] = 0;
}
return n;
};
}, {
"./utils": 135,
"minimalistic-assert": 143
} ],
126: [ function(e, t) {
"use strict";
var r = e("./utils"), n = e("minimalistic-assert");
function i(e, t, n) {
if (!(this instanceof i)) return new i(e, t, n);
this.Hash = e;
this.blockSize = e.blockSize / 8;
this.outSize = e.outSize / 8;
this.inner = null;
this.outer = null;
this._init(r.toArray(t, n));
}
t.exports = i;
i.prototype._init = function(e) {
e.length > this.blockSize && (e = new this.Hash().update(e).digest());
n(e.length <= this.blockSize);
for (var t = e.length; t < this.blockSize; t++) e.push(0);
for (t = 0; t < e.length; t++) e[t] ^= 54;
this.inner = new this.Hash().update(e);
for (t = 0; t < e.length; t++) e[t] ^= 106;
this.outer = new this.Hash().update(e);
};
i.prototype.update = function(e, t) {
this.inner.update(e, t);
return this;
};
i.prototype.digest = function(e) {
this.outer.update(this.inner.digest());
return this.outer.digest(e);
};
}, {
"./utils": 135,
"minimalistic-assert": 143
} ],
127: [ function(e, t, r) {
"use strict";
var n = e("./utils"), i = e("./common"), o = n.rotl32, s = n.sum32, a = n.sum32_3, f = n.sum32_4, c = i.BlockHash;
function u() {
if (!(this instanceof u)) return new u();
c.call(this);
this.h = [ 1732584193, 4023233417, 2562383102, 271733878, 3285377520 ];
this.endian = "little";
}
n.inherits(u, c);
r.ripemd160 = u;
u.blockSize = 512;
u.outSize = 160;
u.hmacStrength = 192;
u.padLength = 64;
u.prototype._update = function(e, t) {
for (var r = this.h[0], n = this.h[1], i = this.h[2], c = this.h[3], u = this.h[4], y = r, g = n, _ = i, w = c, E = u, S = 0; S < 80; S++) {
var M = s(o(f(r, h(S, n, i, c), e[p[S] + t], d(S)), m[S]), u);
r = u;
u = c;
c = o(i, 10);
i = n;
n = M;
M = s(o(f(y, h(79 - S, g, _, w), e[b[S] + t], l(S)), v[S]), E);
y = E;
E = w;
w = o(_, 10);
_ = g;
g = M;
}
M = a(this.h[1], i, w);
this.h[1] = a(this.h[2], c, E);
this.h[2] = a(this.h[3], u, y);
this.h[3] = a(this.h[4], r, g);
this.h[4] = a(this.h[0], n, _);
this.h[0] = M;
};
u.prototype._digest = function(e) {
return "hex" === e ? n.toHex32(this.h, "little") : n.split32(this.h, "little");
};
function h(e, t, r, n) {
return e <= 15 ? t ^ r ^ n : e <= 31 ? t & r | ~t & n : e <= 47 ? (t | ~r) ^ n : e <= 63 ? t & n | r & ~n : t ^ (r | ~n);
}
function d(e) {
return e <= 15 ? 0 : e <= 31 ? 1518500249 : e <= 47 ? 1859775393 : e <= 63 ? 2400959708 : 2840853838;
}
function l(e) {
return e <= 15 ? 1352829926 : e <= 31 ? 1548603684 : e <= 47 ? 1836072691 : e <= 63 ? 2053994217 : 0;
}
var p = [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8, 3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12, 1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2, 4, 0, 5, 9, 7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13 ], b = [ 5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12, 6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2, 15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13, 8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14, 12, 15, 10, 4, 1, 5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11 ], m = [ 11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8, 7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12, 11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5, 11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12, 9, 15, 5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6 ], v = [ 8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6, 9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11, 9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5, 15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8, 8, 5, 12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11 ];
}, {
"./common": 125,
"./utils": 135
} ],
128: [ function(e, t, r) {
"use strict";
r.sha1 = e("./sha/1");
r.sha224 = e("./sha/224");
r.sha256 = e("./sha/256");
r.sha384 = e("./sha/384");
r.sha512 = e("./sha/512");
}, {
"./sha/1": 129,
"./sha/224": 130,
"./sha/256": 131,
"./sha/384": 132,
"./sha/512": 133
} ],
129: [ function(e, t) {
"use strict";
var r = e("../utils"), n = e("../common"), i = e("./common"), o = r.rotl32, s = r.sum32, a = r.sum32_5, f = i.ft_1, c = n.BlockHash, u = [ 1518500249, 1859775393, 2400959708, 3395469782 ];
function h() {
if (!(this instanceof h)) return new h();
c.call(this);
this.h = [ 1732584193, 4023233417, 2562383102, 271733878, 3285377520 ];
this.W = new Array(80);
}
r.inherits(h, c);
t.exports = h;
h.blockSize = 512;
h.outSize = 160;
h.hmacStrength = 80;
h.padLength = 64;
h.prototype._update = function(e, t) {
for (var r = this.W, n = 0; n < 16; n++) r[n] = e[t + n];
for (;n < r.length; n++) r[n] = o(r[n - 3] ^ r[n - 8] ^ r[n - 14] ^ r[n - 16], 1);
var i = this.h[0], c = this.h[1], h = this.h[2], d = this.h[3], l = this.h[4];
for (n = 0; n < r.length; n++) {
var p = ~~(n / 20), b = a(o(i, 5), f(p, c, h, d), l, r[n], u[p]);
l = d;
d = h;
h = o(c, 30);
c = i;
i = b;
}
this.h[0] = s(this.h[0], i);
this.h[1] = s(this.h[1], c);
this.h[2] = s(this.h[2], h);
this.h[3] = s(this.h[3], d);
this.h[4] = s(this.h[4], l);
};
h.prototype._digest = function(e) {
return "hex" === e ? r.toHex32(this.h, "big") : r.split32(this.h, "big");
};
}, {
"../common": 125,
"../utils": 135,
"./common": 134
} ],
130: [ function(e, t) {
"use strict";
var r = e("../utils"), n = e("./256");
function i() {
if (!(this instanceof i)) return new i();
n.call(this);
this.h = [ 3238371032, 914150663, 812702999, 4144912697, 4290775857, 1750603025, 1694076839, 3204075428 ];
}
r.inherits(i, n);
t.exports = i;
i.blockSize = 512;
i.outSize = 224;
i.hmacStrength = 192;
i.padLength = 64;
i.prototype._digest = function(e) {
return "hex" === e ? r.toHex32(this.h.slice(0, 7), "big") : r.split32(this.h.slice(0, 7), "big");
};
}, {
"../utils": 135,
"./256": 131
} ],
131: [ function(e, t) {
"use strict";
var r = e("../utils"), n = e("../common"), i = e("./common"), o = e("minimalistic-assert"), s = r.sum32, a = r.sum32_4, f = r.sum32_5, c = i.ch32, u = i.maj32, h = i.s0_256, d = i.s1_256, l = i.g0_256, p = i.g1_256, b = n.BlockHash, m = [ 1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298 ];
function v() {
if (!(this instanceof v)) return new v();
b.call(this);
this.h = [ 1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225 ];
this.k = m;
this.W = new Array(64);
}
r.inherits(v, b);
t.exports = v;
v.blockSize = 512;
v.outSize = 256;
v.hmacStrength = 192;
v.padLength = 64;
v.prototype._update = function(e, t) {
for (var r = this.W, n = 0; n < 16; n++) r[n] = e[t + n];
for (;n < r.length; n++) r[n] = a(p(r[n - 2]), r[n - 7], l(r[n - 15]), r[n - 16]);
var i = this.h[0], b = this.h[1], m = this.h[2], v = this.h[3], y = this.h[4], g = this.h[5], _ = this.h[6], w = this.h[7];
o(this.k.length === r.length);
for (n = 0; n < r.length; n++) {
var E = f(w, d(y), c(y, g, _), this.k[n], r[n]), S = s(h(i), u(i, b, m));
w = _;
_ = g;
g = y;
y = s(v, E);
v = m;
m = b;
b = i;
i = s(E, S);
}
this.h[0] = s(this.h[0], i);
this.h[1] = s(this.h[1], b);
this.h[2] = s(this.h[2], m);
this.h[3] = s(this.h[3], v);
this.h[4] = s(this.h[4], y);
this.h[5] = s(this.h[5], g);
this.h[6] = s(this.h[6], _);
this.h[7] = s(this.h[7], w);
};
v.prototype._digest = function(e) {
return "hex" === e ? r.toHex32(this.h, "big") : r.split32(this.h, "big");
};
}, {
"../common": 125,
"../utils": 135,
"./common": 134,
"minimalistic-assert": 143
} ],
132: [ function(e, t) {
"use strict";
var r = e("../utils"), n = e("./512");
function i() {
if (!(this instanceof i)) return new i();
n.call(this);
this.h = [ 3418070365, 3238371032, 1654270250, 914150663, 2438529370, 812702999, 355462360, 4144912697, 1731405415, 4290775857, 2394180231, 1750603025, 3675008525, 1694076839, 1203062813, 3204075428 ];
}
r.inherits(i, n);
t.exports = i;
i.blockSize = 1024;
i.outSize = 384;
i.hmacStrength = 192;
i.padLength = 128;
i.prototype._digest = function(e) {
return "hex" === e ? r.toHex32(this.h.slice(0, 12), "big") : r.split32(this.h.slice(0, 12), "big");
};
}, {
"../utils": 135,
"./512": 133
} ],
133: [ function(e, t) {
"use strict";
var r = e("../utils"), n = e("../common"), i = e("minimalistic-assert"), o = r.rotr64_hi, s = r.rotr64_lo, a = r.shr64_hi, f = r.shr64_lo, c = r.sum64, u = r.sum64_hi, h = r.sum64_lo, d = r.sum64_4_hi, l = r.sum64_4_lo, p = r.sum64_5_hi, b = r.sum64_5_lo, m = n.BlockHash, v = [ 1116352408, 3609767458, 1899447441, 602891725, 3049323471, 3964484399, 3921009573, 2173295548, 961987163, 4081628472, 1508970993, 3053834265, 2453635748, 2937671579, 2870763221, 3664609560, 3624381080, 2734883394, 310598401, 1164996542, 607225278, 1323610764, 1426881987, 3590304994, 1925078388, 4068182383, 2162078206, 991336113, 2614888103, 633803317, 3248222580, 3479774868, 3835390401, 2666613458, 4022224774, 944711139, 264347078, 2341262773, 604807628, 2007800933, 770255983, 1495990901, 1249150122, 1856431235, 1555081692, 3175218132, 1996064986, 2198950837, 2554220882, 3999719339, 2821834349, 766784016, 2952996808, 2566594879, 3210313671, 3203337956, 3336571891, 1034457026, 3584528711, 2466948901, 113926993, 3758326383, 338241895, 168717936, 666307205, 1188179964, 773529912, 1546045734, 1294757372, 1522805485, 1396182291, 2643833823, 1695183700, 2343527390, 1986661051, 1014477480, 2177026350, 1206759142, 2456956037, 344077627, 2730485921, 1290863460, 2820302411, 3158454273, 3259730800, 3505952657, 3345764771, 106217008, 3516065817, 3606008344, 3600352804, 1432725776, 4094571909, 1467031594, 275423344, 851169720, 430227734, 3100823752, 506948616, 1363258195, 659060556, 3750685593, 883997877, 3785050280, 958139571, 3318307427, 1322822218, 3812723403, 1537002063, 2003034995, 1747873779, 3602036899, 1955562222, 1575990012, 2024104815, 1125592928, 2227730452, 2716904306, 2361852424, 442776044, 2428436474, 593698344, 2756734187, 3733110249, 3204031479, 2999351573, 3329325298, 3815920427, 3391569614, 3928383900, 3515267271, 566280711, 3940187606, 3454069534, 4118630271, 4000239992, 116418474, 1914138554, 174292421, 2731055270, 289380356, 3203993006, 460393269, 320620315, 685471733, 587496836, 852142971, 1086792851, 1017036298, 365543100, 1126000580, 2618297676, 1288033470, 3409855158, 1501505948, 4234509866, 1607167915, 987167468, 1816402316, 1246189591 ];
function y() {
if (!(this instanceof y)) return new y();
m.call(this);
this.h = [ 1779033703, 4089235720, 3144134277, 2227873595, 1013904242, 4271175723, 2773480762, 1595750129, 1359893119, 2917565137, 2600822924, 725511199, 528734635, 4215389547, 1541459225, 327033209 ];
this.k = v;
this.W = new Array(160);
}
r.inherits(y, m);
t.exports = y;
y.blockSize = 1024;
y.outSize = 512;
y.hmacStrength = 192;
y.padLength = 128;
y.prototype._prepareBlock = function(e, t) {
for (var r = this.W, n = 0; n < 32; n++) r[n] = e[t + n];
for (;n < r.length; n += 2) {
var i = I(r[n - 4], r[n - 3]), o = O(r[n - 4], r[n - 3]), s = r[n - 14], a = r[n - 13], f = k(r[n - 30], r[n - 29]), c = T(r[n - 30], r[n - 29]), u = r[n - 32], h = r[n - 31];
r[n] = d(i, o, s, a, f, c, u, h);
r[n + 1] = l(i, o, s, a, f, c, u, h);
}
};
y.prototype._update = function(e, t) {
this._prepareBlock(e, t);
var r = this.W, n = this.h[0], o = this.h[1], s = this.h[2], a = this.h[3], f = this.h[4], d = this.h[5], l = this.h[6], m = this.h[7], v = this.h[8], y = this.h[9], k = this.h[10], T = this.h[11], I = this.h[12], O = this.h[13], R = this.h[14], C = this.h[15];
i(this.k.length === r.length);
for (var N = 0; N < r.length; N += 2) {
var j = R, P = C, D = A(v, y), L = x(v, y), B = g(v, 0, k, 0, I), U = _(0, y, 0, T, 0, O), F = this.k[N], q = this.k[N + 1], V = r[N], H = r[N + 1], z = p(j, P, D, L, B, U, F, q, V, H), G = b(j, P, D, L, B, U, F, q, V, H);
j = S(n, o);
P = M(n, o);
D = w(n, 0, s, 0, f);
L = E(0, o, 0, a, 0, d);
var W = u(j, P, D, L), K = h(j, P, D, L);
R = I;
C = O;
I = k;
O = T;
k = v;
T = y;
v = u(l, m, z, G);
y = h(m, m, z, G);
l = f;
m = d;
f = s;
d = a;
s = n;
a = o;
n = u(z, G, W, K);
o = h(z, G, W, K);
}
c(this.h, 0, n, o);
c(this.h, 2, s, a);
c(this.h, 4, f, d);
c(this.h, 6, l, m);
c(this.h, 8, v, y);
c(this.h, 10, k, T);
c(this.h, 12, I, O);
c(this.h, 14, R, C);
};
y.prototype._digest = function(e) {
return "hex" === e ? r.toHex32(this.h, "big") : r.split32(this.h, "big");
};
function g(e, t, r, n, i) {
var o = e & r ^ ~e & i;
o < 0 && (o += 4294967296);
return o;
}
function _(e, t, r, n, i, o) {
var s = t & n ^ ~t & o;
s < 0 && (s += 4294967296);
return s;
}
function w(e, t, r, n, i) {
var o = e & r ^ e & i ^ r & i;
o < 0 && (o += 4294967296);
return o;
}
function E(e, t, r, n, i, o) {
var s = t & n ^ t & o ^ n & o;
s < 0 && (s += 4294967296);
return s;
}
function S(e, t) {
var r = o(e, t, 28) ^ o(t, e, 2) ^ o(t, e, 7);
r < 0 && (r += 4294967296);
return r;
}
function M(e, t) {
var r = s(e, t, 28) ^ s(t, e, 2) ^ s(t, e, 7);
r < 0 && (r += 4294967296);
return r;
}
function A(e, t) {
var r = o(e, t, 14) ^ o(e, t, 18) ^ o(t, e, 9);
r < 0 && (r += 4294967296);
return r;
}
function x(e, t) {
var r = s(e, t, 14) ^ s(e, t, 18) ^ s(t, e, 9);
r < 0 && (r += 4294967296);
return r;
}
function k(e, t) {
var r = o(e, t, 1) ^ o(e, t, 8) ^ a(e, t, 7);
r < 0 && (r += 4294967296);
return r;
}
function T(e, t) {
var r = s(e, t, 1) ^ s(e, t, 8) ^ f(e, t, 7);
r < 0 && (r += 4294967296);
return r;
}
function I(e, t) {
var r = o(e, t, 19) ^ o(t, e, 29) ^ a(e, t, 6);
r < 0 && (r += 4294967296);
return r;
}
function O(e, t) {
var r = s(e, t, 19) ^ s(t, e, 29) ^ f(e, t, 6);
r < 0 && (r += 4294967296);
return r;
}
}, {
"../common": 125,
"../utils": 135,
"minimalistic-assert": 143
} ],
134: [ function(e, t, r) {
"use strict";
var n = e("../utils").rotr32;
r.ft_1 = function(e, t, r, n) {
return 0 === e ? i(t, r, n) : 1 === e || 3 === e ? s(t, r, n) : 2 === e ? o(t, r, n) : void 0;
};
function i(e, t, r) {
return e & t ^ ~e & r;
}
r.ch32 = i;
function o(e, t, r) {
return e & t ^ e & r ^ t & r;
}
r.maj32 = o;
function s(e, t, r) {
return e ^ t ^ r;
}
r.p32 = s;
r.s0_256 = function(e) {
return n(e, 2) ^ n(e, 13) ^ n(e, 22);
};
r.s1_256 = function(e) {
return n(e, 6) ^ n(e, 11) ^ n(e, 25);
};
r.g0_256 = function(e) {
return n(e, 7) ^ n(e, 18) ^ e >>> 3;
};
r.g1_256 = function(e) {
return n(e, 17) ^ n(e, 19) ^ e >>> 10;
};
}, {
"../utils": 135
} ],
135: [ function(e, t, r) {
"use strict";
var n = e("minimalistic-assert"), i = e("inherits");
r.inherits = i;
function o(e, t) {
return 55296 == (64512 & e.charCodeAt(t)) && !(t < 0 || t + 1 >= e.length) && 56320 == (64512 & e.charCodeAt(t + 1));
}
r.toArray = function(e, t) {
if (Array.isArray(e)) return e.slice();
if (!e) return [];
var r = [];
if ("string" == typeof e) if (t) {
if ("hex" === t) {
(e = e.replace(/[^a-z0-9]+/gi, "")).length % 2 != 0 && (e = "0" + e);
for (i = 0; i < e.length; i += 2) r.push(parseInt(e[i] + e[i + 1], 16));
}
} else for (var n = 0, i = 0; i < e.length; i++) {
var s = e.charCodeAt(i);
if (s < 128) r[n++] = s; else if (s < 2048) {
r[n++] = s >> 6 | 192;
r[n++] = 63 & s | 128;
} else if (o(e, i)) {
s = 65536 + ((1023 & s) << 10) + (1023 & e.charCodeAt(++i));
r[n++] = s >> 18 | 240;
r[n++] = s >> 12 & 63 | 128;
r[n++] = s >> 6 & 63 | 128;
r[n++] = 63 & s | 128;
} else {
r[n++] = s >> 12 | 224;
r[n++] = s >> 6 & 63 | 128;
r[n++] = 63 & s | 128;
}
} else for (i = 0; i < e.length; i++) r[i] = 0 | e[i];
return r;
};
r.toHex = function(e) {
for (var t = "", r = 0; r < e.length; r++) t += a(e[r].toString(16));
return t;
};
function s(e) {
return (e >>> 24 | e >>> 8 & 65280 | e << 8 & 16711680 | (255 & e) << 24) >>> 0;
}
r.htonl = s;
r.toHex32 = function(e, t) {
for (var r = "", n = 0; n < e.length; n++) {
var i = e[n];
"little" === t && (i = s(i));
r += f(i.toString(16));
}
return r;
};
function a(e) {
return 1 === e.length ? "0" + e : e;
}
r.zero2 = a;
function f(e) {
return 7 === e.length ? "0" + e : 6 === e.length ? "00" + e : 5 === e.length ? "000" + e : 4 === e.length ? "0000" + e : 3 === e.length ? "00000" + e : 2 === e.length ? "000000" + e : 1 === e.length ? "0000000" + e : e;
}
r.zero8 = f;
r.join32 = function(e, t, r, i) {
var o = r - t;
n(o % 4 == 0);
for (var s = new Array(o / 4), a = 0, f = t; a < s.length; a++, f += 4) {
var c;
c = "big" === i ? e[f] << 24 | e[f + 1] << 16 | e[f + 2] << 8 | e[f + 3] : e[f + 3] << 24 | e[f + 2] << 16 | e[f + 1] << 8 | e[f];
s[a] = c >>> 0;
}
return s;
};
r.split32 = function(e, t) {
for (var r = new Array(4 * e.length), n = 0, i = 0; n < e.length; n++, i += 4) {
var o = e[n];
if ("big" === t) {
r[i] = o >>> 24;
r[i + 1] = o >>> 16 & 255;
r[i + 2] = o >>> 8 & 255;
r[i + 3] = 255 & o;
} else {
r[i + 3] = o >>> 24;
r[i + 2] = o >>> 16 & 255;
r[i + 1] = o >>> 8 & 255;
r[i] = 255 & o;
}
}
return r;
};
r.rotr32 = function(e, t) {
return e >>> t | e << 32 - t;
};
r.rotl32 = function(e, t) {
return e << t | e >>> 32 - t;
};
r.sum32 = function(e, t) {
return e + t >>> 0;
};
r.sum32_3 = function(e, t, r) {
return e + t + r >>> 0;
};
r.sum32_4 = function(e, t, r, n) {
return e + t + r + n >>> 0;
};
r.sum32_5 = function(e, t, r, n, i) {
return e + t + r + n + i >>> 0;
};
r.sum64 = function(e, t, r, n) {
var i = e[t], o = n + e[t + 1] >>> 0, s = (o < n ? 1 : 0) + r + i;
e[t] = s >>> 0;
e[t + 1] = o;
};
r.sum64_hi = function(e, t, r, n) {
return (t + n >>> 0 < t ? 1 : 0) + e + r >>> 0;
};
r.sum64_lo = function(e, t, r, n) {
return t + n >>> 0;
};
r.sum64_4_hi = function(e, t, r, n, i, o, s, a) {
var f = 0, c = t;
f += (c = c + n >>> 0) < t ? 1 : 0;
f += (c = c + o >>> 0) < o ? 1 : 0;
return e + r + i + s + (f += (c = c + a >>> 0) < a ? 1 : 0) >>> 0;
};
r.sum64_4_lo = function(e, t, r, n, i, o, s, a) {
return t + n + o + a >>> 0;
};
r.sum64_5_hi = function(e, t, r, n, i, o, s, a, f, c) {
var u = 0, h = t;
u += (h = h + n >>> 0) < t ? 1 : 0;
u += (h = h + o >>> 0) < o ? 1 : 0;
u += (h = h + a >>> 0) < a ? 1 : 0;
return e + r + i + s + f + (u += (h = h + c >>> 0) < c ? 1 : 0) >>> 0;
};
r.sum64_5_lo = function(e, t, r, n, i, o, s, a, f, c) {
return t + n + o + a + c >>> 0;
};
r.rotr64_hi = function(e, t, r) {
return (t << 32 - r | e >>> r) >>> 0;
};
r.rotr64_lo = function(e, t, r) {
return (e << 32 - r | t >>> r) >>> 0;
};
r.shr64_hi = function(e, t, r) {
return e >>> r;
};
r.shr64_lo = function(e, t, r) {
return (e << 32 - r | t >>> r) >>> 0;
};
}, {
inherits: 138,
"minimalistic-assert": 143
} ],
136: [ function(e, t) {
"use strict";
var r = e("hash.js"), n = e("minimalistic-crypto-utils"), i = e("minimalistic-assert");
function o(e) {
if (!(this instanceof o)) return new o(e);
this.hash = e.hash;
this.predResist = !!e.predResist;
this.outLen = this.hash.outSize;
this.minEntropy = e.minEntropy || this.hash.hmacStrength;
this._reseed = null;
this.reseedInterval = null;
this.K = null;
this.V = null;
var t = n.toArray(e.entropy, e.entropyEnc || "hex"), r = n.toArray(e.nonce, e.nonceEnc || "hex"), s = n.toArray(e.pers, e.persEnc || "hex");
i(t.length >= this.minEntropy / 8, "Not enough entropy. Minimum is: " + this.minEntropy + " bits");
this._init(t, r, s);
}
t.exports = o;
o.prototype._init = function(e, t, r) {
var n = e.concat(t).concat(r);
this.K = new Array(this.outLen / 8);
this.V = new Array(this.outLen / 8);
for (var i = 0; i < this.V.length; i++) {
this.K[i] = 0;
this.V[i] = 1;
}
this._update(n);
this._reseed = 1;
this.reseedInterval = 281474976710656;
};
o.prototype._hmac = function() {
return new r.hmac(this.hash, this.K);
};
o.prototype._update = function(e) {
var t = this._hmac().update(this.V).update([ 0 ]);
e && (t = t.update(e));
this.K = t.digest();
this.V = this._hmac().update(this.V).digest();
if (e) {
this.K = this._hmac().update(this.V).update([ 1 ]).update(e).digest();
this.V = this._hmac().update(this.V).digest();
}
};
o.prototype.reseed = function(e, t, r, o) {
if ("string" != typeof t) {
o = r;
r = t;
t = null;
}
e = n.toArray(e, t);
r = n.toArray(r, o);
i(e.length >= this.minEntropy / 8, "Not enough entropy. Minimum is: " + this.minEntropy + " bits");
this._update(e.concat(r || []));
this._reseed = 1;
};
o.prototype.generate = function(e, t, r, i) {
if (this._reseed > this.reseedInterval) throw new Error("Reseed is required");
if ("string" != typeof t) {
i = r;
r = t;
t = null;
}
if (r) {
r = n.toArray(r, i || "hex");
this._update(r);
}
for (var o = []; o.length < e; ) {
this.V = this._hmac().update(this.V).digest();
o = o.concat(this.V);
}
var s = o.slice(0, e);
this._update(r);
this._reseed++;
return n.encode(s, t);
};
}, {
"hash.js": 124,
"minimalistic-assert": 143,
"minimalistic-crypto-utils": 144
} ],
137: [ function(e, t, r) {
r.read = function(e, t, r, n, i) {
var o, s, a = 8 * i - n - 1, f = (1 << a) - 1, c = f >> 1, u = -7, h = r ? i - 1 : 0, d = r ? -1 : 1, l = e[t + h];
h += d;
o = l & (1 << -u) - 1;
l >>= -u;
u += a;
for (;u > 0; o = 256 * o + e[t + h], h += d, u -= 8) ;
s = o & (1 << -u) - 1;
o >>= -u;
u += n;
for (;u > 0; s = 256 * s + e[t + h], h += d, u -= 8) ;
if (0 === o) o = 1 - c; else {
if (o === f) return s ? NaN : Infinity * (l ? -1 : 1);
s += Math.pow(2, n);
o -= c;
}
return (l ? -1 : 1) * s * Math.pow(2, o - n);
};
r.write = function(e, t, r, n, i, o) {
var s, a, f, c = 8 * o - i - 1, u = (1 << c) - 1, h = u >> 1, d = 23 === i ? Math.pow(2, -24) - Math.pow(2, -77) : 0, l = n ? 0 : o - 1, p = n ? 1 : -1, b = t < 0 || 0 === t && 1 / t < 0 ? 1 : 0;
t = Math.abs(t);
if (isNaN(t) || Infinity === t) {
a = isNaN(t) ? 1 : 0;
s = u;
} else {
s = Math.floor(Math.log(t) / Math.LN2);
if (t * (f = Math.pow(2, -s)) < 1) {
s--;
f *= 2;
}
if ((t += s + h >= 1 ? d / f : d * Math.pow(2, 1 - h)) * f >= 2) {
s++;
f /= 2;
}
if (s + h >= u) {
a = 0;
s = u;
} else if (s + h >= 1) {
a = (t * f - 1) * Math.pow(2, i);
s += h;
} else {
a = t * Math.pow(2, h - 1) * Math.pow(2, i);
s = 0;
}
}
for (;i >= 8; e[r + l] = 255 & a, l += p, a /= 256, i -= 8) ;
s = s << i | a;
c += i;
for (;c > 0; e[r + l] = 255 & s, l += p, s /= 256, c -= 8) ;
e[r + l - p] |= 128 * b;
};
}, {} ],
138: [ function(e, t) {
"function" == typeof Object.create ? t.exports = function(e, t) {
if (t) {
e.super_ = t;
e.prototype = Object.create(t.prototype, {
constructor: {
value: e,
enumerable: !1,
writable: !0,
configurable: !0
}
});
}
} : t.exports = function(e, t) {
if (t) {
e.super_ = t;
var r = function() {};
r.prototype = t.prototype;
e.prototype = new r();
e.prototype.constructor = e;
}
};
}, {} ],
139: [ function(e, t) {
t.exports = function(e) {
return null != e && (r(e) || n(e) || !!e._isBuffer);
};
function r(e) {
return !!e.constructor && "function" == typeof e.constructor.isBuffer && e.constructor.isBuffer(e);
}
function n(e) {
return "function" == typeof e.readFloatLE && "function" == typeof e.slice && r(e.slice(0, 0));
}
}, {} ],
140: [ function(e, t) {
"use strict";
var r = e("inherits"), n = e("hash-base"), i = e("safe-buffer").Buffer, o = new Array(16);
function s() {
n.call(this, 64);
this._a = 1732584193;
this._b = 4023233417;
this._c = 2562383102;
this._d = 271733878;
}
r(s, n);
s.prototype._update = function() {
for (var e = o, t = 0; t < 16; ++t) e[t] = this._block.readInt32LE(4 * t);
var r = this._a, n = this._b, i = this._c, s = this._d;
r = f(r, n, i, s, e[0], 3614090360, 7);
s = f(s, r, n, i, e[1], 3905402710, 12);
i = f(i, s, r, n, e[2], 606105819, 17);
n = f(n, i, s, r, e[3], 3250441966, 22);
r = f(r, n, i, s, e[4], 4118548399, 7);
s = f(s, r, n, i, e[5], 1200080426, 12);
i = f(i, s, r, n, e[6], 2821735955, 17);
n = f(n, i, s, r, e[7], 4249261313, 22);
r = f(r, n, i, s, e[8], 1770035416, 7);
s = f(s, r, n, i, e[9], 2336552879, 12);
i = f(i, s, r, n, e[10], 4294925233, 17);
n = f(n, i, s, r, e[11], 2304563134, 22);
r = f(r, n, i, s, e[12], 1804603682, 7);
s = f(s, r, n, i, e[13], 4254626195, 12);
i = f(i, s, r, n, e[14], 2792965006, 17);
r = c(r, n = f(n, i, s, r, e[15], 1236535329, 22), i, s, e[1], 4129170786, 5);
s = c(s, r, n, i, e[6], 3225465664, 9);
i = c(i, s, r, n, e[11], 643717713, 14);
n = c(n, i, s, r, e[0], 3921069994, 20);
r = c(r, n, i, s, e[5], 3593408605, 5);
s = c(s, r, n, i, e[10], 38016083, 9);
i = c(i, s, r, n, e[15], 3634488961, 14);
n = c(n, i, s, r, e[4], 3889429448, 20);
r = c(r, n, i, s, e[9], 568446438, 5);
s = c(s, r, n, i, e[14], 3275163606, 9);
i = c(i, s, r, n, e[3], 4107603335, 14);
n = c(n, i, s, r, e[8], 1163531501, 20);
r = c(r, n, i, s, e[13], 2850285829, 5);
s = c(s, r, n, i, e[2], 4243563512, 9);
i = c(i, s, r, n, e[7], 1735328473, 14);
r = u(r, n = c(n, i, s, r, e[12], 2368359562, 20), i, s, e[5], 4294588738, 4);
s = u(s, r, n, i, e[8], 2272392833, 11);
i = u(i, s, r, n, e[11], 1839030562, 16);
n = u(n, i, s, r, e[14], 4259657740, 23);
r = u(r, n, i, s, e[1], 2763975236, 4);
s = u(s, r, n, i, e[4], 1272893353, 11);
i = u(i, s, r, n, e[7], 4139469664, 16);
n = u(n, i, s, r, e[10], 3200236656, 23);
r = u(r, n, i, s, e[13], 681279174, 4);
s = u(s, r, n, i, e[0], 3936430074, 11);
i = u(i, s, r, n, e[3], 3572445317, 16);
n = u(n, i, s, r, e[6], 76029189, 23);
r = u(r, n, i, s, e[9], 3654602809, 4);
s = u(s, r, n, i, e[12], 3873151461, 11);
i = u(i, s, r, n, e[15], 530742520, 16);
r = h(r, n = u(n, i, s, r, e[2], 3299628645, 23), i, s, e[0], 4096336452, 6);
s = h(s, r, n, i, e[7], 1126891415, 10);
i = h(i, s, r, n, e[14], 2878612391, 15);
n = h(n, i, s, r, e[5], 4237533241, 21);
r = h(r, n, i, s, e[12], 1700485571, 6);
s = h(s, r, n, i, e[3], 2399980690, 10);
i = h(i, s, r, n, e[10], 4293915773, 15);
n = h(n, i, s, r, e[1], 2240044497, 21);
r = h(r, n, i, s, e[8], 1873313359, 6);
s = h(s, r, n, i, e[15], 4264355552, 10);
i = h(i, s, r, n, e[6], 2734768916, 15);
n = h(n, i, s, r, e[13], 1309151649, 21);
r = h(r, n, i, s, e[4], 4149444226, 6);
s = h(s, r, n, i, e[11], 3174756917, 10);
i = h(i, s, r, n, e[2], 718787259, 15);
n = h(n, i, s, r, e[9], 3951481745, 21);
this._a = this._a + r | 0;
this._b = this._b + n | 0;
this._c = this._c + i | 0;
this._d = this._d + s | 0;
};
s.prototype._digest = function() {
this._block[this._blockOffset++] = 128;
if (this._blockOffset > 56) {
this._block.fill(0, this._blockOffset, 64);
this._update();
this._blockOffset = 0;
}
this._block.fill(0, this._blockOffset, 56);
this._block.writeUInt32LE(this._length[0], 56);
this._block.writeUInt32LE(this._length[1], 60);
this._update();
var e = i.allocUnsafe(16);
e.writeInt32LE(this._a, 0);
e.writeInt32LE(this._b, 4);
e.writeInt32LE(this._c, 8);
e.writeInt32LE(this._d, 12);
return e;
};
function a(e, t) {
return e << t | e >>> 32 - t;
}
function f(e, t, r, n, i, o, s) {
return a(e + (t & r | ~t & n) + i + o | 0, s) + t | 0;
}
function c(e, t, r, n, i, o, s) {
return a(e + (t & n | r & ~n) + i + o | 0, s) + t | 0;
}
function u(e, t, r, n, i, o, s) {
return a(e + (t ^ r ^ n) + i + o | 0, s) + t | 0;
}
function h(e, t, r, n, i, o, s) {
return a(e + (r ^ (t | ~n)) + i + o | 0, s) + t | 0;
}
t.exports = s;
}, {
"hash-base": 106,
inherits: 138,
"safe-buffer": 183
} ],
141: [ function(e, t) {
var r = e("bn.js"), n = e("brorand");
function i(e) {
this.rand = e || new n.Rand();
}
t.exports = i;
i.create = function(e) {
return new i(e);
};
i.prototype._randbelow = function(e) {
var t = e.bitLength(), n = Math.ceil(t / 8);
do {
var i = new r(this.rand.generate(n));
} while (i.cmp(e) >= 0);
return i;
};
i.prototype._randrange = function(e, t) {
var r = t.sub(e);
return e.add(this._randbelow(r));
};
i.prototype.test = function(e, t, n) {
var i = e.bitLength(), o = r.mont(e), s = new r(1).toRed(o);
t || (t = Math.max(1, i / 48 | 0));
for (var a = e.subn(1), f = 0; !a.testn(f); f++) ;
for (var c = e.shrn(f), u = a.toRed(o); t > 0; t--) {
var h = this._randrange(new r(2), a);
n && n(h);
var d = h.toRed(o).redPow(c);
if (0 !== d.cmp(s) && 0 !== d.cmp(u)) {
for (var l = 1; l < f; l++) {
if (0 === (d = d.redSqr()).cmp(s)) return !1;
if (0 === d.cmp(u)) break;
}
if (l === f) return !1;
}
}
return !0;
};
i.prototype.getDivisor = function(e, t) {
var n = e.bitLength(), i = r.mont(e), o = new r(1).toRed(i);
t || (t = Math.max(1, n / 48 | 0));
for (var s = e.subn(1), a = 0; !s.testn(a); a++) ;
for (var f = e.shrn(a), c = s.toRed(i); t > 0; t--) {
var u = this._randrange(new r(2), s), h = e.gcd(u);
if (0 !== h.cmpn(1)) return h;
var d = u.toRed(i).redPow(f);
if (0 !== d.cmp(o) && 0 !== d.cmp(c)) {
for (var l = 1; l < a; l++) {
if (0 === (d = d.redSqr()).cmp(o)) return d.fromRed().subn(1).gcd(e);
if (0 === d.cmp(c)) break;
}
if (l === a) return (d = d.redSqr()).fromRed().subn(1).gcd(e);
}
}
return !1;
};
}, {
"bn.js": 142,
brorand: 18
} ],
142: [ function(e, t, r) {
arguments[4][15][0].apply(r, arguments);
}, {
buffer: 19,
dup: 15
} ],
143: [ function(e, t) {
t.exports = r;
function r(e, t) {
if (!e) throw new Error(t || "Assertion failed");
}
r.equal = function(e, t, r) {
if (e != t) throw new Error(r || "Assertion failed: " + e + " != " + t);
};
}, {} ],
144: [ function(e, t, r) {
"use strict";
var n = r;
n.toArray = function(e, t) {
if (Array.isArray(e)) return e.slice();
if (!e) return [];
var r = [];
if ("string" != typeof e) {
for (var n = 0; n < e.length; n++) r[n] = 0 | e[n];
return r;
}
if ("hex" === t) {
(e = e.replace(/[^a-z0-9]+/gi, "")).length % 2 != 0 && (e = "0" + e);
for (n = 0; n < e.length; n += 2) r.push(parseInt(e[n] + e[n + 1], 16));
} else for (n = 0; n < e.length; n++) {
var i = e.charCodeAt(n), o = i >> 8, s = 255 & i;
o ? r.push(o, s) : r.push(s);
}
return r;
};
function i(e) {
return 1 === e.length ? "0" + e : e;
}
n.zero2 = i;
function o(e) {
for (var t = "", r = 0; r < e.length; r++) t += i(e[r].toString(16));
return t;
}
n.toHex = o;
n.encode = function(e, t) {
return "hex" === t ? o(e) : e;
};
}, {} ],
145: [ function(e, t) {
t.exports = {
"2.16.840.1.101.3.4.1.1": "aes-128-ecb",
"2.16.840.1.101.3.4.1.2": "aes-128-cbc",
"2.16.840.1.101.3.4.1.3": "aes-128-ofb",
"2.16.840.1.101.3.4.1.4": "aes-128-cfb",
"2.16.840.1.101.3.4.1.21": "aes-192-ecb",
"2.16.840.1.101.3.4.1.22": "aes-192-cbc",
"2.16.840.1.101.3.4.1.23": "aes-192-ofb",
"2.16.840.1.101.3.4.1.24": "aes-192-cfb",
"2.16.840.1.101.3.4.1.41": "aes-256-ecb",
"2.16.840.1.101.3.4.1.42": "aes-256-cbc",
"2.16.840.1.101.3.4.1.43": "aes-256-ofb",
"2.16.840.1.101.3.4.1.44": "aes-256-cfb"
};
}, {} ],
146: [ function(e, t, r) {
"use strict";
var n = e("asn1.js");
r.certificate = e("./certificate");
var i = n.define("RSAPrivateKey", function() {
this.seq().obj(this.key("version").int(), this.key("modulus").int(), this.key("publicExponent").int(), this.key("privateExponent").int(), this.key("prime1").int(), this.key("prime2").int(), this.key("exponent1").int(), this.key("exponent2").int(), this.key("coefficient").int());
});
r.RSAPrivateKey = i;
var o = n.define("RSAPublicKey", function() {
this.seq().obj(this.key("modulus").int(), this.key("publicExponent").int());
});
r.RSAPublicKey = o;
var s = n.define("SubjectPublicKeyInfo", function() {
this.seq().obj(this.key("algorithm").use(a), this.key("subjectPublicKey").bitstr());
});
r.PublicKey = s;
var a = n.define("AlgorithmIdentifier", function() {
this.seq().obj(this.key("algorithm").objid(), this.key("none").null_().optional(), this.key("curve").objid().optional(), this.key("params").seq().obj(this.key("p").int(), this.key("q").int(), this.key("g").int()).optional());
}), f = n.define("PrivateKeyInfo", function() {
this.seq().obj(this.key("version").int(), this.key("algorithm").use(a), this.key("subjectPrivateKey").octstr());
});
r.PrivateKey = f;
var c = n.define("EncryptedPrivateKeyInfo", function() {
this.seq().obj(this.key("algorithm").seq().obj(this.key("id").objid(), this.key("decrypt").seq().obj(this.key("kde").seq().obj(this.key("id").objid(), this.key("kdeparams").seq().obj(this.key("salt").octstr(), this.key("iters").int())), this.key("cipher").seq().obj(this.key("algo").objid(), this.key("iv").octstr()))), this.key("subjectPrivateKey").octstr());
});
r.EncryptedPrivateKey = c;
var u = n.define("DSAPrivateKey", function() {
this.seq().obj(this.key("version").int(), this.key("p").int(), this.key("q").int(), this.key("g").int(), this.key("pub_key").int(), this.key("priv_key").int());
});
r.DSAPrivateKey = u;
r.DSAparam = n.define("DSAparam", function() {
this.int();
});
var h = n.define("ECPrivateKey", function() {
this.seq().obj(this.key("version").int(), this.key("privateKey").octstr(), this.key("parameters").optional().explicit(0).use(d), this.key("publicKey").optional().explicit(1).bitstr());
});
r.ECPrivateKey = h;
var d = n.define("ECParameters", function() {
this.choice({
namedCurve: this.objid()
});
});
r.signature = n.define("signature", function() {
this.seq().obj(this.key("r").int(), this.key("s").int());
});
}, {
"./certificate": 147,
"asn1.js": 1
} ],
147: [ function(e, t) {
"use strict";
var r = e("asn1.js"), n = r.define("Time", function() {
this.choice({
utcTime: this.utctime(),
generalTime: this.gentime()
});
}), i = r.define("AttributeTypeValue", function() {
this.seq().obj(this.key("type").objid(), this.key("value").any());
}), o = r.define("AlgorithmIdentifier", function() {
this.seq().obj(this.key("algorithm").objid(), this.key("parameters").optional(), this.key("curve").objid().optional());
}), s = r.define("SubjectPublicKeyInfo", function() {
this.seq().obj(this.key("algorithm").use(o), this.key("subjectPublicKey").bitstr());
}), a = r.define("RelativeDistinguishedName", function() {
this.setof(i);
}), f = r.define("RDNSequence", function() {
this.seqof(a);
}), c = r.define("Name", function() {
this.choice({
rdnSequence: this.use(f)
});
}), u = r.define("Validity", function() {
this.seq().obj(this.key("notBefore").use(n), this.key("notAfter").use(n));
}), h = r.define("Extension", function() {
this.seq().obj(this.key("extnID").objid(), this.key("critical").bool().def(!1), this.key("extnValue").octstr());
}), d = r.define("TBSCertificate", function() {
this.seq().obj(this.key("version").explicit(0).int().optional(), this.key("serialNumber").int(), this.key("signature").use(o), this.key("issuer").use(c), this.key("validity").use(u), this.key("subject").use(c), this.key("subjectPublicKeyInfo").use(s), this.key("issuerUniqueID").implicit(1).bitstr().optional(), this.key("subjectUniqueID").implicit(2).bitstr().optional(), this.key("extensions").explicit(3).seqof(h).optional());
}), l = r.define("X509Certificate", function() {
this.seq().obj(this.key("tbsCertificate").use(d), this.key("signatureAlgorithm").use(o), this.key("signatureValue").bitstr());
});
t.exports = l;
}, {
"asn1.js": 1
} ],
148: [ function(e, t) {
var r = /Proc-Type: 4,ENCRYPTED[\n\r]+DEK-Info: AES-((?:128)|(?:192)|(?:256))-CBC,([0-9A-H]+)[\n\r]+([0-9A-z\n\r+/=]+)[\n\r]+/m, n = /^-----BEGIN ((?:.*? KEY)|CERTIFICATE)-----/m, i = /^-----BEGIN ((?:.*? KEY)|CERTIFICATE)-----([0-9A-z\n\r+/=]+)-----END \1-----$/m, o = e("evp_bytestokey"), s = e("browserify-aes"), a = e("safe-buffer").Buffer;
t.exports = function(e, t) {
var f, c = e.toString(), u = c.match(r);
if (u) {
var h = "aes" + u[1], d = a.from(u[2], "hex"), l = a.from(u[3].replace(/[\r\n]/g, ""), "base64"), p = o(t, d.slice(0, 8), parseInt(u[1], 10)).key, b = [], m = s.createDecipheriv(h, p, d);
b.push(m.update(l));
b.push(m.final());
f = a.concat(b);
} else {
var v = c.match(i);
f = a.from(v[2].replace(/[\r\n]/g, ""), "base64");
}
return {
tag: c.match(n)[1],
data: f
};
};
}, {
"browserify-aes": 22,
evp_bytestokey: 105,
"safe-buffer": 183
} ],
149: [ function(e, t) {
var r = e("./asn1"), n = e("./aesid.json"), i = e("./fixProc"), o = e("browserify-aes"), s = e("pbkdf2"), a = e("safe-buffer").Buffer;
t.exports = f;
function f(e) {
var t;
if ("object" == typeof e && !a.isBuffer(e)) {
t = e.passphrase;
e = e.key;
}
"string" == typeof e && (e = a.from(e));
var n, o, s = i(e, t), f = s.tag, u = s.data;
switch (f) {
case "CERTIFICATE":
o = r.certificate.decode(u, "der").tbsCertificate.subjectPublicKeyInfo;

case "PUBLIC KEY":
o || (o = r.PublicKey.decode(u, "der"));
switch (n = o.algorithm.algorithm.join(".")) {
case "1.2.840.113549.1.1.1":
return r.RSAPublicKey.decode(o.subjectPublicKey.data, "der");

case "1.2.840.10045.2.1":
o.subjectPrivateKey = o.subjectPublicKey;
return {
type: "ec",
data: o
};

case "1.2.840.10040.4.1":
o.algorithm.params.pub_key = r.DSAparam.decode(o.subjectPublicKey.data, "der");
return {
type: "dsa",
data: o.algorithm.params
};

default:
throw new Error("unknown key id " + n);
}

case "ENCRYPTED PRIVATE KEY":
u = c(u = r.EncryptedPrivateKey.decode(u, "der"), t);

case "PRIVATE KEY":
switch (n = (o = r.PrivateKey.decode(u, "der")).algorithm.algorithm.join(".")) {
case "1.2.840.113549.1.1.1":
return r.RSAPrivateKey.decode(o.subjectPrivateKey, "der");

case "1.2.840.10045.2.1":
return {
curve: o.algorithm.curve,
privateKey: r.ECPrivateKey.decode(o.subjectPrivateKey, "der").privateKey
};

case "1.2.840.10040.4.1":
o.algorithm.params.priv_key = r.DSAparam.decode(o.subjectPrivateKey, "der");
return {
type: "dsa",
params: o.algorithm.params
};

default:
throw new Error("unknown key id " + n);
}

case "RSA PUBLIC KEY":
return r.RSAPublicKey.decode(u, "der");

case "RSA PRIVATE KEY":
return r.RSAPrivateKey.decode(u, "der");

case "DSA PRIVATE KEY":
return {
type: "dsa",
params: r.DSAPrivateKey.decode(u, "der")
};

case "EC PRIVATE KEY":
return {
curve: (u = r.ECPrivateKey.decode(u, "der")).parameters.value,
privateKey: u.privateKey
};

default:
throw new Error("unknown key type " + f);
}
}
f.signature = r.signature;
function c(e, t) {
var r = e.algorithm.decrypt.kde.kdeparams.salt, i = parseInt(e.algorithm.decrypt.kde.kdeparams.iters.toString(), 10), f = n[e.algorithm.decrypt.cipher.algo.join(".")], c = e.algorithm.decrypt.cipher.iv, u = e.subjectPrivateKey, h = parseInt(f.split("-")[1], 10) / 8, d = s.pbkdf2Sync(t, r, i, h, "sha1"), l = o.createDecipheriv(f, d, c), p = [];
p.push(l.update(u));
p.push(l.final());
return a.concat(p);
}
}, {
"./aesid.json": 145,
"./asn1": 146,
"./fixProc": 148,
"browserify-aes": 22,
pbkdf2: 150,
"safe-buffer": 183
} ],
150: [ function(e, t, r) {
r.pbkdf2 = e("./lib/async");
r.pbkdf2Sync = e("./lib/sync");
}, {
"./lib/async": 151,
"./lib/sync": 154
} ],
151: [ function(e, t) {
(function(r, n) {
var i, o = e("safe-buffer").Buffer, s = e("./precondition"), a = e("./default-encoding"), f = e("./sync"), c = e("./to-buffer"), u = n.crypto && n.crypto.subtle, h = {
sha: "SHA-1",
"sha-1": "SHA-1",
sha1: "SHA-1",
sha256: "SHA-256",
"sha-256": "SHA-256",
sha384: "SHA-384",
"sha-384": "SHA-384",
"sha-512": "SHA-512",
sha512: "SHA-512"
}, d = [];
function l(e) {
if (n.process && !n.process.browser) return Promise.resolve(!1);
if (!u || !u.importKey || !u.deriveBits) return Promise.resolve(!1);
if (void 0 !== d[e]) return d[e];
var t = p(i = i || o.alloc(8), i, 10, 128, e).then(function() {
return !0;
}).catch(function() {
return !1;
});
d[e] = t;
return t;
}
function p(e, t, r, n, i) {
return u.importKey("raw", e, {
name: "PBKDF2"
}, !1, [ "deriveBits" ]).then(function(e) {
return u.deriveBits({
name: "PBKDF2",
salt: t,
iterations: r,
hash: {
name: i
}
}, e, n << 3);
}).then(function(e) {
return o.from(e);
});
}
function b(e, t) {
e.then(function(e) {
r.nextTick(function() {
t(null, e);
});
}, function(e) {
r.nextTick(function() {
t(e);
});
});
}
t.exports = function(e, t, i, o, u, d) {
if ("function" == typeof u) {
d = u;
u = void 0;
}
var m = h[(u = u || "sha1").toLowerCase()];
if (!m || "function" != typeof n.Promise) return r.nextTick(function() {
var r;
try {
r = f(e, t, i, o, u);
} catch (e) {
return d(e);
}
d(null, r);
});
s(i, o);
e = c(e, a, "Password");
t = c(t, a, "Salt");
if ("function" != typeof d) throw new Error("No callback provided to pbkdf2");
b(l(m).then(function(r) {
return r ? p(e, t, i, o, m) : f(e, t, i, o, u);
}), d);
};
}).call(this, e("_process"), "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"./default-encoding": 152,
"./precondition": 153,
"./sync": 154,
"./to-buffer": 155,
_process: 157,
"safe-buffer": 183
} ],
152: [ function(e, t) {
(function(e) {
var r;
r = e.browser ? "utf-8" : e.version ? parseInt(e.version.split(".")[0].slice(1), 10) >= 6 ? "utf-8" : "binary" : "utf-8";
t.exports = r;
}).call(this, e("_process"));
}, {
_process: 157
} ],
153: [ function(e, t) {
var r = Math.pow(2, 30) - 1;
t.exports = function(e, t) {
if ("number" != typeof e) throw new TypeError("Iterations not a number");
if (e < 0) throw new TypeError("Bad iterations");
if ("number" != typeof t) throw new TypeError("Key length not a number");
if (t < 0 || t > r || t != t) throw new TypeError("Bad key length");
};
}, {} ],
154: [ function(e, t) {
var r = e("create-hash/md5"), n = e("ripemd160"), i = e("sha.js"), o = e("safe-buffer").Buffer, s = e("./precondition"), a = e("./default-encoding"), f = e("./to-buffer"), c = o.alloc(128), u = {
md5: 16,
sha1: 20,
sha224: 28,
sha256: 32,
sha384: 48,
sha512: 64,
rmd160: 20,
ripemd160: 20
};
function h(e, t, r) {
var n = d(e), i = "sha512" === e || "sha384" === e ? 128 : 64;
t.length > i ? t = n(t) : t.length < i && (t = o.concat([ t, c ], i));
for (var s = o.allocUnsafe(i + u[e]), a = o.allocUnsafe(i + u[e]), f = 0; f < i; f++) {
s[f] = 54 ^ t[f];
a[f] = 92 ^ t[f];
}
var h = o.allocUnsafe(i + r + 4);
s.copy(h, 0, 0, i);
this.ipad1 = h;
this.ipad2 = s;
this.opad = a;
this.alg = e;
this.blocksize = i;
this.hash = n;
this.size = u[e];
}
h.prototype.run = function(e, t) {
e.copy(t, this.blocksize);
this.hash(t).copy(this.opad, this.blocksize);
return this.hash(this.opad);
};
function d(e) {
return "rmd160" === e || "ripemd160" === e ? function(e) {
return new n().update(e).digest();
} : "md5" === e ? r : function(t) {
return i(e).update(t).digest();
};
}
t.exports = function(e, t, r, n, i) {
s(r, n);
var c = new h(i = i || "sha1", e = f(e, a, "Password"), (t = f(t, a, "Salt")).length), d = o.allocUnsafe(n), l = o.allocUnsafe(t.length + 4);
t.copy(l, 0, 0, t.length);
for (var p = 0, b = u[i], m = Math.ceil(n / b), v = 1; v <= m; v++) {
l.writeUInt32BE(v, t.length);
for (var y = c.run(l, c.ipad1), g = y, _ = 1; _ < r; _++) {
g = c.run(g, c.ipad2);
for (var w = 0; w < b; w++) y[w] ^= g[w];
}
y.copy(d, p);
p += b;
}
return d;
};
}, {
"./default-encoding": 152,
"./precondition": 153,
"./to-buffer": 155,
"create-hash/md5": 72,
ripemd160: 182,
"safe-buffer": 183,
"sha.js": 186
} ],
155: [ function(e, t) {
var r = e("safe-buffer").Buffer;
t.exports = function(e, t, n) {
if (r.isBuffer(e)) return e;
if ("string" == typeof e) return r.from(e, t);
if (ArrayBuffer.isView(e)) return r.from(e.buffer);
throw new TypeError(n + " must be a string, a Buffer, a typed array or a DataView");
};
}, {
"safe-buffer": 183
} ],
156: [ function(e, t) {
(function(e) {
"use strict";
"undefined" == typeof e || !e.version || 0 === e.version.indexOf("v0.") || 0 === e.version.indexOf("v1.") && 0 !== e.version.indexOf("v1.8.") ? t.exports = {
nextTick: function(t, r, n, i) {
if ("function" != typeof t) throw new TypeError('"callback" argument must be a function');
var o, s, a = arguments.length;
switch (a) {
case 0:
case 1:
return e.nextTick(t);

case 2:
return e.nextTick(function() {
t.call(null, r);
});

case 3:
return e.nextTick(function() {
t.call(null, r, n);
});

case 4:
return e.nextTick(function() {
t.call(null, r, n, i);
});

default:
o = new Array(a - 1);
s = 0;
for (;s < o.length; ) o[s++] = arguments[s];
return e.nextTick(function() {
t.apply(null, o);
});
}
}
} : t.exports = e;
}).call(this, e("_process"));
}, {
_process: 157
} ],
157: [ function(e, t) {
var r, n, i = t.exports = {};
function o() {
throw new Error("setTimeout has not been defined");
}
function s() {
throw new Error("clearTimeout has not been defined");
}
(function() {
try {
r = "function" == typeof setTimeout ? setTimeout : o;
} catch (e) {
r = o;
}
try {
n = "function" == typeof clearTimeout ? clearTimeout : s;
} catch (e) {
n = s;
}
})();
function a(e) {
if (r === setTimeout) return setTimeout(e, 0);
if ((r === o || !r) && setTimeout) {
r = setTimeout;
return setTimeout(e, 0);
}
try {
return r(e, 0);
} catch (t) {
try {
return r.call(null, e, 0);
} catch (t) {
return r.call(this, e, 0);
}
}
}
function f(e) {
if (n === clearTimeout) return clearTimeout(e);
if ((n === s || !n) && clearTimeout) {
n = clearTimeout;
return clearTimeout(e);
}
try {
return n(e);
} catch (t) {
try {
return n.call(null, e);
} catch (t) {
return n.call(this, e);
}
}
}
var c, u = [], h = !1, d = -1;
function l() {
if (h && c) {
h = !1;
c.length ? u = c.concat(u) : d = -1;
u.length && p();
}
}
function p() {
if (!h) {
var e = a(l);
h = !0;
for (var t = u.length; t; ) {
c = u;
u = [];
for (;++d < t; ) c && c[d].run();
d = -1;
t = u.length;
}
c = null;
h = !1;
f(e);
}
}
i.nextTick = function(e) {
var t = new Array(arguments.length - 1);
if (arguments.length > 1) for (var r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
u.push(new b(e, t));
1 !== u.length || h || a(p);
};
function b(e, t) {
this.fun = e;
this.array = t;
}
b.prototype.run = function() {
this.fun.apply(null, this.array);
};
i.title = "browser";
i.browser = !0;
i.env = {};
i.argv = [];
i.version = "";
i.versions = {};
function m() {}
i.on = m;
i.addListener = m;
i.once = m;
i.off = m;
i.removeListener = m;
i.removeAllListeners = m;
i.emit = m;
i.prependListener = m;
i.prependOnceListener = m;
i.listeners = function() {
return [];
};
i.binding = function() {
throw new Error("process.binding is not supported");
};
i.cwd = function() {
return "/";
};
i.chdir = function() {
throw new Error("process.chdir is not supported");
};
i.umask = function() {
return 0;
};
}, {} ],
158: [ function(e, t, r) {
r.publicEncrypt = e("./publicEncrypt");
r.privateDecrypt = e("./privateDecrypt");
r.privateEncrypt = function(e, t) {
return r.publicEncrypt(e, t, !0);
};
r.publicDecrypt = function(e, t) {
return r.privateDecrypt(e, t, !0);
};
}, {
"./privateDecrypt": 161,
"./publicEncrypt": 162
} ],
159: [ function(e, t) {
var r = e("create-hash"), n = e("safe-buffer").Buffer;
t.exports = function(e, t) {
for (var o, s = n.alloc(0), a = 0; s.length < t; ) {
o = i(a++);
s = n.concat([ s, r("sha1").update(e).update(o).digest() ]);
}
return s.slice(0, t);
};
function i(e) {
var t = n.allocUnsafe(4);
t.writeUInt32BE(e, 0);
return t;
}
}, {
"create-hash": 71,
"safe-buffer": 183
} ],
160: [ function(e, t, r) {
arguments[4][15][0].apply(r, arguments);
}, {
buffer: 19,
dup: 15
} ],
161: [ function(e, t) {
var r = e("parse-asn1"), n = e("./mgf"), i = e("./xor"), o = e("bn.js"), s = e("browserify-rsa"), a = e("create-hash"), f = e("./withPublic"), c = e("safe-buffer").Buffer;
t.exports = function(e, t, n) {
var i;
i = e.padding ? e.padding : n ? 1 : 4;
var a, d = r(e), l = d.modulus.byteLength();
if (t.length > l || new o(t).cmp(d.modulus) >= 0) throw new Error("decryption error");
a = n ? f(new o(t), d) : s(t, d);
var p = c.alloc(l - a.length);
a = c.concat([ p, a ], l);
if (4 === i) return u(d, a);
if (1 === i) return h(0, a, n);
if (3 === i) return a;
throw new Error("unknown padding");
};
function u(e, t) {
var r = e.modulus.byteLength(), o = a("sha1").update(c.alloc(0)).digest(), s = o.length;
if (0 !== t[0]) throw new Error("decryption error");
var f = t.slice(1, s + 1), u = t.slice(s + 1), h = i(f, n(u, s)), l = i(u, n(h, r - s - 1));
if (d(o, l.slice(0, s))) throw new Error("decryption error");
for (var p = s; 0 === l[p]; ) p++;
if (1 !== l[p++]) throw new Error("decryption error");
return l.slice(p);
}
function h(e, t, r) {
for (var n = t.slice(0, 2), i = 2, o = 0; 0 !== t[i++]; ) if (i >= t.length) {
o++;
break;
}
var s = t.slice(2, i - 1);
("0002" !== n.toString("hex") && !r || "0001" !== n.toString("hex") && r) && o++;
s.length < 8 && o++;
if (o) throw new Error("decryption error");
return t.slice(i);
}
function d(e, t) {
e = c.from(e);
t = c.from(t);
var r = 0, n = e.length;
if (e.length !== t.length) {
r++;
n = Math.min(e.length, t.length);
}
for (var i = -1; ++i < n; ) r += e[i] ^ t[i];
return r;
}
}, {
"./mgf": 159,
"./withPublic": 163,
"./xor": 164,
"bn.js": 160,
"browserify-rsa": 40,
"create-hash": 71,
"parse-asn1": 149,
"safe-buffer": 183
} ],
162: [ function(e, t) {
var r = e("parse-asn1"), n = e("randombytes"), i = e("create-hash"), o = e("./mgf"), s = e("./xor"), a = e("bn.js"), f = e("./withPublic"), c = e("browserify-rsa"), u = e("safe-buffer").Buffer;
t.exports = function(e, t, n) {
var i;
i = e.padding ? e.padding : n ? 1 : 4;
var o, s = r(e);
if (4 === i) o = h(s, t); else if (1 === i) o = d(s, t, n); else {
if (3 !== i) throw new Error("unknown padding");
if ((o = new a(t)).cmp(s.modulus) >= 0) throw new Error("data too long for modulus");
}
return n ? c(o, s) : f(o, s);
};
function h(e, t) {
var r = e.modulus.byteLength(), f = t.length, c = i("sha1").update(u.alloc(0)).digest(), h = c.length, d = 2 * h;
if (f > r - d - 2) throw new Error("message too long");
var l = u.alloc(r - f - d - 2), p = r - h - 1, b = n(h), m = s(u.concat([ c, l, u.alloc(1, 1), t ], p), o(b, p)), v = s(b, o(m, h));
return new a(u.concat([ u.alloc(1), v, m ], r));
}
function d(e, t, r) {
var n, i = t.length, o = e.modulus.byteLength();
if (i > o - 11) throw new Error("message too long");
n = r ? u.alloc(o - i - 3, 255) : l(o - i - 3);
return new a(u.concat([ u.from([ 0, r ? 1 : 2 ]), n, u.alloc(1), t ], o));
}
function l(e) {
for (var t, r = u.allocUnsafe(e), i = 0, o = n(2 * e), s = 0; i < e; ) {
if (s === o.length) {
o = n(2 * e);
s = 0;
}
(t = o[s++]) && (r[i++] = t);
}
return r;
}
}, {
"./mgf": 159,
"./withPublic": 163,
"./xor": 164,
"bn.js": 160,
"browserify-rsa": 40,
"create-hash": 71,
"parse-asn1": 149,
randombytes: 165,
"safe-buffer": 183
} ],
163: [ function(e, t) {
var r = e("bn.js"), n = e("safe-buffer").Buffer;
t.exports = function(e, t) {
return n.from(e.toRed(r.mont(t.modulus)).redPow(new r(t.publicExponent)).fromRed().toArray());
};
}, {
"bn.js": 160,
"safe-buffer": 183
} ],
164: [ function(e, t) {
t.exports = function(e, t) {
for (var r = e.length, n = -1; ++n < r; ) e[n] ^= t[n];
return e;
};
}, {} ],
165: [ function(e, t) {
(function(r, n) {
"use strict";
var i = e("safe-buffer").Buffer, o = n.crypto || n.msCrypto;
o && o.getRandomValues ? t.exports = function(e, t) {
if (e > 4294967295) throw new RangeError("requested too many random bytes");
var n = i.allocUnsafe(e);
if (e > 0) if (e > 65536) for (var s = 0; s < e; s += 65536) o.getRandomValues(n.slice(s, s + 65536)); else o.getRandomValues(n);
return "function" == typeof t ? r.nextTick(function() {
t(null, n);
}) : n;
} : t.exports = function() {
throw new Error("Secure random number generation is not supported by this browser.\nUse Chrome, Firefox or Internet Explorer 11");
};
}).call(this, e("_process"), "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
_process: 157,
"safe-buffer": 183
} ],
166: [ function(e, t, r) {
(function(t, n) {
"use strict";
function i() {
throw new Error("secure random number generation not supported by this browser\nuse chrome, FireFox or Internet Explorer 11");
}
var o = e("safe-buffer"), s = e("randombytes"), a = o.Buffer, f = o.kMaxLength, c = n.crypto || n.msCrypto, u = Math.pow(2, 32) - 1;
function h(e, t) {
if ("number" != typeof e || e != e) throw new TypeError("offset must be a number");
if (e > u || e < 0) throw new TypeError("offset must be a uint32");
if (e > f || e > t) throw new RangeError("offset out of range");
}
function d(e, t, r) {
if ("number" != typeof e || e != e) throw new TypeError("size must be a number");
if (e > u || e < 0) throw new TypeError("size must be a uint32");
if (e + t > r || e > f) throw new RangeError("buffer too small");
}
if (c && c.getRandomValues || !t.browser) {
r.randomFill = function(e, t, r, i) {
if (!(a.isBuffer(e) || e instanceof n.Uint8Array)) throw new TypeError('"buf" argument must be a Buffer or Uint8Array');
if ("function" == typeof t) {
i = t;
t = 0;
r = e.length;
} else if ("function" == typeof r) {
i = r;
r = e.length - t;
} else if ("function" != typeof i) throw new TypeError('"cb" argument must be a function');
h(t, e.length);
d(r, t, e.length);
return l(e, t, r, i);
};
r.randomFillSync = function(e, t, r) {
"undefined" == typeof t && (t = 0);
if (!(a.isBuffer(e) || e instanceof n.Uint8Array)) throw new TypeError('"buf" argument must be a Buffer or Uint8Array');
h(t, e.length);
void 0 === r && (r = e.length - t);
d(r, t, e.length);
return l(e, t, r);
};
} else {
r.randomFill = i;
r.randomFillSync = i;
}
function l(e, r, n, i) {
if (t.browser) {
var o = e.buffer, a = new Uint8Array(o, r, n);
c.getRandomValues(a);
if (i) {
t.nextTick(function() {
i(null, e);
});
return;
}
return e;
}
if (!i) {
s(n).copy(e, r);
return e;
}
s(n, function(t, n) {
if (t) return i(t);
n.copy(e, r);
i(null, e);
});
}
}).call(this, e("_process"), "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
_process: 157,
randombytes: 165,
"safe-buffer": 183
} ],
167: [ function(e, t) {
t.exports = e("./lib/_stream_duplex.js");
}, {
"./lib/_stream_duplex.js": 168
} ],
168: [ function(e, t) {
"use strict";
var r = e("process-nextick-args"), n = Object.keys || function(e) {
var t = [];
for (var r in e) t.push(r);
return t;
};
t.exports = u;
var i = Object.create(e("core-util-is"));
i.inherits = e("inherits");
var o = e("./_stream_readable"), s = e("./_stream_writable");
i.inherits(u, o);
for (var a = n(s.prototype), f = 0; f < a.length; f++) {
var c = a[f];
u.prototype[c] || (u.prototype[c] = s.prototype[c]);
}
function u(e) {
if (!(this instanceof u)) return new u(e);
o.call(this, e);
s.call(this, e);
e && !1 === e.readable && (this.readable = !1);
e && !1 === e.writable && (this.writable = !1);
this.allowHalfOpen = !0;
e && !1 === e.allowHalfOpen && (this.allowHalfOpen = !1);
this.once("end", h);
}
Object.defineProperty(u.prototype, "writableHighWaterMark", {
enumerable: !1,
get: function() {
return this._writableState.highWaterMark;
}
});
function h() {
this.allowHalfOpen || this._writableState.ended || r.nextTick(d, this);
}
function d(e) {
e.end();
}
Object.defineProperty(u.prototype, "destroyed", {
get: function() {
return void 0 !== this._readableState && void 0 !== this._writableState && this._readableState.destroyed && this._writableState.destroyed;
},
set: function(e) {
if (void 0 !== this._readableState && void 0 !== this._writableState) {
this._readableState.destroyed = e;
this._writableState.destroyed = e;
}
}
});
u.prototype._destroy = function(e, t) {
this.push(null);
this.end();
r.nextTick(t, e);
};
}, {
"./_stream_readable": 170,
"./_stream_writable": 172,
"core-util-is": 68,
inherits: 138,
"process-nextick-args": 156
} ],
169: [ function(e, t) {
"use strict";
t.exports = i;
var r = e("./_stream_transform"), n = Object.create(e("core-util-is"));
n.inherits = e("inherits");
n.inherits(i, r);
function i(e) {
if (!(this instanceof i)) return new i(e);
r.call(this, e);
}
i.prototype._transform = function(e, t, r) {
r(null, e);
};
}, {
"./_stream_transform": 171,
"core-util-is": 68,
inherits: 138
} ],
170: [ function(e, t) {
(function(r, n) {
"use strict";
var i = e("process-nextick-args");
t.exports = w;
var o, s = e("isarray");
w.ReadableState = _;
e("events").EventEmitter;
var a = function(e, t) {
return e.listeners(t).length;
}, f = e("./internal/streams/stream"), c = e("safe-buffer").Buffer, u = n.Uint8Array || function() {};
function h(e) {
return c.from(e);
}
var d = Object.create(e("core-util-is"));
d.inherits = e("inherits");
var l = e("util"), p = void 0;
p = l && l.debuglog ? l.debuglog("stream") : function() {};
var b, m = e("./internal/streams/BufferList"), v = e("./internal/streams/destroy");
d.inherits(w, f);
var y = [ "error", "close", "destroy", "pause", "resume" ];
function g(e, t, r) {
if ("function" == typeof e.prependListener) return e.prependListener(t, r);
e._events && e._events[t] ? s(e._events[t]) ? e._events[t].unshift(r) : e._events[t] = [ r, e._events[t] ] : e.on(t, r);
}
function _(t, r) {
t = t || {};
var n = r instanceof (o = o || e("./_stream_duplex"));
this.objectMode = !!t.objectMode;
n && (this.objectMode = this.objectMode || !!t.readableObjectMode);
var i = t.highWaterMark, s = t.readableHighWaterMark, a = this.objectMode ? 16 : 16384;
this.highWaterMark = i || 0 === i ? i : n && (s || 0 === s) ? s : a;
this.highWaterMark = Math.floor(this.highWaterMark);
this.buffer = new m();
this.length = 0;
this.pipes = null;
this.pipesCount = 0;
this.flowing = null;
this.ended = !1;
this.endEmitted = !1;
this.reading = !1;
this.sync = !0;
this.needReadable = !1;
this.emittedReadable = !1;
this.readableListening = !1;
this.resumeScheduled = !1;
this.destroyed = !1;
this.defaultEncoding = t.defaultEncoding || "utf8";
this.awaitDrain = 0;
this.readingMore = !1;
this.decoder = null;
this.encoding = null;
if (t.encoding) {
b || (b = e("string_decoder/").StringDecoder);
this.decoder = new b(t.encoding);
this.encoding = t.encoding;
}
}
function w(t) {
o = o || e("./_stream_duplex");
if (!(this instanceof w)) return new w(t);
this._readableState = new _(t, this);
this.readable = !0;
if (t) {
"function" == typeof t.read && (this._read = t.read);
"function" == typeof t.destroy && (this._destroy = t.destroy);
}
f.call(this);
}
Object.defineProperty(w.prototype, "destroyed", {
get: function() {
return void 0 !== this._readableState && this._readableState.destroyed;
},
set: function(e) {
this._readableState && (this._readableState.destroyed = e);
}
});
w.prototype.destroy = v.destroy;
w.prototype._undestroy = v.undestroy;
w.prototype._destroy = function(e, t) {
this.push(null);
t(e);
};
w.prototype.push = function(e, t) {
var r, n = this._readableState;
if (n.objectMode) r = !0; else if ("string" == typeof e) {
if ((t = t || n.defaultEncoding) !== n.encoding) {
e = c.from(e, t);
t = "";
}
r = !0;
}
return E(this, e, t, !1, r);
};
w.prototype.unshift = function(e) {
return E(this, e, null, !0, !1);
};
function E(e, t, r, n, i) {
var o = e._readableState;
if (null === t) {
o.reading = !1;
I(e, o);
} else {
var s;
i || (s = M(o, t));
if (s) e.emit("error", s); else if (o.objectMode || t && t.length > 0) {
"string" == typeof t || o.objectMode || Object.getPrototypeOf(t) === c.prototype || (t = h(t));
if (n) o.endEmitted ? e.emit("error", new Error("stream.unshift() after end event")) : S(e, o, t, !0); else if (o.ended) e.emit("error", new Error("stream.push() after EOF")); else {
o.reading = !1;
if (o.decoder && !r) {
t = o.decoder.write(t);
o.objectMode || 0 !== t.length ? S(e, o, t, !1) : C(e, o);
} else S(e, o, t, !1);
}
} else n || (o.reading = !1);
}
return A(o);
}
function S(e, t, r, n) {
if (t.flowing && 0 === t.length && !t.sync) {
e.emit("data", r);
e.read(0);
} else {
t.length += t.objectMode ? 1 : r.length;
n ? t.buffer.unshift(r) : t.buffer.push(r);
t.needReadable && O(e);
}
C(e, t);
}
function M(e, t) {
var r, n;
(n = t, c.isBuffer(n) || n instanceof u) || "string" == typeof t || void 0 === t || e.objectMode || (r = new TypeError("Invalid non-string/buffer chunk"));
return r;
}
function A(e) {
return !e.ended && (e.needReadable || e.length < e.highWaterMark || 0 === e.length);
}
w.prototype.isPaused = function() {
return !1 === this._readableState.flowing;
};
w.prototype.setEncoding = function(t) {
b || (b = e("string_decoder/").StringDecoder);
this._readableState.decoder = new b(t);
this._readableState.encoding = t;
return this;
};
var x = 8388608;
function k(e) {
if (e >= x) e = x; else {
e--;
e |= e >>> 1;
e |= e >>> 2;
e |= e >>> 4;
e |= e >>> 8;
e |= e >>> 16;
e++;
}
return e;
}
function T(e, t) {
if (e <= 0 || 0 === t.length && t.ended) return 0;
if (t.objectMode) return 1;
if (e != e) return t.flowing && t.length ? t.buffer.head.data.length : t.length;
e > t.highWaterMark && (t.highWaterMark = k(e));
if (e <= t.length) return e;
if (!t.ended) {
t.needReadable = !0;
return 0;
}
return t.length;
}
w.prototype.read = function(e) {
p("read", e);
e = parseInt(e, 10);
var t = this._readableState, r = e;
0 !== e && (t.emittedReadable = !1);
if (0 === e && t.needReadable && (t.length >= t.highWaterMark || t.ended)) {
p("read: emitReadable", t.length, t.ended);
0 === t.length && t.ended ? H(this) : O(this);
return null;
}
if (0 === (e = T(e, t)) && t.ended) {
0 === t.length && H(this);
return null;
}
var n, i = t.needReadable;
p("need readable", i);
(0 === t.length || t.length - e < t.highWaterMark) && p("length less than watermark", i = !0);
if (t.ended || t.reading) p("reading or ended", i = !1); else if (i) {
p("do read");
t.reading = !0;
t.sync = !0;
0 === t.length && (t.needReadable = !0);
this._read(t.highWaterMark);
t.sync = !1;
t.reading || (e = T(r, t));
}
if (null === (n = e > 0 ? U(e, t) : null)) {
t.needReadable = !0;
e = 0;
} else t.length -= e;
if (0 === t.length) {
t.ended || (t.needReadable = !0);
r !== e && t.ended && H(this);
}
null !== n && this.emit("data", n);
return n;
};
function I(e, t) {
if (!t.ended) {
if (t.decoder) {
var r = t.decoder.end();
if (r && r.length) {
t.buffer.push(r);
t.length += t.objectMode ? 1 : r.length;
}
}
t.ended = !0;
O(e);
}
}
function O(e) {
var t = e._readableState;
t.needReadable = !1;
if (!t.emittedReadable) {
p("emitReadable", t.flowing);
t.emittedReadable = !0;
t.sync ? i.nextTick(R, e) : R(e);
}
}
function R(e) {
p("emit readable");
e.emit("readable");
B(e);
}
function C(e, t) {
if (!t.readingMore) {
t.readingMore = !0;
i.nextTick(N, e, t);
}
}
function N(e, t) {
for (var r = t.length; !t.reading && !t.flowing && !t.ended && t.length < t.highWaterMark; ) {
p("maybeReadMore read 0");
e.read(0);
if (r === t.length) break;
r = t.length;
}
t.readingMore = !1;
}
w.prototype._read = function() {
this.emit("error", new Error("_read() is not implemented"));
};
w.prototype.pipe = function(e, t) {
var n = this, o = this._readableState;
switch (o.pipesCount) {
case 0:
o.pipes = e;
break;

case 1:
o.pipes = [ o.pipes, e ];
break;

default:
o.pipes.push(e);
}
o.pipesCount += 1;
p("pipe count=%d opts=%j", o.pipesCount, t);
var s = t && !1 === t.end || e === r.stdout || e === r.stderr ? _ : c;
o.endEmitted ? i.nextTick(s) : n.once("end", s);
e.on("unpipe", f);
function f(e, t) {
p("onunpipe");
if (e === n && t && !1 === t.hasUnpiped) {
t.hasUnpiped = !0;
d();
}
}
function c() {
p("onend");
e.end();
}
var u = j(n);
e.on("drain", u);
var h = !1;
function d() {
p("cleanup");
e.removeListener("close", v);
e.removeListener("finish", y);
e.removeListener("drain", u);
e.removeListener("error", m);
e.removeListener("unpipe", f);
n.removeListener("end", c);
n.removeListener("end", _);
n.removeListener("data", b);
h = !0;
!o.awaitDrain || e._writableState && !e._writableState.needDrain || u();
}
var l = !1;
n.on("data", b);
function b(t) {
p("ondata");
l = !1;
if (!1 === e.write(t) && !l) {
if ((1 === o.pipesCount && o.pipes === e || o.pipesCount > 1 && -1 !== G(o.pipes, e)) && !h) {
p("false write response, pause", n._readableState.awaitDrain);
n._readableState.awaitDrain++;
l = !0;
}
n.pause();
}
}
function m(t) {
p("onerror", t);
_();
e.removeListener("error", m);
0 === a(e, "error") && e.emit("error", t);
}
g(e, "error", m);
function v() {
e.removeListener("finish", y);
_();
}
e.once("close", v);
function y() {
p("onfinish");
e.removeListener("close", v);
_();
}
e.once("finish", y);
function _() {
p("unpipe");
n.unpipe(e);
}
e.emit("pipe", n);
if (!o.flowing) {
p("pipe resume");
n.resume();
}
return e;
};
function j(e) {
return function() {
var t = e._readableState;
p("pipeOnDrain", t.awaitDrain);
t.awaitDrain && t.awaitDrain--;
if (0 === t.awaitDrain && a(e, "data")) {
t.flowing = !0;
B(e);
}
};
}
w.prototype.unpipe = function(e) {
var t = this._readableState, r = {
hasUnpiped: !1
};
if (0 === t.pipesCount) return this;
if (1 === t.pipesCount) {
if (e && e !== t.pipes) return this;
e || (e = t.pipes);
t.pipes = null;
t.pipesCount = 0;
t.flowing = !1;
e && e.emit("unpipe", this, r);
return this;
}
if (!e) {
var n = t.pipes, i = t.pipesCount;
t.pipes = null;
t.pipesCount = 0;
t.flowing = !1;
for (var o = 0; o < i; o++) n[o].emit("unpipe", this, r);
return this;
}
var s = G(t.pipes, e);
if (-1 === s) return this;
t.pipes.splice(s, 1);
t.pipesCount -= 1;
1 === t.pipesCount && (t.pipes = t.pipes[0]);
e.emit("unpipe", this, r);
return this;
};
w.prototype.on = function(e, t) {
var r = f.prototype.on.call(this, e, t);
if ("data" === e) !1 !== this._readableState.flowing && this.resume(); else if ("readable" === e) {
var n = this._readableState;
if (!n.endEmitted && !n.readableListening) {
n.readableListening = n.needReadable = !0;
n.emittedReadable = !1;
n.reading ? n.length && O(this) : i.nextTick(P, this);
}
}
return r;
};
w.prototype.addListener = w.prototype.on;
function P(e) {
p("readable nexttick read 0");
e.read(0);
}
w.prototype.resume = function() {
var e = this._readableState;
if (!e.flowing) {
p("resume");
e.flowing = !0;
D(this, e);
}
return this;
};
function D(e, t) {
if (!t.resumeScheduled) {
t.resumeScheduled = !0;
i.nextTick(L, e, t);
}
}
function L(e, t) {
if (!t.reading) {
p("resume read 0");
e.read(0);
}
t.resumeScheduled = !1;
t.awaitDrain = 0;
e.emit("resume");
B(e);
t.flowing && !t.reading && e.read(0);
}
w.prototype.pause = function() {
p("call pause flowing=%j", this._readableState.flowing);
if (!1 !== this._readableState.flowing) {
p("pause");
this._readableState.flowing = !1;
this.emit("pause");
}
return this;
};
function B(e) {
var t = e._readableState;
p("flow", t.flowing);
for (;t.flowing && null !== e.read(); ) ;
}
w.prototype.wrap = function(e) {
var t = this, r = this._readableState, n = !1;
e.on("end", function() {
p("wrapped end");
if (r.decoder && !r.ended) {
var e = r.decoder.end();
e && e.length && t.push(e);
}
t.push(null);
});
e.on("data", function(i) {
p("wrapped data");
r.decoder && (i = r.decoder.write(i));
if ((!r.objectMode || null != i) && (r.objectMode || i && i.length) && !t.push(i)) {
n = !0;
e.pause();
}
});
for (var i in e) void 0 === this[i] && "function" == typeof e[i] && (this[i] = function(t) {
return function() {
return e[t].apply(e, arguments);
};
}(i));
for (var o = 0; o < y.length; o++) e.on(y[o], this.emit.bind(this, y[o]));
this._read = function(t) {
p("wrapped _read", t);
if (n) {
n = !1;
e.resume();
}
};
return this;
};
Object.defineProperty(w.prototype, "readableHighWaterMark", {
enumerable: !1,
get: function() {
return this._readableState.highWaterMark;
}
});
w._fromList = U;
function U(e, t) {
if (0 === t.length) return null;
var r;
if (t.objectMode) r = t.buffer.shift(); else if (!e || e >= t.length) {
r = t.decoder ? t.buffer.join("") : 1 === t.buffer.length ? t.buffer.head.data : t.buffer.concat(t.length);
t.buffer.clear();
} else r = F(e, t.buffer, t.decoder);
return r;
}
function F(e, t, r) {
var n;
if (e < t.head.data.length) {
n = t.head.data.slice(0, e);
t.head.data = t.head.data.slice(e);
} else n = e === t.head.data.length ? t.shift() : r ? q(e, t) : V(e, t);
return n;
}
function q(e, t) {
var r = t.head, n = 1, i = r.data;
e -= i.length;
for (;r = r.next; ) {
var o = r.data, s = e > o.length ? o.length : e;
s === o.length ? i += o : i += o.slice(0, e);
if (0 == (e -= s)) {
if (s === o.length) {
++n;
r.next ? t.head = r.next : t.head = t.tail = null;
} else {
t.head = r;
r.data = o.slice(s);
}
break;
}
++n;
}
t.length -= n;
return i;
}
function V(e, t) {
var r = c.allocUnsafe(e), n = t.head, i = 1;
n.data.copy(r);
e -= n.data.length;
for (;n = n.next; ) {
var o = n.data, s = e > o.length ? o.length : e;
o.copy(r, r.length - e, 0, s);
if (0 == (e -= s)) {
if (s === o.length) {
++i;
n.next ? t.head = n.next : t.head = t.tail = null;
} else {
t.head = n;
n.data = o.slice(s);
}
break;
}
++i;
}
t.length -= i;
return r;
}
function H(e) {
var t = e._readableState;
if (t.length > 0) throw new Error('"endReadable()" called on non-empty stream');
if (!t.endEmitted) {
t.ended = !0;
i.nextTick(z, t, e);
}
}
function z(e, t) {
if (!e.endEmitted && 0 === e.length) {
e.endEmitted = !0;
t.readable = !1;
t.emit("end");
}
}
function G(e, t) {
for (var r = 0, n = e.length; r < n; r++) if (e[r] === t) return r;
return -1;
}
}).call(this, e("_process"), "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"./_stream_duplex": 168,
"./internal/streams/BufferList": 173,
"./internal/streams/destroy": 174,
"./internal/streams/stream": 175,
_process: 157,
"core-util-is": 68,
events: 104,
inherits: 138,
isarray: 176,
"process-nextick-args": 156,
"safe-buffer": 183,
"string_decoder/": 177,
util: 19
} ],
171: [ function(e, t) {
"use strict";
t.exports = o;
var r = e("./_stream_duplex"), n = Object.create(e("core-util-is"));
n.inherits = e("inherits");
n.inherits(o, r);
function i(e, t) {
var r = this._transformState;
r.transforming = !1;
var n = r.writecb;
if (!n) return this.emit("error", new Error("write callback called multiple times"));
r.writechunk = null;
r.writecb = null;
null != t && this.push(t);
n(e);
var i = this._readableState;
i.reading = !1;
(i.needReadable || i.length < i.highWaterMark) && this._read(i.highWaterMark);
}
function o(e) {
if (!(this instanceof o)) return new o(e);
r.call(this, e);
this._transformState = {
afterTransform: i.bind(this),
needTransform: !1,
transforming: !1,
writecb: null,
writechunk: null,
writeencoding: null
};
this._readableState.needReadable = !0;
this._readableState.sync = !1;
if (e) {
"function" == typeof e.transform && (this._transform = e.transform);
"function" == typeof e.flush && (this._flush = e.flush);
}
this.on("prefinish", s);
}
function s() {
var e = this;
"function" == typeof this._flush ? this._flush(function(t, r) {
a(e, t, r);
}) : a(this, null, null);
}
o.prototype.push = function(e, t) {
this._transformState.needTransform = !1;
return r.prototype.push.call(this, e, t);
};
o.prototype._transform = function() {
throw new Error("_transform() is not implemented");
};
o.prototype._write = function(e, t, r) {
var n = this._transformState;
n.writecb = r;
n.writechunk = e;
n.writeencoding = t;
if (!n.transforming) {
var i = this._readableState;
(n.needTransform || i.needReadable || i.length < i.highWaterMark) && this._read(i.highWaterMark);
}
};
o.prototype._read = function() {
var e = this._transformState;
if (null !== e.writechunk && e.writecb && !e.transforming) {
e.transforming = !0;
this._transform(e.writechunk, e.writeencoding, e.afterTransform);
} else e.needTransform = !0;
};
o.prototype._destroy = function(e, t) {
var n = this;
r.prototype._destroy.call(this, e, function(e) {
t(e);
n.emit("close");
});
};
function a(e, t, r) {
if (t) return e.emit("error", t);
null != r && e.push(r);
if (e._writableState.length) throw new Error("Calling transform done when ws.length != 0");
if (e._transformState.transforming) throw new Error("Calling transform done when still transforming");
return e.push(null);
}
}, {
"./_stream_duplex": 168,
"core-util-is": 68,
inherits: 138
} ],
172: [ function(e, t) {
(function(r, n) {
"use strict";
var i = e("process-nextick-args");
t.exports = y;
function o(e) {
var t = this;
this.next = null;
this.entry = null;
this.finish = function() {
P(t, e);
};
}
var s, a = !r.browser && [ "v0.10", "v0.9." ].indexOf(r.version.slice(0, 5)) > -1 ? setImmediate : i.nextTick;
y.WritableState = v;
var f = Object.create(e("core-util-is"));
f.inherits = e("inherits");
var c = {
deprecate: e("util-deprecate")
}, u = e("./internal/streams/stream"), h = e("safe-buffer").Buffer, d = n.Uint8Array || function() {};
function l(e) {
return h.from(e);
}
var p, b = e("./internal/streams/destroy");
f.inherits(y, u);
function m() {}
function v(t, r) {
s = s || e("./_stream_duplex");
t = t || {};
var n = r instanceof s;
this.objectMode = !!t.objectMode;
n && (this.objectMode = this.objectMode || !!t.writableObjectMode);
var i = t.highWaterMark, a = t.writableHighWaterMark, f = this.objectMode ? 16 : 16384;
this.highWaterMark = i || 0 === i ? i : n && (a || 0 === a) ? a : f;
this.highWaterMark = Math.floor(this.highWaterMark);
this.finalCalled = !1;
this.needDrain = !1;
this.ending = !1;
this.ended = !1;
this.finished = !1;
this.destroyed = !1;
var c = !1 === t.decodeStrings;
this.decodeStrings = !c;
this.defaultEncoding = t.defaultEncoding || "utf8";
this.length = 0;
this.writing = !1;
this.corked = 0;
this.sync = !0;
this.bufferProcessing = !1;
this.onwrite = function(e) {
x(r, e);
};
this.writecb = null;
this.writelen = 0;
this.bufferedRequest = null;
this.lastBufferedRequest = null;
this.pendingcb = 0;
this.prefinished = !1;
this.errorEmitted = !1;
this.bufferedRequestCount = 0;
this.corkedRequestsFree = new o(this);
}
v.prototype.getBuffer = function() {
for (var e = this.bufferedRequest, t = []; e; ) {
t.push(e);
e = e.next;
}
return t;
};
(function() {
try {
Object.defineProperty(v.prototype, "buffer", {
get: c.deprecate(function() {
return this.getBuffer();
}, "_writableState.buffer is deprecated. Use _writableState.getBuffer instead.", "DEP0003")
});
} catch (e) {}
})();
if ("function" == typeof Symbol && Symbol.hasInstance && "function" == typeof Function.prototype[Symbol.hasInstance]) {
p = Function.prototype[Symbol.hasInstance];
Object.defineProperty(y, Symbol.hasInstance, {
value: function(e) {
return !!p.call(this, e) || this === y && e && e._writableState instanceof v;
}
});
} else p = function(e) {
return e instanceof this;
};
function y(t) {
s = s || e("./_stream_duplex");
if (!(p.call(y, this) || this instanceof s)) return new y(t);
this._writableState = new v(t, this);
this.writable = !0;
if (t) {
"function" == typeof t.write && (this._write = t.write);
"function" == typeof t.writev && (this._writev = t.writev);
"function" == typeof t.destroy && (this._destroy = t.destroy);
"function" == typeof t.final && (this._final = t.final);
}
u.call(this);
}
y.prototype.pipe = function() {
this.emit("error", new Error("Cannot pipe, not readable"));
};
function g(e, t) {
var r = new Error("write after end");
e.emit("error", r);
i.nextTick(t, r);
}
function _(e, t, r, n) {
var o = !0, s = !1;
null === r ? s = new TypeError("May not write null values to stream") : "string" == typeof r || void 0 === r || t.objectMode || (s = new TypeError("Invalid non-string/buffer chunk"));
if (s) {
e.emit("error", s);
i.nextTick(n, s);
o = !1;
}
return o;
}
y.prototype.write = function(e, t, r) {
var n, i = this._writableState, o = !1, s = !i.objectMode && (n = e, h.isBuffer(n) || n instanceof d);
s && !h.isBuffer(e) && (e = l(e));
if ("function" == typeof t) {
r = t;
t = null;
}
s ? t = "buffer" : t || (t = i.defaultEncoding);
"function" != typeof r && (r = m);
if (i.ended) g(this, r); else if (s || _(this, i, e, r)) {
i.pendingcb++;
o = E(this, i, s, e, t, r);
}
return o;
};
y.prototype.cork = function() {
this._writableState.corked++;
};
y.prototype.uncork = function() {
var e = this._writableState;
if (e.corked) {
e.corked--;
e.writing || e.corked || e.finished || e.bufferProcessing || !e.bufferedRequest || I(this, e);
}
};
y.prototype.setDefaultEncoding = function(e) {
"string" == typeof e && (e = e.toLowerCase());
if (!([ "hex", "utf8", "utf-8", "ascii", "binary", "base64", "ucs2", "ucs-2", "utf16le", "utf-16le", "raw" ].indexOf((e + "").toLowerCase()) > -1)) throw new TypeError("Unknown encoding: " + e);
this._writableState.defaultEncoding = e;
return this;
};
function w(e, t, r) {
e.objectMode || !1 === e.decodeStrings || "string" != typeof t || (t = h.from(t, r));
return t;
}
Object.defineProperty(y.prototype, "writableHighWaterMark", {
enumerable: !1,
get: function() {
return this._writableState.highWaterMark;
}
});
function E(e, t, r, n, i, o) {
if (!r) {
var s = w(t, n, i);
if (n !== s) {
r = !0;
i = "buffer";
n = s;
}
}
var a = t.objectMode ? 1 : n.length;
t.length += a;
var f = t.length < t.highWaterMark;
f || (t.needDrain = !0);
if (t.writing || t.corked) {
var c = t.lastBufferedRequest;
t.lastBufferedRequest = {
chunk: n,
encoding: i,
isBuf: r,
callback: o,
next: null
};
c ? c.next = t.lastBufferedRequest : t.bufferedRequest = t.lastBufferedRequest;
t.bufferedRequestCount += 1;
} else S(e, t, !1, a, n, i, o);
return f;
}
function S(e, t, r, n, i, o, s) {
t.writelen = n;
t.writecb = s;
t.writing = !0;
t.sync = !0;
r ? e._writev(i, t.onwrite) : e._write(i, o, t.onwrite);
t.sync = !1;
}
function M(e, t, r, n, o) {
--t.pendingcb;
if (r) {
i.nextTick(o, n);
i.nextTick(N, e, t);
e._writableState.errorEmitted = !0;
e.emit("error", n);
} else {
o(n);
e._writableState.errorEmitted = !0;
e.emit("error", n);
N(e, t);
}
}
function A(e) {
e.writing = !1;
e.writecb = null;
e.length -= e.writelen;
e.writelen = 0;
}
function x(e, t) {
var r = e._writableState, n = r.sync, i = r.writecb;
A(r);
if (t) M(e, r, n, t, i); else {
var o = O(r);
o || r.corked || r.bufferProcessing || !r.bufferedRequest || I(e, r);
n ? a(k, e, r, o, i) : k(e, r, o, i);
}
}
function k(e, t, r, n) {
r || T(e, t);
t.pendingcb--;
n();
N(e, t);
}
function T(e, t) {
if (0 === t.length && t.needDrain) {
t.needDrain = !1;
e.emit("drain");
}
}
function I(e, t) {
t.bufferProcessing = !0;
var r = t.bufferedRequest;
if (e._writev && r && r.next) {
var n = t.bufferedRequestCount, i = new Array(n), s = t.corkedRequestsFree;
s.entry = r;
for (var a = 0, f = !0; r; ) {
i[a] = r;
r.isBuf || (f = !1);
r = r.next;
a += 1;
}
i.allBuffers = f;
S(e, t, !0, t.length, i, "", s.finish);
t.pendingcb++;
t.lastBufferedRequest = null;
if (s.next) {
t.corkedRequestsFree = s.next;
s.next = null;
} else t.corkedRequestsFree = new o(t);
t.bufferedRequestCount = 0;
} else {
for (;r; ) {
var c = r.chunk, u = r.encoding, h = r.callback;
S(e, t, !1, t.objectMode ? 1 : c.length, c, u, h);
r = r.next;
t.bufferedRequestCount--;
if (t.writing) break;
}
null === r && (t.lastBufferedRequest = null);
}
t.bufferedRequest = r;
t.bufferProcessing = !1;
}
y.prototype._write = function(e, t, r) {
r(new Error("_write() is not implemented"));
};
y.prototype._writev = null;
y.prototype.end = function(e, t, r) {
var n = this._writableState;
if ("function" == typeof e) {
r = e;
e = null;
t = null;
} else if ("function" == typeof t) {
r = t;
t = null;
}
null != e && this.write(e, t);
if (n.corked) {
n.corked = 1;
this.uncork();
}
n.ending || n.finished || j(this, n, r);
};
function O(e) {
return e.ending && 0 === e.length && null === e.bufferedRequest && !e.finished && !e.writing;
}
function R(e, t) {
e._final(function(r) {
t.pendingcb--;
r && e.emit("error", r);
t.prefinished = !0;
e.emit("prefinish");
N(e, t);
});
}
function C(e, t) {
if (!t.prefinished && !t.finalCalled) if ("function" == typeof e._final) {
t.pendingcb++;
t.finalCalled = !0;
i.nextTick(R, e, t);
} else {
t.prefinished = !0;
e.emit("prefinish");
}
}
function N(e, t) {
var r = O(t);
if (r) {
C(e, t);
if (0 === t.pendingcb) {
t.finished = !0;
e.emit("finish");
}
}
return r;
}
function j(e, t, r) {
t.ending = !0;
N(e, t);
r && (t.finished ? i.nextTick(r) : e.once("finish", r));
t.ended = !0;
e.writable = !1;
}
function P(e, t, r) {
var n = e.entry;
e.entry = null;
for (;n; ) {
var i = n.callback;
t.pendingcb--;
i(r);
n = n.next;
}
t.corkedRequestsFree ? t.corkedRequestsFree.next = e : t.corkedRequestsFree = e;
}
Object.defineProperty(y.prototype, "destroyed", {
get: function() {
return void 0 !== this._writableState && this._writableState.destroyed;
},
set: function(e) {
this._writableState && (this._writableState.destroyed = e);
}
});
y.prototype.destroy = b.destroy;
y.prototype._undestroy = b.undestroy;
y.prototype._destroy = function(e, t) {
this.end();
t(e);
};
}).call(this, e("_process"), "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"./_stream_duplex": 168,
"./internal/streams/destroy": 174,
"./internal/streams/stream": 175,
_process: 157,
"core-util-is": 68,
inherits: 138,
"process-nextick-args": 156,
"safe-buffer": 183,
"util-deprecate": 195
} ],
173: [ function(e, t) {
"use strict";
function r(e, t) {
if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}
var n = e("safe-buffer").Buffer, i = e("util");
t.exports = function() {
function e() {
r(this, e);
this.head = null;
this.tail = null;
this.length = 0;
}
e.prototype.push = function(e) {
var t = {
data: e,
next: null
};
this.length > 0 ? this.tail.next = t : this.head = t;
this.tail = t;
++this.length;
};
e.prototype.unshift = function(e) {
var t = {
data: e,
next: this.head
};
0 === this.length && (this.tail = t);
this.head = t;
++this.length;
};
e.prototype.shift = function() {
if (0 !== this.length) {
var e = this.head.data;
1 === this.length ? this.head = this.tail = null : this.head = this.head.next;
--this.length;
return e;
}
};
e.prototype.clear = function() {
this.head = this.tail = null;
this.length = 0;
};
e.prototype.join = function(e) {
if (0 === this.length) return "";
for (var t = this.head, r = "" + t.data; t = t.next; ) r += e + t.data;
return r;
};
e.prototype.concat = function(e) {
if (0 === this.length) return n.alloc(0);
if (1 === this.length) return this.head.data;
for (var t, r, i = n.allocUnsafe(e >>> 0), o = this.head, s = 0; o; ) {
t = i, r = s, o.data.copy(t, r);
s += o.data.length;
o = o.next;
}
return i;
};
return e;
}();
i && i.inspect && i.inspect.custom && (t.exports.prototype[i.inspect.custom] = function() {
var e = i.inspect({
length: this.length
});
return this.constructor.name + " " + e;
});
}, {
"safe-buffer": 183,
util: 19
} ],
174: [ function(e, t) {
"use strict";
var r = e("process-nextick-args");
function n(e, t) {
e.emit("error", t);
}
t.exports = {
destroy: function(e, t) {
var i = this, o = this._readableState && this._readableState.destroyed, s = this._writableState && this._writableState.destroyed;
if (o || s) {
t ? t(e) : !e || this._writableState && this._writableState.errorEmitted || r.nextTick(n, this, e);
return this;
}
this._readableState && (this._readableState.destroyed = !0);
this._writableState && (this._writableState.destroyed = !0);
this._destroy(e || null, function(e) {
if (!t && e) {
r.nextTick(n, i, e);
i._writableState && (i._writableState.errorEmitted = !0);
} else t && t(e);
});
return this;
},
undestroy: function() {
if (this._readableState) {
this._readableState.destroyed = !1;
this._readableState.reading = !1;
this._readableState.ended = !1;
this._readableState.endEmitted = !1;
}
if (this._writableState) {
this._writableState.destroyed = !1;
this._writableState.ended = !1;
this._writableState.ending = !1;
this._writableState.finished = !1;
this._writableState.errorEmitted = !1;
}
}
};
}, {
"process-nextick-args": 156
} ],
175: [ function(e, t, r) {
arguments[4][60][0].apply(r, arguments);
}, {
dup: 60,
events: 104
} ],
176: [ function(e, t, r) {
arguments[4][66][0].apply(r, arguments);
}, {
dup: 66
} ],
177: [ function(e, t, r) {
arguments[4][63][0].apply(r, arguments);
}, {
dup: 63,
"safe-buffer": 183
} ],
178: [ function(e, t) {
t.exports = e("./readable").PassThrough;
}, {
"./readable": 179
} ],
179: [ function(e, t, r) {
(r = t.exports = e("./lib/_stream_readable.js")).Stream = r;
r.Readable = r;
r.Writable = e("./lib/_stream_writable.js");
r.Duplex = e("./lib/_stream_duplex.js");
r.Transform = e("./lib/_stream_transform.js");
r.PassThrough = e("./lib/_stream_passthrough.js");
}, {
"./lib/_stream_duplex.js": 168,
"./lib/_stream_passthrough.js": 169,
"./lib/_stream_readable.js": 170,
"./lib/_stream_transform.js": 171,
"./lib/_stream_writable.js": 172
} ],
180: [ function(e, t) {
t.exports = e("./readable").Transform;
}, {
"./readable": 179
} ],
181: [ function(e, t) {
t.exports = e("./lib/_stream_writable.js");
}, {
"./lib/_stream_writable.js": 172
} ],
182: [ function(e, t) {
"use strict";
var r = e("buffer").Buffer, n = e("inherits"), i = e("hash-base"), o = new Array(16), s = [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8, 3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12, 1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2, 4, 0, 5, 9, 7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13 ], a = [ 5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12, 6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2, 15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13, 8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14, 12, 15, 10, 4, 1, 5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11 ], f = [ 11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8, 7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12, 11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5, 11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12, 9, 15, 5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6 ], c = [ 8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6, 9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11, 9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5, 15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8, 8, 5, 12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11 ], u = [ 0, 1518500249, 1859775393, 2400959708, 2840853838 ], h = [ 1352829926, 1548603684, 1836072691, 2053994217, 0 ];
function d() {
i.call(this, 64);
this._a = 1732584193;
this._b = 4023233417;
this._c = 2562383102;
this._d = 271733878;
this._e = 3285377520;
}
n(d, i);
d.prototype._update = function() {
for (var e = o, t = 0; t < 16; ++t) e[t] = this._block.readInt32LE(4 * t);
for (var r = 0 | this._a, n = 0 | this._b, i = 0 | this._c, d = 0 | this._d, g = 0 | this._e, _ = 0 | this._a, w = 0 | this._b, E = 0 | this._c, S = 0 | this._d, M = 0 | this._e, A = 0; A < 80; A += 1) {
var x, k;
if (A < 16) {
x = p(r, n, i, d, g, e[s[A]], u[0], f[A]);
k = y(_, w, E, S, M, e[a[A]], h[0], c[A]);
} else if (A < 32) {
x = b(r, n, i, d, g, e[s[A]], u[1], f[A]);
k = v(_, w, E, S, M, e[a[A]], h[1], c[A]);
} else if (A < 48) {
x = m(r, n, i, d, g, e[s[A]], u[2], f[A]);
k = m(_, w, E, S, M, e[a[A]], h[2], c[A]);
} else if (A < 64) {
x = v(r, n, i, d, g, e[s[A]], u[3], f[A]);
k = b(_, w, E, S, M, e[a[A]], h[3], c[A]);
} else {
x = y(r, n, i, d, g, e[s[A]], u[4], f[A]);
k = p(_, w, E, S, M, e[a[A]], h[4], c[A]);
}
r = g;
g = d;
d = l(i, 10);
i = n;
n = x;
_ = M;
M = S;
S = l(E, 10);
E = w;
w = k;
}
var T = this._b + i + S | 0;
this._b = this._c + d + M | 0;
this._c = this._d + g + _ | 0;
this._d = this._e + r + w | 0;
this._e = this._a + n + E | 0;
this._a = T;
};
d.prototype._digest = function() {
this._block[this._blockOffset++] = 128;
if (this._blockOffset > 56) {
this._block.fill(0, this._blockOffset, 64);
this._update();
this._blockOffset = 0;
}
this._block.fill(0, this._blockOffset, 56);
this._block.writeUInt32LE(this._length[0], 56);
this._block.writeUInt32LE(this._length[1], 60);
this._update();
var e = r.alloc ? r.alloc(20) : new r(20);
e.writeInt32LE(this._a, 0);
e.writeInt32LE(this._b, 4);
e.writeInt32LE(this._c, 8);
e.writeInt32LE(this._d, 12);
e.writeInt32LE(this._e, 16);
return e;
};
function l(e, t) {
return e << t | e >>> 32 - t;
}
function p(e, t, r, n, i, o, s, a) {
return l(e + (t ^ r ^ n) + o + s | 0, a) + i | 0;
}
function b(e, t, r, n, i, o, s, a) {
return l(e + (t & r | ~t & n) + o + s | 0, a) + i | 0;
}
function m(e, t, r, n, i, o, s, a) {
return l(e + ((t | ~r) ^ n) + o + s | 0, a) + i | 0;
}
function v(e, t, r, n, i, o, s, a) {
return l(e + (t & n | r & ~n) + o + s | 0, a) + i | 0;
}
function y(e, t, r, n, i, o, s, a) {
return l(e + (t ^ (r | ~n)) + o + s | 0, a) + i | 0;
}
t.exports = d;
}, {
buffer: 65,
"hash-base": 106,
inherits: 138
} ],
183: [ function(e, t, r) {
var n = e("buffer"), i = n.Buffer;
function o(e, t) {
for (var r in e) t[r] = e[r];
}
if (i.from && i.alloc && i.allocUnsafe && i.allocUnsafeSlow) t.exports = n; else {
o(n, r);
r.Buffer = s;
}
function s(e, t, r) {
return i(e, t, r);
}
o(i, s);
s.from = function(e, t, r) {
if ("number" == typeof e) throw new TypeError("Argument must not be a number");
return i(e, t, r);
};
s.alloc = function(e, t, r) {
if ("number" != typeof e) throw new TypeError("Argument must be a number");
var n = i(e);
void 0 !== t ? "string" == typeof r ? n.fill(t, r) : n.fill(t) : n.fill(0);
return n;
};
s.allocUnsafe = function(e) {
if ("number" != typeof e) throw new TypeError("Argument must be a number");
return i(e);
};
s.allocUnsafeSlow = function(e) {
if ("number" != typeof e) throw new TypeError("Argument must be a number");
return n.SlowBuffer(e);
};
}, {
buffer: 65
} ],
184: [ function(e, t) {
(function(r) {
"use strict";
var n, i = e("buffer"), o = i.Buffer, s = {};
for (n in i) i.hasOwnProperty(n) && "SlowBuffer" !== n && "Buffer" !== n && (s[n] = i[n]);
var a = s.Buffer = {};
for (n in o) o.hasOwnProperty(n) && "allocUnsafe" !== n && "allocUnsafeSlow" !== n && (a[n] = o[n]);
s.Buffer.prototype = o.prototype;
a.from && a.from !== Uint8Array.from || (a.from = function(e, t, r) {
if ("number" == typeof e) throw new TypeError('The "value" argument must not be of type number. Received type ' + typeof e);
if (e && "undefined" == typeof e.length) throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof e);
return o(e, t, r);
});
a.alloc || (a.alloc = function(e, t, r) {
if ("number" != typeof e) throw new TypeError('The "size" argument must be of type number. Received type ' + typeof e);
if (e < 0 || e >= 2 * (1 << 30)) throw new RangeError('The value "' + e + '" is invalid for option "size"');
var n = o(e);
t && 0 !== t.length ? "string" == typeof r ? n.fill(t, r) : n.fill(t) : n.fill(0);
return n;
});
if (!s.kStringMaxLength) try {
s.kStringMaxLength = r.binding("buffer").kStringMaxLength;
} catch (e) {}
if (!s.constants) {
s.constants = {
MAX_LENGTH: s.kMaxLength
};
s.kStringMaxLength && (s.constants.MAX_STRING_LENGTH = s.kStringMaxLength);
}
t.exports = s;
}).call(this, e("_process"));
}, {
_process: 157,
buffer: 65
} ],
185: [ function(e, t) {
var r = e("safe-buffer").Buffer;
function n(e, t) {
this._block = r.alloc(e);
this._finalSize = t;
this._blockSize = e;
this._len = 0;
}
n.prototype.update = function(e, t) {
if ("string" == typeof e) {
t = t || "utf8";
e = r.from(e, t);
}
for (var n = this._block, i = this._blockSize, o = e.length, s = this._len, a = 0; a < o; ) {
for (var f = s % i, c = Math.min(o - a, i - f), u = 0; u < c; u++) n[f + u] = e[a + u];
a += c;
(s += c) % i == 0 && this._update(n);
}
this._len += o;
return this;
};
n.prototype.digest = function(e) {
var t = this._len % this._blockSize;
this._block[t] = 128;
this._block.fill(0, t + 1);
if (t >= this._finalSize) {
this._update(this._block);
this._block.fill(0);
}
var r = 8 * this._len;
if (r <= 4294967295) this._block.writeUInt32BE(r, this._blockSize - 4); else {
var n = (4294967295 & r) >>> 0, i = (r - n) / 4294967296;
this._block.writeUInt32BE(i, this._blockSize - 8);
this._block.writeUInt32BE(n, this._blockSize - 4);
}
this._update(this._block);
var o = this._hash();
return e ? o.toString(e) : o;
};
n.prototype._update = function() {
throw new Error("_update must be implemented by subclass");
};
t.exports = n;
}, {
"safe-buffer": 183
} ],
186: [ function(e, t, r) {
(r = t.exports = function(e) {
e = e.toLowerCase();
var t = r[e];
if (!t) throw new Error(e + " is not supported (we accept pull requests)");
return new t();
}).sha = e("./sha");
r.sha1 = e("./sha1");
r.sha224 = e("./sha224");
r.sha256 = e("./sha256");
r.sha384 = e("./sha384");
r.sha512 = e("./sha512");
}, {
"./sha": 187,
"./sha1": 188,
"./sha224": 189,
"./sha256": 190,
"./sha384": 191,
"./sha512": 192
} ],
187: [ function(e, t) {
var r = e("inherits"), n = e("./hash"), i = e("safe-buffer").Buffer, o = [ 1518500249, 1859775393, -1894007588, -899497514 ], s = new Array(80);
function a() {
this.init();
this._w = s;
n.call(this, 64, 56);
}
r(a, n);
a.prototype.init = function() {
this._a = 1732584193;
this._b = 4023233417;
this._c = 2562383102;
this._d = 271733878;
this._e = 3285377520;
return this;
};
function f(e) {
return e << 30 | e >>> 2;
}
function c(e, t, r, n) {
return 0 === e ? t & r | ~t & n : 2 === e ? t & r | t & n | r & n : t ^ r ^ n;
}
a.prototype._update = function(e) {
for (var t, r = this._w, n = 0 | this._a, i = 0 | this._b, s = 0 | this._c, a = 0 | this._d, u = 0 | this._e, h = 0; h < 16; ++h) r[h] = e.readInt32BE(4 * h);
for (;h < 80; ++h) r[h] = r[h - 3] ^ r[h - 8] ^ r[h - 14] ^ r[h - 16];
for (var d = 0; d < 80; ++d) {
var l = ~~(d / 20), p = ((t = n) << 5 | t >>> 27) + c(l, i, s, a) + u + r[d] + o[l] | 0;
u = a;
a = s;
s = f(i);
i = n;
n = p;
}
this._a = n + this._a | 0;
this._b = i + this._b | 0;
this._c = s + this._c | 0;
this._d = a + this._d | 0;
this._e = u + this._e | 0;
};
a.prototype._hash = function() {
var e = i.allocUnsafe(20);
e.writeInt32BE(0 | this._a, 0);
e.writeInt32BE(0 | this._b, 4);
e.writeInt32BE(0 | this._c, 8);
e.writeInt32BE(0 | this._d, 12);
e.writeInt32BE(0 | this._e, 16);
return e;
};
t.exports = a;
}, {
"./hash": 185,
inherits: 138,
"safe-buffer": 183
} ],
188: [ function(e, t) {
var r = e("inherits"), n = e("./hash"), i = e("safe-buffer").Buffer, o = [ 1518500249, 1859775393, -1894007588, -899497514 ], s = new Array(80);
function a() {
this.init();
this._w = s;
n.call(this, 64, 56);
}
r(a, n);
a.prototype.init = function() {
this._a = 1732584193;
this._b = 4023233417;
this._c = 2562383102;
this._d = 271733878;
this._e = 3285377520;
return this;
};
function f(e) {
return e << 5 | e >>> 27;
}
function c(e) {
return e << 30 | e >>> 2;
}
function u(e, t, r, n) {
return 0 === e ? t & r | ~t & n : 2 === e ? t & r | t & n | r & n : t ^ r ^ n;
}
a.prototype._update = function(e) {
for (var t, r = this._w, n = 0 | this._a, i = 0 | this._b, s = 0 | this._c, a = 0 | this._d, h = 0 | this._e, d = 0; d < 16; ++d) r[d] = e.readInt32BE(4 * d);
for (;d < 80; ++d) r[d] = (t = r[d - 3] ^ r[d - 8] ^ r[d - 14] ^ r[d - 16]) << 1 | t >>> 31;
for (var l = 0; l < 80; ++l) {
var p = ~~(l / 20), b = f(n) + u(p, i, s, a) + h + r[l] + o[p] | 0;
h = a;
a = s;
s = c(i);
i = n;
n = b;
}
this._a = n + this._a | 0;
this._b = i + this._b | 0;
this._c = s + this._c | 0;
this._d = a + this._d | 0;
this._e = h + this._e | 0;
};
a.prototype._hash = function() {
var e = i.allocUnsafe(20);
e.writeInt32BE(0 | this._a, 0);
e.writeInt32BE(0 | this._b, 4);
e.writeInt32BE(0 | this._c, 8);
e.writeInt32BE(0 | this._d, 12);
e.writeInt32BE(0 | this._e, 16);
return e;
};
t.exports = a;
}, {
"./hash": 185,
inherits: 138,
"safe-buffer": 183
} ],
189: [ function(e, t) {
var r = e("inherits"), n = e("./sha256"), i = e("./hash"), o = e("safe-buffer").Buffer, s = new Array(64);
function a() {
this.init();
this._w = s;
i.call(this, 64, 56);
}
r(a, n);
a.prototype.init = function() {
this._a = 3238371032;
this._b = 914150663;
this._c = 812702999;
this._d = 4144912697;
this._e = 4290775857;
this._f = 1750603025;
this._g = 1694076839;
this._h = 3204075428;
return this;
};
a.prototype._hash = function() {
var e = o.allocUnsafe(28);
e.writeInt32BE(this._a, 0);
e.writeInt32BE(this._b, 4);
e.writeInt32BE(this._c, 8);
e.writeInt32BE(this._d, 12);
e.writeInt32BE(this._e, 16);
e.writeInt32BE(this._f, 20);
e.writeInt32BE(this._g, 24);
return e;
};
t.exports = a;
}, {
"./hash": 185,
"./sha256": 190,
inherits: 138,
"safe-buffer": 183
} ],
190: [ function(e, t) {
var r = e("inherits"), n = e("./hash"), i = e("safe-buffer").Buffer, o = [ 1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298 ], s = new Array(64);
function a() {
this.init();
this._w = s;
n.call(this, 64, 56);
}
r(a, n);
a.prototype.init = function() {
this._a = 1779033703;
this._b = 3144134277;
this._c = 1013904242;
this._d = 2773480762;
this._e = 1359893119;
this._f = 2600822924;
this._g = 528734635;
this._h = 1541459225;
return this;
};
function f(e, t, r) {
return r ^ e & (t ^ r);
}
function c(e, t, r) {
return e & t | r & (e | t);
}
function u(e) {
return (e >>> 2 | e << 30) ^ (e >>> 13 | e << 19) ^ (e >>> 22 | e << 10);
}
function h(e) {
return (e >>> 6 | e << 26) ^ (e >>> 11 | e << 21) ^ (e >>> 25 | e << 7);
}
function d(e) {
return (e >>> 7 | e << 25) ^ (e >>> 18 | e << 14) ^ e >>> 3;
}
a.prototype._update = function(e) {
for (var t, r = this._w, n = 0 | this._a, i = 0 | this._b, s = 0 | this._c, a = 0 | this._d, l = 0 | this._e, p = 0 | this._f, b = 0 | this._g, m = 0 | this._h, v = 0; v < 16; ++v) r[v] = e.readInt32BE(4 * v);
for (;v < 64; ++v) r[v] = (((t = r[v - 2]) >>> 17 | t << 15) ^ (t >>> 19 | t << 13) ^ t >>> 10) + r[v - 7] + d(r[v - 15]) + r[v - 16] | 0;
for (var y = 0; y < 64; ++y) {
var g = m + h(l) + f(l, p, b) + o[y] + r[y] | 0, _ = u(n) + c(n, i, s) | 0;
m = b;
b = p;
p = l;
l = a + g | 0;
a = s;
s = i;
i = n;
n = g + _ | 0;
}
this._a = n + this._a | 0;
this._b = i + this._b | 0;
this._c = s + this._c | 0;
this._d = a + this._d | 0;
this._e = l + this._e | 0;
this._f = p + this._f | 0;
this._g = b + this._g | 0;
this._h = m + this._h | 0;
};
a.prototype._hash = function() {
var e = i.allocUnsafe(32);
e.writeInt32BE(this._a, 0);
e.writeInt32BE(this._b, 4);
e.writeInt32BE(this._c, 8);
e.writeInt32BE(this._d, 12);
e.writeInt32BE(this._e, 16);
e.writeInt32BE(this._f, 20);
e.writeInt32BE(this._g, 24);
e.writeInt32BE(this._h, 28);
return e;
};
t.exports = a;
}, {
"./hash": 185,
inherits: 138,
"safe-buffer": 183
} ],
191: [ function(e, t) {
var r = e("inherits"), n = e("./sha512"), i = e("./hash"), o = e("safe-buffer").Buffer, s = new Array(160);
function a() {
this.init();
this._w = s;
i.call(this, 128, 112);
}
r(a, n);
a.prototype.init = function() {
this._ah = 3418070365;
this._bh = 1654270250;
this._ch = 2438529370;
this._dh = 355462360;
this._eh = 1731405415;
this._fh = 2394180231;
this._gh = 3675008525;
this._hh = 1203062813;
this._al = 3238371032;
this._bl = 914150663;
this._cl = 812702999;
this._dl = 4144912697;
this._el = 4290775857;
this._fl = 1750603025;
this._gl = 1694076839;
this._hl = 3204075428;
return this;
};
a.prototype._hash = function() {
var e = o.allocUnsafe(48);
function t(t, r, n) {
e.writeInt32BE(t, n);
e.writeInt32BE(r, n + 4);
}
t(this._ah, this._al, 0);
t(this._bh, this._bl, 8);
t(this._ch, this._cl, 16);
t(this._dh, this._dl, 24);
t(this._eh, this._el, 32);
t(this._fh, this._fl, 40);
return e;
};
t.exports = a;
}, {
"./hash": 185,
"./sha512": 192,
inherits: 138,
"safe-buffer": 183
} ],
192: [ function(e, t) {
var r = e("inherits"), n = e("./hash"), i = e("safe-buffer").Buffer, o = [ 1116352408, 3609767458, 1899447441, 602891725, 3049323471, 3964484399, 3921009573, 2173295548, 961987163, 4081628472, 1508970993, 3053834265, 2453635748, 2937671579, 2870763221, 3664609560, 3624381080, 2734883394, 310598401, 1164996542, 607225278, 1323610764, 1426881987, 3590304994, 1925078388, 4068182383, 2162078206, 991336113, 2614888103, 633803317, 3248222580, 3479774868, 3835390401, 2666613458, 4022224774, 944711139, 264347078, 2341262773, 604807628, 2007800933, 770255983, 1495990901, 1249150122, 1856431235, 1555081692, 3175218132, 1996064986, 2198950837, 2554220882, 3999719339, 2821834349, 766784016, 2952996808, 2566594879, 3210313671, 3203337956, 3336571891, 1034457026, 3584528711, 2466948901, 113926993, 3758326383, 338241895, 168717936, 666307205, 1188179964, 773529912, 1546045734, 1294757372, 1522805485, 1396182291, 2643833823, 1695183700, 2343527390, 1986661051, 1014477480, 2177026350, 1206759142, 2456956037, 344077627, 2730485921, 1290863460, 2820302411, 3158454273, 3259730800, 3505952657, 3345764771, 106217008, 3516065817, 3606008344, 3600352804, 1432725776, 4094571909, 1467031594, 275423344, 851169720, 430227734, 3100823752, 506948616, 1363258195, 659060556, 3750685593, 883997877, 3785050280, 958139571, 3318307427, 1322822218, 3812723403, 1537002063, 2003034995, 1747873779, 3602036899, 1955562222, 1575990012, 2024104815, 1125592928, 2227730452, 2716904306, 2361852424, 442776044, 2428436474, 593698344, 2756734187, 3733110249, 3204031479, 2999351573, 3329325298, 3815920427, 3391569614, 3928383900, 3515267271, 566280711, 3940187606, 3454069534, 4118630271, 4000239992, 116418474, 1914138554, 174292421, 2731055270, 289380356, 3203993006, 460393269, 320620315, 685471733, 587496836, 852142971, 1086792851, 1017036298, 365543100, 1126000580, 2618297676, 1288033470, 3409855158, 1501505948, 4234509866, 1607167915, 987167468, 1816402316, 1246189591 ], s = new Array(160);
function a() {
this.init();
this._w = s;
n.call(this, 128, 112);
}
r(a, n);
a.prototype.init = function() {
this._ah = 1779033703;
this._bh = 3144134277;
this._ch = 1013904242;
this._dh = 2773480762;
this._eh = 1359893119;
this._fh = 2600822924;
this._gh = 528734635;
this._hh = 1541459225;
this._al = 4089235720;
this._bl = 2227873595;
this._cl = 4271175723;
this._dl = 1595750129;
this._el = 2917565137;
this._fl = 725511199;
this._gl = 4215389547;
this._hl = 327033209;
return this;
};
function f(e, t, r) {
return r ^ e & (t ^ r);
}
function c(e, t, r) {
return e & t | r & (e | t);
}
function u(e, t) {
return (e >>> 28 | t << 4) ^ (t >>> 2 | e << 30) ^ (t >>> 7 | e << 25);
}
function h(e, t) {
return (e >>> 14 | t << 18) ^ (e >>> 18 | t << 14) ^ (t >>> 9 | e << 23);
}
function d(e, t) {
return (e >>> 1 | t << 31) ^ (e >>> 8 | t << 24) ^ e >>> 7;
}
function l(e, t) {
return (e >>> 1 | t << 31) ^ (e >>> 8 | t << 24) ^ (e >>> 7 | t << 25);
}
function p(e, t) {
return (e >>> 19 | t << 13) ^ (t >>> 29 | e << 3) ^ e >>> 6;
}
function b(e, t) {
return (e >>> 19 | t << 13) ^ (t >>> 29 | e << 3) ^ (e >>> 6 | t << 26);
}
function m(e, t) {
return e >>> 0 < t >>> 0 ? 1 : 0;
}
a.prototype._update = function(e) {
for (var t = this._w, r = 0 | this._ah, n = 0 | this._bh, i = 0 | this._ch, s = 0 | this._dh, a = 0 | this._eh, v = 0 | this._fh, y = 0 | this._gh, g = 0 | this._hh, _ = 0 | this._al, w = 0 | this._bl, E = 0 | this._cl, S = 0 | this._dl, M = 0 | this._el, A = 0 | this._fl, x = 0 | this._gl, k = 0 | this._hl, T = 0; T < 32; T += 2) {
t[T] = e.readInt32BE(4 * T);
t[T + 1] = e.readInt32BE(4 * T + 4);
}
for (;T < 160; T += 2) {
var I = t[T - 30], O = t[T - 30 + 1], R = d(I, O), C = l(O, I), N = p(I = t[T - 4], O = t[T - 4 + 1]), j = b(O, I), P = t[T - 14], D = t[T - 14 + 1], L = t[T - 32], B = t[T - 32 + 1], U = C + D | 0, F = R + P + m(U, C) | 0;
F = (F = F + N + m(U = U + j | 0, j) | 0) + L + m(U = U + B | 0, B) | 0;
t[T] = F;
t[T + 1] = U;
}
for (var q = 0; q < 160; q += 2) {
F = t[q];
U = t[q + 1];
var V = c(r, n, i), H = c(_, w, E), z = u(r, _), G = u(_, r), W = h(a, M), K = h(M, a), Y = o[q], X = o[q + 1], J = f(a, v, y), Z = f(M, A, x), $ = k + K | 0, Q = g + W + m($, k) | 0;
Q = (Q = (Q = Q + J + m($ = $ + Z | 0, Z) | 0) + Y + m($ = $ + X | 0, X) | 0) + F + m($ = $ + U | 0, U) | 0;
var ee = G + H | 0, te = z + V + m(ee, G) | 0;
g = y;
k = x;
y = v;
x = A;
v = a;
A = M;
a = s + Q + m(M = S + $ | 0, S) | 0;
s = i;
S = E;
i = n;
E = w;
n = r;
w = _;
r = Q + te + m(_ = $ + ee | 0, $) | 0;
}
this._al = this._al + _ | 0;
this._bl = this._bl + w | 0;
this._cl = this._cl + E | 0;
this._dl = this._dl + S | 0;
this._el = this._el + M | 0;
this._fl = this._fl + A | 0;
this._gl = this._gl + x | 0;
this._hl = this._hl + k | 0;
this._ah = this._ah + r + m(this._al, _) | 0;
this._bh = this._bh + n + m(this._bl, w) | 0;
this._ch = this._ch + i + m(this._cl, E) | 0;
this._dh = this._dh + s + m(this._dl, S) | 0;
this._eh = this._eh + a + m(this._el, M) | 0;
this._fh = this._fh + v + m(this._fl, A) | 0;
this._gh = this._gh + y + m(this._gl, x) | 0;
this._hh = this._hh + g + m(this._hl, k) | 0;
};
a.prototype._hash = function() {
var e = i.allocUnsafe(64);
function t(t, r, n) {
e.writeInt32BE(t, n);
e.writeInt32BE(r, n + 4);
}
t(this._ah, this._al, 0);
t(this._bh, this._bl, 8);
t(this._ch, this._cl, 16);
t(this._dh, this._dl, 24);
t(this._eh, this._el, 32);
t(this._fh, this._fl, 40);
t(this._gh, this._gl, 48);
t(this._hh, this._hl, 56);
return e;
};
t.exports = a;
}, {
"./hash": 185,
inherits: 138,
"safe-buffer": 183
} ],
193: [ function(e, t) {
t.exports = n;
var r = e("events").EventEmitter;
e("inherits")(n, r);
n.Readable = e("readable-stream/readable.js");
n.Writable = e("readable-stream/writable.js");
n.Duplex = e("readable-stream/duplex.js");
n.Transform = e("readable-stream/transform.js");
n.PassThrough = e("readable-stream/passthrough.js");
n.Stream = n;
function n() {
r.call(this);
}
n.prototype.pipe = function(e, t) {
var n = this;
function i(t) {
e.writable && !1 === e.write(t) && n.pause && n.pause();
}
n.on("data", i);
function o() {
n.readable && n.resume && n.resume();
}
e.on("drain", o);
if (!(e._isStdio || t && !1 === t.end)) {
n.on("end", a);
n.on("close", f);
}
var s = !1;
function a() {
if (!s) {
s = !0;
e.end();
}
}
function f() {
if (!s) {
s = !0;
"function" == typeof e.destroy && e.destroy();
}
}
function c(e) {
u();
if (0 === r.listenerCount(this, "error")) throw e;
}
n.on("error", c);
e.on("error", c);
function u() {
n.removeListener("data", i);
e.removeListener("drain", o);
n.removeListener("end", a);
n.removeListener("close", f);
n.removeListener("error", c);
e.removeListener("error", c);
n.removeListener("end", u);
n.removeListener("close", u);
e.removeListener("close", u);
}
n.on("end", u);
n.on("close", u);
e.on("close", u);
e.emit("pipe", n);
return e;
};
}, {
events: 104,
inherits: 138,
"readable-stream/duplex.js": 167,
"readable-stream/passthrough.js": 178,
"readable-stream/readable.js": 179,
"readable-stream/transform.js": 180,
"readable-stream/writable.js": 181
} ],
194: [ function(e, t, r) {
var n = e("buffer").Buffer, i = n.isEncoding || function(e) {
switch (e && e.toLowerCase()) {
case "hex":
case "utf8":
case "utf-8":
case "ascii":
case "binary":
case "base64":
case "ucs2":
case "ucs-2":
case "utf16le":
case "utf-16le":
case "raw":
return !0;

default:
return !1;
}
};
function o(e) {
if (e && !i(e)) throw new Error("Unknown encoding: " + e);
}
var s = r.StringDecoder = function(e) {
this.encoding = (e || "utf8").toLowerCase().replace(/[-_]/, "");
o(e);
switch (this.encoding) {
case "utf8":
this.surrogateSize = 3;
break;

case "ucs2":
case "utf16le":
this.surrogateSize = 2;
this.detectIncompleteChar = f;
break;

case "base64":
this.surrogateSize = 3;
this.detectIncompleteChar = c;
break;

default:
this.write = a;
return;
}
this.charBuffer = new n(6);
this.charReceived = 0;
this.charLength = 0;
};
s.prototype.write = function(e) {
for (var t = ""; this.charLength; ) {
var r = e.length >= this.charLength - this.charReceived ? this.charLength - this.charReceived : e.length;
e.copy(this.charBuffer, this.charReceived, 0, r);
this.charReceived += r;
if (this.charReceived < this.charLength) return "";
e = e.slice(r, e.length);
if (!((n = (t = this.charBuffer.slice(0, this.charLength).toString(this.encoding)).charCodeAt(t.length - 1)) >= 55296 && n <= 56319)) {
this.charReceived = this.charLength = 0;
if (0 === e.length) return t;
break;
}
this.charLength += this.surrogateSize;
t = "";
}
this.detectIncompleteChar(e);
var n, i = e.length;
if (this.charLength) {
e.copy(this.charBuffer, 0, e.length - this.charReceived, i);
i -= this.charReceived;
}
i = (t += e.toString(this.encoding, 0, i)).length - 1;
if ((n = t.charCodeAt(i)) >= 55296 && n <= 56319) {
var o = this.surrogateSize;
this.charLength += o;
this.charReceived += o;
this.charBuffer.copy(this.charBuffer, o, 0, o);
e.copy(this.charBuffer, 0, 0, o);
return t.substring(0, i);
}
return t;
};
s.prototype.detectIncompleteChar = function(e) {
for (var t = e.length >= 3 ? 3 : e.length; t > 0; t--) {
var r = e[e.length - t];
if (1 == t && r >> 5 == 6) {
this.charLength = 2;
break;
}
if (t <= 2 && r >> 4 == 14) {
this.charLength = 3;
break;
}
if (t <= 3 && r >> 3 == 30) {
this.charLength = 4;
break;
}
}
this.charReceived = t;
};
s.prototype.end = function(e) {
var t = "";
e && e.length && (t = this.write(e));
if (this.charReceived) {
var r = this.charReceived, n = this.charBuffer, i = this.encoding;
t += n.slice(0, r).toString(i);
}
return t;
};
function a(e) {
return e.toString(this.encoding);
}
function f(e) {
this.charReceived = e.length % 2;
this.charLength = this.charReceived ? 2 : 0;
}
function c(e) {
this.charReceived = e.length % 3;
this.charLength = this.charReceived ? 3 : 0;
}
}, {
buffer: 65
} ],
195: [ function(e, t) {
(function(e) {
t.exports = function(e, t) {
if (r("noDeprecation")) return e;
var n = !1;
return function() {
if (!n) {
if (r("throwDeprecation")) throw new Error(t);
r("traceDeprecation") ? console.trace(t) : console.warn(t);
n = !0;
}
return e.apply(this, arguments);
};
};
function r(t) {
try {
if (!e.localStorage) return !1;
} catch (e) {
return !1;
}
var r = e.localStorage[t];
return null != r && "true" === String(r).toLowerCase();
}
}).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
DropDownItem: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "0e0c1OzYPVOfpEPKQp433tu", "DropDownItem");
var n, i = this && this.__extends || (n = function(e, t) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
})(e, t);
}, function(e, t) {
n(e, t);
function r() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, new r());
}), o = this && this.__decorate || function(e, t, r, n) {
var i, o = arguments.length, s = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, n); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (s = (o < 3 ? i(s) : o > 3 ? i(t, r, s) : i(t, r)) || s);
return o > 3 && s && Object.defineProperty(t, r, s), s;
};
Object.defineProperty(r, "__esModule", {
value: !0
});
var s = cc._decorator, a = s.ccclass, f = s.property, c = function(e) {
i(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.label = void 0;
t.sprite = void 0;
t.toggle = void 0;
return t;
}
o([ f(cc.Label) ], t.prototype, "label", void 0);
o([ f(cc.Sprite) ], t.prototype, "sprite", void 0);
o([ f(cc.Toggle) ], t.prototype, "toggle", void 0);
return o([ a() ], t);
}(cc.Component);
r.default = c;
cc._RF.pop();
}, {} ],
DropDownOptionData: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "fd5cfBXVIZC4Ks6evy9ygnF", "DropDownOptionData");
var n = this && this.__decorate || function(e, t, r, n) {
var i, o = arguments.length, s = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, n); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (s = (o < 3 ? i(s) : o > 3 ? i(t, r, s) : i(t, r)) || s);
return o > 3 && s && Object.defineProperty(t, r, s), s;
};
Object.defineProperty(r, "__esModule", {
value: !0
});
var i = cc._decorator, o = i.ccclass, s = i.property, a = function() {
function e() {
this.optionString = "";
this.optionSf = null;
}
n([ s(cc.String) ], e.prototype, "optionString", void 0);
n([ s(cc.SpriteFrame) ], e.prototype, "optionSf", void 0);
return n([ o("DropDownOptionData") ], e);
}();
r.default = a;
cc._RF.pop();
}, {} ],
DropDown: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "4c73768DrRIEpBrhG+kF/zC", "DropDown");
var n, i = this && this.__extends || (n = function(e, t) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
})(e, t);
}, function(e, t) {
n(e, t);
function r() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, new r());
}), o = this && this.__decorate || function(e, t, r, n) {
var i, o = arguments.length, s = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, n); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (s = (o < 3 ? i(s) : o > 3 ? i(t, r, s) : i(t, r)) || s);
return o > 3 && s && Object.defineProperty(t, r, s), s;
}, s = this && this.__awaiter || function(e, t, r, n) {
return new (r || (r = Promise))(function(i, o) {
function s(e) {
try {
f(n.next(e));
} catch (e) {
o(e);
}
}
function a(e) {
try {
f(n.throw(e));
} catch (e) {
o(e);
}
}
function f(e) {
e.done ? i(e.value) : (t = e.value, t instanceof r ? t : new r(function(e) {
e(t);
})).then(s, a);
var t;
}
f((n = n.apply(e, t || [])).next());
});
}, a = this && this.__generator || function(e, t) {
var r, n, i, o, s = {
label: 0,
sent: function() {
if (1 & i[0]) throw i[1];
return i[1];
},
trys: [],
ops: []
};
return o = {
next: a(0),
throw: a(1),
return: a(2)
}, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
return this;
}), o;
function a(e) {
return function(t) {
return f([ e, t ]);
};
}
function f(o) {
if (r) throw new TypeError("Generator is already executing.");
for (;s; ) try {
if (r = 1, n && (i = 2 & o[0] ? n.return : o[0] ? n.throw || ((i = n.return) && i.call(n), 
0) : n.next) && !(i = i.call(n, o[1])).done) return i;
(n = 0, i) && (o = [ 2 & o[0], i.value ]);
switch (o[0]) {
case 0:
case 1:
i = o;
break;

case 4:
s.label++;
return {
value: o[1],
done: !1
};

case 5:
s.label++;
n = o[1];
o = [ 0 ];
continue;

case 7:
o = s.ops.pop();
s.trys.pop();
continue;

default:
if (!(i = s.trys, i = i.length > 0 && i[i.length - 1]) && (6 === o[0] || 2 === o[0])) {
s = 0;
continue;
}
if (3 === o[0] && (!i || o[1] > i[0] && o[1] < i[3])) {
s.label = o[1];
break;
}
if (6 === o[0] && s.label < i[1]) {
s.label = i[1];
i = o;
break;
}
if (i && s.label < i[2]) {
s.label = i[2];
s.ops.push(o);
break;
}
i[2] && s.ops.pop();
s.trys.pop();
continue;
}
o = t.call(e, s);
} catch (e) {
o = [ 6, e ];
n = 0;
} finally {
r = i = 0;
}
if (5 & o[0]) throw o[1];
return {
value: o[0] ? o[1] : void 0,
done: !0
};
}
};
Object.defineProperty(r, "__esModule", {
value: !0
});
var f = e("./DropDownOptionData"), c = e("./DropDownItem"), u = cc._decorator, h = u.ccclass, d = u.property, l = function(e) {
i(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.template = void 0;
t.labelCaption = void 0;
t.spriteCaption = void 0;
t.labelItem = void 0;
t.spriteItem = void 0;
t.optionDatas = [];
t.validTemplate = !1;
t.items = [];
t.isShow = !1;
t._selectedIndex = -1;
return t;
}
Object.defineProperty(t.prototype, "selectedIndex", {
get: function() {
return this._selectedIndex;
},
set: function(e) {
this._selectedIndex = e;
this.refreshShownValue();
},
enumerable: !1,
configurable: !0
});
t.prototype.addOptionDatas = function(e) {
var t = this;
e && e.forEach(function(e) {
t.optionDatas.push(e);
});
this.refreshShownValue();
};
t.prototype.clearOptionDatas = function() {
cc.js.clear(this.optionDatas);
this.optionDatas = new Array();
this.refreshShownValue();
};
t.prototype.show = function() {
if (!this.validTemplate) {
this.setUpTemplate();
if (!this.validTemplate) return;
}
this.isShow = !0;
this._dropDown = this.createDropDownList(this.template);
this._dropDown.name = "DropDown List";
this._dropDown.active = !0;
this._dropDown.setParent(this.template.parent);
var e = this._dropDown.getComponentInChildren(c.default), t = e.node.parent;
e.node.active = !0;
cc.js.clear(this.items);
for (var r = 0, n = this.optionDatas.length; r < n; r++) {
var i = this.optionDatas[r], o = this.addItem(i, r == this.selectedIndex, e, this.items);
if (o) {
o.toggle.isChecked = r == this.selectedIndex;
o.toggle.node.on("toggle", this.onSelectedItem, this);
}
}
e.node.active = !1;
t.height = e.node.height * this.optionDatas.length;
};
t.prototype.addItem = function(e, t, r) {
var n = this.createItem(r);
n.node.setParent(r.node.parent);
n.node.active = !0;
n.node.name = "item_" + (this.items.length + e.optionString ? e.optionString : "");
n.toggle && (n.toggle.isChecked = !1);
n.label && (n.label.string = e.optionString);
if (n.sprite) {
n.sprite.spriteFrame = e.optionSf;
n.sprite.enabled = null != e.optionSf;
}
this.items.push(n);
return n;
};
t.prototype.hide = function() {
this.isShow = !1;
null != this._dropDown && this.delayedDestroyDropdownList(.15);
};
t.prototype.delayedDestroyDropdownList = function() {
return s(this, void 0, void 0, function() {
var e, t;
return a(this, function() {
for (e = 0, t = this.items.length; e < t; e++) null != this.items[e] && this.destroyItem(this.items[e]);
cc.js.clear(this.items);
null != this._dropDown && this.destroyDropDownList(this._dropDown);
this._dropDown = void 0;
return [ 2 ];
});
});
};
t.prototype.destroyItem = function() {};
t.prototype.setUpTemplate = function() {
this.validTemplate = !1;
if (this.template) {
this.template.active = !0;
var e = this.template.getComponentInChildren(cc.Toggle);
this.validTemplate = !0;
if (e && e.node != this.template) if (null == this.labelItem || this.labelItem.node.isChildOf(e.node)) {
if (null != this.spriteItem && !this.spriteItem.node.isChildOf(e.node)) {
this.validTemplate = !1;
cc.error("The dropdown template is not valid. The Item Sprite must be on the item Node or children of it.");
}
} else {
this.validTemplate = !1;
cc.error("The dropdown template is not valid. The Item Label must be on the item Node or children of it.");
} else {
this.validTemplate = !1;
cc.error("The dropdown template is not valid. The template must have a child Node with a Toggle component serving as the item.");
}
if (this.validTemplate) {
var t = e.node.addComponent(c.default);
t.label = this.labelItem;
t.sprite = this.spriteItem;
t.toggle = e;
t.node = e.node;
this.template.active = !1;
this.validTemplate = !0;
} else this.template.active = !1;
} else cc.error("The dropdown template is not assigned. The template needs to be assigned and must have a child GameObject with a Toggle component serving as the item");
};
t.prototype.refreshShownValue = function() {
if (!(this.optionDatas.length <= 0)) {
var e = this.optionDatas[this.clamp(this.selectedIndex, 0, this.optionDatas.length - 1)];
this.labelCaption && (e && e.optionString ? this.labelCaption.string = e.optionString : this.labelCaption.string = "");
if (this.spriteCaption) {
e && e.optionSf ? this.spriteCaption.spriteFrame = e.optionSf : this.spriteCaption.spriteFrame = void 0;
this.spriteCaption.enabled = null != this.spriteCaption.spriteFrame;
}
}
};
t.prototype.createDropDownList = function(e) {
return cc.instantiate(e);
};
t.prototype.destroyDropDownList = function(e) {
e.destroy();
};
t.prototype.createItem = function(e) {
return cc.instantiate(e.node).getComponent(c.default);
};
t.prototype.onSelectedItem = function(e) {
for (var t = e.node.parent, r = 0; r < t.childrenCount; r++) if (t.children[r] == e.node) {
this.selectedIndex = r - 1;
break;
}
this.hide();
null != this.callback && this.callback(this.selectedIndex);
};
t.prototype.setCallBack = function(e) {
this.callback = e;
};
t.prototype.onClick = function() {
this.isShow ? this.hide() : this.show();
};
t.prototype.start = function() {
this.template.active = !1;
this.refreshShownValue();
};
t.prototype.onEnable = function() {
this.node.on("touchend", this.onClick, this);
};
t.prototype.onDisable = function() {
this.node.off("touchend", this.onClick, this);
};
t.prototype.clamp = function(e, t, r) {
return e < t ? t : e > r ? r : e;
};
o([ d(cc.Node) ], t.prototype, "template", void 0);
o([ d(cc.Label) ], t.prototype, "labelCaption", void 0);
o([ d(cc.Sprite) ], t.prototype, "spriteCaption", void 0);
o([ d(cc.Label) ], t.prototype, "labelItem", void 0);
o([ d(cc.Sprite) ], t.prototype, "spriteItem", void 0);
o([ d([ f.default ]) ], t.prototype, "optionDatas", void 0);
return o([ h() ], t);
}(cc.Component);
r.default = l;
cc._RF.pop();
}, {
"./DropDownItem": "DropDownItem",
"./DropDownOptionData": "DropDownOptionData"
} ],
Global: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "488fcGn5YZMzKtipwNuZkTw", "Global");
var n = this && this.__decorate || function(e, t, r, n) {
var i, o = arguments.length, s = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, n); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (s = (o < 3 ? i(s) : o > 3 ? i(t, r, s) : i(t, r)) || s);
return o > 3 && s && Object.defineProperty(t, r, s), s;
};
Object.defineProperty(r, "__esModule", {
value: !0
});
r.Global = void 0;
var i = cc._decorator, o = i.ccclass, s = (i.property, function() {
function e() {}
e.PopupSecurity = null;
e.LobbyController = null;
e.PopupRegister = null;
e.BundleLobby = null;
e.isLoginFromOtherPlaces = !1;
e.LanguageManager = null;
return n([ o ], e);
}());
r.Global = s;
cc._RF.pop();
}, {} ],
HelloWorld: [ function(e, t) {
"use strict";
cc._RF.push(t, "18fae+0JotI76IMbz0XKZNb", "HelloWorld");
cc.Class({
extends: cc.Component,
properties: {
label: {
default: null,
type: cc.Label
},
pfbDatePicker: cc.Prefab
},
onLoad: function() {
var e = new Date();
this.year = e.getFullYear();
this.month = e.getMonth();
this.day = e.getDate();
this.updateDate();
},
onClickDate: function() {
var e = this, t = cc.instantiate(this.pfbDatePicker);
t.parent = this.node;
var r = t.getComponent("UIDatePicker");
r.setDate(this.year, this.month, this.day);
r.setPickDateCallback(function(t, r, n) {
e.year = t;
e.month = r;
e.day = n;
e.updateDate();
});
},
updateDate: function() {
this.label.string = cc.js.formatStr("%s-%s-%s", this.year, this.month + 1, this.day);
}
});
cc._RF.pop();
}, {} ],
Helloworld: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "e1b90/rohdEk4SdmmEZANaD", "Helloworld");
var n, i = this && this.__extends || (n = function(e, t) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
})(e, t);
}, function(e, t) {
n(e, t);
function r() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, new r());
}), o = this && this.__decorate || function(e, t, r, n) {
var i, o = arguments.length, s = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, n); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (s = (o < 3 ? i(s) : o > 3 ? i(t, r, s) : i(t, r)) || s);
return o > 3 && s && Object.defineProperty(t, r, s), s;
};
Object.defineProperty(r, "__esModule", {
value: !0
});
var s = cc._decorator, a = s.ccclass, f = s.property, c = function(e) {
i(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.label = null;
t.text = "hello";
return t;
}
t.prototype.start = function() {
this.label.string = this.text;
};
o([ f(cc.Label) ], t.prototype, "label", void 0);
o([ f ], t.prototype, "text", void 0);
return o([ a ], t);
}(cc.Component);
r.default = c;
cc._RF.pop();
}, {} ],
HotUpdate: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "2ffa0G2dXNOEK/nOzR1EEZB", "HotUpdate");
var n, i = this && this.__extends || (n = function(e, t) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
})(e, t);
}, function(e, t) {
n(e, t);
function r() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, new r());
}), o = this && this.__decorate || function(e, t, r, n) {
var i, o = arguments.length, s = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, n); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (s = (o < 3 ? i(s) : o > 3 ? i(t, r, s) : i(t, r)) || s);
return o > 3 && s && Object.defineProperty(t, r, s), s;
};
Object.defineProperty(r, "__esModule", {
value: !0
});
var s = cc._decorator, a = s.ccclass, f = s.property, c = function(e) {
i(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.manifestUrl = null;
t.loadingNode = null;
t.bgSplash = [];
t.loadingBar = null;
t.listSprBg = [];
t.lb_Info = null;
t._updating = !1;
t._failCount = 0;
t._canRetry = !1;
t._storagePath = "";
t._updateListener = null;
t._am = null;
t._checkListener = null;
t.versionCompareHandle = null;
t.gameSceneName = "main";
t.loadingGameComp = null;
return t;
}
t.prototype.checkCb = function(e) {
switch (e.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.loadGame();
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.loadGame();
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
this.lb_Info.node.active = !0;
this.lb_Info.string = "Đang tải bản cập nhật...";
this.loadingBar.fillRange = 0;
this.hotUpdate();
break;

default:
return;
}
this._am.setEventCallback(null);
this._checkListener = null;
this._updating = !1;
};
t.prototype.updateCb = function(e) {
var t = !1, r = !1;
switch (e.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
r = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
e.getMessage();
this.lb_Info.string = "Updating: " + Math.floor(100 * e.getPercent()) + "%";
this.loadingBar.fillRange = e.getPercent();
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
r = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
t = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
this._am.downloadFailedAssets();
this._updating = !1;
this._canRetry = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
case jsb.EventAssetsManager.ERROR_DECOMPRESS:
}
if (r) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadGame();
}
if (t) {
this._am.setEventCallback(null);
this._updateListener = null;
var n = jsb.fileUtils.getSearchPaths(), i = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(n, i);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(n));
jsb.fileUtils.setSearchPaths(n);
cc.audioEngine.stopAll();
cc.game.restart();
}
};
t.prototype.checkUpdate = function() {
if (this._updating) this.lb_Info.string = "Checking or updating ..."; else {
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var e = this.manifestUrl.nativeUrl;
cc.loader.md5Pipe && (e = cc.loader.md5Pipe.transformURL(e));
this._am.loadLocalManifest(e);
}
if (this._am.getLocalManifest() && this._am.getLocalManifest().isLoaded()) {
this._am.setEventCallback(this.checkCb.bind(this));
this._am.checkUpdate();
this._updating = !0;
}
}
};
t.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var e = this.manifestUrl.nativeUrl;
cc.loader.md5Pipe && (e = cc.loader.md5Pipe.transformURL(e));
this._am.loadLocalManifest(e);
}
this._failCount = 0;
this._am.update();
this._updating = !0;
} else {
var t = this;
this.scheduleOnce(function() {
t.hotUpdate();
}, .5);
}
};
t.prototype.onLoad = function() {
this.loadingGameComp = this.loadingNode.getComponent("Loading");
if (!cc.sys.isNative && cc.sys.isBrowser || cc.sys.os === cc.sys.OS_OSX) this.loadGame(); else {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "lote88-remote-asset";
this.versionCompareHandle = function(e, t) {
for (var r = e.split("."), n = t.split("."), i = 0; i < r.length; ++i) {
var o = parseInt(r[i]), s = parseInt(n[i] || 0);
if (o !== s) return o - s;
}
return n.length > r.length ? -1 : 0;
};
this._am = new jsb.AssetsManager("", this._storagePath, this.versionCompareHandle);
this._am.setVerifyCallback(function(e, t) {
t.compressed, t.md5, t.path, t.size;
return !0;
});
cc.sys.os === cc.sys.OS_ANDROID && this._am.setMaxConcurrentTask(10);
this.checkUpdate();
}
};
t.prototype.start = function() {
cc.sys.isBrowser;
};
t.prototype.loadGame = function() {
this.loadingGameComp.startGame();
};
t.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
o([ f({
type: cc.Asset
}) ], t.prototype, "manifestUrl", void 0);
o([ f(cc.Node) ], t.prototype, "loadingNode", void 0);
o([ f([ cc.SpriteFrame ]) ], t.prototype, "bgSplash", void 0);
o([ f(cc.Sprite) ], t.prototype, "loadingBar", void 0);
o([ f([ cc.SpriteFrame ]) ], t.prototype, "listSprBg", void 0);
o([ f(cc.Label) ], t.prototype, "lb_Info", void 0);
return o([ a ], t);
}(cc.Component);
r.default = c;
cc._RF.pop();
}, {} ],
Http: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "2cd84ecMG9CWL/aifwSEhhY", "Http");
var n = this && this.__decorate || function(e, t, r, n) {
var i, o = arguments.length, s = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, n); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (s = (o < 3 ? i(s) : o > 3 ? i(t, r, s) : i(t, r)) || s);
return o > 3 && s && Object.defineProperty(t, r, s), s;
};
Object.defineProperty(r, "__esModule", {
value: !0
});
var i = e("../../Loading/src/Configs"), o = e("./VersionConfig"), s = cc._decorator, a = s.ccclass, f = (s.property, 
function() {
function e() {}
e.post = function(e, t, r, n) {
void 0 === n && (n = !1);
var i = new XMLHttpRequest(), o = "";
if (null !== t) {
var s = 0, a = Object.keys(t).length;
for (var f in t) {
if (t.hasOwnProperty(f)) {
o += f + "=" + t[f];
s < a - 1 && (o += "&");
}
s++;
}
}
i.onreadystatechange = function() {
if (4 === i.readyState) if (200 === i.status) {
var e = null, t = null;
try {
e = JSON.parse(i.responseText);
} catch (e) {
t = e;
}
r(t, e);
} else r(i.status, null);
};
i.open("POST", e, !0);
i.setRequestHeader("Content-type", "application/json");
n ? i.send(JSON.stringify(t)) : i.send(o);
};
e.postz = function(e, t, r) {
var n = new XMLHttpRequest(), i = "";
if (null !== t) {
var o = 0, s = Object.keys(t).length;
for (var a in t) {
if (t.hasOwnProperty(a)) {
i += a + "=" + t[a];
o < s - 1 && (i += "&");
}
o++;
}
}
n.onreadystatechange = function() {
if (4 === n.readyState) if (200 === n.status) {
var e = null, t = null;
try {
e = JSON.parse(n.responseText);
} catch (e) {
t = e;
}
r(t, e);
} else r(n.status, null);
};
n.open("POST", encodeURI(e), !0);
n.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
n.send(i);
};
e.get = function(e, t, r) {
var n = new XMLHttpRequest(), s = "";
t = t || {};
o.default.CPName;
t.hasOwnProperty("cp") || (t.cp = "R");
t.cl = "R";
cc.sys.isNative && cc.sys.os == cc.sys.OS_ANDROID ? t.pf = "ad" : cc.sys.isNative && cc.sys.os == cc.sys.OS_IOS ? t.pf = "ios" : cc.sys.isNative ? t.pf = "other" : t.pf = "web";
t.at = i.default.Login.AccessToken;
if (null !== t) {
var a = 0, f = Object.keys(t).length;
for (var c in t) if (t.hasOwnProperty(c)) {
s += c + "=" + t[c];
a++ < f - 1 && (s += "&");
}
}
n.onreadystatechange = function() {
if (4 === n.readyState) if (200 === n.status) {
var e = null, t = null;
try {
e = JSON.parse(n.responseText);
} catch (e) {
t = e;
}
r(t, e);
} else r(n.status, null);
};
var u = e + "?" + s;
n.open("GET", u, !0);
n.send();
};
return n([ a ], e);
}());
r.default = f;
cc._RF.pop();
}, {
"../../Loading/src/Configs": "Configs",
"./VersionConfig": "VersionConfig"
} ],
Loading: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "06c935DvwpCJ5nCCvhzAwFf", "Loading");
var n, i = this && this.__extends || (n = function(e, t) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
})(e, t);
}, function(e, t) {
n(e, t);
function r() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, new r());
}), o = this && this.__decorate || function(e, t, r, n) {
var i, o = arguments.length, s = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, n); else for (var a = e.length - 1; a >= 0; a--) (i = e[a]) && (s = (o < 3 ? i(s) : o > 3 ? i(t, r, s) : i(t, r)) || s);
return o > 3 && s && Object.defineProperty(t, r, s), s;
};
Object.defineProperty(r, "__esModule", {
value: !0
});
var s = e("../../Loading/src/Http"), a = e("./BundleControl"), f = e("./Configs"), c = e("./Global"), u = e("./UtilsNative"), h = cc._decorator, d = h.ccclass, l = h.property, p = function(e) {
i(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.lblStatus = null;
t.lbTips = null;
t.nodeSlider = null;
t.spriteProgress = null;
t.listSkeData = [];
t.listTips = [ {
vi: "Đừng quên đăng nhập hàng ngày để nhận thưởng Điểm Danh bạn nhé!",
en: "Dont forget login every day to get free attendance bonus!"
}, {
vi: "Tiến Lên Miền Nam: Chống gian lận,an toàn tuyệt đối",
en: "Killer 13: Anti cheating,absolute safety"
}, {
vi: "Nạp đầu nhận thưởng lên tới 790K",
en: "First cash-in can receive bonus up to 790K"
}, {
vi: "Bộ phận chăm sóc khách hàng luôn online 24/24 bạn nhé!",
en: "Customer care team support online 24/24!"
}, {
vi: "Bentley nạp rút nhanh chóng và an toàn!",
en: "Bentley quick cashin,cashout and alway safety!"
} ];
return t;
}
t.prototype.start = function() {
cc.assetManager.downloader.maxConcurrency = 20;
cc.assetManager.downloader.maxRequestsPerFrame = 6;
this.showTips();
};
t.prototype.startGame = function() {
var e = this;
this.lblStatus.string = "Tải tài nguyên từ máy chủ...";
this.spriteProgress.fillRange = 0;
this.nodeSlider.progress = 0;
0 == f.default.App.IS_LOCAL ? s.default.get("https://play.rik1vip.win/assets/AssetBundleVersion.json", {}, function(t, r) {
a.default.init(r);
e.loadLobby();
}) : this.loadLobby();
u.default.getDeviceId();
};
t.prototype.loadScriptCore = function() {
var e = this;
a.default.loadBundle("ScriptCore", function() {
e.loadLobby();
});
};
t.prototype.loadLobby = function() {
var e = this, t = this;
new Date().getTime();
a.default.loadBundle("Lobby", function(r) {
c.Global.BundleLobby = r;
for (var n = e.listSkeData.length, i = 0; i < n; i++) {
var o = e.listSkeData[i];
r.load(o, sp.SkeletonData, function() {});
}
r.loadScene("Lobby", function(e, r) {
t.lblStatus.string = "Loading: " + parseInt(e / r * 100) + "%";
t.spriteProgress.fillRange = e / r;
t.nodeSlider.progress = t.spriteProgress.fillRange;
}, function(e, t) {
cc.sys.localStorage.setItem("SceneLobby", t);
cc.director.runScene(t);
new Date().getTime();
});
r.loadDir("PrefabPopup", cc.Prefab, function() {});
});
};
t.prototype.showTips = function() {
var e = this;
this.schedule(function() {
e.lbTips.string = e.getStrTips();
}, 3, cc.macro.REPEAT_FOREVER, .1);
};
t.prototype.getStrTips = function() {
var e = cc.sys.localStorage.getItem("langCode");
null == e && (e = "vi");
return this.listTips[this.randomRangeInt(0, this.listTips.length)][e];
};
t.prototype.randomRangeInt = function(e, t) {
return Math.floor(Math.random() * (t - e)) + e;
};
o([ l(cc.Label) ], t.prototype, "lblStatus", void 0);
o([ l(cc.Label) ], t.prototype, "lbTips", void 0);
o([ l(cc.Slider) ], t.prototype, "nodeSlider", void 0);
o([ l(cc.Sprite) ], t.prototype, "spriteProgress", void 0);
return o([ d ], t);
}(cc.Component);
r.default = p;
cc._RF.pop();
}, {
"../../Loading/src/Http": "Http",
"./BundleControl": "BundleControl",
"./Configs": "Configs",
"./Global": "Global",
"./UtilsNative": "UtilsNative"
} ],
"LogEvent.Facebook": [ function(e, t, r) {
"use strict";
cc._RF.push(t, "4ca09lb5WpN1qyZP0SX7eS4", "LogEvent.Facebook");
Object.defineProperty(r, "__esModule", {
value: !0
});
var n = e("../Configs"), i = function() {
function e() {}
e.getInstance = function() {
null == this.instance && (this.instance = new e());
return this.instance;
};
e.prototype.isUseSDK = function() {
return !(!cc.sys.isNative || cc.sys.os != cc.sys.OS_ANDROID && cc.sys.os != cc.sys.OS_IOS);
};
e.prototype.facebookCustomLogsEvent = function(e, t, r) {
void 0 === r && (r = null);
};
e.prototype.createEventParam = function(e, t, r) {
void 0 === r && (r = null);
void 0 !== r && null != r || (r = n.default.ParamType.STRING);
return {
key: e,
value: t,
typeValue: r
};
};
e.prototype.sendEventSdt = function(e) {
var t = [];
t.push(this.createEventParam("phone", e));
this.facebookCustomLogsEvent(n.default.EventFacebook.EVENT_NAME_ADDED_PAYMENT_INFO, t);
};
e.prototype.sendEventSigupSuccess = function(e) {
var t = [];
t.push(this.createEventParam(n.default.ParamsFacebook.EVENT_PARAM_REGISTRATION_METHOD, e));
this.facebookCustomLogsEvent(n.default.EventFacebook.EVENT_NAME_COMPLETED_REGISTRATION, t);
};
e.prototype.sendEventLogin = function(e) {
var t = [];
t.push(this.createEventParam(n.default.ParamsFacebook.EVENT_PARAM_LOGIN_METHOD, e, n.default.ParamType.STRING));
this.facebookCustomLogsEvent(n.default.EventFacebook.EVENT_NAME_COMPLETED_LOGIN, t);
};
e.prototype.sendEventOpenApp = function() {};
e.prototype.sendEventPurchase = function(e, t) {
var r = [];
r.push(this.createEventParam(n.default.ParamsFacebook.EVENT_PARAM_CURRENCY, e, n.default.ParamType.STRING));
this.facebookCustomLogsEvent(n.default.EventFacebook.EVENT_NAME_PURCHASED, r, t);
};
e.prototype.sendEventMoneyChange = function(e, t, r) {
var i = [];
i.push(this.createEventParam(n.default.ParamsFacebook.EVENT_PARAM_CONTENT, e, n.default.ParamType.STRING));
i.push(this.createEventParam(n.default.ParamsFacebook.EVENT_PARAM_CURRENCY, t, n.default.ParamType.STRING));
this.facebookCustomLogsEvent(n.default.EventFacebook.EVENT_NAME_SPENT_CREDITS, i, r);
};
e.prototype.sendEventCashout = function(e, t) {
var r = [];
r.push(this.createEventParam(n.default.ParamsFacebook.EVENT_PARAM_CURRENCY, e, n.default.ParamType.STRING));
this.facebookCustomLogsEvent(n.default.EventFacebook.EVENT_NAME_EARN_VIRTUAL_CURRENCY, r, t);
};
e.prototype.sendEventClickShop = function(e, t) {
var r = [];
r.push(this.createEventParam(n.default.ParamsFacebook.EVENT_PARAM_CURRENCY, e, n.default.ParamType.STRING));
this.facebookCustomLogsEvent(n.default.EventFacebook.EVENT_NAME_INITIATED_CHECKOUT, r, t);
};
e.instance = null;
return e;
}();
r.default = i;
cc._RF.pop();
}, {
"../Configs": "Configs"
} ],
"LogEvent.FireBase": [ function(e, t, r) {
"use strict";
cc._RF.push(t, "2c4f2kkOwdER7tJkWRSAYzr", "LogEvent.FireBase");
Object.defineProperty(r, "__esModule", {
value: !0
});
var n = e("../Configs"), i = function() {
function e() {}
e.getInstance = function() {
null == this.instance && (this.instance = new e());
return this.instance;
};
e.prototype.isUseSDK = function() {
return !(!cc.sys.isNative || cc.sys.os != cc.sys.OS_ANDROID && cc.sys.os != cc.sys.OS_IOS);
};
e.prototype.onClickSendLogEvent = function() {};
e.prototype.firebaseSendLogEvent = function() {};
e.prototype.sendEventSdt = function(e) {
var t = {};
t.phone = e;
this.firebaseSendLogEvent(n.default.EventFirebase.ADD_PAYMENT_INFO, t);
};
e.prototype.sendEventSigupSuccess = function(e) {
var t = {};
t[n.default.ParamsFireBase.METHOD] = e;
this.firebaseSendLogEvent(n.default.EventFirebase.SIGN_UP, t);
};
e.prototype.sendEventLogin = function(e) {
var t = {};
t[n.default.ParamsFireBase.METHOD] = e;
this.firebaseSendLogEvent(n.default.EventFirebase.LOGIN, t);
};
e.prototype.sendEventOpenApp = function() {
var e = {};
e[n.default.ParamsFireBase.CONTENT] = "1";
this.firebaseSendLogEvent(n.default.EventFirebase.APP_OPEN, e);
};
e.prototype.sendEventPurchase = function(e, t) {
var r = {};
r[n.default.ParamsFireBase.CURRENCY] = e;
r[n.default.ParamsFireBase.VALUE] = t;
this.firebaseSendLogEvent(n.default.EventFirebase.ECOMMERCE_PURCHASE, r);
};
e.prototype.sendEventMoneyChange = function(e, t, r) {
var i = {};
i[n.default.ParamsFireBase.ITEM_NAME] = e;
i[n.default.ParamsFireBase.VIRTUAL_CURRENCY_NAME] = t;
i[n.default.ParamsFireBase.VALUE] = r;
this.firebaseSendLogEvent(n.default.EventFirebase.SPEND_VIRTUAL_CURRENCY, i);
};
e.prototype.sendEventCashout = function(e, t) {
var r = {};
r[n.default.ParamsFireBase.VIRTUAL_CURRENCY_NAME] = e;
r[n.default.ParamsFireBase.VALUE] = t;
this.firebaseSendLogEvent(n.default.EventFirebase.EARN_VIRTUAL_CURRENCY, r);
};
e.prototype.sendEventClickShop = function(e, t) {
var r = {};
r[n.default.ParamsFireBase.CURRENCY] = e;
r[n.default.ParamsFireBase.VALUE] = t;
this.firebaseSendLogEvent(n.default.EventFirebase.BEGIN_CHECKOUT, r);
};
e.instance = null;
return e;
}();
r.default = i;
cc._RF.pop();
}, {
"../Configs": "Configs"
} ],
LogEvent: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "8582fS1gU1D1Lp+gCCJai7n", "LogEvent");
Object.defineProperty(r, "__esModule", {
value: !0
});
var n = e("../Configs"), i = e("./LogEvent.Facebook"), o = e("./LogEvent.FireBase"), s = function() {
function e() {}
e.getInstance = function() {
null == this.instance && (this.instance = new e());
return this.instance;
};
e.prototype.createEventParam = function(e, t, r) {
void 0 === r && (r = null);
void 0 !== r && null != r || (r = n.default.ParamType.STRING);
return {
key: e,
value: t,
typeValue: r
};
};
e.prototype.sendEventSdt = function(e) {
i.default.getInstance().sendEventSdt(e);
o.default.getInstance().sendEventSdt(e);
};
e.prototype.sendEventSigupSuccess = function(e) {
i.default.getInstance().sendEventSigupSuccess(e);
o.default.getInstance().sendEventSigupSuccess(e);
};
e.prototype.sendEventLogin = function(e) {
i.default.getInstance().sendEventLogin(e);
o.default.getInstance().sendEventLogin(e);
};
e.prototype.sendEventOpenApp = function() {
o.default.getInstance().sendEventOpenApp();
};
e.prototype.sendEventPurchase = function(e, t) {
i.default.getInstance().sendEventPurchase(e, t);
o.default.getInstance().sendEventPurchase(e, t);
};
e.prototype.sendEventMoneyChange = function(e, t, r) {
i.default.getInstance().sendEventMoneyChange(e, t, r);
o.default.getInstance().sendEventMoneyChange(e, t, r);
};
e.prototype.sendEventCashout = function(e, t) {
i.default.getInstance().sendEventCashout(e, t);
o.default.getInstance().sendEventCashout(e, t);
};
e.prototype.sendEventClickShop = function(e, t) {
i.default.getInstance().sendEventClickShop(e, t);
o.default.getInstance().sendEventClickShop(e, t);
};
e.instance = null;
return e;
}();
r.default = s;
cc._RF.pop();
}, {
"../Configs": "Configs",
"./LogEvent.Facebook": "LogEvent.Facebook",
"./LogEvent.FireBase": "LogEvent.FireBase"
} ],
"Sockjs.min": [ function(e, t, r) {
(function(n) {
"use strict";
cc._RF.push(t, "9d754OczR9BKawrN1ElQuWx", "Sockjs.min");
!function(e) {
"object" == typeof r && "undefined" != typeof t ? t.exports = e() : "function" == typeof define && define.amd ? define([], e) : ("undefined" != typeof window ? window : "undefined" != typeof n ? n : "undefined" != typeof self ? self : this).SockJS = e();
}(function() {
return function t(r, n, i) {
function o(a, f) {
if (!n[a]) {
if (!r[a]) {
var c = "function" == typeof e && e;
if (!f && c) return c(a, !0);
if (s) return s(a, !0);
var u = new Error("Cannot find module '" + a + "'");
throw u.code = "MODULE_NOT_FOUND", u;
}
var h = n[a] = {
exports: {}
};
r[a][0].call(h.exports, function(e) {
return o(r[a][1][e] || e);
}, h, h.exports, t, r, n, i);
}
return n[a].exports;
}
for (var s = "function" == typeof e && e, a = 0; a < i.length; a++) o(i[a]);
return o;
}({
1: [ function(e, t) {
(function(r) {
var n = e("./transport-list");
t.exports = e("./main")(n), "_sockjs_onload" in r && setTimeout(r._sockjs_onload, 1);
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"./main": 14,
"./transport-list": 16
} ],
2: [ function(e, t) {
var r = e("inherits"), n = e("./event");
function i() {
n.call(this), this.initEvent("close", !1, !1), this.wasClean = !1, this.code = 0, 
this.reason = "";
}
r(i, n), t.exports = i;
}, {
"./event": 4,
inherits: 54
} ],
3: [ function(e, t) {
var r = e("inherits"), n = e("./eventtarget");
function i() {
n.call(this);
}
r(i, n), i.prototype.removeAllListeners = function(e) {
e ? delete this._listeners[e] : this._listeners = {};
}, i.prototype.once = function(e, t) {
var r = this, n = !1;
this.on(e, function i() {
r.removeListener(e, i), n || (n = !0, t.apply(this, arguments));
});
}, i.prototype.emit = function() {
var e = arguments[0], t = this._listeners[e];
if (t) {
for (var r = arguments.length, n = new Array(r - 1), i = 1; i < r; i++) n[i - 1] = arguments[i];
for (var o = 0; o < t.length; o++) t[o].apply(this, n);
}
}, i.prototype.on = i.prototype.addListener = n.prototype.addEventListener, i.prototype.removeListener = n.prototype.removeEventListener, 
t.exports.EventEmitter = i;
}, {
"./eventtarget": 5,
inherits: 54
} ],
4: [ function(e, t) {
function r(e) {
this.type = e;
}
r.prototype.initEvent = function(e, t, r) {
return this.type = e, this.bubbles = t, this.cancelable = r, this.timeStamp = +new Date(), 
this;
}, r.prototype.stopPropagation = function() {}, r.prototype.preventDefault = function() {}, 
r.CAPTURING_PHASE = 1, r.AT_TARGET = 2, r.BUBBLING_PHASE = 3, t.exports = r;
}, {} ],
5: [ function(e, t) {
function r() {
this._listeners = {};
}
r.prototype.addEventListener = function(e, t) {
e in this._listeners || (this._listeners[e] = []);
var r = this._listeners[e];
-1 === r.indexOf(t) && (r = r.concat([ t ])), this._listeners[e] = r;
}, r.prototype.removeEventListener = function(e, t) {
var r = this._listeners[e];
if (r) {
var n = r.indexOf(t);
-1 === n || (1 < r.length ? this._listeners[e] = r.slice(0, n).concat(r.slice(n + 1)) : delete this._listeners[e]);
}
}, r.prototype.dispatchEvent = function() {
var e = arguments[0], t = e.type, r = 1 === arguments.length ? [ e ] : Array.apply(null, arguments);
if (this["on" + t] && this["on" + t].apply(this, r), t in this._listeners) for (var n = this._listeners[t], i = 0; i < n.length; i++) n[i].apply(this, r);
}, t.exports = r;
}, {} ],
6: [ function(e, t) {
var r = e("inherits"), n = e("./event");
function i(e) {
n.call(this), this.initEvent("message", !1, !1), this.data = e;
}
r(i, n), t.exports = i;
}, {
"./event": 4,
inherits: 54
} ],
7: [ function(e, t) {
var r = e("json3"), n = e("./utils/iframe");
function i(e) {
(this._transport = e).on("message", this._transportMessage.bind(this)), e.on("close", this._transportClose.bind(this));
}
i.prototype._transportClose = function(e, t) {
n.postMessage("c", r.stringify([ e, t ]));
}, i.prototype._transportMessage = function(e) {
n.postMessage("t", e);
}, i.prototype._send = function(e) {
this._transport.send(e);
}, i.prototype._close = function() {
this._transport.close(), this._transport.removeAllListeners();
}, t.exports = i;
}, {
"./utils/iframe": 47,
json3: 55
} ],
8: [ function(e, t) {
var r = e("./utils/url"), n = e("./utils/event"), i = e("json3"), o = e("./facade"), s = e("./info-iframe-receiver"), a = e("./utils/iframe"), f = e("./location");
t.exports = function(e, t) {
var c, u = {};
t.forEach(function(e) {
e.facadeTransport && (u[e.facadeTransport.transportName] = e.facadeTransport);
}), u[s.transportName] = s, e.bootstrap_iframe = function() {
var t;
a.currentWindowId = f.hash.slice(1);
n.attachEvent("message", function(n) {
if (n.source === parent && (void 0 === c && (c = n.origin), n.origin === c)) {
var s;
try {
s = i.parse(n.data);
} catch (h) {
return void n.data;
}
if (s.windowId === a.currentWindowId) switch (s.type) {
case "s":
var h;
try {
h = i.parse(s.data);
} catch (h) {
s.data;
break;
}
var d = h[0], l = h[1], p = h[2], b = h[3];
if (d !== e.version) throw new Error('Incompatible SockJS! Main site uses: "' + d + '", the iframe: "' + e.version + '".');
if (!r.isOriginEqual(p, f.href) || !r.isOriginEqual(b, f.href)) throw new Error("Can't connect to different domain from within an iframe. (" + f.href + ", " + p + ", " + b + ")");
t = new o(new u[l](p, b));
break;

case "m":
t._send(s.data);
break;

case "c":
t && t._close(), t = null;
}
}
}), a.postMessage("s");
};
};
}, {
"./facade": 7,
"./info-iframe-receiver": 10,
"./location": 13,
"./utils/event": 46,
"./utils/iframe": 47,
"./utils/url": 52,
debug: void 0,
json3: 55
} ],
9: [ function(e, t) {
var r = e("events").EventEmitter, n = e("inherits"), i = e("json3"), o = e("./utils/object"), s = function() {};
function a(e, t) {
r.call(this);
var n = this, a = +new Date();
this.xo = new t("GET", e), this.xo.once("finish", function(e, t) {
var r, f;
if (200 === e) {
if (f = +new Date() - a, t) try {
r = i.parse(t);
} catch (e) {
s("bad json", t);
}
o.isObject(r) || (r = {});
}
n.emit("finish", r, f), n.removeAllListeners();
});
}
n(a, r), a.prototype.close = function() {
this.removeAllListeners(), this.xo.close();
}, t.exports = a;
}, {
"./utils/object": 49,
debug: void 0,
events: 3,
inherits: 54,
json3: 55
} ],
10: [ function(e, t) {
var r = e("inherits"), n = e("events").EventEmitter, i = e("json3"), o = e("./transport/sender/xhr-local"), s = e("./info-ajax");
function a(e) {
var t = this;
n.call(this), this.ir = new s(e, o), this.ir.once("finish", function(e, r) {
t.ir = null, t.emit("message", i.stringify([ e, r ]));
});
}
r(a, n), a.transportName = "iframe-info-receiver", a.prototype.close = function() {
this.ir && (this.ir.close(), this.ir = null), this.removeAllListeners();
}, t.exports = a;
}, {
"./info-ajax": 9,
"./transport/sender/xhr-local": 37,
events: 3,
inherits: 54,
json3: 55
} ],
11: [ function(e, t) {
(function(r) {
var n = e("events").EventEmitter, i = e("inherits"), o = e("json3"), s = e("./utils/event"), a = e("./transport/iframe"), f = e("./info-iframe-receiver"), c = function() {};
function u(e, t) {
var i = this;
n.call(this);
var u = function() {
var r = i.ifr = new a(f.transportName, t, e);
r.once("message", function(e) {
if (e) {
var t;
try {
t = o.parse(e);
} catch (t) {
return c("bad json", e), i.emit("finish"), void i.close();
}
var r = t[0], n = t[1];
i.emit("finish", r, n);
}
i.close();
}), r.once("close", function() {
i.emit("finish"), i.close();
});
};
r.document.body ? u() : s.attachEvent("load", u);
}
i(u, n), u.enabled = function() {
return a.enabled();
}, u.prototype.close = function() {
this.ifr && this.ifr.close(), this.removeAllListeners(), this.ifr = null;
}, t.exports = u;
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"./info-iframe-receiver": 10,
"./transport/iframe": 22,
"./utils/event": 46,
debug: void 0,
events: 3,
inherits: 54,
json3: 55
} ],
12: [ function(e, t) {
var r = e("events").EventEmitter, n = e("inherits"), i = e("./utils/url"), o = e("./transport/sender/xdr"), s = e("./transport/sender/xhr-cors"), a = e("./transport/sender/xhr-local"), f = e("./transport/sender/xhr-fake"), c = e("./info-iframe"), u = e("./info-ajax"), h = function() {};
function d(e, t) {
h(e);
var n = this;
r.call(this), setTimeout(function() {
n.doXhr(e, t);
}, 0);
}
n(d, r), d._getReceiver = function(e, t, r) {
return r.sameOrigin ? new u(t, a) : s.enabled ? new u(t, s) : o.enabled && r.sameScheme ? new u(t, o) : c.enabled() ? new c(e, t) : new u(t, f);
}, d.prototype.doXhr = function(e, t) {
var r = this, n = i.addPath(e, "/info");
h("doXhr", n), this.xo = d._getReceiver(e, n, t), this.timeoutRef = setTimeout(function() {
h("timeout"), r._cleanup(!1), r.emit("finish");
}, d.timeout), this.xo.once("finish", function(e, t) {
h("finish", e, t), r._cleanup(!0), r.emit("finish", e, t);
});
}, d.prototype._cleanup = function(e) {
h("_cleanup"), clearTimeout(this.timeoutRef), this.timeoutRef = null, !e && this.xo && this.xo.close(), 
this.xo = null;
}, d.prototype.close = function() {
h("close"), this.removeAllListeners(), this._cleanup(!1);
}, d.timeout = 8e3, t.exports = d;
}, {
"./info-ajax": 9,
"./info-iframe": 11,
"./transport/sender/xdr": 34,
"./transport/sender/xhr-cors": 35,
"./transport/sender/xhr-fake": 36,
"./transport/sender/xhr-local": 37,
"./utils/url": 52,
debug: void 0,
events: 3,
inherits: 54
} ],
13: [ function(e, t) {
(function(e) {
t.exports = e.location || {
origin: "http://localhost:80",
protocol: "http:",
host: "localhost",
port: 80,
href: "http://localhost/",
hash: ""
};
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
14: [ function(e, t) {
(function(r) {
e("./shims");
var n, i = e("url-parse"), o = e("inherits"), s = e("json3"), a = e("./utils/random"), f = e("./utils/escape"), c = e("./utils/url"), u = e("./utils/event"), h = e("./utils/transport"), d = e("./utils/object"), l = e("./utils/browser"), p = e("./utils/log"), b = e("./event/event"), m = e("./event/eventtarget"), v = e("./location"), y = e("./event/close"), g = e("./event/trans-message"), _ = e("./info-receiver"), w = function() {};
function E(e, t, r) {
if (!(this instanceof E)) return new E(e, t, r);
if (arguments.length < 1) throw new TypeError("Failed to construct 'SockJS: 1 argument required, but only 0 present");
m.call(this), this.readyState = E.CONNECTING, this.extensions = "", this.protocol = "", 
(r = r || {}).protocols_whitelist && p.warn("'protocols_whitelist' is DEPRECATED. Use 'transports' instead."), 
this._transportsWhitelist = r.transports, this._transportOptions = r.transportOptions || {};
var n = r.sessionId || 8;
if ("function" == typeof n) this._generateSessionId = n; else {
if ("number" != typeof n) throw new TypeError("If sessionId is used in the options, it needs to be a number or a function.");
this._generateSessionId = function() {
return a.string(n);
};
}
this._server = r.server || a.numberString(1e3);
var o = new i(e);
if (!o.host || !o.protocol) throw new SyntaxError("The URL '" + e + "' is invalid");
if (o.hash) throw new SyntaxError("The URL must not contain a fragment");
if ("http:" !== o.protocol && "https:" !== o.protocol) throw new SyntaxError("The URL's scheme must be either 'http:' or 'https:'. '" + o.protocol + "' is not allowed.");
var s = "https:" === o.protocol;
if ("https:" === v.protocol && !s) throw new Error("SecurityError: An insecure SockJS connection may not be initiated from a page loaded over HTTPS");
t ? Array.isArray(t) || (t = [ t ]) : t = [];
var f = t.sort();
f.forEach(function(e, t) {
if (!e) throw new SyntaxError("The protocols entry '" + e + "' is invalid.");
if (t < f.length - 1 && e === f[t + 1]) throw new SyntaxError("The protocols entry '" + e + "' is duplicated.");
});
var u = c.getOrigin(v.href);
this._origin = u ? u.toLowerCase() : null, o.set("pathname", o.pathname.replace(/\/+$/, "")), 
this.url = o.href, w("using url", this.url), this._urlInfo = {
nullOrigin: !l.hasDomain(),
sameOrigin: c.isOriginEqual(this.url, v.href),
sameScheme: c.isSchemeEqual(this.url, v.href)
}, this._ir = new _(this.url, this._urlInfo), this._ir.once("finish", this._receiveInfo.bind(this));
}
function S(e) {
return 1e3 === e || 3e3 <= e && e <= 4999;
}
o(E, m), E.prototype.close = function(e, t) {
if (e && !S(e)) throw new Error("InvalidAccessError: Invalid code");
if (t && 123 < t.length) throw new SyntaxError("reason argument has an invalid length");
this.readyState !== E.CLOSING && this.readyState !== E.CLOSED && this._close(e || 1e3, t || "Normal closure", !0);
}, E.prototype.send = function(e) {
if ("string" != typeof e && (e = "" + e), this.readyState === E.CONNECTING) throw new Error("InvalidStateError: The connection has not been established yet");
this.readyState === E.OPEN && this._transport.send(f.quote(e));
}, E.version = e("./version"), E.CONNECTING = 0, E.OPEN = 1, E.CLOSING = 2, E.CLOSED = 3, 
E.prototype._receiveInfo = function(e, t) {
if (w("_receiveInfo", t), this._ir = null, e) {
this._rto = this.countRTO(t), this._transUrl = e.base_url ? e.base_url : this.url, 
e = d.extend(e, this._urlInfo), w("info", e);
var r = n.filterToEnabled(this._transportsWhitelist, e);
this._transports = r.main, w(this._transports.length + " enabled transports"), this._connect();
} else this._close(1002, "Cannot connect to server");
}, E.prototype._connect = function() {
for (var e = this._transports.shift(); e; e = this._transports.shift()) {
if (w("attempt", e.transportName), e.needBody && (!r.document.body || void 0 !== r.document.readyState && "complete" !== r.document.readyState && "interactive" !== r.document.readyState)) return w("waiting for body"), 
this._transports.unshift(e), void u.attachEvent("load", this._connect.bind(this));
var t = this._rto * e.roundTrips || 5e3;
this._transportTimeoutId = setTimeout(this._transportTimeout.bind(this), t), w("using timeout", t);
var n = c.addPath(this._transUrl, "/" + this._server + "/" + this._generateSessionId()), i = this._transportOptions[e.transportName];
w("transport url", n);
var o = new e(n, this._transUrl, i);
return o.on("message", this._transportMessage.bind(this)), o.once("close", this._transportClose.bind(this)), 
o.transportName = e.transportName, void (this._transport = o);
}
this._close(2e3, "All transports failed", !1);
}, E.prototype._transportTimeout = function() {
w("_transportTimeout"), this.readyState === E.CONNECTING && (this._transport && this._transport.close(), 
this._transportClose(2007, "Transport timed out"));
}, E.prototype._transportMessage = function(e) {
w("_transportMessage", e);
var t, r = this, n = e.slice(0, 1), i = e.slice(1);
switch (n) {
case "o":
return void this._open();

case "h":
return this.dispatchEvent(new b("heartbeat")), void w("heartbeat", this.transport);
}
if (i) try {
t = s.parse(i);
} catch (e) {
w("bad json", i);
}
if (void 0 !== t) switch (n) {
case "a":
Array.isArray(t) && t.forEach(function(e) {
w("message", r.transport, e), r.dispatchEvent(new g(e));
});
break;

case "m":
w("message", this.transport, t), this.dispatchEvent(new g(t));
break;

case "c":
Array.isArray(t) && 2 === t.length && this._close(t[0], t[1], !0);
} else w("empty payload", i);
}, E.prototype._transportClose = function(e, t) {
w("_transportClose", this.transport, e, t), this._transport && (this._transport.removeAllListeners(), 
this._transport = null, this.transport = null), S(e) || 2e3 === e || this.readyState !== E.CONNECTING ? this._close(e, t) : this._connect();
}, E.prototype._open = function() {
w("_open", this._transport.transportName, this.readyState), this.readyState === E.CONNECTING ? (this._transportTimeoutId && (clearTimeout(this._transportTimeoutId), 
this._transportTimeoutId = null), this.readyState = E.OPEN, this.transport = this._transport.transportName, 
this.dispatchEvent(new b("open")), w("connected", this.transport)) : this._close(1006, "Server lost session");
}, E.prototype._close = function(e, t, r) {
w("_close", this.transport, e, t, r, this.readyState);
var n = !1;
if (this._ir && (n = !0, this._ir.close(), this._ir = null), this._transport && (this._transport.close(), 
this._transport = null, this.transport = null), this.readyState === E.CLOSED) throw new Error("InvalidStateError: SockJS has already been closed");
this.readyState = E.CLOSING, setTimeout(function() {
this.readyState = E.CLOSED, n && this.dispatchEvent(new b("error"));
var i = new y("close");
i.wasClean = r || !1, i.code = e || 1e3, i.reason = t, this.dispatchEvent(i), this.onmessage = this.onclose = this.onerror = null, 
w("disconnected");
}.bind(this), 0);
}, E.prototype.countRTO = function(e) {
return 100 < e ? 4 * e : 300 + e;
}, t.exports = function(t) {
return n = h(t), e("./iframe-bootstrap")(E, t), E;
};
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"./event/close": 2,
"./event/event": 4,
"./event/eventtarget": 5,
"./event/trans-message": 6,
"./iframe-bootstrap": 8,
"./info-receiver": 12,
"./location": 13,
"./shims": 15,
"./utils/browser": 44,
"./utils/escape": 45,
"./utils/event": 46,
"./utils/log": 48,
"./utils/object": 49,
"./utils/random": 50,
"./utils/transport": 51,
"./utils/url": 52,
"./version": 53,
debug: void 0,
inherits: 54,
json3: 55,
"url-parse": 58
} ],
15: [ function() {
var e, t = Array.prototype, r = Object.prototype, n = Function.prototype, i = String.prototype, o = t.slice, s = r.toString, a = function(e) {
return "[object Function]" === r.toString.call(e);
}, f = function(e) {
return "[object String]" === s.call(e);
}, c = Object.defineProperty && function() {
try {
return Object.defineProperty({}, "x", {}), !0;
} catch (e) {
return !1;
}
}();
e = c ? function(e, t, r, n) {
!n && t in e || Object.defineProperty(e, t, {
configurable: !0,
enumerable: !1,
writable: !0,
value: r
});
} : function(e, t, r, n) {
!n && t in e || (e[t] = r);
};
var u = function(t, n, i) {
for (var o in n) r.hasOwnProperty.call(n, o) && e(t, o, n[o], i);
}, h = function(e) {
if (null == e) throw new TypeError("can't convert " + e + " to object");
return Object(e);
};
function d() {}
u(n, {
bind: function(e) {
var t = this;
if (!a(t)) throw new TypeError("Function.prototype.bind called on incompatible " + t);
for (var r = o.call(arguments, 1), n = Math.max(0, t.length - r.length), i = [], s = 0; s < n; s++) i.push("$" + s);
var f = Function("binder", "return function (" + i.join(",") + "){ return binder.apply(this, arguments); }")(function() {
if (this instanceof f) {
var n = t.apply(this, r.concat(o.call(arguments)));
return Object(n) === n ? n : this;
}
return t.apply(e, r.concat(o.call(arguments)));
});
return t.prototype && (d.prototype = t.prototype, f.prototype = new d(), d.prototype = null), 
f;
}
}), u(Array, {
isArray: function(e) {
return "[object Array]" === s.call(e);
}
});
var l, p, b, m = Object("a"), v = "a" !== m[0] || !(0 in m);
u(t, {
forEach: function(e) {
var t = h(this), r = v && f(this) ? this.split("") : t, n = arguments[1], i = -1, o = r.length >>> 0;
if (!a(e)) throw new TypeError();
for (;++i < o; ) i in r && e.call(n, r[i], i, t);
}
}, (l = t.forEach, b = p = !0, l && (l.call("foo", function(e, t, r) {
"object" != typeof r && (p = !1);
}), l.call([ 1 ], function() {
b = "string" == typeof this;
}, "x")), !(l && p && b)));
var y = Array.prototype.indexOf && -1 !== [ 0, 1 ].indexOf(1, 2);
u(t, {
indexOf: function(e) {
var t = v && f(this) ? this.split("") : h(this), r = t.length >>> 0;
if (!r) return -1;
var n, i = 0;
for (1 < arguments.length && ((n = +arguments[1]) != n ? n = 0 : 0 !== n && n !== 1 / 0 && n !== -1 / 0 && (n = (0 < n || -1) * Math.floor(Math.abs(n))), 
i = n), i = 0 <= i ? i : Math.max(0, r + i); i < r; i++) if (i in t && t[i] === e) return i;
return -1;
}
}, y);
var g, _ = i.split;
2 !== "ab".split(/(?:ab)*/).length || 4 !== ".".split(/(.?)(.?)/).length || "t" === "tesst".split(/(s)*/)[1] || 4 !== "test".split(/(?:)/, -1).length || "".split(/.?/).length || 1 < ".".split(/()()/).length ? (g = void 0 === /()??/.exec("")[1], 
i.split = function(e, r) {
var n = this;
if (void 0 === e && 0 === r) return [];
if ("[object RegExp]" !== s.call(e)) return _.call(this, e, r);
var i, o, a, f, c = [], u = (e.ignoreCase ? "i" : "") + (e.multiline ? "m" : "") + (e.extended ? "x" : "") + (e.sticky ? "y" : ""), h = 0;
for (e = new RegExp(e.source, u + "g"), n += "", g || (i = new RegExp("^" + e.source + "$(?!\\s)", u)), 
r = void 0 === r ? -1 >>> 0 : r >>> 0; (o = e.exec(n)) && !(h < (a = o.index + o[0].length) && (c.push(n.slice(h, o.index)), 
!g && 1 < o.length && o[0].replace(i, function() {
for (var e = 1; e < arguments.length - 2; e++) void 0 === arguments[e] && (o[e] = void 0);
}), 1 < o.length && o.index < n.length && t.push.apply(c, o.slice(1)), f = o[0].length, 
h = a, c.length >= r)); ) e.lastIndex === o.index && e.lastIndex++;
return h === n.length ? !f && e.test("") || c.push("") : c.push(n.slice(h)), c.length > r ? c.slice(0, r) : c;
}) : "0".split(void 0, 0).length && (i.split = function(e, t) {
return void 0 === e && 0 === t ? [] : _.call(this, e, t);
});
var w = i.substr;
u(i, {
substr: function(e, t) {
return w.call(this, e < 0 && (e = this.length + e) < 0 ? 0 : e, t);
}
}, "".substr && "b" !== "0b".substr(-1));
}, {} ],
16: [ function(e, t) {
t.exports = [ e("./transport/websocket"), e("./transport/xhr-streaming"), e("./transport/xdr-streaming"), e("./transport/eventsource"), e("./transport/lib/iframe-wrap")(e("./transport/eventsource")), e("./transport/htmlfile"), e("./transport/lib/iframe-wrap")(e("./transport/htmlfile")), e("./transport/xhr-polling"), e("./transport/xdr-polling"), e("./transport/lib/iframe-wrap")(e("./transport/xhr-polling")), e("./transport/jsonp-polling") ];
}, {
"./transport/eventsource": 20,
"./transport/htmlfile": 21,
"./transport/jsonp-polling": 23,
"./transport/lib/iframe-wrap": 26,
"./transport/websocket": 38,
"./transport/xdr-polling": 39,
"./transport/xdr-streaming": 40,
"./transport/xhr-polling": 41,
"./transport/xhr-streaming": 42
} ],
17: [ function(e, t) {
(function(r) {
var n = e("events").EventEmitter, i = e("inherits"), o = e("../../utils/event"), s = e("../../utils/url"), a = r.XMLHttpRequest, f = function() {};
function c(e, t, r, i) {
f(e, t);
var o = this;
n.call(this), setTimeout(function() {
o._start(e, t, r, i);
}, 0);
}
i(c, n), c.prototype._start = function(e, t, r, n) {
var i = this;
try {
this.xhr = new a();
} catch (e) {}
if (!this.xhr) return f("no xhr"), this.emit("finish", 0, "no xhr support"), void this._cleanup();
t = s.addQuery(t, "t=" + +new Date()), this.unloadRef = o.unloadAdd(function() {
f("unload cleanup"), i._cleanup(!0);
});
try {
this.xhr.open(e, t, !0), this.timeout && "timeout" in this.xhr && (this.xhr.timeout = this.timeout, 
this.xhr.ontimeout = function() {
f("xhr timeout"), i.emit("finish", 0, ""), i._cleanup(!1);
});
} catch (e) {
return f("exception", e), this.emit("finish", 0, ""), void this._cleanup(!1);
}
if (n && n.noCredentials || !c.supportsCORS || (f("withCredentials"), this.xhr.withCredentials = !0), 
n && n.headers) for (var u in n.headers) this.xhr.setRequestHeader(u, n.headers[u]);
this.xhr.onreadystatechange = function() {
if (i.xhr) {
var e, t, r = i.xhr;
switch (f("readyState", r.readyState), r.readyState) {
case 3:
try {
t = r.status, e = r.responseText;
} catch (e) {}
f("status", t), 1223 === t && (t = 204), 200 === t && e && 0 < e.length && (f("chunk"), 
i.emit("chunk", t, e));
break;

case 4:
t = r.status, f("status", t), 1223 === t && (t = 204), 12005 !== t && 12029 !== t || (t = 0), 
f("finish", t, r.responseText), i.emit("finish", t, r.responseText), i._cleanup(!1);
}
}
};
try {
i.xhr.send(r);
} catch (e) {
i.emit("finish", 0, ""), i._cleanup(!1);
}
}, c.prototype._cleanup = function(e) {
if (f("cleanup"), this.xhr) {
if (this.removeAllListeners(), o.unloadDel(this.unloadRef), this.xhr.onreadystatechange = function() {}, 
this.xhr.ontimeout && (this.xhr.ontimeout = null), e) try {
this.xhr.abort();
} catch (e) {}
this.unloadRef = this.xhr = null;
}
}, c.prototype.close = function() {
f("close"), this._cleanup(!0);
}, c.enabled = !!a;
var u = [ "Active" ].concat("Object").join("X");
!c.enabled && u in r && (f("overriding xmlhttprequest"), c.enabled = !!new (a = function() {
try {
return new r[u]("Microsoft.XMLHTTP");
} catch (e) {
return null;
}
})());
var h = !1;
try {
h = "withCredentials" in new a();
} catch (r) {}
c.supportsCORS = h, t.exports = c;
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../../utils/event": 46,
"../../utils/url": 52,
debug: void 0,
events: 3,
inherits: 54
} ],
18: [ function(e, t) {
(function(e) {
t.exports = e.EventSource;
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
19: [ function(e, t) {
(function(e) {
var r = e.WebSocket || e.MozWebSocket;
t.exports = r ? function(e) {
return new r(e);
} : void 0;
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
20: [ function(e, t) {
var r = e("inherits"), n = e("./lib/ajax-based"), i = e("./receiver/eventsource"), o = e("./sender/xhr-cors"), s = e("eventsource");
function a(e) {
if (!a.enabled()) throw new Error("Transport created when disabled");
n.call(this, e, "/eventsource", i, o);
}
r(a, n), a.enabled = function() {
return !!s;
}, a.transportName = "eventsource", a.roundTrips = 2, t.exports = a;
}, {
"./lib/ajax-based": 24,
"./receiver/eventsource": 29,
"./sender/xhr-cors": 35,
eventsource: 18,
inherits: 54
} ],
21: [ function(e, t) {
var r = e("inherits"), n = e("./receiver/htmlfile"), i = e("./sender/xhr-local"), o = e("./lib/ajax-based");
function s(e) {
if (!n.enabled) throw new Error("Transport created when disabled");
o.call(this, e, "/htmlfile", n, i);
}
r(s, o), s.enabled = function(e) {
return n.enabled && e.sameOrigin;
}, s.transportName = "htmlfile", s.roundTrips = 2, t.exports = s;
}, {
"./lib/ajax-based": 24,
"./receiver/htmlfile": 30,
"./sender/xhr-local": 37,
inherits: 54
} ],
22: [ function(e, t) {
var r = e("inherits"), n = e("json3"), i = e("events").EventEmitter, o = e("../version"), s = e("../utils/url"), a = e("../utils/iframe"), f = e("../utils/event"), c = e("../utils/random"), u = function() {};
function h(e, t, r) {
if (!h.enabled()) throw new Error("Transport created when disabled");
i.call(this);
var n = this;
this.origin = s.getOrigin(r), this.baseUrl = r, this.transUrl = t, this.transport = e, 
this.windowId = c.string(8);
var o = s.addPath(r, "/iframe.html") + "#" + this.windowId;
u(e, t, o), this.iframeObj = a.createIframe(o, function(e) {
u("err callback"), n.emit("close", 1006, "Unable to load an iframe (" + e + ")"), 
n.close();
}), this.onmessageCallback = this._message.bind(this), f.attachEvent("message", this.onmessageCallback);
}
r(h, i), h.prototype.close = function() {
if (u("close"), this.removeAllListeners(), this.iframeObj) {
f.detachEvent("message", this.onmessageCallback);
try {
this.postMessage("c");
} catch (e) {}
this.iframeObj.cleanup(), this.iframeObj = null, this.onmessageCallback = this.iframeObj = null;
}
}, h.prototype._message = function(e) {
if (u("message", e.data), s.isOriginEqual(e.origin, this.origin)) {
var t;
try {
t = n.parse(e.data);
} catch (r) {
return void u("bad json", e.data);
}
if (t.windowId === this.windowId) switch (t.type) {
case "s":
this.iframeObj.loaded(), this.postMessage("s", n.stringify([ o, this.transport, this.transUrl, this.baseUrl ]));
break;

case "t":
this.emit("message", t.data);
break;

case "c":
var r;
try {
r = n.parse(t.data);
} catch (r) {
return void u("bad json", t.data);
}
this.emit("close", r[0], r[1]), this.close();
} else u("mismatched window id", t.windowId, this.windowId);
} else u("not same origin", e.origin, this.origin);
}, h.prototype.postMessage = function(e, t) {
u("postMessage", e, t), this.iframeObj.post(n.stringify({
windowId: this.windowId,
type: e,
data: t || ""
}), this.origin);
}, h.prototype.send = function(e) {
u("send", e), this.postMessage("m", e);
}, h.enabled = function() {
return a.iframeEnabled;
}, h.transportName = "iframe", h.roundTrips = 2, t.exports = h;
}, {
"../utils/event": 46,
"../utils/iframe": 47,
"../utils/random": 50,
"../utils/url": 52,
"../version": 53,
debug: void 0,
events: 3,
inherits: 54,
json3: 55
} ],
23: [ function(e, t) {
(function(r) {
var n = e("inherits"), i = e("./lib/sender-receiver"), o = e("./receiver/jsonp"), s = e("./sender/jsonp");
function a(e) {
if (!a.enabled()) throw new Error("Transport created when disabled");
i.call(this, e, "/jsonp", s, o);
}
n(a, i), a.enabled = function() {
return !!r.document;
}, a.transportName = "jsonp-polling", a.roundTrips = 1, a.needBody = !0, t.exports = a;
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"./lib/sender-receiver": 28,
"./receiver/jsonp": 31,
"./sender/jsonp": 33,
inherits: 54
} ],
24: [ function(e, t) {
var r = e("inherits"), n = e("../../utils/url"), i = e("./sender-receiver"), o = function() {};
function s(e, t, r, s) {
var a;
i.call(this, e, t, (a = s, function(e, t, r) {
o("create ajax sender", e, t);
var i = {};
"string" == typeof t && (i.headers = {
"Content-type": "text/plain"
});
var s = n.addPath(e, "/xhr_send"), f = new a("POST", s, t, i);
return f.once("finish", function(e) {
if (o("finish", e), f = null, 200 !== e && 204 !== e) return r(new Error("http status " + e));
r();
}), function() {
o("abort"), f.close(), f = null;
var e = new Error("Aborted");
e.code = 1e3, r(e);
};
}), r, s);
}
r(s, i), t.exports = s;
}, {
"../../utils/url": 52,
"./sender-receiver": 28,
debug: void 0,
inherits: 54
} ],
25: [ function(e, t) {
var r = e("inherits"), n = e("events").EventEmitter, i = function() {};
function o(e, t) {
i(e), n.call(this), this.sendBuffer = [], this.sender = t, this.url = e;
}
r(o, n), o.prototype.send = function(e) {
i("send", e), this.sendBuffer.push(e), this.sendStop || this.sendSchedule();
}, o.prototype.sendScheduleWait = function() {
i("sendScheduleWait");
var e, t = this;
this.sendStop = function() {
i("sendStop"), t.sendStop = null, clearTimeout(e);
}, e = setTimeout(function() {
i("timeout"), t.sendStop = null, t.sendSchedule();
}, 25);
}, o.prototype.sendSchedule = function() {
i("sendSchedule", this.sendBuffer.length);
var e = this;
if (0 < this.sendBuffer.length) {
var t = "[" + this.sendBuffer.join(",") + "]";
this.sendStop = this.sender(this.url, t, function(t) {
e.sendStop = null, t ? (i("error", t), e.emit("close", t.code || 1006, "Sending error: " + t), 
e.close()) : e.sendScheduleWait();
}), this.sendBuffer = [];
}
}, o.prototype._cleanup = function() {
i("_cleanup"), this.removeAllListeners();
}, o.prototype.close = function() {
i("close"), this._cleanup(), this.sendStop && (this.sendStop(), this.sendStop = null);
}, t.exports = o;
}, {
debug: void 0,
events: 3,
inherits: 54
} ],
26: [ function(e, t) {
(function(r) {
var n = e("inherits"), i = e("../iframe"), o = e("../../utils/object");
t.exports = function(e) {
function t(t, r) {
i.call(this, e.transportName, t, r);
}
return n(t, i), t.enabled = function(t, n) {
if (!r.document) return !1;
var s = o.extend({}, n);
return s.sameOrigin = !0, e.enabled(s) && i.enabled();
}, t.transportName = "iframe-" + e.transportName, t.needBody = !0, t.roundTrips = i.roundTrips + e.roundTrips - 1, 
t.facadeTransport = e, t;
};
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../../utils/object": 49,
"../iframe": 22,
inherits: 54
} ],
27: [ function(e, t) {
var r = e("inherits"), n = e("events").EventEmitter, i = function() {};
function o(e, t, r) {
i(t), n.call(this), this.Receiver = e, this.receiveUrl = t, this.AjaxObject = r, 
this._scheduleReceiver();
}
r(o, n), o.prototype._scheduleReceiver = function() {
i("_scheduleReceiver");
var e = this, t = this.poll = new this.Receiver(this.receiveUrl, this.AjaxObject);
t.on("message", function(t) {
i("message", t), e.emit("message", t);
}), t.once("close", function(r, n) {
i("close", r, n, e.pollIsClosing), e.poll = t = null, e.pollIsClosing || ("network" === n ? e._scheduleReceiver() : (e.emit("close", r || 1006, n), 
e.removeAllListeners()));
});
}, o.prototype.abort = function() {
i("abort"), this.removeAllListeners(), this.pollIsClosing = !0, this.poll && this.poll.abort();
}, t.exports = o;
}, {
debug: void 0,
events: 3,
inherits: 54
} ],
28: [ function(e, t) {
var r = e("inherits"), n = e("../../utils/url"), i = e("./buffered-sender"), o = e("./polling"), s = function() {};
function a(e, t, r, a, f) {
var c = n.addPath(e, t);
s(c);
var u = this;
i.call(this, e, r), this.poll = new o(a, c, f), this.poll.on("message", function(e) {
s("poll message", e), u.emit("message", e);
}), this.poll.once("close", function(e, t) {
s("poll close", e, t), u.poll = null, u.emit("close", e, t), u.close();
});
}
r(a, i), a.prototype.close = function() {
i.prototype.close.call(this), s("close"), this.removeAllListeners(), this.poll && (this.poll.abort(), 
this.poll = null);
}, t.exports = a;
}, {
"../../utils/url": 52,
"./buffered-sender": 25,
"./polling": 27,
debug: void 0,
inherits: 54
} ],
29: [ function(e, t) {
var r = e("inherits"), n = e("events").EventEmitter, i = e("eventsource"), o = function() {};
function s(e) {
o(e), n.call(this);
var t = this, r = this.es = new i(e);
r.onmessage = function(e) {
o("message", e.data), t.emit("message", decodeURI(e.data));
}, r.onerror = function(e) {
o("error", r.readyState, e);
var n = 2 !== r.readyState ? "network" : "permanent";
t._cleanup(), t._close(n);
};
}
r(s, n), s.prototype.abort = function() {
o("abort"), this._cleanup(), this._close("user");
}, s.prototype._cleanup = function() {
o("cleanup");
var e = this.es;
e && (e.onmessage = e.onerror = null, e.close(), this.es = null);
}, s.prototype._close = function(e) {
o("close", e);
var t = this;
setTimeout(function() {
t.emit("close", null, e), t.removeAllListeners();
}, 200);
}, t.exports = s;
}, {
debug: void 0,
events: 3,
eventsource: 18,
inherits: 54
} ],
30: [ function(e, t) {
(function(r) {
var n = e("inherits"), i = e("../../utils/iframe"), o = e("../../utils/url"), s = e("events").EventEmitter, a = e("../../utils/random"), f = function() {};
function c(e) {
f(e), s.call(this);
var t = this;
i.polluteGlobalNamespace(), this.id = "a" + a.string(6), e = o.addQuery(e, "c=" + decodeURIComponent(i.WPrefix + "." + this.id)), 
f("using htmlfile", c.htmlfileEnabled);
var n = c.htmlfileEnabled ? i.createHtmlfile : i.createIframe;
r[i.WPrefix][this.id] = {
start: function() {
f("start"), t.iframeObj.loaded();
},
message: function(e) {
f("message", e), t.emit("message", e);
},
stop: function() {
f("stop"), t._cleanup(), t._close("network");
}
}, this.iframeObj = n(e, function() {
f("callback"), t._cleanup(), t._close("permanent");
});
}
n(c, s), c.prototype.abort = function() {
f("abort"), this._cleanup(), this._close("user");
}, c.prototype._cleanup = function() {
f("_cleanup"), this.iframeObj && (this.iframeObj.cleanup(), this.iframeObj = null), 
delete r[i.WPrefix][this.id];
}, c.prototype._close = function(e) {
f("_close", e), this.emit("close", null, e), this.removeAllListeners();
}, c.htmlfileEnabled = !1;
var u = [ "Active" ].concat("Object").join("X");
if (u in r) try {
c.htmlfileEnabled = !!new r[u]("htmlfile");
} catch (n) {}
c.enabled = c.htmlfileEnabled || i.iframeEnabled, t.exports = c;
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../../utils/iframe": 47,
"../../utils/random": 50,
"../../utils/url": 52,
debug: void 0,
events: 3,
inherits: 54
} ],
31: [ function(e, t) {
(function(r) {
var n = e("../../utils/iframe"), i = e("../../utils/random"), o = e("../../utils/browser"), s = e("../../utils/url"), a = e("inherits"), f = e("events").EventEmitter, c = function() {};
function u(e) {
c(e);
var t = this;
f.call(this), n.polluteGlobalNamespace(), this.id = "a" + i.string(6);
var o = s.addQuery(e, "c=" + encodeURIComponent(n.WPrefix + "." + this.id));
r[n.WPrefix][this.id] = this._callback.bind(this), this._createScript(o), this.timeoutId = setTimeout(function() {
c("timeout"), t._abort(new Error("JSONP script loaded abnormally (timeout)"));
}, u.timeout);
}
a(u, f), u.prototype.abort = function() {
if (c("abort"), r[n.WPrefix][this.id]) {
var e = new Error("JSONP user aborted read");
e.code = 1e3, this._abort(e);
}
}, u.timeout = 35e3, u.scriptErrorTimeout = 1e3, u.prototype._callback = function(e) {
c("_callback", e), this._cleanup(), this.aborting || (e && (c("message", e), this.emit("message", e)), 
this.emit("close", null, "network"), this.removeAllListeners());
}, u.prototype._abort = function(e) {
c("_abort", e), this._cleanup(), this.aborting = !0, this.emit("close", e.code, e.message), 
this.removeAllListeners();
}, u.prototype._cleanup = function() {
if (c("_cleanup"), clearTimeout(this.timeoutId), this.script2 && (this.script2.parentNode.removeChild(this.script2), 
this.script2 = null), this.script) {
var e = this.script;
e.parentNode.removeChild(e), e.onreadystatechange = e.onerror = e.onload = e.onclick = null, 
this.script = null;
}
delete r[n.WPrefix][this.id];
}, u.prototype._scriptError = function() {
c("_scriptError");
var e = this;
this.errorTimer || (this.errorTimer = setTimeout(function() {
e.loadedOkay || e._abort(new Error("JSONP script loaded abnormally (onerror)"));
}, u.scriptErrorTimeout));
}, u.prototype._createScript = function(e) {
c("_createScript", e);
var t, n = this, s = this.script = r.document.createElement("script");
if (s.id = "a" + i.string(8), s.src = e, s.type = "text/javascript", s.charset = "UTF-8", 
s.onerror = this._scriptError.bind(this), s.onload = function() {
c("onload"), n._abort(new Error("JSONP script loaded abnormally (onload)"));
}, s.onreadystatechange = function() {
if (c("onreadystatechange", s.readyState), /loaded|closed/.test(s.readyState)) {
if (s && s.htmlFor && s.onclick) {
n.loadedOkay = !0;
try {
s.onclick();
} catch (e) {}
}
s && n._abort(new Error("JSONP script loaded abnormally (onreadystatechange)"));
}
}, void 0 === s.async && r.document.attachEvent) if (o.isOpera()) (t = this.script2 = r.document.createElement("script")).text = "try{var a = document.getElementById('" + s.id + "'); if(a)a.onerror();}catch(x){};", 
s.async = t.async = !1; else {
try {
s.htmlFor = s.id, s.event = "onclick";
} catch (e) {}
s.async = !0;
}
void 0 !== s.async && (s.async = !0);
var a = r.document.getElementsByTagName("head")[0];
a.insertBefore(s, a.firstChild), t && a.insertBefore(t, a.firstChild);
}, t.exports = u;
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../../utils/browser": 44,
"../../utils/iframe": 47,
"../../utils/random": 50,
"../../utils/url": 52,
debug: void 0,
events: 3,
inherits: 54
} ],
32: [ function(e, t) {
var r = e("inherits"), n = e("events").EventEmitter, i = function() {};
function o(e, t) {
i(e), n.call(this);
var r = this;
this.bufferPosition = 0, this.xo = new t("POST", e, null), this.xo.on("chunk", this._chunkHandler.bind(this)), 
this.xo.once("finish", function(e, t) {
i("finish", e, t), r._chunkHandler(e, t), r.xo = null;
var n = 200 === e ? "network" : "permanent";
i("close", n), r.emit("close", null, n), r._cleanup();
});
}
r(o, n), o.prototype._chunkHandler = function(e, t) {
if (i("_chunkHandler", e), 200 === e && t) for (var r = -1; ;this.bufferPosition += r + 1) {
var n = t.slice(this.bufferPosition);
if (-1 === (r = n.indexOf("\n"))) break;
var o = n.slice(0, r);
o && (i("message", o), this.emit("message", o));
}
}, o.prototype._cleanup = function() {
i("_cleanup"), this.removeAllListeners();
}, o.prototype.abort = function() {
i("abort"), this.xo && (this.xo.close(), i("close"), this.emit("close", null, "user"), 
this.xo = null), this._cleanup();
}, t.exports = o;
}, {
debug: void 0,
events: 3,
inherits: 54
} ],
33: [ function(e, t) {
(function(r) {
var n, i, o = e("../../utils/random"), s = e("../../utils/url");
t.exports = function(e, t, a) {
n || ((n = r.document.createElement("form")).style.display = "none", n.style.position = "absolute", 
n.method = "POST", n.enctype = "application/x-www-form-urlencoded", n.acceptCharset = "UTF-8", 
(i = r.document.createElement("textarea")).name = "d", n.appendChild(i), r.document.body.appendChild(n));
var f = "a" + o.string(8);
n.target = f, n.action = s.addQuery(s.addPath(e, "/jsonp_send"), "i=" + f);
var c = function(e) {
try {
return r.document.createElement('<iframe name="' + e + '">');
} catch (n) {
var t = r.document.createElement("iframe");
return t.name = e, t;
}
}(f);
c.id = f, c.style.display = "none", n.appendChild(c);
try {
i.value = t;
} catch (e) {}
n.submit();
var u = function(e) {
c.onerror && (c.onreadystatechange = c.onerror = c.onload = null, setTimeout(function() {
c.parentNode.removeChild(c), c = null;
}, 500), i.value = "", a(e));
};
return c.onerror = function() {
u();
}, c.onload = function() {
u();
}, c.onreadystatechange = function() {
c.readyState, "complete" === c.readyState && u();
}, function() {
u(new Error("Aborted"));
};
};
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../../utils/random": 50,
"../../utils/url": 52,
debug: void 0
} ],
34: [ function(e, t) {
(function(r) {
var n = e("events").EventEmitter, i = e("inherits"), o = e("../../utils/event"), s = e("../../utils/browser"), a = e("../../utils/url"), f = function() {};
function c(e, t, r) {
f(e, t);
var i = this;
n.call(this), setTimeout(function() {
i._start(e, t, r);
}, 0);
}
i(c, n), c.prototype._start = function(e, t, n) {
f("_start");
var i = this, s = new r.XDomainRequest();
t = a.addQuery(t, "t=" + +new Date()), s.onerror = function() {
f("onerror"), i._error();
}, s.ontimeout = function() {
f("ontimeout"), i._error();
}, s.onprogress = function() {
f("progress", s.responseText), i.emit("chunk", 200, s.responseText);
}, s.onload = function() {
f("load"), i.emit("finish", 200, s.responseText), i._cleanup(!1);
}, this.xdr = s, this.unloadRef = o.unloadAdd(function() {
i._cleanup(!0);
});
try {
this.xdr.open(e, t), this.timeout && (this.xdr.timeout = this.timeout), this.xdr.send(n);
} catch (e) {
this._error();
}
}, c.prototype._error = function() {
this.emit("finish", 0, ""), this._cleanup(!1);
}, c.prototype._cleanup = function(e) {
if (f("cleanup", e), this.xdr) {
if (this.removeAllListeners(), o.unloadDel(this.unloadRef), this.xdr.ontimeout = this.xdr.onerror = this.xdr.onprogress = this.xdr.onload = null, 
e) try {
this.xdr.abort();
} catch (e) {}
this.unloadRef = this.xdr = null;
}
}, c.prototype.close = function() {
f("close"), this._cleanup(!0);
}, c.enabled = !(!r.XDomainRequest || !s.hasDomain()), t.exports = c;
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../../utils/browser": 44,
"../../utils/event": 46,
"../../utils/url": 52,
debug: void 0,
events: 3,
inherits: 54
} ],
35: [ function(e, t) {
var r = e("inherits"), n = e("../driver/xhr");
function i(e, t, r, i) {
n.call(this, e, t, r, i);
}
r(i, n), i.enabled = n.enabled && n.supportsCORS, t.exports = i;
}, {
"../driver/xhr": 17,
inherits: 54
} ],
36: [ function(e, t) {
var r = e("events").EventEmitter;
function n() {
var e = this;
r.call(this), this.to = setTimeout(function() {
e.emit("finish", 200, "{}");
}, n.timeout);
}
e("inherits")(n, r), n.prototype.close = function() {
clearTimeout(this.to);
}, n.timeout = 2e3, t.exports = n;
}, {
events: 3,
inherits: 54
} ],
37: [ function(e, t) {
var r = e("inherits"), n = e("../driver/xhr");
function i(e, t, r) {
n.call(this, e, t, r, {
noCredentials: !0
});
}
r(i, n), i.enabled = n.enabled, t.exports = i;
}, {
"../driver/xhr": 17,
inherits: 54
} ],
38: [ function(e, t) {
var r = e("../utils/event"), n = e("../utils/url"), i = e("inherits"), o = e("events").EventEmitter, s = e("./driver/websocket"), a = function() {};
function f(e, t, i) {
if (!f.enabled()) throw new Error("Transport created when disabled");
o.call(this), a("constructor", e);
var c = this, u = n.addPath(e, "/websocket");
u = "https" === u.slice(0, 5) ? "wss" + u.slice(5) : "ws" + u.slice(4), this.url = u, 
this.ws = new s(this.url, [], i), this.ws.onmessage = function(e) {
a("message event", e.data), c.emit("message", e.data);
}, this.unloadRef = r.unloadAdd(function() {
a("unload"), c.ws.close();
}), this.ws.onclose = function(e) {
a("close event", e.code, e.reason), c.emit("close", e.code, e.reason), c._cleanup();
}, this.ws.onerror = function(e) {
a("error event", e), c.emit("close", 1006, "WebSocket connection broken"), c._cleanup();
};
}
i(f, o), f.prototype.send = function(e) {
var t = "[" + e + "]";
a("send", t), this.ws.send(t);
}, f.prototype.close = function() {
a("close");
var e = this.ws;
this._cleanup(), e && e.close();
}, f.prototype._cleanup = function() {
a("_cleanup");
var e = this.ws;
e && (e.onmessage = e.onclose = e.onerror = null), r.unloadDel(this.unloadRef), 
this.unloadRef = this.ws = null, this.removeAllListeners();
}, f.enabled = function() {
return a("enabled"), !!s;
}, f.transportName = "websocket", f.roundTrips = 2, t.exports = f;
}, {
"../utils/event": 46,
"../utils/url": 52,
"./driver/websocket": 19,
debug: void 0,
events: 3,
inherits: 54
} ],
39: [ function(e, t) {
var r = e("inherits"), n = e("./lib/ajax-based"), i = e("./xdr-streaming"), o = e("./receiver/xhr"), s = e("./sender/xdr");
function a(e) {
if (!s.enabled) throw new Error("Transport created when disabled");
n.call(this, e, "/xhr", o, s);
}
r(a, n), a.enabled = i.enabled, a.transportName = "xdr-polling", a.roundTrips = 2, 
t.exports = a;
}, {
"./lib/ajax-based": 24,
"./receiver/xhr": 32,
"./sender/xdr": 34,
"./xdr-streaming": 40,
inherits: 54
} ],
40: [ function(e, t) {
var r = e("inherits"), n = e("./lib/ajax-based"), i = e("./receiver/xhr"), o = e("./sender/xdr");
function s(e) {
if (!o.enabled) throw new Error("Transport created when disabled");
n.call(this, e, "/xhr_streaming", i, o);
}
r(s, n), s.enabled = function(e) {
return !e.cookie_needed && !e.nullOrigin && o.enabled && e.sameScheme;
}, s.transportName = "xdr-streaming", s.roundTrips = 2, t.exports = s;
}, {
"./lib/ajax-based": 24,
"./receiver/xhr": 32,
"./sender/xdr": 34,
inherits: 54
} ],
41: [ function(e, t) {
var r = e("inherits"), n = e("./lib/ajax-based"), i = e("./receiver/xhr"), o = e("./sender/xhr-cors"), s = e("./sender/xhr-local");
function a(e) {
if (!s.enabled && !o.enabled) throw new Error("Transport created when disabled");
n.call(this, e, "/xhr", i, o);
}
r(a, n), a.enabled = function(e) {
return !e.nullOrigin && (!(!s.enabled || !e.sameOrigin) || o.enabled);
}, a.transportName = "xhr-polling", a.roundTrips = 2, t.exports = a;
}, {
"./lib/ajax-based": 24,
"./receiver/xhr": 32,
"./sender/xhr-cors": 35,
"./sender/xhr-local": 37,
inherits: 54
} ],
42: [ function(e, t) {
(function(r) {
var n = e("inherits"), i = e("./lib/ajax-based"), o = e("./receiver/xhr"), s = e("./sender/xhr-cors"), a = e("./sender/xhr-local"), f = e("../utils/browser");
function c(e) {
if (!a.enabled && !s.enabled) throw new Error("Transport created when disabled");
i.call(this, e, "/xhr_streaming", o, s);
}
n(c, i), c.enabled = function(e) {
return !e.nullOrigin && !f.isOpera() && s.enabled;
}, c.transportName = "xhr-streaming", c.roundTrips = 2, c.needBody = !!r.document, 
t.exports = c;
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../utils/browser": 44,
"./lib/ajax-based": 24,
"./receiver/xhr": 32,
"./sender/xhr-cors": 35,
"./sender/xhr-local": 37,
inherits: 54
} ],
43: [ function(e, t) {
(function(e) {
e.crypto && e.crypto.getRandomValues ? t.exports.randomBytes = function(t) {
var r = new Uint8Array(t);
return e.crypto.getRandomValues(r), r;
} : t.exports.randomBytes = function(e) {
for (var t = new Array(e), r = 0; r < e; r++) t[r] = Math.floor(256 * Math.random());
return t;
};
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
44: [ function(e, t) {
(function(e) {
t.exports = {
isOpera: function() {
return e.navigator && /opera/i.test(e.navigator.userAgent);
},
isKonqueror: function() {
return e.navigator && /konqueror/i.test(e.navigator.userAgent);
},
hasDomain: function() {
if (!e.document) return !0;
try {
return !!e.document.domain;
} catch (e) {
return !1;
}
}
};
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
45: [ function(e, t) {
var r, n = e("json3"), i = /[\x00-\x1f\ud800-\udfff\ufffe\uffff\u0300-\u0333\u033d-\u0346\u034a-\u034c\u0350-\u0352\u0357-\u0358\u035c-\u0362\u0374\u037e\u0387\u0591-\u05af\u05c4\u0610-\u0617\u0653-\u0654\u0657-\u065b\u065d-\u065e\u06df-\u06e2\u06eb-\u06ec\u0730\u0732-\u0733\u0735-\u0736\u073a\u073d\u073f-\u0741\u0743\u0745\u0747\u07eb-\u07f1\u0951\u0958-\u095f\u09dc-\u09dd\u09df\u0a33\u0a36\u0a59-\u0a5b\u0a5e\u0b5c-\u0b5d\u0e38-\u0e39\u0f43\u0f4d\u0f52\u0f57\u0f5c\u0f69\u0f72-\u0f76\u0f78\u0f80-\u0f83\u0f93\u0f9d\u0fa2\u0fa7\u0fac\u0fb9\u1939-\u193a\u1a17\u1b6b\u1cda-\u1cdb\u1dc0-\u1dcf\u1dfc\u1dfe\u1f71\u1f73\u1f75\u1f77\u1f79\u1f7b\u1f7d\u1fbb\u1fbe\u1fc9\u1fcb\u1fd3\u1fdb\u1fe3\u1feb\u1fee-\u1fef\u1ff9\u1ffb\u1ffd\u2000-\u2001\u20d0-\u20d1\u20d4-\u20d7\u20e7-\u20e9\u2126\u212a-\u212b\u2329-\u232a\u2adc\u302b-\u302c\uaab2-\uaab3\uf900-\ufa0d\ufa10\ufa12\ufa15-\ufa1e\ufa20\ufa22\ufa25-\ufa26\ufa2a-\ufa2d\ufa30-\ufa6d\ufa70-\ufad9\ufb1d\ufb1f\ufb2a-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufb4e\ufff0-\uffff]/g;
t.exports = {
quote: function(e) {
var t = n.stringify(e);
return i.lastIndex = 0, i.test(t) ? (r || (r = function(e) {
var t, r = {}, n = [];
for (t = 0; t < 65536; t++) n.push(String.fromCharCode(t));
return e.lastIndex = 0, n.join("").replace(e, function(e) {
return r[e] = "\\u" + ("0000" + e.charCodeAt(0).toString(16)).slice(-4), "";
}), e.lastIndex = 0, r;
}(i)), t.replace(i, function(e) {
return r[e];
})) : t;
}
};
}, {
json3: 55
} ],
46: [ function(e, t) {
(function(r) {
var n = e("./random"), i = {}, o = !1, s = r.chrome && r.chrome.app && r.chrome.app.runtime;
t.exports = {
attachEvent: function(e, t) {
void 0 !== r.addEventListener ? r.addEventListener(e, t, !1) : r.document && r.attachEvent && (r.document.attachEvent("on" + e, t), 
r.attachEvent("on" + e, t));
},
detachEvent: function(e, t) {
void 0 !== r.addEventListener ? r.removeEventListener(e, t, !1) : r.document && r.detachEvent && (r.document.detachEvent("on" + e, t), 
r.detachEvent("on" + e, t));
},
unloadAdd: function(e) {
if (s) return null;
var t = n.string(8);
return i[t] = e, o && setTimeout(this.triggerUnloadCallbacks, 0), t;
},
unloadDel: function(e) {
e in i && delete i[e];
},
triggerUnloadCallbacks: function() {
for (var e in i) i[e](), delete i[e];
}
};
s || t.exports.attachEvent("unload", function() {
o || (o = !0, t.exports.triggerUnloadCallbacks());
});
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"./random": 50
} ],
47: [ function(e, t) {
(function(r) {
var n = e("./event"), i = e("json3"), o = e("./browser");
t.exports = {
WPrefix: "_jp",
currentWindowId: null,
polluteGlobalNamespace: function() {
t.exports.WPrefix in r || (r[t.exports.WPrefix] = {});
},
postMessage: function(e, n) {
r.parent !== r && r.parent.postMessage(i.stringify({
windowId: t.exports.currentWindowId,
type: e,
data: n || ""
}), "*");
},
createIframe: function(e, t) {
var i, o, s = r.document.createElement("iframe"), a = function() {
clearTimeout(i);
try {
s.onload = null;
} catch (e) {}
s.onerror = null;
}, f = function() {
s && (a(), setTimeout(function() {
s && s.parentNode.removeChild(s), s = null;
}, 0), n.unloadDel(o));
}, c = function(e) {
s && (f(), t(e));
};
return s.src = e, s.style.display = "none", s.style.position = "absolute", s.onerror = function() {
c("onerror");
}, s.onload = function() {
clearTimeout(i), i = setTimeout(function() {
c("onload timeout");
}, 2e3);
}, r.document.body.appendChild(s), i = setTimeout(function() {
c("timeout");
}, 15e3), o = n.unloadAdd(f), {
post: function(e, t) {
setTimeout(function() {
try {
s && s.contentWindow && s.contentWindow.postMessage(e, t);
} catch (e) {}
}, 0);
},
cleanup: f,
loaded: a
};
},
createHtmlfile: function(e, i) {
var o, s, a, f = [ "Active" ].concat("Object").join("X"), c = new r[f]("htmlfile"), u = function() {
clearTimeout(o), a.onerror = null;
}, h = function() {
c && (u(), n.unloadDel(s), a.parentNode.removeChild(a), a = c = null, CollectGarbage());
}, d = function(e) {
c && (h(), i(e));
};
c.open(), c.write('<html><script>document.domain="' + r.document.domain + '";<\/script></html>'), 
c.close(), c.parentWindow[t.exports.WPrefix] = r[t.exports.WPrefix];
var l = c.createElement("div");
return c.body.appendChild(l), a = c.createElement("iframe"), l.appendChild(a), a.src = e, 
a.onerror = function() {
d("onerror");
}, o = setTimeout(function() {
d("timeout");
}, 15e3), s = n.unloadAdd(h), {
post: function(e, t) {
try {
setTimeout(function() {
a && a.contentWindow && a.contentWindow.postMessage(e, t);
}, 0);
} catch (e) {}
},
cleanup: h,
loaded: u
};
}
}, t.exports.iframeEnabled = !1, r.document && (t.exports.iframeEnabled = ("function" == typeof r.postMessage || "object" == typeof r.postMessage) && !o.isKonqueror());
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"./browser": 44,
"./event": 46,
debug: void 0,
json3: 55
} ],
48: [ function(e, t) {
(function(e) {
var r = {};
[ "log", "debug", "warn" ].forEach(function(t) {
var n;
try {
n = e.console && e.console[t] && e.console[t].apply;
} catch (t) {}
r[t] = n ? function() {
return e.console[t].apply(e.console, arguments);
} : "log" === t ? function() {} : r.log;
}), t.exports = r;
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
49: [ function(e, t) {
t.exports = {
isObject: function(e) {
var t = typeof e;
return "function" === t || "object" === t && !!e;
},
extend: function(e) {
if (!this.isObject(e)) return e;
for (var t, r, n = 1, i = arguments.length; n < i; n++) for (r in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
return e;
}
};
}, {} ],
50: [ function(e, t) {
var r = e("crypto"), n = "abcdefghijklmnopqrstuvwxyz012345";
t.exports = {
string: function(e) {
for (var t = n.length, i = r.randomBytes(e), o = [], s = 0; s < e; s++) o.push(n.substr(i[s] % t, 1));
return o.join("");
},
number: function(e) {
return Math.floor(Math.random() * e);
},
numberString: function(e) {
var t = ("" + (e - 1)).length;
return (new Array(t + 1).join("0") + this.number(e)).slice(-t);
}
};
}, {
crypto: 43
} ],
51: [ function(e, t) {
t.exports = function(e) {
return {
filterToEnabled: function(t, r) {
var n = {
main: [],
facade: []
};
return t ? "string" == typeof t && (t = [ t ]) : t = [], e.forEach(function(e) {
e && ("websocket" !== e.transportName || !1 !== r.websocket) && (t.length && -1 === t.indexOf(e.transportName) ? e.transportName : e.enabled(r) ? (e.transportName, 
n.main.push(e), e.facadeTransport && n.facade.push(e.facadeTransport)) : e.transportName);
}), n;
}
};
};
}, {
debug: void 0
} ],
52: [ function(e, t) {
var r = e("url-parse");
t.exports = {
getOrigin: function(e) {
if (!e) return null;
var t = new r(e);
if ("file:" === t.protocol) return null;
var n = t.port;
return n || (n = "https:" === t.protocol ? "443" : "80"), t.protocol + "//" + t.hostname + ":" + n;
},
isOriginEqual: function(e, t) {
return this.getOrigin(e) === this.getOrigin(t);
},
isSchemeEqual: function(e, t) {
return e.split(":")[0] === t.split(":")[0];
},
addPath: function(e, t) {
var r = e.split("?");
return r[0] + t + (r[1] ? "?" + r[1] : "");
},
addQuery: function(e, t) {
return e + (-1 === e.indexOf("?") ? "?" + t : "&" + t);
}
};
}, {
debug: void 0,
"url-parse": 58
} ],
53: [ function(e, t) {
t.exports = "1.3.0";
}, {} ],
54: [ function(e, t) {
"function" == typeof Object.create ? t.exports = function(e, t) {
e.super_ = t, e.prototype = Object.create(t.prototype, {
constructor: {
value: e,
enumerable: !1,
writable: !0,
configurable: !0
}
});
} : t.exports = function(e, t) {
e.super_ = t;
var r = function() {};
r.prototype = t.prototype, e.prototype = new r(), e.prototype.constructor = e;
};
}, {} ],
55: [ function(e, t, r) {
(function(e) {
(function() {
var n = {
function: !0,
object: !0
}, i = n[typeof r] && r && !r.nodeType && r, o = n[typeof window] && window || this, s = i && n[typeof t] && t && !t.nodeType && "object" == typeof e && e;
function a(e, t) {
e || (e = o.Object()), t || (t = o.Object());
var r = e.Number || o.Number, i = e.String || o.String, s = e.Object || o.Object, f = e.Date || o.Date, c = e.SyntaxError || o.SyntaxError, u = e.TypeError || o.TypeError, h = e.Math || o.Math, d = e.JSON || o.JSON;
"object" == typeof d && d && (t.stringify = d.stringify, t.parse = d.parse);
var l, p, b, m = s.prototype, v = m.toString, y = new f(-0xc782b5b800cec);
try {
y = -109252 == y.getUTCFullYear() && 0 === y.getUTCMonth() && 1 === y.getUTCDate() && 10 == y.getUTCHours() && 37 == y.getUTCMinutes() && 6 == y.getUTCSeconds() && 708 == y.getUTCMilliseconds();
} catch (e) {}
function g(e) {
if (g[e] !== b) return g[e];
var n;
if ("bug-string-char-index" == e) n = "a" != "a"[0]; else if ("json" == e) n = g("json-stringify") && g("json-parse"); else {
var o, s = '{"a":[1,true,false,null,"\\u0000\\b\\n\\f\\r\\t"]}';
if ("json-stringify" == e) {
var a = t.stringify, c = "function" == typeof a && y;
if (c) {
(o = function() {
return 1;
}).toJSON = o;
try {
c = "0" === a(0) && "0" === a(new r()) && '""' == a(new i()) && a(v) === b && a(b) === b && a() === b && "1" === a(o) && "[1]" == a([ o ]) && "[null]" == a([ b ]) && "null" == a(null) && "[null,null,null]" == a([ b, v, null ]) && a({
a: [ o, !0, !1, null, "\0\b\n\f\r\t" ]
}) == s && "1" === a(null, o) && "[\n 1,\n 2\n]" == a([ 1, 2 ], null, 1) && '"-271821-04-20T00:00:00.000Z"' == a(new f(-864e13)) && '"+275760-09-13T00:00:00.000Z"' == a(new f(864e13)) && '"-000001-01-01T00:00:00.000Z"' == a(new f(-621987552e5)) && '"1969-12-31T23:59:59.999Z"' == a(new f(-1));
} catch (e) {
c = !1;
}
}
n = c;
}
if ("json-parse" == e) {
var u = t.parse;
if ("function" == typeof u) try {
if (0 === u("0") && !u(!1)) {
var h = 5 == (o = u(s)).a.length && 1 === o.a[0];
if (h) {
try {
h = !u('"\t"');
} catch (e) {}
if (h) try {
h = 1 !== u("01");
} catch (e) {}
if (h) try {
h = 1 !== u("1.");
} catch (e) {}
}
}
} catch (e) {
h = !1;
}
n = h;
}
}
return g[e] = !!n;
}
if (!g("json")) {
var _ = "[object Function]", w = "[object Number]", E = "[object String]", S = "[object Array]", M = g("bug-string-char-index");
if (!y) var A = h.floor, x = [ 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 ], k = function(e, t) {
return x[t] + 365 * (e - 1970) + A((e - 1969 + (t = +(1 < t))) / 4) - A((e - 1901 + t) / 100) + A((e - 1601 + t) / 400);
};
if ((l = m.hasOwnProperty) || (l = function(e) {
var t, r = {};
return l = (r.__proto__ = null, r.__proto__ = {
toString: 1
}, r).toString != v ? function(e) {
var t = this.__proto__, r = e in (this.__proto__ = null, this);
return this.__proto__ = t, r;
} : (t = r.constructor, function(e) {
var r = (this.constructor || t).prototype;
return e in this && !(e in r && this[e] === r[e]);
}), r = null, l.call(this, e);
}), p = function(e, t) {
var r, i, o, s = 0;
for (o in (r = function() {
this.valueOf = 0;
}).prototype.valueOf = 0, i = new r()) l.call(i, o) && s++;
return r = i = null, (p = s ? 2 == s ? function(e, t) {
var r, n = {}, i = v.call(e) == _;
for (r in e) i && "prototype" == r || l.call(n, r) || !(n[r] = 1) || !l.call(e, r) || t(r);
} : function(e, t) {
var r, n, i = v.call(e) == _;
for (r in e) i && "prototype" == r || !l.call(e, r) || (n = "constructor" === r) || t(r);
(n || l.call(e, r = "constructor")) && t(r);
} : (i = [ "valueOf", "toString", "toLocaleString", "propertyIsEnumerable", "isPrototypeOf", "hasOwnProperty", "constructor" ], 
function(e, t) {
var r, o, s = v.call(e) == _, a = !s && "function" != typeof e.constructor && n[typeof e.hasOwnProperty] && e.hasOwnProperty || l;
for (r in e) s && "prototype" == r || !a.call(e, r) || t(r);
for (o = i.length; r = i[--o]; a.call(e, r) && t(r)) ;
}))(e, t);
}, !g("json-stringify")) {
var T = {
92: "\\\\",
34: '\\"',
8: "\\b",
12: "\\f",
10: "\\n",
13: "\\r",
9: "\\t"
}, I = function(e, t) {
return ("000000" + (t || 0)).slice(-e);
}, O = function(e) {
for (var t = '"', r = 0, n = e.length, i = !M || 10 < n, o = i && (M ? e.split("") : e); r < n; r++) {
var s = e.charCodeAt(r);
switch (s) {
case 8:
case 9:
case 10:
case 12:
case 13:
case 34:
case 92:
t += T[s];
break;

default:
if (s < 32) {
t += "\\u00" + I(2, s.toString(16));
break;
}
t += i ? o[r] : e.charAt(r);
}
}
return t + '"';
}, R = function e(t, r, n, i, o, s, a) {
var f, c, h, d, m, y, g, _, M, x, T, R, C, N, j, P;
try {
f = r[t];
} catch (t) {}
if ("object" == typeof f && f) if ("[object Date]" != (c = v.call(f)) || l.call(f, "toJSON")) "function" == typeof f.toJSON && (c != w && c != E && c != S || l.call(f, "toJSON")) && (f = f.toJSON(t)); else if (-1 / 0 < f && f < 1 / 0) {
if (k) {
for (m = A(f / 864e5), h = A(m / 365.2425) + 1970 - 1; k(h + 1, 0) <= m; h++) ;
for (d = A((m - k(h, 0)) / 30.42); k(h, d + 1) <= m; d++) ;
m = 1 + m - k(h, d), g = A((y = (f % 864e5 + 864e5) % 864e5) / 36e5) % 24, _ = A(y / 6e4) % 60, 
M = A(y / 1e3) % 60, x = y % 1e3;
} else h = f.getUTCFullYear(), d = f.getUTCMonth(), m = f.getUTCDate(), g = f.getUTCHours(), 
_ = f.getUTCMinutes(), M = f.getUTCSeconds(), x = f.getUTCMilliseconds();
f = (h <= 0 || 1e4 <= h ? (h < 0 ? "-" : "+") + I(6, h < 0 ? -h : h) : I(4, h)) + "-" + I(2, d + 1) + "-" + I(2, m) + "T" + I(2, g) + ":" + I(2, _) + ":" + I(2, M) + "." + I(3, x) + "Z";
} else f = null;
if (n && (f = n.call(r, t, f)), null === f) return "null";
if ("[object Boolean]" == (c = v.call(f))) return "" + f;
if (c == w) return -1 / 0 < f && f < 1 / 0 ? "" + f : "null";
if (c == E) return O("" + f);
if ("object" == typeof f) {
for (N = a.length; N--; ) if (a[N] === f) throw u();
if (a.push(f), T = [], j = s, s += o, c == S) {
for (C = 0, N = f.length; C < N; C++) R = e(C, f, n, i, o, s, a), T.push(R === b ? "null" : R);
P = T.length ? o ? "[\n" + s + T.join(",\n" + s) + "\n" + j + "]" : "[" + T.join(",") + "]" : "[]";
} else p(i || f, function(t) {
var r = e(t, f, n, i, o, s, a);
r !== b && T.push(O(t) + ":" + (o ? " " : "") + r);
}), P = T.length ? o ? "{\n" + s + T.join(",\n" + s) + "\n" + j + "}" : "{" + T.join(",") + "}" : "{}";
return a.pop(), P;
}
};
t.stringify = function(e, t, r) {
var i, o, s, a;
if (n[typeof t] && t) if ((a = v.call(t)) == _) o = t; else if (a == S) {
s = {};
for (var f, c = 0, u = t.length; c < u; f = t[c++], ((a = v.call(f)) == E || a == w) && (s[f] = 1)) ;
}
if (r) if ((a = v.call(r)) == w) {
if (0 < (r -= r % 1)) for (i = "", 10 < r && (r = 10); i.length < r; i += " ") ;
} else a == E && (i = r.length <= 10 ? r : r.slice(0, 10));
return R("", ((f = {})[""] = e, f), o, s, i, "", []);
};
}
if (!g("json-parse")) {
var C, N, j = i.fromCharCode, P = {
92: "\\",
34: '"',
47: "/",
98: "\b",
116: "\t",
110: "\n",
102: "\f",
114: "\r"
}, D = function() {
throw C = N = null, c();
}, L = function() {
for (var e, t, r, n, i, o = N, s = o.length; C < s; ) switch (i = o.charCodeAt(C)) {
case 9:
case 10:
case 13:
case 32:
C++;
break;

case 123:
case 125:
case 91:
case 93:
case 58:
case 44:
return e = M ? o.charAt(C) : o[C], C++, e;

case 34:
for (e = "@", C++; C < s; ) if ((i = o.charCodeAt(C)) < 32) D(); else if (92 == i) switch (i = o.charCodeAt(++C)) {
case 92:
case 34:
case 47:
case 98:
case 116:
case 110:
case 102:
case 114:
e += P[i], C++;
break;

case 117:
for (t = ++C, r = C + 4; C < r; C++) 48 <= (i = o.charCodeAt(C)) && i <= 57 || 97 <= i && i <= 102 || 65 <= i && i <= 70 || D();
e += j("0x" + o.slice(t, C));
break;

default:
D();
} else {
if (34 == i) break;
for (i = o.charCodeAt(C), t = C; 32 <= i && 92 != i && 34 != i; ) i = o.charCodeAt(++C);
e += o.slice(t, C);
}
if (34 == o.charCodeAt(C)) return C++, e;
D();

default:
if (t = C, 45 == i && (n = !0, i = o.charCodeAt(++C)), 48 <= i && i <= 57) {
for (48 == i && 48 <= (i = o.charCodeAt(C + 1)) && i <= 57 && D(), n = !1; C < s && 48 <= (i = o.charCodeAt(C)) && i <= 57; C++) ;
if (46 == o.charCodeAt(C)) {
for (r = ++C; r < s && 48 <= (i = o.charCodeAt(r)) && i <= 57; r++) ;
r == C && D(), C = r;
}
if (101 == (i = o.charCodeAt(C)) || 69 == i) {
for (43 != (i = o.charCodeAt(++C)) && 45 != i || C++, r = C; r < s && 48 <= (i = o.charCodeAt(r)) && i <= 57; r++) ;
r == C && D(), C = r;
}
return +o.slice(t, C);
}
if (n && D(), "true" == o.slice(C, C + 4)) return C += 4, !0;
if ("false" == o.slice(C, C + 5)) return C += 5, !1;
if ("null" == o.slice(C, C + 4)) return C += 4, null;
D();
}
return "$";
}, B = function e(t) {
var r, n;
if ("$" == t && D(), "string" == typeof t) {
if ("@" == (M ? t.charAt(0) : t[0])) return t.slice(1);
if ("[" == t) {
for (r = []; "]" != (t = L()); n || (n = !0)) n && ("," == t ? "]" == (t = L()) && D() : D()), 
"," == t && D(), r.push(e(t));
return r;
}
if ("{" == t) {
for (r = {}; "}" != (t = L()); n || (n = !0)) n && ("," == t ? "}" == (t = L()) && D() : D()), 
"," != t && "string" == typeof t && "@" == (M ? t.charAt(0) : t[0]) && ":" == L() || D(), 
r[t.slice(1)] = e(L());
return r;
}
D();
}
return t;
}, U = function(e, t, r) {
var n = F(e, t, r);
n === b ? delete e[t] : e[t] = n;
}, F = function(e, t, r) {
var n, i = e[t];
if ("object" == typeof i && i) if (v.call(i) == S) for (n = i.length; n--; ) U(i, n, r); else p(i, function(e) {
U(i, e, r);
});
return r.call(e, t, i);
};
t.parse = function(e, t) {
var r, n;
return C = 0, N = "" + e, r = B(L()), "$" != L() && D(), C = N = null, t && v.call(t) == _ ? F(((n = {})[""] = r, 
n), "", t) : r;
};
}
}
return t.runInContext = a, t;
}
if (!s || s.global !== s && s.window !== s && s.self !== s || (o = s), i) a(o, i); else {
var f = o.JSON, c = o.JSON3, u = !1, h = a(o, o.JSON3 = {
noConflict: function() {
return u || (u = !0, o.JSON = f, o.JSON3 = c, f = c = null), h;
}
});
o.JSON = {
parse: h.parse,
stringify: h.stringify
};
}
}).call(this);
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
56: [ function(e, t, r) {
var n = Object.prototype.hasOwnProperty;
function i(e) {
return decodeURIComponent(e.replace(/\+/g, " "));
}
r.stringify = function(e, t) {
t = t || "";
var r = [];
for (var i in "string" != typeof t && (t = "?"), e) n.call(e, i) && r.push(encodeURIComponent(i) + "=" + encodeURIComponent(e[i]));
return r.length ? t + r.join("&") : "";
}, r.parse = function(e) {
for (var t, r = /([^=?&]+)=?([^&]*)/g, n = {}; t = r.exec(e); ) {
var o = i(t[1]), s = i(t[2]);
o in n || (n[o] = s);
}
return n;
};
}, {} ],
57: [ function(e, t) {
t.exports = function(e, t) {
if (t = t.split(":")[0], !(e = +e)) return !1;
switch (t) {
case "http":
case "ws":
return 80 !== e;

case "https":
case "wss":
return 443 !== e;

case "ftp":
return 21 !== e;

case "gopher":
return 70 !== e;

case "file":
return !1;
}
return 0 !== e;
};
}, {} ],
58: [ function(e, t) {
(function(r) {
var n = e("requires-port"), i = e("querystringify"), o = /^([a-z][a-z0-9.+-]*:)?(\/\/)?([\S\s]*)/i, s = /^[A-Za-z][A-Za-z0-9+-.]*:\/\//, a = [ [ "#", "hash" ], [ "?", "query" ], function(e) {
return e.replace("\\", "/");
}, [ "/", "pathname" ], [ "@", "auth", 1 ], [ NaN, "host", void 0, 1, 1 ], [ /:(\d+)$/, "port", void 0, 1 ], [ NaN, "hostname", void 0, 1, 1 ] ], f = {
hash: 1,
query: 1
};
function c(e) {
var t, n = r && r.location || {}, i = {}, o = typeof (e = e || n);
if ("blob:" === e.protocol) i = new h(unescape(e.pathname), {}); else if ("string" === o) for (t in i = new h(e, {}), 
f) delete i[t]; else if ("object" === o) {
for (t in e) t in f || (i[t] = e[t]);
void 0 === i.slashes && (i.slashes = s.test(e.href));
}
return i;
}
function u(e) {
var t = o.exec(e);
return {
protocol: t[1] ? t[1].toLowerCase() : "",
slashes: !!t[2],
rest: t[3]
};
}
function h(e, t, r) {
if (!(this instanceof h)) return new h(e, t, r);
var o, s, f, d, l, p, b = a.slice(), m = typeof t, v = this, y = 0;
for ("object" !== m && "string" !== m && (r = t, t = null), r && "function" != typeof r && (r = i.parse), 
t = c(t), o = !(s = u(e || "")).protocol && !s.slashes, v.slashes = s.slashes || o && t.slashes, 
v.protocol = s.protocol || t.protocol || "", e = s.rest, s.slashes || (b[3] = [ /(.*)/, "pathname" ]); y < b.length; y++) "function" != typeof (d = b[y]) ? (f = d[0], 
p = d[1], f != f ? v[p] = e : "string" == typeof f ? ~(l = e.indexOf(f)) && (e = "number" == typeof d[2] ? (v[p] = e.slice(0, l), 
e.slice(l + d[2])) : (v[p] = e.slice(l), e.slice(0, l))) : (l = f.exec(e)) && (v[p] = l[1], 
e = e.slice(0, l.index)), v[p] = v[p] || o && d[3] && t[p] || "", d[4] && (v[p] = v[p].toLowerCase())) : e = d(e);
r && (v.query = r(v.query)), o && t.slashes && "/" !== v.pathname.charAt(0) && ("" !== v.pathname || "" !== t.pathname) && (v.pathname = function(e, t) {
for (var r = (t || "/").split("/").slice(0, -1).concat(e.split("/")), n = r.length, i = r[n - 1], o = !1, s = 0; n--; ) "." === r[n] ? r.splice(n, 1) : ".." === r[n] ? (r.splice(n, 1), 
s++) : s && (0 === n && (o = !0), r.splice(n, 1), s--);
return o && r.unshift(""), "." !== i && ".." !== i || r.push(""), r.join("/");
}(v.pathname, t.pathname)), n(v.port, v.protocol) || (v.host = v.hostname, v.port = ""), 
v.username = v.password = "", v.auth && (d = v.auth.split(":"), v.username = d[0] || "", 
v.password = d[1] || ""), v.origin = v.protocol && v.host && "file:" !== v.protocol ? v.protocol + "//" + v.host : "null", 
v.href = v.toString();
}
h.prototype = {
set: function(e, t, r) {
var o = this;
switch (e) {
case "query":
"string" == typeof t && t.length && (t = (r || i.parse)(t)), o[e] = t;
break;

case "port":
o[e] = t, n(t, o.protocol) ? t && (o.host = o.hostname + ":" + t) : (o.host = o.hostname, 
o[e] = "");
break;

case "hostname":
o[e] = t, o.port && (t += ":" + o.port), o.host = t;
break;

case "host":
o[e] = t, /:\d+$/.test(t) ? (t = t.split(":"), o.port = t.pop(), o.hostname = t.join(":")) : (o.hostname = t, 
o.port = "");
break;

case "protocol":
o.protocol = t.toLowerCase(), o.slashes = !r;
break;

case "pathname":
case "hash":
if (t) {
var s = "pathname" === e ? "/" : "#";
o[e] = t.charAt(0) !== s ? s + t : t;
} else o[e] = t;
break;

default:
o[e] = t;
}
for (var f = 0; f < a.length; f++) {
var c = a[f];
c[4] && (o[c[1]] = o[c[1]].toLowerCase());
}
return o.origin = o.protocol && o.host && "file:" !== o.protocol ? o.protocol + "//" + o.host : "null", 
o.href = o.toString(), o;
},
toString: function(e) {
e && "function" == typeof e || (e = i.stringify);
var t, r = this, n = r.protocol;
n && ":" !== n.charAt(n.length - 1) && (n += ":");
var o = n + (r.slashes ? "//" : "");
return r.username && (o += r.username, r.password && (o += ":" + r.password), o += "@"), 
o += r.host + r.pathname, (t = "object" == typeof r.query ? e(r.query) : r.query) && (o += "?" !== t.charAt(0) ? "?" + t : t), 
r.hash && (o += r.hash), o;
}
}, h.extractProtocol = u, h.location = c, h.qs = i, t.exports = h;
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
querystringify: 56,
"requires-port": 57
} ]
}, {}, [ 1 ])(1);
});
cc._RF.pop();
}).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
UIDatePicker: [ function(e, t) {
"use strict";
cc._RF.push(t, "6d106l+tDRL5rbAU45iCnts", "UIDatePicker");
cc.Class({
extends: cc.Component,
properties: {
lbYearMonth: cc.Label,
ndDays: cc.Node,
pfbDay: cc.Prefab,
displayDate: cc.Label,
contentShow: cc.Node,
ChangeEvent: {
default: [],
type: cc.Component.EventHandler
}
},
onLoad: function() {
this.initData();
this.updateDate();
},
initData: function() {
this.date = new Date(Date.now());
this.year = this.date.getFullYear();
this.month = this.date.getMonth() + 1;
this.day = this.date.getDate();
this.pfgListDay = [];
for (var e = 0; e < 31; ++e) {
var t = cc.instantiate(this.pfbDay);
t.parent = this.ndDays;
this.pfgListDay.push(t);
}
},
setDate: function(e, t, r) {
this.date = new Date(e, t - 1, r);
this.year = this.date.getFullYear();
this.month = this.date.getMonth() + 1;
this.day = this.date.getDate();
this.updateDate();
},
updateDate: function() {
var e = this;
this.lbYearMonth.string = cc.js.formatStr("%s-%s", this.year, this.month + 1);
for (var t = new Date(this.year, this.month - 1, 0), r = t.getDate(), n = t.getDay(), i = 0; i < this.pfgListDay.length; ++i) {
var o = this.pfgListDay[i];
if (i < r) {
o.active = !0;
var s = n + i, a = Math.floor(s / 7), f = s % 7, c = .5 * -(this.ndDays.width - o.width) + f * o.width, u = .5 * (this.ndDays.height - o.height) - a * o.height;
o.setPosition(c, u);
o.getComponent("UIItemDay").setDay(i, i + 1, this.day === i + 1, function(t, r) {
e.day = r;
e.updateDate();
});
} else o.active = !1;
}
var h = ("0" + this.month).slice(-2), d = ("0" + this.day).slice(-2);
this.displayDate.string = d + "-" + h + "-" + this.year;
this.CurrentDayChoose = this.year + "/" + h + "/" + d;
this.onClickClose();
},
onClickLeft: function() {
if (this.month > 0) this.month -= 1; else {
this.month = 11;
this.year -= 1;
}
this.date.setFullYear(this.year);
this.date.setMonth(this.month);
this.updateDate();
},
onClickRight: function() {
if (this.month < 11) this.month += 1; else {
this.month = 0;
this.year += 1;
}
this.date.setFullYear(this.year);
this.date.setMonth(this.month);
this.updateDate();
},
setPickDateCallback: function(e) {
this.cb = e;
},
onClickClose: function() {
this.cb && this.cb(this.year, this.month, this.day);
null != this.ChangeEvent && this.ChangeEvent.forEach(function(e) {
e.emit();
});
this.contentShow.active = !1;
},
onClickShow: function() {
this.contentShow.active = !0;
}
});
cc._RF.pop();
}, {} ],
UIItemDay: [ function(e, t) {
"use strict";
cc._RF.push(t, "252a5nAq6pLOITqXWwWN/H/", "UIItemDay");
cc.Class({
extends: cc.Component,
properties: {
lbDay: cc.Label,
spSel: cc.Sprite,
button: cc.Button
},
setDay: function(e, t, r, n) {
this.index = e;
this.day = t;
this.cb = n;
this.lbDay.string = t;
this.spSel.enabled = r;
},
onClickItem: function() {
this.cb && this.cb(this.index, this.day);
}
});
cc._RF.pop();
}, {} ],
UtilsNative: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "336b2+HbC9HMZQobmyH8RwZ", "UtilsNative");
Object.defineProperty(r, "__esModule", {
value: !0
});
var n = e("./Global");
cc.NativeCallJS = function(e, t) {
switch (e + "") {
case "1":
case "2":
break;

case "3":
var r = t;
n.Global.PopupSecurity.actGetOtpServer(r);
break;

case "4":
var i = t;
n.Global.PopupSecurity.actGetVerifyCode(i);
}
};
var i = function() {
function e() {}
e.onCallNative = function() {
cc.sys.os === cc.sys.OS_ANDROID && cc.sys.isNative || cc.sys.os === cc.sys.OS_IOS && cc.sys.isNative;
};
e.sendLogEvent = function(e) {
this.onCallNative("1", JSON.stringify(e));
};
e.getDeviceId = function() {
cc.sys.os == cc.sys.OS_ANDROID || (cc.sys.os, cc.sys.OS_IOS);
};
e.verifyPhone = function(e) {
this.onCallNative("3", e);
};
e.verifyOTP = function(e) {
this.onCallNative("4", e);
};
e.httpGet = function(e, t) {
var r = new XMLHttpRequest();
r.onreadystatechange = function() {
if (4 === r.readyState) if (200 === r.status) {
var e = null, n = null;
try {
e = JSON.parse(r.responseText);
} catch (e) {
n = e;
}
t(n, e);
} else t(r.status, null);
};
r.open("GET", e, !0);
r.send();
};
e.copyClipboard = function(e) {
this.onCallNative("5", e);
};
return e;
}();
r.default = i;
cc._RF.pop();
}, {
"./Global": "Global"
} ],
VersionConfig: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "4432dTxaiNCLKzaQM0wvnBN", "VersionConfig");
Object.defineProperty(r, "__esModule", {
value: !0
});
var n = function() {
function e() {}
e.CP_NAME_F69 = "F69";
e.ENV_DEV = "dev";
e.ENV_PROD = "prod";
e.DOMAIN_DEV = "rik1vip.win";
e.DOMAIN_PRO = "rik1vip.win";
e.VersionName = "";
e.CPName = "";
e.ENV = e.ENV_DEV;
return e;
}();
r.default = n;
if (cc.sys.isNative) {
var i = cc.sys.localStorage.getItem("VersionConfig");
if (null != i) {
i = JSON.parse(i);
n.VersionName = i.VersionName;
n.CPName = i.CPName;
} else {
n.VersionName = "1.0.0";
n.CPName = n.CP_NAME_F69;
}
} else {
n.VersionName = "1.0.0";
n.CPName = n.CP_NAME_F69;
}
cc._RF.pop();
}, {} ],
sockjs114: [ function(e, t, r) {
(function(n) {
"use strict";
cc._RF.push(t, "8caac4coytAhL1oG68GoCt6", "sockjs114");
(function(e) {
"object" == typeof r && "undefined" != typeof t ? t.exports = e() : "function" == typeof define && define.amd ? define([], e) : ("undefined" != typeof window ? window : "undefined" != typeof n ? n : "undefined" != typeof self ? self : this).SockJS = e();
})(function() {
return function t(r, n, i) {
function o(a, f) {
if (!n[a]) {
if (!r[a]) {
var c = "function" == typeof e && e;
if (!f && c) return c(a, !0);
if (s) return s(a, !0);
var u = new Error("Cannot find module '" + a + "'");
throw u.code = "MODULE_NOT_FOUND", u;
}
var h = n[a] = {
exports: {}
};
r[a][0].call(h.exports, function(e) {
return o(r[a][1][e] || e);
}, h, h.exports, t, r, n, i);
}
return n[a].exports;
}
for (var s = "function" == typeof e && e, a = 0; a < i.length; a++) o(i[a]);
return o;
}({
1: [ function(e, t) {
(function(r) {
var n = e("./transport-list");
t.exports = e("./main")(n);
"_sockjs_onload" in r && setTimeout(r._sockjs_onload, 1);
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"./main": 14,
"./transport-list": 16
} ],
2: [ function(e, t) {
var r = e("inherits"), n = e("./event");
function i() {
n.call(this);
this.initEvent("close", !1, !1);
this.wasClean = !1;
this.code = 0;
this.reason = "";
}
r(i, n);
t.exports = i;
}, {
"./event": 4,
inherits: 57
} ],
3: [ function(e, t) {
var r = e("inherits"), n = e("./eventtarget");
function i() {
n.call(this);
}
r(i, n);
i.prototype.removeAllListeners = function(e) {
e ? delete this._listeners[e] : this._listeners = {};
};
i.prototype.once = function(e, t) {
var r = this, n = !1;
this.on(e, function i() {
r.removeListener(e, i);
if (!n) {
n = !0;
t.apply(this, arguments);
}
});
};
i.prototype.emit = function() {
var e = arguments[0], t = this._listeners[e];
if (t) {
for (var r = arguments.length, n = new Array(r - 1), i = 1; i < r; i++) n[i - 1] = arguments[i];
for (var o = 0; o < t.length; o++) t[o].apply(this, n);
}
};
i.prototype.on = i.prototype.addListener = n.prototype.addEventListener;
i.prototype.removeListener = n.prototype.removeEventListener;
t.exports.EventEmitter = i;
}, {
"./eventtarget": 5,
inherits: 57
} ],
4: [ function(e, t) {
function r(e) {
this.type = e;
}
r.prototype.initEvent = function(e, t, r) {
this.type = e;
this.bubbles = t;
this.cancelable = r;
this.timeStamp = +new Date();
return this;
};
r.prototype.stopPropagation = function() {};
r.prototype.preventDefault = function() {};
r.CAPTURING_PHASE = 1;
r.AT_TARGET = 2;
r.BUBBLING_PHASE = 3;
t.exports = r;
}, {} ],
5: [ function(e, t) {
function r() {
this._listeners = {};
}
r.prototype.addEventListener = function(e, t) {
e in this._listeners || (this._listeners[e] = []);
var r = this._listeners[e];
-1 === r.indexOf(t) && (r = r.concat([ t ]));
this._listeners[e] = r;
};
r.prototype.removeEventListener = function(e, t) {
var r = this._listeners[e];
if (r) {
var n = r.indexOf(t);
-1 === n || (r.length > 1 ? this._listeners[e] = r.slice(0, n).concat(r.slice(n + 1)) : delete this._listeners[e]);
}
};
r.prototype.dispatchEvent = function() {
var e = arguments[0], t = e.type, r = 1 === arguments.length ? [ e ] : Array.apply(null, arguments);
this["on" + t] && this["on" + t].apply(this, r);
if (t in this._listeners) for (var n = this._listeners[t], i = 0; i < n.length; i++) n[i].apply(this, r);
};
t.exports = r;
}, {} ],
6: [ function(e, t) {
var r = e("inherits"), n = e("./event");
function i(e) {
n.call(this);
this.initEvent("message", !1, !1);
this.data = e;
}
r(i, n);
t.exports = i;
}, {
"./event": 4,
inherits: 57
} ],
7: [ function(e, t) {
var r = e("json3"), n = e("./utils/iframe");
function i(e) {
this._transport = e;
e.on("message", this._transportMessage.bind(this));
e.on("close", this._transportClose.bind(this));
}
i.prototype._transportClose = function(e, t) {
n.postMessage("c", r.stringify([ e, t ]));
};
i.prototype._transportMessage = function(e) {
n.postMessage("t", e);
};
i.prototype._send = function(e) {
this._transport.send(e);
};
i.prototype._close = function() {
this._transport.close();
this._transport.removeAllListeners();
};
t.exports = i;
}, {
"./utils/iframe": 47,
json3: 58
} ],
8: [ function(e, t) {
(function(r) {
var n = e("./utils/url"), i = e("./utils/event"), o = e("json3"), s = e("./facade"), a = e("./info-iframe-receiver"), f = e("./utils/iframe"), c = e("./location"), u = function() {};
"production" !== r.env.NODE_ENV && (u = e("debug")("sockjs-client:iframe-bootstrap"));
t.exports = function(e, t) {
var r, h = {};
t.forEach(function(e) {
e.facadeTransport && (h[e.facadeTransport.transportName] = e.facadeTransport);
});
h[a.transportName] = a;
e.bootstrap_iframe = function() {
var t;
f.currentWindowId = c.hash.slice(1);
i.attachEvent("message", function(i) {
if (i.source === parent) {
"undefined" == typeof r && (r = i.origin);
if (i.origin === r) {
var a;
try {
a = o.parse(i.data);
} catch (e) {
u("bad json", i.data);
return;
}
if (a.windowId === f.currentWindowId) switch (a.type) {
case "s":
var d;
try {
d = o.parse(a.data);
} catch (e) {
u("bad json", a.data);
break;
}
var l = d[0], p = d[1], b = d[2], m = d[3];
u(l, p, b, m);
if (l !== e.version) throw new Error('Incompatible SockJS! Main site uses: "' + l + '", the iframe: "' + e.version + '".');
if (!n.isOriginEqual(b, c.href) || !n.isOriginEqual(m, c.href)) throw new Error("Can't connect to different domain from within an iframe. (" + c.href + ", " + b + ", " + m + ")");
t = new s(new h[p](b, m));
break;

case "m":
t._send(a.data);
break;

case "c":
t && t._close();
t = null;
}
}
}
});
f.postMessage("s");
};
};
}).call(this, {
env: {}
});
}, {
"./facade": 7,
"./info-iframe-receiver": 10,
"./location": 13,
"./utils/event": 46,
"./utils/iframe": 47,
"./utils/url": 52,
debug: 55,
json3: 58
} ],
9: [ function(e, t) {
(function(r) {
var n = e("events").EventEmitter, i = e("inherits"), o = e("json3"), s = e("./utils/object"), a = function() {};
"production" !== r.env.NODE_ENV && (a = e("debug")("sockjs-client:info-ajax"));
function f(e, t) {
n.call(this);
var r = this, i = +new Date();
this.xo = new t("GET", e);
this.xo.once("finish", function(e, t) {
var n, f;
if (200 === e) {
f = +new Date() - i;
if (t) try {
n = o.parse(t);
} catch (e) {
a("bad json", t);
}
s.isObject(n) || (n = {});
}
r.emit("finish", n, f);
r.removeAllListeners();
});
}
i(f, n);
f.prototype.close = function() {
this.removeAllListeners();
this.xo.close();
};
t.exports = f;
}).call(this, {
env: {}
});
}, {
"./utils/object": 49,
debug: 55,
events: 3,
inherits: 57,
json3: 58
} ],
10: [ function(e, t) {
var r = e("inherits"), n = e("events").EventEmitter, i = e("json3"), o = e("./transport/sender/xhr-local"), s = e("./info-ajax");
function a(e) {
var t = this;
n.call(this);
this.ir = new s(e, o);
this.ir.once("finish", function(e, r) {
t.ir = null;
t.emit("message", i.stringify([ e, r ]));
});
}
r(a, n);
a.transportName = "iframe-info-receiver";
a.prototype.close = function() {
if (this.ir) {
this.ir.close();
this.ir = null;
}
this.removeAllListeners();
};
t.exports = a;
}, {
"./info-ajax": 9,
"./transport/sender/xhr-local": 37,
events: 3,
inherits: 57,
json3: 58
} ],
11: [ function(e, t) {
(function(r, n) {
var i = e("events").EventEmitter, o = e("inherits"), s = e("json3"), a = e("./utils/event"), f = e("./transport/iframe"), c = e("./info-iframe-receiver"), u = function() {};
"production" !== r.env.NODE_ENV && (u = e("debug")("sockjs-client:info-iframe"));
function h(e, t) {
var r = this;
i.call(this);
var o = function() {
var n = r.ifr = new f(c.transportName, t, e);
n.once("message", function(e) {
if (e) {
var t;
try {
t = s.parse(e);
} catch (t) {
u("bad json", e);
r.emit("finish");
r.close();
return;
}
var n = t[0], i = t[1];
r.emit("finish", n, i);
}
r.close();
});
n.once("close", function() {
r.emit("finish");
r.close();
});
};
n.document.body ? o() : a.attachEvent("load", o);
}
o(h, i);
h.enabled = function() {
return f.enabled();
};
h.prototype.close = function() {
this.ifr && this.ifr.close();
this.removeAllListeners();
this.ifr = null;
};
t.exports = h;
}).call(this, {
env: {}
}, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"./info-iframe-receiver": 10,
"./transport/iframe": 22,
"./utils/event": 46,
debug: 55,
events: 3,
inherits: 57,
json3: 58
} ],
12: [ function(e, t) {
(function(r) {
var n = e("events").EventEmitter, i = e("inherits"), o = e("./utils/url"), s = e("./transport/sender/xdr"), a = e("./transport/sender/xhr-cors"), f = e("./transport/sender/xhr-local"), c = e("./transport/sender/xhr-fake"), u = e("./info-iframe"), h = e("./info-ajax"), d = function() {};
"production" !== r.env.NODE_ENV && (d = e("debug")("sockjs-client:info-receiver"));
function l(e, t) {
d(e);
var r = this;
n.call(this);
setTimeout(function() {
r.doXhr(e, t);
}, 0);
}
i(l, n);
l._getReceiver = function(e, t, r) {
return r.sameOrigin ? new h(t, f) : a.enabled ? new h(t, a) : s.enabled && r.sameScheme ? new h(t, s) : u.enabled() ? new u(e, t) : new h(t, c);
};
l.prototype.doXhr = function(e, t) {
var r = this, n = o.addPath(e, "/info");
d("doXhr", n);
this.xo = l._getReceiver(e, n, t);
this.timeoutRef = setTimeout(function() {
d("timeout");
r._cleanup(!1);
r.emit("finish");
}, l.timeout);
this.xo.once("finish", function(e, t) {
d("finish", e, t);
r._cleanup(!0);
r.emit("finish", e, t);
});
};
l.prototype._cleanup = function(e) {
d("_cleanup");
clearTimeout(this.timeoutRef);
this.timeoutRef = null;
!e && this.xo && this.xo.close();
this.xo = null;
};
l.prototype.close = function() {
d("close");
this.removeAllListeners();
this._cleanup(!1);
};
l.timeout = 8e3;
t.exports = l;
}).call(this, {
env: {}
});
}, {
"./info-ajax": 9,
"./info-iframe": 11,
"./transport/sender/xdr": 34,
"./transport/sender/xhr-cors": 35,
"./transport/sender/xhr-fake": 36,
"./transport/sender/xhr-local": 37,
"./utils/url": 52,
debug: 55,
events: 3,
inherits: 57
} ],
13: [ function(e, t) {
(function(e) {
t.exports = e.location || {
origin: "http://localhost:80",
protocol: "http",
host: "localhost",
port: 80,
href: "http://localhost/",
hash: ""
};
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
14: [ function(e, t) {
(function(r, n) {
e("./shims");
var i, o = e("url-parse"), s = e("inherits"), a = e("json3"), f = e("./utils/random"), c = e("./utils/escape"), u = e("./utils/url"), h = e("./utils/event"), d = e("./utils/transport"), l = e("./utils/object"), p = e("./utils/browser"), b = e("./utils/log"), m = e("./event/event"), v = e("./event/eventtarget"), y = e("./location"), g = e("./event/close"), _ = e("./event/trans-message"), w = e("./info-receiver"), E = function() {};
"production" !== r.env.NODE_ENV && (E = e("debug")("sockjs-client:main"));
function S(e, t, r) {
if (!(this instanceof S)) return new S(e, t, r);
if (arguments.length < 1) throw new TypeError("Failed to construct 'SockJS: 1 argument required, but only 0 present");
v.call(this);
this.readyState = S.CONNECTING;
this.extensions = "";
this.protocol = "";
(r = r || {}).protocols_whitelist && b.warn("'protocols_whitelist' is DEPRECATED. Use 'transports' instead.");
this._transportsWhitelist = r.transports;
this._transportOptions = r.transportOptions || {};
var n = r.sessionId || 8;
if ("function" == typeof n) this._generateSessionId = n; else {
if ("number" != typeof n) throw new TypeError("If sessionId is used in the options, it needs to be a number or a function.");
this._generateSessionId = function() {
return f.string(n);
};
}
this._server = r.server || f.numberString(1e3);
var i = new o(e);
if (!i.host || !i.protocol) throw new SyntaxError("The URL '" + e + "' is invalid");
if (i.hash) throw new SyntaxError("The URL must not contain a fragment");
if ("http:" !== i.protocol && "https:" !== i.protocol) throw new SyntaxError("The URL's scheme must be either 'http:' or 'https:'. '" + i.protocol + "' is not allowed.");
var s = "https:" === i.protocol;
if ("https" === y.protocol && !s) throw new Error("SecurityError: An insecure SockJS connection may not be initiated from a page loaded over HTTPS");
t ? Array.isArray(t) || (t = [ t ]) : t = [];
var a = t.sort();
a.forEach(function(e, t) {
if (!e) throw new SyntaxError("The protocols entry '" + e + "' is invalid.");
if (t < a.length - 1 && e === a[t + 1]) throw new SyntaxError("The protocols entry '" + e + "' is duplicated.");
});
var c = u.getOrigin(y.href);
this._origin = c ? c.toLowerCase() : null;
i.set("pathname", i.pathname.replace(/\/+$/, ""));
this.url = i.href;
E("using url", this.url);
this._urlInfo = {
nullOrigin: !p.hasDomain(),
sameOrigin: u.isOriginEqual(this.url, y.href),
sameScheme: u.isSchemeEqual(this.url, y.href)
};
this._ir = new w(this.url, this._urlInfo);
this._ir.once("finish", this._receiveInfo.bind(this));
}
s(S, v);
function M(e) {
return 1e3 === e || e >= 3e3 && e <= 4999;
}
S.prototype.close = function(e, t) {
if (e && !M(e)) throw new Error("InvalidAccessError: Invalid code");
if (t && t.length > 123) throw new SyntaxError("reason argument has an invalid length");
this.readyState !== S.CLOSING && this.readyState !== S.CLOSED && this._close(e || 1e3, t || "Normal closure", !0);
};
S.prototype.send = function(e) {
"string" != typeof e && (e = "" + e);
if (this.readyState === S.CONNECTING) throw new Error("InvalidStateError: The connection has not been established yet");
this.readyState === S.OPEN && this._transport.send(c.quote(e));
};
S.version = e("./version");
S.CONNECTING = 0;
S.OPEN = 1;
S.CLOSING = 2;
S.CLOSED = 3;
S.prototype._receiveInfo = function(e, t) {
E("_receiveInfo", t);
this._ir = null;
if (e) {
this._rto = this.countRTO(t);
this._transUrl = e.base_url ? e.base_url : this.url;
e = l.extend(e, this._urlInfo);
E("info", e);
var r = i.filterToEnabled(this._transportsWhitelist, e);
this._transports = r.main;
E(this._transports.length + " enabled transports");
this._connect();
} else this._close(1002, "Cannot connect to server");
};
S.prototype._connect = function() {
for (var e = this._transports.shift(); e; e = this._transports.shift()) {
E("attempt", e.transportName);
if (e.needBody && (!n.document.body || "undefined" != typeof n.document.readyState && "complete" !== n.document.readyState && "interactive" !== n.document.readyState)) {
E("waiting for body");
this._transports.unshift(e);
h.attachEvent("load", this._connect.bind(this));
return;
}
var t = this._rto * e.roundTrips || 5e3;
this._transportTimeoutId = setTimeout(this._transportTimeout.bind(this), t);
E("using timeout", t);
var r = u.addPath(this._transUrl, "/" + this._server + "/" + this._generateSessionId()), i = this._transportOptions[e.transportName];
E("transport url", r);
var o = new e(r, this._transUrl, i);
o.on("message", this._transportMessage.bind(this));
o.once("close", this._transportClose.bind(this));
o.transportName = e.transportName;
this._transport = o;
return;
}
this._close(2e3, "All transports failed", !1);
};
S.prototype._transportTimeout = function() {
E("_transportTimeout");
this.readyState === S.CONNECTING && this._transportClose(2007, "Transport timed out");
};
S.prototype._transportMessage = function(e) {
E("_transportMessage", e);
var t, r = this, n = e.slice(0, 1), i = e.slice(1);
switch (n) {
case "o":
this._open();
return;

case "h":
this.dispatchEvent(new m("heartbeat"));
E("heartbeat", this.transport);
return;
}
if (i) try {
t = a.parse(i);
} catch (e) {
E("bad json", i);
}
if ("undefined" != typeof t) switch (n) {
case "a":
Array.isArray(t) && t.forEach(function(e) {
E("message", r.transport, e);
r.dispatchEvent(new _(e));
});
break;

case "m":
E("message", this.transport, t);
this.dispatchEvent(new _(t));
break;

case "c":
Array.isArray(t) && 2 === t.length && this._close(t[0], t[1], !0);
} else E("empty payload", i);
};
S.prototype._transportClose = function(e, t) {
E("_transportClose", this.transport, e, t);
if (this._transport) {
this._transport.removeAllListeners();
this._transport = null;
this.transport = null;
}
M(e) || 2e3 === e || this.readyState !== S.CONNECTING ? this._close(e, t) : this._connect();
};
S.prototype._open = function() {
E("_open", this._transport.transportName, this.readyState);
if (this.readyState === S.CONNECTING) {
if (this._transportTimeoutId) {
clearTimeout(this._transportTimeoutId);
this._transportTimeoutId = null;
}
this.readyState = S.OPEN;
this.transport = this._transport.transportName;
this.dispatchEvent(new m("open"));
E("connected", this.transport);
} else this._close(1006, "Server lost session");
};
S.prototype._close = function(e, t, r) {
E("_close", this.transport, e, t, r, this.readyState);
var n = !1;
if (this._ir) {
n = !0;
this._ir.close();
this._ir = null;
}
if (this._transport) {
this._transport.close();
this._transport = null;
this.transport = null;
}
if (this.readyState === S.CLOSED) throw new Error("InvalidStateError: SockJS has already been closed");
this.readyState = S.CLOSING;
setTimeout(function() {
this.readyState = S.CLOSED;
n && this.dispatchEvent(new m("error"));
var i = new g("close");
i.wasClean = r || !1;
i.code = e || 1e3;
i.reason = t;
this.dispatchEvent(i);
this.onmessage = this.onclose = this.onerror = null;
E("disconnected");
}.bind(this), 0);
};
S.prototype.countRTO = function(e) {
return e > 100 ? 4 * e : 300 + e;
};
t.exports = function(t) {
i = d(t);
e("./iframe-bootstrap")(S, t);
return S;
};
}).call(this, {
env: {}
}, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"./event/close": 2,
"./event/event": 4,
"./event/eventtarget": 5,
"./event/trans-message": 6,
"./iframe-bootstrap": 8,
"./info-receiver": 12,
"./location": 13,
"./shims": 15,
"./utils/browser": 44,
"./utils/escape": 45,
"./utils/event": 46,
"./utils/log": 48,
"./utils/object": 49,
"./utils/random": 50,
"./utils/transport": 51,
"./utils/url": 52,
"./version": 53,
debug: 55,
inherits: 57,
json3: 58,
"url-parse": 61
} ],
15: [ function() {
var e, t = Array.prototype, r = Object.prototype, n = Function.prototype, i = String.prototype, o = t.slice, s = r.toString, a = function(e) {
return "[object Function]" === r.toString.call(e);
}, f = function(e) {
return "[object String]" === s.call(e);
}, c = Object.defineProperty && function() {
try {
Object.defineProperty({}, "x", {});
return !0;
} catch (e) {
return !1;
}
}();
e = c ? function(e, t, r, n) {
!n && t in e || Object.defineProperty(e, t, {
configurable: !0,
enumerable: !1,
writable: !0,
value: r
});
} : function(e, t, r, n) {
!n && t in e || (e[t] = r);
};
var u = function(t, n, i) {
for (var o in n) r.hasOwnProperty.call(n, o) && e(t, o, n[o], i);
}, h = function(e) {
if (null == e) throw new TypeError("can't convert " + e + " to object");
return Object(e);
};
function d(e) {
var t = +e;
t != t ? t = 0 : 0 !== t && t !== 1 / 0 && t !== -1 / 0 && (t = (t > 0 || -1) * Math.floor(Math.abs(t)));
return t;
}
function l() {}
u(n, {
bind: function(e) {
var t = this;
if (!a(t)) throw new TypeError("Function.prototype.bind called on incompatible " + t);
for (var r = o.call(arguments, 1), n = function() {
if (this instanceof c) {
var n = t.apply(this, r.concat(o.call(arguments)));
return Object(n) === n ? n : this;
}
return t.apply(e, r.concat(o.call(arguments)));
}, i = Math.max(0, t.length - r.length), s = [], f = 0; f < i; f++) s.push("$" + f);
var c = Function("binder", "return function (" + s.join(",") + "){ return binder.apply(this, arguments); }")(n);
if (t.prototype) {
l.prototype = t.prototype;
c.prototype = new l();
l.prototype = null;
}
return c;
}
});
u(Array, {
isArray: function(e) {
return "[object Array]" === s.call(e);
}
});
var p = Object("a"), b = "a" !== p[0] || !(0 in p);
u(t, {
forEach: function(e) {
var t = h(this), r = b && f(this) ? this.split("") : t, n = arguments[1], i = -1, o = r.length >>> 0;
if (!a(e)) throw new TypeError();
for (;++i < o; ) i in r && e.call(n, r[i], i, t);
}
}, !function(e) {
var t = !0, r = !0;
if (e) {
e.call("foo", function(e, r, n) {
"object" != typeof n && (t = !1);
});
e.call([ 1 ], function() {
r = "string" == typeof this;
}, "x");
}
return !!e && t && r;
}(t.forEach));
var m = Array.prototype.indexOf && -1 !== [ 0, 1 ].indexOf(1, 2);
u(t, {
indexOf: function(e) {
var t = b && f(this) ? this.split("") : h(this), r = t.length >>> 0;
if (!r) return -1;
var n = 0;
arguments.length > 1 && (n = d(arguments[1]));
n = n >= 0 ? n : Math.max(0, r + n);
for (;n < r; n++) if (n in t && t[n] === e) return n;
return -1;
}
}, m);
var v, y = i.split;
2 !== "ab".split(/(?:ab)*/).length || 4 !== ".".split(/(.?)(.?)/).length || "t" === "tesst".split(/(s)*/)[1] || 4 !== "test".split(/(?:)/, -1).length || "".split(/.?/).length || ".".split(/()()/).length > 1 ? (v = void 0 === /()??/.exec("")[1], 
i.split = function(e, r) {
var n = this;
if (void 0 === e && 0 === r) return [];
if ("[object RegExp]" !== s.call(e)) return y.call(this, e, r);
var i, o, a, f, c = [], u = (e.ignoreCase ? "i" : "") + (e.multiline ? "m" : "") + (e.extended ? "x" : "") + (e.sticky ? "y" : ""), h = 0;
e = new RegExp(e.source, u + "g");
n += "";
v || (i = new RegExp("^" + e.source + "$(?!\\s)", u));
r = void 0 === r ? -1 >>> 0 : r >>> 0;
for (;o = e.exec(n); ) {
if ((a = o.index + o[0].length) > h) {
c.push(n.slice(h, o.index));
!v && o.length > 1 && o[0].replace(i, function() {
for (var e = 1; e < arguments.length - 2; e++) void 0 === arguments[e] && (o[e] = void 0);
});
o.length > 1 && o.index < n.length && t.push.apply(c, o.slice(1));
f = o[0].length;
h = a;
if (c.length >= r) break;
}
e.lastIndex === o.index && e.lastIndex++;
}
h === n.length ? !f && e.test("") || c.push("") : c.push(n.slice(h));
return c.length > r ? c.slice(0, r) : c;
}) : "0".split(void 0, 0).length && (i.split = function(e, t) {
return void 0 === e && 0 === t ? [] : y.call(this, e, t);
});
var g = i.substr;
u(i, {
substr: function(e, t) {
return g.call(this, e < 0 && (e = this.length + e) < 0 ? 0 : e, t);
}
}, "".substr && "b" !== "0b".substr(-1));
}, {} ],
16: [ function(e, t) {
t.exports = [ e("./transport/websocket"), e("./transport/xhr-streaming"), e("./transport/xdr-streaming"), e("./transport/eventsource"), e("./transport/lib/iframe-wrap")(e("./transport/eventsource")), e("./transport/htmlfile"), e("./transport/lib/iframe-wrap")(e("./transport/htmlfile")), e("./transport/xhr-polling"), e("./transport/xdr-polling"), e("./transport/lib/iframe-wrap")(e("./transport/xhr-polling")), e("./transport/jsonp-polling") ];
}, {
"./transport/eventsource": 20,
"./transport/htmlfile": 21,
"./transport/jsonp-polling": 23,
"./transport/lib/iframe-wrap": 26,
"./transport/websocket": 38,
"./transport/xdr-polling": 39,
"./transport/xdr-streaming": 40,
"./transport/xhr-polling": 41,
"./transport/xhr-streaming": 42
} ],
17: [ function(e, t) {
(function(r, n) {
var i = e("events").EventEmitter, o = e("inherits"), s = e("../../utils/event"), a = e("../../utils/url"), f = n.XMLHttpRequest, c = function() {};
"production" !== r.env.NODE_ENV && (c = e("debug")("sockjs-client:browser:xhr"));
function u(e, t, r, n) {
c(e, t);
var o = this;
i.call(this);
setTimeout(function() {
o._start(e, t, r, n);
}, 0);
}
o(u, i);
u.prototype._start = function(e, t, r, n) {
var i = this;
try {
this.xhr = new f();
} catch (e) {}
if (this.xhr) {
t = a.addQuery(t, "t=" + +new Date());
this.unloadRef = s.unloadAdd(function() {
c("unload cleanup");
i._cleanup(!0);
});
try {
this.xhr.open(e, t, !0);
if (this.timeout && "timeout" in this.xhr) {
this.xhr.timeout = this.timeout;
this.xhr.ontimeout = function() {
c("xhr timeout");
i.emit("finish", 0, "");
i._cleanup(!1);
};
}
} catch (e) {
c("exception", e);
this.emit("finish", 0, "");
this._cleanup(!1);
return;
}
if ((!n || !n.noCredentials) && u.supportsCORS) {
c("withCredentials");
this.xhr.withCredentials = "true";
}
if (n && n.headers) for (var o in n.headers) this.xhr.setRequestHeader(o, n.headers[o]);
this.xhr.onreadystatechange = function() {
if (i.xhr) {
var e, t, r = i.xhr;
c("readyState", r.readyState);
switch (r.readyState) {
case 3:
try {
t = r.status;
e = r.responseText;
} catch (e) {}
c("status", t);
1223 === t && (t = 204);
if (200 === t && e && e.length > 0) {
c("chunk");
i.emit("chunk", t, e);
}
break;

case 4:
t = r.status;
c("status", t);
1223 === t && (t = 204);
12005 !== t && 12029 !== t || (t = 0);
c("finish", t, r.responseText);
i.emit("finish", t, r.responseText);
i._cleanup(!1);
}
}
};
try {
i.xhr.send(r);
} catch (e) {
i.emit("finish", 0, "");
i._cleanup(!1);
}
} else {
c("no xhr");
this.emit("finish", 0, "no xhr support");
this._cleanup();
}
};
u.prototype._cleanup = function(e) {
c("cleanup");
if (this.xhr) {
this.removeAllListeners();
s.unloadDel(this.unloadRef);
this.xhr.onreadystatechange = function() {};
this.xhr.ontimeout && (this.xhr.ontimeout = null);
if (e) try {
this.xhr.abort();
} catch (e) {}
this.unloadRef = this.xhr = null;
}
};
u.prototype.close = function() {
c("close");
this._cleanup(!0);
};
u.enabled = !!f;
var h = [ "Active" ].concat("Object").join("X");
if (!u.enabled && h in n) {
c("overriding xmlhttprequest");
f = function() {
try {
return new n[h]("Microsoft.XMLHTTP");
} catch (e) {
return null;
}
};
u.enabled = !!new f();
}
var d = !1;
try {
d = "withCredentials" in new f();
} catch (e) {}
u.supportsCORS = d;
t.exports = u;
}).call(this, {
env: {}
}, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../../utils/event": 46,
"../../utils/url": 52,
debug: 55,
events: 3,
inherits: 57
} ],
18: [ function(e, t) {
(function(e) {
t.exports = e.EventSource;
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
19: [ function(e, t) {
(function(e) {
var r = e.WebSocket || e.MozWebSocket;
t.exports = r ? function(e) {
return new r(e);
} : void 0;
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
20: [ function(e, t) {
var r = e("inherits"), n = e("./lib/ajax-based"), i = e("./receiver/eventsource"), o = e("./sender/xhr-cors"), s = e("eventsource");
function a(e) {
if (!a.enabled()) throw new Error("Transport created when disabled");
n.call(this, e, "/eventsource", i, o);
}
r(a, n);
a.enabled = function() {
return !!s;
};
a.transportName = "eventsource";
a.roundTrips = 2;
t.exports = a;
}, {
"./lib/ajax-based": 24,
"./receiver/eventsource": 29,
"./sender/xhr-cors": 35,
eventsource: 18,
inherits: 57
} ],
21: [ function(e, t) {
var r = e("inherits"), n = e("./receiver/htmlfile"), i = e("./sender/xhr-local"), o = e("./lib/ajax-based");
function s(e) {
if (!n.enabled) throw new Error("Transport created when disabled");
o.call(this, e, "/htmlfile", n, i);
}
r(s, o);
s.enabled = function(e) {
return n.enabled && e.sameOrigin;
};
s.transportName = "htmlfile";
s.roundTrips = 2;
t.exports = s;
}, {
"./lib/ajax-based": 24,
"./receiver/htmlfile": 30,
"./sender/xhr-local": 37,
inherits: 57
} ],
22: [ function(e, t) {
(function(r) {
var n = e("inherits"), i = e("json3"), o = e("events").EventEmitter, s = e("../version"), a = e("../utils/url"), f = e("../utils/iframe"), c = e("../utils/event"), u = e("../utils/random"), h = function() {};
"production" !== r.env.NODE_ENV && (h = e("debug")("sockjs-client:transport:iframe"));
function d(e, t, r) {
if (!d.enabled()) throw new Error("Transport created when disabled");
o.call(this);
var n = this;
this.origin = a.getOrigin(r);
this.baseUrl = r;
this.transUrl = t;
this.transport = e;
this.windowId = u.string(8);
var i = a.addPath(r, "/iframe.html") + "#" + this.windowId;
h(e, t, i);
this.iframeObj = f.createIframe(i, function(e) {
h("err callback");
n.emit("close", 1006, "Unable to load an iframe (" + e + ")");
n.close();
});
this.onmessageCallback = this._message.bind(this);
c.attachEvent("message", this.onmessageCallback);
}
n(d, o);
d.prototype.close = function() {
h("close");
this.removeAllListeners();
if (this.iframeObj) {
c.detachEvent("message", this.onmessageCallback);
try {
this.postMessage("c");
} catch (e) {}
this.iframeObj.cleanup();
this.iframeObj = null;
this.onmessageCallback = this.iframeObj = null;
}
};
d.prototype._message = function(e) {
h("message", e.data);
if (a.isOriginEqual(e.origin, this.origin)) {
var t;
try {
t = i.parse(e.data);
} catch (t) {
h("bad json", e.data);
return;
}
if (t.windowId === this.windowId) switch (t.type) {
case "s":
this.iframeObj.loaded();
this.postMessage("s", i.stringify([ s, this.transport, this.transUrl, this.baseUrl ]));
break;

case "t":
this.emit("message", t.data);
break;

case "c":
var r;
try {
r = i.parse(t.data);
} catch (e) {
h("bad json", t.data);
return;
}
this.emit("close", r[0], r[1]);
this.close();
} else h("mismatched window id", t.windowId, this.windowId);
} else h("not same origin", e.origin, this.origin);
};
d.prototype.postMessage = function(e, t) {
h("postMessage", e, t);
this.iframeObj.post(i.stringify({
windowId: this.windowId,
type: e,
data: t || ""
}), this.origin);
};
d.prototype.send = function(e) {
h("send", e);
this.postMessage("m", e);
};
d.enabled = function() {
return f.iframeEnabled;
};
d.transportName = "iframe";
d.roundTrips = 2;
t.exports = d;
}).call(this, {
env: {}
});
}, {
"../utils/event": 46,
"../utils/iframe": 47,
"../utils/random": 50,
"../utils/url": 52,
"../version": 53,
debug: 55,
events: 3,
inherits: 57,
json3: 58
} ],
23: [ function(e, t) {
(function(r) {
var n = e("inherits"), i = e("./lib/sender-receiver"), o = e("./receiver/jsonp"), s = e("./sender/jsonp");
function a(e) {
if (!a.enabled()) throw new Error("Transport created when disabled");
i.call(this, e, "/jsonp", s, o);
}
n(a, i);
a.enabled = function() {
return !!r.document;
};
a.transportName = "jsonp-polling";
a.roundTrips = 1;
a.needBody = !0;
t.exports = a;
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"./lib/sender-receiver": 28,
"./receiver/jsonp": 31,
"./sender/jsonp": 33,
inherits: 57
} ],
24: [ function(e, t) {
(function(r) {
var n = e("inherits"), i = e("../../utils/url"), o = e("./sender-receiver"), s = function() {};
"production" !== r.env.NODE_ENV && (s = e("debug")("sockjs-client:ajax-based"));
function a(e) {
return function(t, r, n) {
s("create ajax sender", t, r);
var o = {};
"string" == typeof r && (o.headers = {
"Content-type": "text/plain"
});
var a = i.addPath(t, "/xhr_send"), f = new e("POST", a, r, o);
f.once("finish", function(e) {
s("finish", e);
f = null;
if (200 !== e && 204 !== e) return n(new Error("http status " + e));
n();
});
return function() {
s("abort");
f.close();
f = null;
var e = new Error("Aborted");
e.code = 1e3;
n(e);
};
};
}
function f(e, t, r, n) {
o.call(this, e, t, a(n), r, n);
}
n(f, o);
t.exports = f;
}).call(this, {
env: {}
});
}, {
"../../utils/url": 52,
"./sender-receiver": 28,
debug: 55,
inherits: 57
} ],
25: [ function(e, t) {
(function(r) {
var n = e("inherits"), i = e("events").EventEmitter, o = function() {};
"production" !== r.env.NODE_ENV && (o = e("debug")("sockjs-client:buffered-sender"));
function s(e, t) {
o(e);
i.call(this);
this.sendBuffer = [];
this.sender = t;
this.url = e;
}
n(s, i);
s.prototype.send = function(e) {
o("send", e);
this.sendBuffer.push(e);
this.sendStop || this.sendSchedule();
};
s.prototype.sendScheduleWait = function() {
o("sendScheduleWait");
var e, t = this;
this.sendStop = function() {
o("sendStop");
t.sendStop = null;
clearTimeout(e);
};
e = setTimeout(function() {
o("timeout");
t.sendStop = null;
t.sendSchedule();
}, 25);
};
s.prototype.sendSchedule = function() {
o("sendSchedule", this.sendBuffer.length);
var e = this;
if (this.sendBuffer.length > 0) {
var t = "[" + this.sendBuffer.join(",") + "]";
this.sendStop = this.sender(this.url, t, function(t) {
e.sendStop = null;
if (t) {
o("error", t);
e.emit("close", t.code || 1006, "Sending error: " + t);
e.close();
} else e.sendScheduleWait();
});
this.sendBuffer = [];
}
};
s.prototype._cleanup = function() {
o("_cleanup");
this.removeAllListeners();
};
s.prototype.close = function() {
o("close");
this._cleanup();
if (this.sendStop) {
this.sendStop();
this.sendStop = null;
}
};
t.exports = s;
}).call(this, {
env: {}
});
}, {
debug: 55,
events: 3,
inherits: 57
} ],
26: [ function(e, t) {
(function(r) {
var n = e("inherits"), i = e("../iframe"), o = e("../../utils/object");
t.exports = function(e) {
function t(t, r) {
i.call(this, e.transportName, t, r);
}
n(t, i);
t.enabled = function(t, n) {
if (!r.document) return !1;
var s = o.extend({}, n);
s.sameOrigin = !0;
return e.enabled(s) && i.enabled();
};
t.transportName = "iframe-" + e.transportName;
t.needBody = !0;
t.roundTrips = i.roundTrips + e.roundTrips - 1;
t.facadeTransport = e;
return t;
};
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../../utils/object": 49,
"../iframe": 22,
inherits: 57
} ],
27: [ function(e, t) {
(function(r) {
var n = e("inherits"), i = e("events").EventEmitter, o = function() {};
"production" !== r.env.NODE_ENV && (o = e("debug")("sockjs-client:polling"));
function s(e, t, r) {
o(t);
i.call(this);
this.Receiver = e;
this.receiveUrl = t;
this.AjaxObject = r;
this._scheduleReceiver();
}
n(s, i);
s.prototype._scheduleReceiver = function() {
o("_scheduleReceiver");
var e = this, t = this.poll = new this.Receiver(this.receiveUrl, this.AjaxObject);
t.on("message", function(t) {
o("message", t);
e.emit("message", t);
});
t.once("close", function(r, n) {
o("close", r, n, e.pollIsClosing);
e.poll = t = null;
if (!e.pollIsClosing) if ("network" === n) e._scheduleReceiver(); else {
e.emit("close", r || 1006, n);
e.removeAllListeners();
}
});
};
s.prototype.abort = function() {
o("abort");
this.removeAllListeners();
this.pollIsClosing = !0;
this.poll && this.poll.abort();
};
t.exports = s;
}).call(this, {
env: {}
});
}, {
debug: 55,
events: 3,
inherits: 57
} ],
28: [ function(e, t) {
(function(r) {
var n = e("inherits"), i = e("../../utils/url"), o = e("./buffered-sender"), s = e("./polling"), a = function() {};
"production" !== r.env.NODE_ENV && (a = e("debug")("sockjs-client:sender-receiver"));
function f(e, t, r, n, f) {
var c = i.addPath(e, t);
a(c);
var u = this;
o.call(this, e, r);
this.poll = new s(n, c, f);
this.poll.on("message", function(e) {
a("poll message", e);
u.emit("message", e);
});
this.poll.once("close", function(e, t) {
a("poll close", e, t);
u.poll = null;
u.emit("close", e, t);
u.close();
});
}
n(f, o);
f.prototype.close = function() {
o.prototype.close.call(this);
a("close");
this.removeAllListeners();
if (this.poll) {
this.poll.abort();
this.poll = null;
}
};
t.exports = f;
}).call(this, {
env: {}
});
}, {
"../../utils/url": 52,
"./buffered-sender": 25,
"./polling": 27,
debug: 55,
inherits: 57
} ],
29: [ function(e, t) {
(function(r) {
var n = e("inherits"), i = e("events").EventEmitter, o = e("eventsource"), s = function() {};
"production" !== r.env.NODE_ENV && (s = e("debug")("sockjs-client:receiver:eventsource"));
function a(e) {
s(e);
i.call(this);
var t = this, r = this.es = new o(e);
r.onmessage = function(e) {
s("message", e.data);
t.emit("message", decodeURI(e.data));
};
r.onerror = function(e) {
s("error", r.readyState, e);
var n = 2 !== r.readyState ? "network" : "permanent";
t._cleanup();
t._close(n);
};
}
n(a, i);
a.prototype.abort = function() {
s("abort");
this._cleanup();
this._close("user");
};
a.prototype._cleanup = function() {
s("cleanup");
var e = this.es;
if (e) {
e.onmessage = e.onerror = null;
e.close();
this.es = null;
}
};
a.prototype._close = function(e) {
s("close", e);
var t = this;
setTimeout(function() {
t.emit("close", null, e);
t.removeAllListeners();
}, 200);
};
t.exports = a;
}).call(this, {
env: {}
});
}, {
debug: 55,
events: 3,
eventsource: 18,
inherits: 57
} ],
30: [ function(e, t) {
(function(r, n) {
var i = e("inherits"), o = e("../../utils/iframe"), s = e("../../utils/url"), a = e("events").EventEmitter, f = e("../../utils/random"), c = function() {};
"production" !== r.env.NODE_ENV && (c = e("debug")("sockjs-client:receiver:htmlfile"));
function u(e) {
c(e);
a.call(this);
var t = this;
o.polluteGlobalNamespace();
this.id = "a" + f.string(6);
e = s.addQuery(e, "c=" + decodeURIComponent(o.WPrefix + "." + this.id));
c("using htmlfile", u.htmlfileEnabled);
var r = u.htmlfileEnabled ? o.createHtmlfile : o.createIframe;
n[o.WPrefix][this.id] = {
start: function() {
c("start");
t.iframeObj.loaded();
},
message: function(e) {
c("message", e);
t.emit("message", e);
},
stop: function() {
c("stop");
t._cleanup();
t._close("network");
}
};
this.iframeObj = r(e, function() {
c("callback");
t._cleanup();
t._close("permanent");
});
}
i(u, a);
u.prototype.abort = function() {
c("abort");
this._cleanup();
this._close("user");
};
u.prototype._cleanup = function() {
c("_cleanup");
if (this.iframeObj) {
this.iframeObj.cleanup();
this.iframeObj = null;
}
delete n[o.WPrefix][this.id];
};
u.prototype._close = function(e) {
c("_close", e);
this.emit("close", null, e);
this.removeAllListeners();
};
u.htmlfileEnabled = !1;
var h = [ "Active" ].concat("Object").join("X");
if (h in n) try {
u.htmlfileEnabled = !!new n[h]("htmlfile");
} catch (e) {}
u.enabled = u.htmlfileEnabled || o.iframeEnabled;
t.exports = u;
}).call(this, {
env: {}
}, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../../utils/iframe": 47,
"../../utils/random": 50,
"../../utils/url": 52,
debug: 55,
events: 3,
inherits: 57
} ],
31: [ function(e, t) {
(function(r, n) {
var i = e("../../utils/iframe"), o = e("../../utils/random"), s = e("../../utils/browser"), a = e("../../utils/url"), f = e("inherits"), c = e("events").EventEmitter, u = function() {};
"production" !== r.env.NODE_ENV && (u = e("debug")("sockjs-client:receiver:jsonp"));
function h(e) {
u(e);
var t = this;
c.call(this);
i.polluteGlobalNamespace();
this.id = "a" + o.string(6);
var r = a.addQuery(e, "c=" + encodeURIComponent(i.WPrefix + "." + this.id));
n[i.WPrefix][this.id] = this._callback.bind(this);
this._createScript(r);
this.timeoutId = setTimeout(function() {
u("timeout");
t._abort(new Error("JSONP script loaded abnormally (timeout)"));
}, h.timeout);
}
f(h, c);
h.prototype.abort = function() {
u("abort");
if (n[i.WPrefix][this.id]) {
var e = new Error("JSONP user aborted read");
e.code = 1e3;
this._abort(e);
}
};
h.timeout = 35e3;
h.scriptErrorTimeout = 1e3;
h.prototype._callback = function(e) {
u("_callback", e);
this._cleanup();
if (!this.aborting) {
if (e) {
u("message", e);
this.emit("message", e);
}
this.emit("close", null, "network");
this.removeAllListeners();
}
};
h.prototype._abort = function(e) {
u("_abort", e);
this._cleanup();
this.aborting = !0;
this.emit("close", e.code, e.message);
this.removeAllListeners();
};
h.prototype._cleanup = function() {
u("_cleanup");
clearTimeout(this.timeoutId);
if (this.script2) {
this.script2.parentNode.removeChild(this.script2);
this.script2 = null;
}
if (this.script) {
var e = this.script;
e.parentNode.removeChild(e);
e.onreadystatechange = e.onerror = e.onload = e.onclick = null;
this.script = null;
}
delete n[i.WPrefix][this.id];
};
h.prototype._scriptError = function() {
u("_scriptError");
var e = this;
this.errorTimer || (this.errorTimer = setTimeout(function() {
e.loadedOkay || e._abort(new Error("JSONP script loaded abnormally (onerror)"));
}, h.scriptErrorTimeout));
};
h.prototype._createScript = function(e) {
u("_createScript", e);
var t, r = this, i = this.script = n.document.createElement("script");
i.id = "a" + o.string(8);
i.src = e;
i.type = "text/javascript";
i.charset = "UTF-8";
i.onerror = this._scriptError.bind(this);
i.onload = function() {
u("onload");
r._abort(new Error("JSONP script loaded abnormally (onload)"));
};
i.onreadystatechange = function() {
u("onreadystatechange", i.readyState);
if (/loaded|closed/.test(i.readyState)) {
if (i && i.htmlFor && i.onclick) {
r.loadedOkay = !0;
try {
i.onclick();
} catch (e) {}
}
i && r._abort(new Error("JSONP script loaded abnormally (onreadystatechange)"));
}
};
if ("undefined" == typeof i.async && n.document.attachEvent) if (s.isOpera()) {
(t = this.script2 = n.document.createElement("script")).text = "try{var a = document.getElementById('" + i.id + "'); if(a)a.onerror();}catch(x){};";
i.async = t.async = !1;
} else {
try {
i.htmlFor = i.id;
i.event = "onclick";
} catch (e) {}
i.async = !0;
}
"undefined" != typeof i.async && (i.async = !0);
var a = n.document.getElementsByTagName("head")[0];
a.insertBefore(i, a.firstChild);
t && a.insertBefore(t, a.firstChild);
};
t.exports = h;
}).call(this, {
env: {}
}, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../../utils/browser": 44,
"../../utils/iframe": 47,
"../../utils/random": 50,
"../../utils/url": 52,
debug: 55,
events: 3,
inherits: 57
} ],
32: [ function(e, t) {
(function(r) {
var n = e("inherits"), i = e("events").EventEmitter, o = function() {};
"production" !== r.env.NODE_ENV && (o = e("debug")("sockjs-client:receiver:xhr"));
function s(e, t) {
o(e);
i.call(this);
var r = this;
this.bufferPosition = 0;
this.xo = new t("POST", e, null);
this.xo.on("chunk", this._chunkHandler.bind(this));
this.xo.once("finish", function(e, t) {
o("finish", e, t);
r._chunkHandler(e, t);
r.xo = null;
var n = 200 === e ? "network" : "permanent";
o("close", n);
r.emit("close", null, n);
r._cleanup();
});
}
n(s, i);
s.prototype._chunkHandler = function(e, t) {
o("_chunkHandler", e);
if (200 === e && t) for (var r = -1; ;this.bufferPosition += r + 1) {
var n = t.slice(this.bufferPosition);
if (-1 === (r = n.indexOf("\n"))) break;
var i = n.slice(0, r);
if (i) {
o("message", i);
this.emit("message", i);
}
}
};
s.prototype._cleanup = function() {
o("_cleanup");
this.removeAllListeners();
};
s.prototype.abort = function() {
o("abort");
if (this.xo) {
this.xo.close();
o("close");
this.emit("close", null, "user");
this.xo = null;
}
this._cleanup();
};
t.exports = s;
}).call(this, {
env: {}
});
}, {
debug: 55,
events: 3,
inherits: 57
} ],
33: [ function(e, t) {
(function(r, n) {
var i, o, s = e("../../utils/random"), a = e("../../utils/url"), f = function() {};
"production" !== r.env.NODE_ENV && (f = e("debug")("sockjs-client:sender:jsonp"));
function c(e) {
f("createIframe", e);
try {
return n.document.createElement('<iframe name="' + e + '">');
} catch (r) {
var t = n.document.createElement("iframe");
t.name = e;
return t;
}
}
function u() {
f("createForm");
(i = n.document.createElement("form")).style.display = "none";
i.style.position = "absolute";
i.method = "POST";
i.enctype = "application/x-www-form-urlencoded";
i.acceptCharset = "UTF-8";
(o = n.document.createElement("textarea")).name = "d";
i.appendChild(o);
n.document.body.appendChild(i);
}
t.exports = function(e, t, r) {
f(e, t);
i || u();
var n = "a" + s.string(8);
i.target = n;
i.action = a.addQuery(a.addPath(e, "/jsonp_send"), "i=" + n);
var h = c(n);
h.id = n;
h.style.display = "none";
i.appendChild(h);
try {
o.value = t;
} catch (e) {}
i.submit();
var d = function(e) {
f("completed", n, e);
if (h.onerror) {
h.onreadystatechange = h.onerror = h.onload = null;
setTimeout(function() {
f("cleaning up", n);
h.parentNode.removeChild(h);
h = null;
}, 500);
o.value = "";
r(e);
}
};
h.onerror = function() {
f("onerror", n);
d();
};
h.onload = function() {
f("onload", n);
d();
};
h.onreadystatechange = function(e) {
f("onreadystatechange", n, h.readyState, e);
"complete" === h.readyState && d();
};
return function() {
f("aborted", n);
d(new Error("Aborted"));
};
};
}).call(this, {
env: {}
}, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../../utils/random": 50,
"../../utils/url": 52,
debug: 55
} ],
34: [ function(e, t) {
(function(r, n) {
var i = e("events").EventEmitter, o = e("inherits"), s = e("../../utils/event"), a = e("../../utils/browser"), f = e("../../utils/url"), c = function() {};
"production" !== r.env.NODE_ENV && (c = e("debug")("sockjs-client:sender:xdr"));
function u(e, t, r) {
c(e, t);
var n = this;
i.call(this);
setTimeout(function() {
n._start(e, t, r);
}, 0);
}
o(u, i);
u.prototype._start = function(e, t, r) {
c("_start");
var i = this, o = new n.XDomainRequest();
t = f.addQuery(t, "t=" + +new Date());
o.onerror = function() {
c("onerror");
i._error();
};
o.ontimeout = function() {
c("ontimeout");
i._error();
};
o.onprogress = function() {
c("progress", o.responseText);
i.emit("chunk", 200, o.responseText);
};
o.onload = function() {
c("load");
i.emit("finish", 200, o.responseText);
i._cleanup(!1);
};
this.xdr = o;
this.unloadRef = s.unloadAdd(function() {
i._cleanup(!0);
});
try {
this.xdr.open(e, t);
this.timeout && (this.xdr.timeout = this.timeout);
this.xdr.send(r);
} catch (e) {
this._error();
}
};
u.prototype._error = function() {
this.emit("finish", 0, "");
this._cleanup(!1);
};
u.prototype._cleanup = function(e) {
c("cleanup", e);
if (this.xdr) {
this.removeAllListeners();
s.unloadDel(this.unloadRef);
this.xdr.ontimeout = this.xdr.onerror = this.xdr.onprogress = this.xdr.onload = null;
if (e) try {
this.xdr.abort();
} catch (e) {}
this.unloadRef = this.xdr = null;
}
};
u.prototype.close = function() {
c("close");
this._cleanup(!0);
};
u.enabled = !(!n.XDomainRequest || !a.hasDomain());
t.exports = u;
}).call(this, {
env: {}
}, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../../utils/browser": 44,
"../../utils/event": 46,
"../../utils/url": 52,
debug: 55,
events: 3,
inherits: 57
} ],
35: [ function(e, t) {
var r = e("inherits"), n = e("../driver/xhr");
function i(e, t, r, i) {
n.call(this, e, t, r, i);
}
r(i, n);
i.enabled = n.enabled && n.supportsCORS;
t.exports = i;
}, {
"../driver/xhr": 17,
inherits: 57
} ],
36: [ function(e, t) {
var r = e("events").EventEmitter;
function n() {
var e = this;
r.call(this);
this.to = setTimeout(function() {
e.emit("finish", 200, "{}");
}, n.timeout);
}
e("inherits")(n, r);
n.prototype.close = function() {
clearTimeout(this.to);
};
n.timeout = 2e3;
t.exports = n;
}, {
events: 3,
inherits: 57
} ],
37: [ function(e, t) {
var r = e("inherits"), n = e("../driver/xhr");
function i(e, t, r) {
n.call(this, e, t, r, {
noCredentials: !0
});
}
r(i, n);
i.enabled = n.enabled;
t.exports = i;
}, {
"../driver/xhr": 17,
inherits: 57
} ],
38: [ function(e, t) {
(function(r) {
var n = e("../utils/event"), i = e("../utils/url"), o = e("inherits"), s = e("events").EventEmitter, a = e("./driver/websocket"), f = function() {};
"production" !== r.env.NODE_ENV && (f = e("debug")("sockjs-client:websocket"));
function c(e, t, r) {
if (!c.enabled()) throw new Error("Transport created when disabled");
s.call(this);
f("constructor", e);
var o = this, u = i.addPath(e, "/websocket");
if ("https" === u.slice(0, 5)) {
console.log("clm wsss");
u = "wss" + u.slice(5);
} else u = "ws" + u.slice(4);
this.url = u;
this.ws = new a(this.url, [], r);
this.ws.onmessage = function(e) {
f("message event", e.data);
o.emit("message", e.data);
};
this.unloadRef = n.unloadAdd(function() {
f("unload");
o.ws.close();
});
this.ws.onclose = function(e) {
f("close event", e.code, e.reason);
o.emit("close", e.code, e.reason);
o._cleanup();
};
this.ws.onerror = function(e) {
f("error event", e);
o.emit("close", 1006, "WebSocket connection broken");
o._cleanup();
};
}
o(c, s);
c.prototype.send = function(e) {
var t = "[" + e + "]";
f("send", t);
this.ws.send(t);
};
c.prototype.close = function() {
f("close");
var e = this.ws;
this._cleanup();
e && e.close();
};
c.prototype._cleanup = function() {
f("_cleanup");
var e = this.ws;
e && (e.onmessage = e.onclose = e.onerror = null);
n.unloadDel(this.unloadRef);
this.unloadRef = this.ws = null;
this.removeAllListeners();
};
c.enabled = function() {
f("enabled");
return !!a;
};
c.transportName = "websocket";
c.roundTrips = 2;
t.exports = c;
}).call(this, {
env: {}
});
}, {
"../utils/event": 46,
"../utils/url": 52,
"./driver/websocket": 19,
debug: 55,
events: 3,
inherits: 57
} ],
39: [ function(e, t) {
var r = e("inherits"), n = e("./lib/ajax-based"), i = e("./xdr-streaming"), o = e("./receiver/xhr"), s = e("./sender/xdr");
function a(e) {
if (!s.enabled) throw new Error("Transport created when disabled");
n.call(this, e, "/xhr", o, s);
}
r(a, n);
a.enabled = i.enabled;
a.transportName = "xdr-polling";
a.roundTrips = 2;
t.exports = a;
}, {
"./lib/ajax-based": 24,
"./receiver/xhr": 32,
"./sender/xdr": 34,
"./xdr-streaming": 40,
inherits: 57
} ],
40: [ function(e, t) {
var r = e("inherits"), n = e("./lib/ajax-based"), i = e("./receiver/xhr"), o = e("./sender/xdr");
function s(e) {
if (!o.enabled) throw new Error("Transport created when disabled");
n.call(this, e, "/xhr_streaming", i, o);
}
r(s, n);
s.enabled = function(e) {
return !e.cookie_needed && !e.nullOrigin && o.enabled && e.sameScheme;
};
s.transportName = "xdr-streaming";
s.roundTrips = 2;
t.exports = s;
}, {
"./lib/ajax-based": 24,
"./receiver/xhr": 32,
"./sender/xdr": 34,
inherits: 57
} ],
41: [ function(e, t) {
var r = e("inherits"), n = e("./lib/ajax-based"), i = e("./receiver/xhr"), o = e("./sender/xhr-cors"), s = e("./sender/xhr-local");
function a(e) {
if (!s.enabled && !o.enabled) throw new Error("Transport created when disabled");
n.call(this, e, "/xhr", i, o);
}
r(a, n);
a.enabled = function(e) {
return !e.nullOrigin && (!(!s.enabled || !e.sameOrigin) || o.enabled);
};
a.transportName = "xhr-polling";
a.roundTrips = 2;
t.exports = a;
}, {
"./lib/ajax-based": 24,
"./receiver/xhr": 32,
"./sender/xhr-cors": 35,
"./sender/xhr-local": 37,
inherits: 57
} ],
42: [ function(e, t) {
(function(r) {
var n = e("inherits"), i = e("./lib/ajax-based"), o = e("./receiver/xhr"), s = e("./sender/xhr-cors"), a = e("./sender/xhr-local"), f = e("../utils/browser");
function c(e) {
if (!a.enabled && !s.enabled) throw new Error("Transport created when disabled");
i.call(this, e, "/xhr_streaming", o, s);
}
n(c, i);
c.enabled = function(e) {
return !e.nullOrigin && !f.isOpera() && s.enabled;
};
c.transportName = "xhr-streaming";
c.roundTrips = 2;
c.needBody = !!r.document;
t.exports = c;
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../utils/browser": 44,
"./lib/ajax-based": 24,
"./receiver/xhr": 32,
"./sender/xhr-cors": 35,
"./sender/xhr-local": 37,
inherits: 57
} ],
43: [ function(e, t) {
(function(e) {
e.crypto && e.crypto.getRandomValues ? t.exports.randomBytes = function(t) {
var r = new Uint8Array(t);
e.crypto.getRandomValues(r);
return r;
} : t.exports.randomBytes = function(e) {
for (var t = new Array(e), r = 0; r < e; r++) t[r] = Math.floor(256 * Math.random());
return t;
};
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
44: [ function(e, t) {
(function(e) {
t.exports = {
isOpera: function() {
return e.navigator && /opera/i.test(e.navigator.userAgent);
},
isKonqueror: function() {
return e.navigator && /konqueror/i.test(e.navigator.userAgent);
},
hasDomain: function() {
if (!e.document) return !0;
try {
return !!e.document.domain;
} catch (e) {
return !1;
}
}
};
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
45: [ function(e, t) {
var r, n = e("json3"), i = /[\x00-\x1f\ud800-\udfff\ufffe\uffff\u0300-\u0333\u033d-\u0346\u034a-\u034c\u0350-\u0352\u0357-\u0358\u035c-\u0362\u0374\u037e\u0387\u0591-\u05af\u05c4\u0610-\u0617\u0653-\u0654\u0657-\u065b\u065d-\u065e\u06df-\u06e2\u06eb-\u06ec\u0730\u0732-\u0733\u0735-\u0736\u073a\u073d\u073f-\u0741\u0743\u0745\u0747\u07eb-\u07f1\u0951\u0958-\u095f\u09dc-\u09dd\u09df\u0a33\u0a36\u0a59-\u0a5b\u0a5e\u0b5c-\u0b5d\u0e38-\u0e39\u0f43\u0f4d\u0f52\u0f57\u0f5c\u0f69\u0f72-\u0f76\u0f78\u0f80-\u0f83\u0f93\u0f9d\u0fa2\u0fa7\u0fac\u0fb9\u1939-\u193a\u1a17\u1b6b\u1cda-\u1cdb\u1dc0-\u1dcf\u1dfc\u1dfe\u1f71\u1f73\u1f75\u1f77\u1f79\u1f7b\u1f7d\u1fbb\u1fbe\u1fc9\u1fcb\u1fd3\u1fdb\u1fe3\u1feb\u1fee-\u1fef\u1ff9\u1ffb\u1ffd\u2000-\u2001\u20d0-\u20d1\u20d4-\u20d7\u20e7-\u20e9\u2126\u212a-\u212b\u2329-\u232a\u2adc\u302b-\u302c\uaab2-\uaab3\uf900-\ufa0d\ufa10\ufa12\ufa15-\ufa1e\ufa20\ufa22\ufa25-\ufa26\ufa2a-\ufa2d\ufa30-\ufa6d\ufa70-\ufad9\ufb1d\ufb1f\ufb2a-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufb4e\ufff0-\uffff]/g, o = function(e) {
var t, r = {}, n = [];
for (t = 0; t < 65536; t++) n.push(String.fromCharCode(t));
e.lastIndex = 0;
n.join("").replace(e, function(e) {
r[e] = "\\u" + ("0000" + e.charCodeAt(0).toString(16)).slice(-4);
return "";
});
e.lastIndex = 0;
return r;
};
t.exports = {
quote: function(e) {
var t = n.stringify(e);
i.lastIndex = 0;
if (!i.test(t)) return t;
r || (r = o(i));
return t.replace(i, function(e) {
return r[e];
});
}
};
}, {
json3: 58
} ],
46: [ function(e, t) {
(function(r) {
var n = e("./random"), i = {}, o = !1, s = r.chrome && r.chrome.app && r.chrome.app.runtime;
t.exports = {
attachEvent: function(e, t) {
if ("undefined" != typeof r.addEventListener) r.addEventListener(e, t, !1); else if (r.document && r.attachEvent) {
r.document.attachEvent("on" + e, t);
r.attachEvent("on" + e, t);
}
},
detachEvent: function(e, t) {
if ("undefined" != typeof r.addEventListener) r.removeEventListener(e, t, !1); else if (r.document && r.detachEvent) {
r.document.detachEvent("on" + e, t);
r.detachEvent("on" + e, t);
}
},
unloadAdd: function(e) {
if (s) return null;
var t = n.string(8);
i[t] = e;
o && setTimeout(this.triggerUnloadCallbacks, 0);
return t;
},
unloadDel: function(e) {
e in i && delete i[e];
},
triggerUnloadCallbacks: function() {
for (var e in i) {
i[e]();
delete i[e];
}
}
};
s || t.exports.attachEvent("unload", function() {
if (!o) {
o = !0;
t.exports.triggerUnloadCallbacks();
}
});
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"./random": 50
} ],
47: [ function(e, t) {
(function(r, n) {
var i = e("./event"), o = e("json3"), s = e("./browser"), a = function() {};
"production" !== r.env.NODE_ENV && (a = e("debug")("sockjs-client:utils:iframe"));
t.exports = {
WPrefix: "_jp",
currentWindowId: null,
polluteGlobalNamespace: function() {
t.exports.WPrefix in n || (n[t.exports.WPrefix] = {});
},
postMessage: function(e, r) {
n.parent !== n ? n.parent.postMessage(o.stringify({
windowId: t.exports.currentWindowId,
type: e,
data: r || ""
}), "*") : a("Cannot postMessage, no parent window.", e, r);
},
createIframe: function(e, t) {
var r, o, s = n.document.createElement("iframe"), f = function() {
a("unattach");
clearTimeout(r);
try {
s.onload = null;
} catch (e) {}
s.onerror = null;
}, c = function() {
a("cleanup");
if (s) {
f();
setTimeout(function() {
s && s.parentNode.removeChild(s);
s = null;
}, 0);
i.unloadDel(o);
}
}, u = function(e) {
a("onerror", e);
if (s) {
c();
t(e);
}
};
s.src = e;
s.style.display = "none";
s.style.position = "absolute";
s.onerror = function() {
u("onerror");
};
s.onload = function() {
a("onload");
clearTimeout(r);
r = setTimeout(function() {
u("onload timeout");
}, 2e3);
};
n.document.body.appendChild(s);
r = setTimeout(function() {
u("timeout");
}, 15e3);
o = i.unloadAdd(c);
return {
post: function(e, t) {
a("post", e, t);
try {
setTimeout(function() {
s && s.contentWindow && s.contentWindow.postMessage(e, t);
}, 0);
} catch (e) {}
},
cleanup: c,
loaded: f
};
},
createHtmlfile: function(e, r) {
var o, s, f, c = [ "Active" ].concat("Object").join("X"), u = new n[c]("htmlfile"), h = function() {
clearTimeout(o);
f.onerror = null;
}, d = function() {
if (u) {
h();
i.unloadDel(s);
f.parentNode.removeChild(f);
f = u = null;
CollectGarbage();
}
}, l = function(e) {
a("onerror", e);
if (u) {
d();
r(e);
}
};
u.open();
u.write('<html><script>document.domain="' + n.document.domain + '";<\/script></html>');
u.close();
u.parentWindow[t.exports.WPrefix] = n[t.exports.WPrefix];
var p = u.createElement("div");
u.body.appendChild(p);
f = u.createElement("iframe");
p.appendChild(f);
f.src = e;
f.onerror = function() {
l("onerror");
};
o = setTimeout(function() {
l("timeout");
}, 15e3);
s = i.unloadAdd(d);
return {
post: function(e, t) {
try {
setTimeout(function() {
f && f.contentWindow && f.contentWindow.postMessage(e, t);
}, 0);
} catch (e) {}
},
cleanup: d,
loaded: h
};
}
};
t.exports.iframeEnabled = !1;
n.document && (t.exports.iframeEnabled = ("function" == typeof n.postMessage || "object" == typeof n.postMessage) && !s.isKonqueror());
}).call(this, {
env: {}
}, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"./browser": 44,
"./event": 46,
debug: 55,
json3: 58
} ],
48: [ function(e, t) {
(function(e) {
var r = {};
[ "log", "debug", "warn" ].forEach(function(t) {
var n;
try {
n = e.console && e.console[t] && e.console[t].apply;
} catch (e) {}
r[t] = n ? function() {
return e.console[t].apply(e.console, arguments);
} : "log" === t ? function() {} : r.log;
});
t.exports = r;
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
49: [ function(e, t) {
t.exports = {
isObject: function(e) {
var t = typeof e;
return "function" === t || "object" === t && !!e;
},
extend: function(e) {
if (!this.isObject(e)) return e;
for (var t, r, n = 1, i = arguments.length; n < i; n++) {
t = arguments[n];
for (r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
}
return e;
}
};
}, {} ],
50: [ function(e, t) {
var r = e("crypto");
t.exports = {
string: function(e) {
for (var t = "abcdefghijklmnopqrstuvwxyz012345".length, n = r.randomBytes(e), i = [], o = 0; o < e; o++) i.push("abcdefghijklmnopqrstuvwxyz012345".substr(n[o] % t, 1));
return i.join("");
},
number: function(e) {
return Math.floor(Math.random() * e);
},
numberString: function(e) {
var t = ("" + (e - 1)).length;
return (new Array(t + 1).join("0") + this.number(e)).slice(-t);
}
};
}, {
crypto: 43
} ],
51: [ function(e, t) {
(function(r) {
var n = function() {};
"production" !== r.env.NODE_ENV && (n = e("debug")("sockjs-client:utils:transport"));
t.exports = function(e) {
return {
filterToEnabled: function(t, r) {
var i = {
main: [],
facade: []
};
t ? "string" == typeof t && (t = [ t ]) : t = [];
e.forEach(function(e) {
if (e) if ("websocket" !== e.transportName || !1 !== r.websocket) if (t.length && -1 === t.indexOf(e.transportName)) n("not in whitelist", e.transportName); else if (e.enabled(r)) {
n("enabled", e.transportName);
i.main.push(e);
e.facadeTransport && i.facade.push(e.facadeTransport);
} else n("disabled", e.transportName); else n("disabled from server", "websocket");
});
return i;
}
};
};
}).call(this, {
env: {}
});
}, {
debug: 55
} ],
52: [ function(e, t) {
(function(r) {
var n = e("url-parse"), i = function() {};
"production" !== r.env.NODE_ENV && (i = e("debug")("sockjs-client:utils:url"));
t.exports = {
getOrigin: function(e) {
if (!e) return null;
var t = new n(e);
if ("file:" === t.protocol) return null;
var r = t.port;
r || (r = "https:" === t.protocol ? "443" : "80");
return t.protocol + "//" + t.hostname + ":" + r;
},
isOriginEqual: function(e, t) {
var r = this.getOrigin(e) === this.getOrigin(t);
i("same", e, t, r);
return r;
},
isSchemeEqual: function(e, t) {
return e.split(":")[0] === t.split(":")[0];
},
addPath: function(e, t) {
var r = e.split("?");
return r[0] + t + (r[1] ? "?" + r[1] : "");
},
addQuery: function(e, t) {
return e + (-1 === e.indexOf("?") ? "?" + t : "&" + t);
}
};
}).call(this, {
env: {}
});
}, {
debug: 55,
"url-parse": 61
} ],
53: [ function(e, t) {
t.exports = "1.1.4";
}, {} ],
54: [ function(e, t) {
var r = 1e3, n = 60 * r, i = 60 * n, o = 24 * i, s = 365.25 * o;
t.exports = function(e, t) {
t = t || {};
var s, u = typeof e;
if ("string" === u && e.length > 0) return a(e);
if ("number" === u && !1 === isNaN(e)) return t.long ? c(s = e, o, "day") || c(s, i, "hour") || c(s, n, "minute") || c(s, r, "second") || s + " ms" : f(e);
throw new Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(e));
};
function a(e) {
if (!((e = String(e)).length > 1e4)) {
var t = /^((?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|years?|yrs?|y)?$/i.exec(e);
if (t) {
var a = parseFloat(t[1]);
switch ((t[2] || "ms").toLowerCase()) {
case "years":
case "year":
case "yrs":
case "yr":
case "y":
return a * s;

case "days":
case "day":
case "d":
return a * o;

case "hours":
case "hour":
case "hrs":
case "hr":
case "h":
return a * i;

case "minutes":
case "minute":
case "mins":
case "min":
case "m":
return a * n;

case "seconds":
case "second":
case "secs":
case "sec":
case "s":
return a * r;

case "milliseconds":
case "millisecond":
case "msecs":
case "msec":
case "ms":
return a;

default:
return;
}
}
}
}
function f(e) {
return e >= o ? Math.round(e / o) + "d" : e >= i ? Math.round(e / i) + "h" : e >= n ? Math.round(e / n) + "m" : e >= r ? Math.round(e / r) + "s" : e + "ms";
}
function c(e, t, r) {
if (!(e < t)) return e < 1.5 * t ? Math.floor(e / t) + " " + r : Math.ceil(e / t) + " " + r + "s";
}
}, {} ],
55: [ function(e, t, r) {
(function(n) {
(r = t.exports = e("./debug")).log = function() {
return "object" == typeof console && console.log && Function.prototype.apply.call(console.log, console, arguments);
};
r.formatArgs = function(e) {
var t = this.useColors;
e[0] = (t ? "%c" : "") + this.namespace + (t ? " %c" : " ") + e[0] + (t ? "%c " : " ") + "+" + r.humanize(this.diff);
if (t) {
var n = "color: " + this.color;
e.splice(1, 0, n, "color: inherit");
var i = 0, o = 0;
e[0].replace(/%[a-zA-Z%]/g, function(e) {
if ("%%" !== e) {
i++;
"%c" === e && (o = i);
}
});
e.splice(o, 0, n);
}
};
r.save = function(e) {
try {
null == e ? r.storage.removeItem("debug") : r.storage.debug = e;
} catch (e) {}
};
r.load = i;
r.useColors = function() {
return !("undefined" == typeof window || !window.process || "renderer" !== window.process.type) || ("undefined" != typeof document && document && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || "undefined" != typeof window && window && window.console && (window.console.firebug || window.console.exception && window.console.table) || "undefined" != typeof navigator && navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) && parseInt(RegExp.$1, 10) >= 31 || "undefined" != typeof navigator && navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/));
};
r.storage = "undefined" != typeof chrome && "undefined" != typeof chrome.storage ? chrome.storage.local : function() {
try {
return window.localStorage;
} catch (e) {}
}();
r.colors = [ "lightseagreen", "forestgreen", "goldenrod", "dodgerblue", "darkorchid", "crimson" ];
r.formatters.j = function(e) {
try {
return JSON.stringify(e);
} catch (e) {
return "[UnexpectedJSONParseError]: " + e.message;
}
};
function i() {
var e;
try {
e = r.storage.debug;
} catch (e) {}
!e && "undefined" != typeof n && "env" in n && (e = n.env.DEBUG);
return e;
}
r.enable(i());
}).call(this, {
env: {}
});
}, {
"./debug": 56
} ],
56: [ function(e, t, r) {
(r = t.exports = o.debug = o.default = o).coerce = function(e) {
return e instanceof Error ? e.stack || e.message : e;
};
r.disable = function() {
r.enable("");
};
r.enable = function(e) {
r.save(e);
r.names = [];
r.skips = [];
for (var t = ("string" == typeof e ? e : "").split(/[\s,]+/), n = t.length, i = 0; i < n; i++) t[i] && ("-" === (e = t[i].replace(/\*/g, ".*?"))[0] ? r.skips.push(new RegExp("^" + e.substr(1) + "$")) : r.names.push(new RegExp("^" + e + "$")));
};
r.enabled = function(e) {
var t, n;
for (t = 0, n = r.skips.length; t < n; t++) if (r.skips[t].test(e)) return !1;
for (t = 0, n = r.names.length; t < n; t++) if (r.names[t].test(e)) return !0;
return !1;
};
r.humanize = e("ms");
r.names = [];
r.skips = [];
r.formatters = {};
var n;
function i(e) {
var t, n = 0;
for (t in e) {
n = (n << 5) - n + e.charCodeAt(t);
n |= 0;
}
return r.colors[Math.abs(n) % r.colors.length];
}
function o(e) {
function t() {
if (t.enabled) {
var e = t, i = +new Date(), o = i - (n || i);
e.diff = o;
e.prev = n;
e.curr = i;
n = i;
for (var s = new Array(arguments.length), a = 0; a < s.length; a++) s[a] = arguments[a];
s[0] = r.coerce(s[0]);
"string" != typeof s[0] && s.unshift("%O");
var f = 0;
s[0] = s[0].replace(/%([a-zA-Z%])/g, function(t, n) {
if ("%%" === t) return t;
f++;
var i = r.formatters[n];
if ("function" == typeof i) {
var o = s[f];
t = i.call(e, o);
s.splice(f, 1);
f--;
}
return t;
});
r.formatArgs.call(e, s);
(t.log || r.log || console.log.bind(console)).apply(e, s);
}
}
t.namespace = e;
t.enabled = r.enabled(e);
t.useColors = r.useColors();
t.color = i(e);
"function" == typeof r.init && r.init(t);
return t;
}
}, {
ms: 54
} ],
57: [ function(e, t) {
"function" == typeof Object.create ? t.exports = function(e, t) {
e.super_ = t;
e.prototype = Object.create(t.prototype, {
constructor: {
value: e,
enumerable: !1,
writable: !0,
configurable: !0
}
});
} : t.exports = function(e, t) {
e.super_ = t;
var r = function() {};
r.prototype = t.prototype;
e.prototype = new r();
e.prototype.constructor = e;
};
}, {} ],
58: [ function(e, t, r) {
(function(e) {
(function() {
var n = {
function: !0,
object: !0
}, i = n[typeof r] && r && !r.nodeType && r, o = n[typeof window] && window || this, s = i && n[typeof t] && t && !t.nodeType && "object" == typeof e && e;
!s || s.global !== s && s.window !== s && s.self !== s || (o = s);
function a(e, t) {
e || (e = o.Object());
t || (t = o.Object());
var r = e.Number || o.Number, i = e.String || o.String, s = e.Object || o.Object, f = e.Date || o.Date, c = e.SyntaxError || o.SyntaxError, u = e.TypeError || o.TypeError, h = e.Math || o.Math, d = e.JSON || o.JSON;
if ("object" == typeof d && d) {
t.stringify = d.stringify;
t.parse = d.parse;
}
var l, p, b, m = s.prototype, v = m.toString, y = new f(-0xc782b5b800cec);
try {
y = -109252 == y.getUTCFullYear() && 0 === y.getUTCMonth() && 1 === y.getUTCDate() && 10 == y.getUTCHours() && 37 == y.getUTCMinutes() && 6 == y.getUTCSeconds() && 708 == y.getUTCMilliseconds();
} catch (e) {}
function g(e) {
if (g[e] !== b) return g[e];
var n;
if ("bug-string-char-index" == e) n = "a" != "a"[0]; else if ("json" == e) n = g("json-stringify") && g("json-parse"); else {
var o, s = '{"a":[1,true,false,null,"\\u0000\\b\\n\\f\\r\\t"]}';
if ("json-stringify" == e) {
var a = t.stringify, c = "function" == typeof a && y;
if (c) {
(o = function() {
return 1;
}).toJSON = o;
try {
c = "0" === a(0) && "0" === a(new r()) && '""' == a(new i()) && a(v) === b && a(b) === b && a() === b && "1" === a(o) && "[1]" == a([ o ]) && "[null]" == a([ b ]) && "null" == a(null) && "[null,null,null]" == a([ b, v, null ]) && a({
a: [ o, !0, !1, null, "\0\b\n\f\r\t" ]
}) == s && "1" === a(null, o) && "[\n 1,\n 2\n]" == a([ 1, 2 ], null, 1) && '"-271821-04-20T00:00:00.000Z"' == a(new f(-864e13)) && '"+275760-09-13T00:00:00.000Z"' == a(new f(864e13)) && '"-000001-01-01T00:00:00.000Z"' == a(new f(-621987552e5)) && '"1969-12-31T23:59:59.999Z"' == a(new f(-1));
} catch (e) {
c = !1;
}
}
n = c;
}
if ("json-parse" == e) {
var u = t.parse;
if ("function" == typeof u) try {
if (0 === u("0") && !u(!1)) {
var h = 5 == (o = u(s)).a.length && 1 === o.a[0];
if (h) {
try {
h = !u('"\t"');
} catch (e) {}
if (h) try {
h = 1 !== u("01");
} catch (e) {}
if (h) try {
h = 1 !== u("1.");
} catch (e) {}
}
}
} catch (e) {
h = !1;
}
n = h;
}
}
return g[e] = !!n;
}
if (!g("json")) {
var _ = g("bug-string-char-index");
if (!y) var w = h.floor, E = [ 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 ], S = function(e, t) {
return E[t] + 365 * (e - 1970) + w((e - 1969 + (t = +(t > 1))) / 4) - w((e - 1901 + t) / 100) + w((e - 1601 + t) / 400);
};
(l = m.hasOwnProperty) || (l = function(e) {
var t, r = {};
if ((r.__proto__ = null, r.__proto__ = {
toString: 1
}, r).toString != v) l = function(e) {
var t = this.__proto__, r = e in (this.__proto__ = null, this);
this.__proto__ = t;
return r;
}; else {
t = r.constructor;
l = function(e) {
var r = (this.constructor || t).prototype;
return e in this && !(e in r && this[e] === r[e]);
};
}
r = null;
return l.call(this, e);
});
p = function(e, t) {
var r, i, o, s = 0;
(r = function() {
this.valueOf = 0;
}).prototype.valueOf = 0;
i = new r();
for (o in i) l.call(i, o) && s++;
r = i = null;
if (s) p = 2 == s ? function(e, t) {
var r, n = {}, i = "[object Function]" == v.call(e);
for (r in e) i && "prototype" == r || l.call(n, r) || !(n[r] = 1) || !l.call(e, r) || t(r);
} : function(e, t) {
var r, n, i = "[object Function]" == v.call(e);
for (r in e) i && "prototype" == r || !l.call(e, r) || (n = "constructor" === r) || t(r);
(n || l.call(e, r = "constructor")) && t(r);
}; else {
i = [ "valueOf", "toString", "toLocaleString", "propertyIsEnumerable", "isPrototypeOf", "hasOwnProperty", "constructor" ];
p = function(e, t) {
var r, o, s = "[object Function]" == v.call(e), a = !s && "function" != typeof e.constructor && n[typeof e.hasOwnProperty] && e.hasOwnProperty || l;
for (r in e) s && "prototype" == r || !a.call(e, r) || t(r);
for (o = i.length; r = i[--o]; a.call(e, r) && t(r)) ;
};
}
return p(e, t);
};
if (!g("json-stringify")) {
var M = {
92: "\\\\",
34: '\\"',
8: "\\b",
12: "\\f",
10: "\\n",
13: "\\r",
9: "\\t"
}, A = function(e, t) {
return ("000000" + (t || 0)).slice(-e);
}, x = function(e) {
for (var t = '"', r = 0, n = e.length, i = !_ || n > 10, o = i && (_ ? e.split("") : e); r < n; r++) {
var s = e.charCodeAt(r);
switch (s) {
case 8:
case 9:
case 10:
case 12:
case 13:
case 34:
case 92:
t += M[s];
break;

default:
if (s < 32) {
t += "\\u00" + A(2, s.toString(16));
break;
}
t += i ? o[r] : e.charAt(r);
}
}
return t + '"';
}, k = function e(t, r, n, i, o, s, a) {
var f, c, h, d, m, y, g, _, E, M, k, T, I, O, R, C;
try {
f = r[t];
} catch (e) {}
if ("object" == typeof f && f) if ("[object Date]" != (c = v.call(f)) || l.call(f, "toJSON")) "function" == typeof f.toJSON && ("[object Number]" != c && "[object String]" != c && "[object Array]" != c || l.call(f, "toJSON")) && (f = f.toJSON(t)); else if (f > -1 / 0 && f < 1 / 0) {
if (S) {
m = w(f / 864e5);
for (h = w(m / 365.2425) + 1970 - 1; S(h + 1, 0) <= m; h++) ;
for (d = w((m - S(h, 0)) / 30.42); S(h, d + 1) <= m; d++) ;
m = 1 + m - S(h, d);
g = w((y = (f % 864e5 + 864e5) % 864e5) / 36e5) % 24;
_ = w(y / 6e4) % 60;
E = w(y / 1e3) % 60;
M = y % 1e3;
} else {
h = f.getUTCFullYear();
d = f.getUTCMonth();
m = f.getUTCDate();
g = f.getUTCHours();
_ = f.getUTCMinutes();
E = f.getUTCSeconds();
M = f.getUTCMilliseconds();
}
f = (h <= 0 || h >= 1e4 ? (h < 0 ? "-" : "+") + A(6, h < 0 ? -h : h) : A(4, h)) + "-" + A(2, d + 1) + "-" + A(2, m) + "T" + A(2, g) + ":" + A(2, _) + ":" + A(2, E) + "." + A(3, M) + "Z";
} else f = null;
n && (f = n.call(r, t, f));
if (null === f) return "null";
if ("[object Boolean]" == (c = v.call(f))) return "" + f;
if ("[object Number]" == c) return f > -1 / 0 && f < 1 / 0 ? "" + f : "null";
if ("[object String]" == c) return x("" + f);
if ("object" == typeof f) {
for (O = a.length; O--; ) if (a[O] === f) throw u();
a.push(f);
k = [];
R = s;
s += o;
if ("[object Array]" == c) {
for (I = 0, O = f.length; I < O; I++) {
T = e(I, f, n, i, o, s, a);
k.push(T === b ? "null" : T);
}
C = k.length ? o ? "[\n" + s + k.join(",\n" + s) + "\n" + R + "]" : "[" + k.join(",") + "]" : "[]";
} else {
p(i || f, function(t) {
var r = e(t, f, n, i, o, s, a);
r !== b && k.push(x(t) + ":" + (o ? " " : "") + r);
});
C = k.length ? o ? "{\n" + s + k.join(",\n" + s) + "\n" + R + "}" : "{" + k.join(",") + "}" : "{}";
}
a.pop();
return C;
}
};
t.stringify = function(e, t, r) {
var i, o, s, a;
if (n[typeof t] && t) if ("[object Function]" == (a = v.call(t))) o = t; else if ("[object Array]" == a) {
s = {};
for (var f, c = 0, u = t.length; c < u; f = t[c++], ("[object String]" == (a = v.call(f)) || "[object Number]" == a) && (s[f] = 1)) ;
}
if (r) if ("[object Number]" == (a = v.call(r))) {
if ((r -= r % 1) > 0) for (i = "", r > 10 && (r = 10); i.length < r; i += " ") ;
} else "[object String]" == a && (i = r.length <= 10 ? r : r.slice(0, 10));
return k("", ((f = {})[""] = e, f), o, s, i, "", []);
};
}
if (!g("json-parse")) {
var T, I, O = i.fromCharCode, R = {
92: "\\",
34: '"',
47: "/",
98: "\b",
116: "\t",
110: "\n",
102: "\f",
114: "\r"
}, C = function() {
T = I = null;
throw c();
}, N = function() {
for (var e, t, r, n, i, o = I, s = o.length; T < s; ) switch (i = o.charCodeAt(T)) {
case 9:
case 10:
case 13:
case 32:
T++;
break;

case 123:
case 125:
case 91:
case 93:
case 58:
case 44:
e = _ ? o.charAt(T) : o[T];
T++;
return e;

case 34:
for (e = "@", T++; T < s; ) if ((i = o.charCodeAt(T)) < 32) C(); else if (92 == i) switch (i = o.charCodeAt(++T)) {
case 92:
case 34:
case 47:
case 98:
case 116:
case 110:
case 102:
case 114:
e += R[i];
T++;
break;

case 117:
t = ++T;
for (r = T + 4; T < r; T++) (i = o.charCodeAt(T)) >= 48 && i <= 57 || i >= 97 && i <= 102 || i >= 65 && i <= 70 || C();
e += O("0x" + o.slice(t, T));
break;

default:
C();
} else {
if (34 == i) break;
i = o.charCodeAt(T);
t = T;
for (;i >= 32 && 92 != i && 34 != i; ) i = o.charCodeAt(++T);
e += o.slice(t, T);
}
if (34 == o.charCodeAt(T)) {
T++;
return e;
}
C();

default:
t = T;
if (45 == i) {
n = !0;
i = o.charCodeAt(++T);
}
if (i >= 48 && i <= 57) {
48 == i && (i = o.charCodeAt(T + 1)) >= 48 && i <= 57 && C();
n = !1;
for (;T < s && (i = o.charCodeAt(T)) >= 48 && i <= 57; T++) ;
if (46 == o.charCodeAt(T)) {
r = ++T;
for (;r < s && (i = o.charCodeAt(r)) >= 48 && i <= 57; r++) ;
r == T && C();
T = r;
}
if (101 == (i = o.charCodeAt(T)) || 69 == i) {
43 != (i = o.charCodeAt(++T)) && 45 != i || T++;
for (r = T; r < s && (i = o.charCodeAt(r)) >= 48 && i <= 57; r++) ;
r == T && C();
T = r;
}
return +o.slice(t, T);
}
n && C();
if ("true" == o.slice(T, T + 4)) {
T += 4;
return !0;
}
if ("false" == o.slice(T, T + 5)) {
T += 5;
return !1;
}
if ("null" == o.slice(T, T + 4)) {
T += 4;
return null;
}
C();
}
return "$";
}, j = function e(t) {
var r, n;
"$" == t && C();
if ("string" == typeof t) {
if ("@" == (_ ? t.charAt(0) : t[0])) return t.slice(1);
if ("[" == t) {
r = [];
for (;"]" != (t = N()); n || (n = !0)) {
n && ("," == t ? "]" == (t = N()) && C() : C());
"," == t && C();
r.push(e(t));
}
return r;
}
if ("{" == t) {
r = {};
for (;"}" != (t = N()); n || (n = !0)) {
n && ("," == t ? "}" == (t = N()) && C() : C());
"," != t && "string" == typeof t && "@" == (_ ? t.charAt(0) : t[0]) && ":" == N() || C();
r[t.slice(1)] = e(N());
}
return r;
}
C();
}
return t;
}, P = function(e, t, r) {
var n = D(e, t, r);
n === b ? delete e[t] : e[t] = n;
}, D = function(e, t, r) {
var n, i = e[t];
if ("object" == typeof i && i) if ("[object Array]" == v.call(i)) for (n = i.length; n--; ) P(i, n, r); else p(i, function(e) {
P(i, e, r);
});
return r.call(e, t, i);
};
t.parse = function(e, t) {
var r, n;
T = 0;
I = "" + e;
r = j(N());
"$" != N() && C();
T = I = null;
return t && "[object Function]" == v.call(t) ? D(((n = {})[""] = r, n), "", t) : r;
};
}
}
t.runInContext = a;
return t;
}
if (i) a(o, i); else {
var f = o.JSON, c = o.JSON3, u = !1, h = a(o, o.JSON3 = {
noConflict: function() {
if (!u) {
u = !0;
o.JSON = f;
o.JSON3 = c;
f = c = null;
}
return h;
}
});
o.JSON = {
parse: h.parse,
stringify: h.stringify
};
}
}).call(this);
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
59: [ function(e, t, r) {
var n = Object.prototype.hasOwnProperty;
r.stringify = function(e, t) {
var r = [];
"string" != typeof (t = t || "") && (t = "?");
for (var i in e) n.call(e, i) && r.push(encodeURIComponent(i) + "=" + encodeURIComponent(e[i]));
return r.length ? t + r.join("&") : "";
};
r.parse = function(e) {
for (var t, r = /([^=?&]+)=?([^&]*)/g, n = {}; t = r.exec(e); n[decodeURIComponent(t[1])] = decodeURIComponent(t[2])) ;
return n;
};
}, {} ],
60: [ function(e, t) {
t.exports = function(e, t) {
t = t.split(":")[0];
if (!(e = +e)) return !1;
switch (t) {
case "http":
case "ws":
return 80 !== e;

case "https":
case "wss":
return 443 !== e;

case "ftp":
return 21 !== e;

case "gopher":
return 70 !== e;

case "file":
return !1;
}
return 0 !== e;
};
}, {} ],
61: [ function(e, t) {
var r = e("requires-port"), n = e("./lolcation"), i = e("querystringify"), o = /^([a-z][a-z0-9.+-]*:)?(\/\/)?([\S\s]*)/i, s = [ [ "#", "hash" ], [ "?", "query" ], [ "/", "pathname" ], [ "@", "auth", 1 ], [ NaN, "host", void 0, 1, 1 ], [ /:(\d+)$/, "port", void 0, 1 ], [ NaN, "hostname", void 0, 1, 1 ] ];
function a(e) {
var t = o.exec(e);
return {
protocol: t[1] ? t[1].toLowerCase() : "",
slashes: !!t[2],
rest: t[3]
};
}
function f(e, t) {
for (var r = (t || "/").split("/").slice(0, -1).concat(e.split("/")), n = r.length, i = r[n - 1], o = !1, s = 0; n--; ) if ("." === r[n]) r.splice(n, 1); else if (".." === r[n]) {
r.splice(n, 1);
s++;
} else if (s) {
0 === n && (o = !0);
r.splice(n, 1);
s--;
}
o && r.unshift("");
"." !== i && ".." !== i || r.push("");
return r.join("/");
}
function c(e, t, o) {
if (!(this instanceof c)) return new c(e, t, o);
var u, h, d, l, p, b, m = s.slice(), v = typeof t, y = this, g = 0;
if ("object" !== v && "string" !== v) {
o = t;
t = null;
}
o && "function" != typeof o && (o = i.parse);
t = n(t);
u = !(h = a(e || "")).protocol && !h.slashes;
y.slashes = h.slashes || u && t.slashes;
y.protocol = h.protocol || t.protocol || "";
e = h.rest;
h.slashes || (m[2] = [ /(.*)/, "pathname" ]);
for (;g < m.length; g++) {
d = (l = m[g])[0];
b = l[1];
if (d != d) y[b] = e; else if ("string" == typeof d) {
if (~(p = e.indexOf(d))) if ("number" == typeof l[2]) {
y[b] = e.slice(0, p);
e = e.slice(p + l[2]);
} else {
y[b] = e.slice(p);
e = e.slice(0, p);
}
} else if (p = d.exec(e)) {
y[b] = p[1];
e = e.slice(0, p.index);
}
y[b] = y[b] || u && l[3] && t[b] || "";
l[4] && (y[b] = y[b].toLowerCase());
}
o && (y.query = o(y.query));
u && t.slashes && "/" !== y.pathname.charAt(0) && ("" !== y.pathname || "" !== t.pathname) && (y.pathname = f(y.pathname, t.pathname));
if (!r(y.port, y.protocol)) {
y.host = y.hostname;
y.port = "";
}
y.username = y.password = "";
if (y.auth) {
l = y.auth.split(":");
y.username = l[0] || "";
y.password = l[1] || "";
}
y.origin = y.protocol && y.host && "file:" !== y.protocol ? y.protocol + "//" + y.host : "null";
y.href = y.toString();
}
c.prototype = {
set: function(e, t, n) {
var o = this;
switch (e) {
case "query":
"string" == typeof t && t.length && (t = (n || i.parse)(t));
o[e] = t;
break;

case "port":
o[e] = t;
if (r(t, o.protocol)) t && (o.host = o.hostname + ":" + t); else {
o.host = o.hostname;
o[e] = "";
}
break;

case "hostname":
o[e] = t;
o.port && (t += ":" + o.port);
o.host = t;
break;

case "host":
o[e] = t;
if (/:\d+$/.test(t)) {
t = t.split(":");
o.port = t.pop();
o.hostname = t.join(":");
} else {
o.hostname = t;
o.port = "";
}
break;

case "protocol":
o.protocol = t.toLowerCase();
o.slashes = !n;
break;

case "pathname":
o.pathname = t.length && "/" !== t.charAt(0) ? "/" + t : t;
break;

default:
o[e] = t;
}
for (var a = 0; a < s.length; a++) {
var f = s[a];
f[4] && (o[f[1]] = o[f[1]].toLowerCase());
}
o.origin = o.protocol && o.host && "file:" !== o.protocol ? o.protocol + "//" + o.host : "null";
o.href = o.toString();
return o;
},
toString: function(e) {
e && "function" == typeof e || (e = i.stringify);
var t, r = this, n = r.protocol;
n && ":" !== n.charAt(n.length - 1) && (n += ":");
var o = n + (r.slashes ? "//" : "");
if (r.username) {
o += r.username;
r.password && (o += ":" + r.password);
o += "@";
}
o += r.host + r.pathname;
(t = "object" == typeof r.query ? e(r.query) : r.query) && (o += "?" !== t.charAt(0) ? "?" + t : t);
r.hash && (o += r.hash);
return o;
}
};
c.extractProtocol = a;
c.location = n;
c.qs = i;
t.exports = c;
}, {
"./lolcation": 62,
querystringify: 59,
"requires-port": 60
} ],
62: [ function(e, t) {
(function(r) {
var n, i = /^[A-Za-z][A-Za-z0-9+-.]*:\/\//, o = {
hash: 1,
query: 1
};
t.exports = function(t) {
t = t || r.location || {};
n = n || e("./");
var s, a = {}, f = typeof t;
if ("blob:" === t.protocol) a = new n(unescape(t.pathname), {}); else if ("string" === f) {
a = new n(t, {});
for (s in o) delete a[s];
} else if ("object" === f) {
for (s in t) s in o || (a[s] = t[s]);
void 0 === a.slashes && (a.slashes = i.test(t.href));
}
return a;
};
}).call(this, "undefined" != typeof n ? n : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"./": 61
} ]
}, {}, [ 1 ])(1);
});
cc._RF.pop();
}).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {
"../../utils/browser": void 0,
"../../utils/event": void 0,
"../../utils/iframe": void 0,
"../../utils/object": void 0,
"../../utils/random": void 0,
"../../utils/url": void 0,
"../driver/xhr": void 0,
"../iframe": void 0,
"../utils/browser": void 0,
"../utils/event": void 0,
"../utils/iframe": void 0,
"../utils/random": void 0,
"../utils/url": void 0,
"../version": void 0,
"./": void 0,
"./browser": void 0,
"./buffered-sender": void 0,
"./debug": void 0,
"./driver/websocket": void 0,
"./event": void 0,
"./event/close": void 0,
"./event/event": void 0,
"./event/eventtarget": void 0,
"./event/trans-message": void 0,
"./eventtarget": void 0,
"./facade": void 0,
"./iframe-bootstrap": void 0,
"./info-ajax": void 0,
"./info-iframe": void 0,
"./info-iframe-receiver": void 0,
"./info-receiver": void 0,
"./lib/ajax-based": void 0,
"./lib/sender-receiver": void 0,
"./location": void 0,
"./lolcation": void 0,
"./main": void 0,
"./polling": void 0,
"./random": void 0,
"./receiver/eventsource": void 0,
"./receiver/htmlfile": void 0,
"./receiver/jsonp": void 0,
"./receiver/xhr": void 0,
"./sender-receiver": void 0,
"./sender/jsonp": void 0,
"./sender/xdr": void 0,
"./sender/xhr-cors": void 0,
"./sender/xhr-local": void 0,
"./shims": void 0,
"./transport-list": void 0,
"./transport/eventsource": void 0,
"./transport/htmlfile": void 0,
"./transport/iframe": void 0,
"./transport/jsonp-polling": void 0,
"./transport/lib/iframe-wrap": void 0,
"./transport/sender/xdr": void 0,
"./transport/sender/xhr-cors": void 0,
"./transport/sender/xhr-fake": void 0,
"./transport/sender/xhr-local": void 0,
"./transport/websocket": void 0,
"./transport/xdr-polling": void 0,
"./transport/xdr-streaming": void 0,
"./transport/xhr-polling": void 0,
"./transport/xhr-streaming": void 0,
"./utils/browser": void 0,
"./utils/escape": void 0,
"./utils/event": void 0,
"./utils/iframe": void 0,
"./utils/log": void 0,
"./utils/object": void 0,
"./utils/random": void 0,
"./utils/transport": void 0,
"./utils/url": void 0,
"./version": void 0,
"./xdr-streaming": void 0,
crypto: 75,
debug: void 0,
events: 104,
eventsource: void 0,
inherits: void 0,
json3: void 0,
ms: void 0,
querystringify: void 0,
"requires-port": void 0,
"url-parse": void 0
} ],
stomp233: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "67923/RWYlO6qZbp1qBD6s1", "stomp233");
(function() {
var e, t, n, i, o = {}.hasOwnProperty, s = [].slice;
e = {
LF: "\n",
NULL: "\0"
};
n = function() {
var t;
function r(e, t, r) {
this.command = e;
this.headers = null != t ? t : {};
this.body = null != r ? r : "";
}
r.prototype.toString = function() {
var t, n, i, s, a;
t = [ this.command ];
(i = !1 === this.headers["content-length"]) && delete this.headers["content-length"];
a = this.headers;
for (n in a) if (o.call(a, n)) {
s = a[n];
t.push(n + ":" + s);
}
this.body && !i && t.push("content-length:" + r.sizeOfUTF8(this.body));
t.push(e.LF + this.body);
return t.join(e.LF);
};
r.sizeOfUTF8 = function(e) {
return e ? encodeURI(e).match(/%..|./g).length : 0;
};
t = function(t) {
var n, i, o, s, a, f, c, u, h, d, l, p, b, m, v, y, g;
s = t.search(RegExp("" + e.LF + e.LF));
o = (a = t.substring(0, s).split(e.LF)).shift();
f = {};
p = function(e) {
return e.replace(/^\s+|\s+$/g, "");
};
for (b = 0, v = (y = a.reverse()).length; b < v; b++) {
u = (d = y[b]).indexOf(":");
f[p(d.substring(0, u))] = p(d.substring(u + 1));
}
n = "";
l = s + 2;
if (f["content-length"]) {
h = parseInt(f["content-length"]);
n = ("" + t).substring(l, l + h);
} else {
i = null;
for (c = m = l, g = t.length; (l <= g ? m < g : m > g) && (i = t.charAt(c)) !== e.NULL; c = l <= g ? ++m : --m) n += i;
}
return new r(o, f, n);
};
r.unmarshall = function(r) {
var n;
return function() {
var i, o, s, a;
a = [];
for (i = 0, o = (s = r.split(RegExp("" + e.NULL + e.LF + "*"))).length; i < o; i++) (null != (n = s[i]) ? n.length : void 0) > 0 && a.push(t(n));
return a;
}();
};
r.marshall = function(t, n, i) {
return new r(t, n, i).toString() + e.NULL;
};
return r;
}();
t = function() {
var t;
function r(e) {
this.ws = e;
this.ws.binaryType = "arraybuffer";
this.counter = 0;
this.connected = !1;
this.heartbeat = {
outgoing: 1e4,
incoming: 1e4
};
this.maxWebSocketFrameSize = 16384;
this.subscriptions = {};
}
r.prototype.debug = function(e) {
var t;
return "undefined" != typeof window && null !== window && null != (t = window.console) ? t.log(e) : void 0;
};
t = function() {
return Date.now ? Date.now() : new Date().valueOf;
};
r.prototype._transmit = function(e, t, r) {
var i;
i = n.marshall(e, t, r);
"function" == typeof this.debug && this.debug(">>> " + i);
for (;;) {
if (!(i.length > this.maxWebSocketFrameSize)) return this.ws.send(i);
this.ws.send(i.substring(0, this.maxWebSocketFrameSize));
i = i.substring(this.maxWebSocketFrameSize);
"function" == typeof this.debug && this.debug("remaining = " + i.length);
}
};
r.prototype._setupHeartbeat = function(r) {
var n, o, s, a, f, c;
if ((f = r.version) === i.VERSIONS.V1_1 || f === i.VERSIONS.V1_2) {
o = (c = function() {
var e, t, n, i;
i = [];
for (e = 0, t = (n = r["heart-beat"].split(",")).length; e < t; e++) {
a = n[e];
i.push(parseInt(a));
}
return i;
}())[0], n = c[1];
if (0 !== this.heartbeat.outgoing && 0 !== n) {
s = Math.max(this.heartbeat.outgoing, n);
"function" == typeof this.debug && this.debug("send PING every " + s + "ms");
this.pinger = i.setInterval(s, function(t) {
return function() {
t.ws.send(e.LF);
return "function" == typeof t.debug ? t.debug(">>> PING") : void 0;
};
}(this));
}
if (0 !== this.heartbeat.incoming && 0 !== o) {
s = Math.max(this.heartbeat.incoming, o);
"function" == typeof this.debug && this.debug("check PONG every " + s + "ms");
return this.ponger = i.setInterval(s, function(e) {
return function() {
var r;
if ((r = t() - e.serverActivity) > 2 * s) {
"function" == typeof e.debug && e.debug("did not receive server activity for the last " + r + "ms");
return e.ws.close();
}
};
}(this));
}
}
};
r.prototype._parseConnect = function() {
var e, t, r, n;
n = {};
switch ((e = 1 <= arguments.length ? s.call(arguments, 0) : []).length) {
case 2:
n = e[0], t = e[1];
break;

case 3:
e[1] instanceof Function ? (n = e[0], t = e[1], r = e[2]) : (n.login = e[0], n.passcode = e[1], 
t = e[2]);
break;

case 4:
n.login = e[0], n.passcode = e[1], t = e[2], r = e[3];
break;

default:
n.login = e[0], n.passcode = e[1], t = e[2], r = e[3], n.host = e[4];
}
return [ n, t, r ];
};
r.prototype.connect = function() {
var r, o, a, f;
r = 1 <= arguments.length ? s.call(arguments, 0) : [];
f = this._parseConnect.apply(this, r);
a = f[0], this.connectCallback = f[1], o = f[2];
"function" == typeof this.debug && this.debug("Opening Web Socket...");
this.ws.onmessage = function(r) {
return function(i) {
var s, a, f, c, u, h, d, l, p, b, m, v;
c = "undefined" != typeof ArrayBuffer && i.data instanceof ArrayBuffer ? (s = new Uint8Array(i.data), 
"function" == typeof r.debug && r.debug("--- got data length: " + s.length), function() {
var e, t, r;
r = [];
for (e = 0, t = s.length; e < t; e++) {
a = s[e];
r.push(String.fromCharCode(a));
}
return r;
}().join("")) : i.data;
r.serverActivity = t();
if (c !== e.LF) {
"function" == typeof r.debug && r.debug("<<< " + c);
v = [];
for (p = 0, b = (m = n.unmarshall(c)).length; p < b; p++) switch ((u = m[p]).command) {
case "CONNECTED":
"function" == typeof r.debug && r.debug("connected to server " + u.headers.server);
r.connected = !0;
r._setupHeartbeat(u.headers);
v.push("function" == typeof r.connectCallback ? r.connectCallback(u) : void 0);
break;

case "MESSAGE":
l = u.headers.subscription;
if (d = r.subscriptions[l] || r.onreceive) {
f = r;
h = u.headers["message-id"];
u.ack = function(e) {
null == e && (e = {});
return f.ack(h, l, e);
};
u.nack = function(e) {
null == e && (e = {});
return f.nack(h, l, e);
};
v.push(d(u));
} else v.push("function" == typeof r.debug ? r.debug("Unhandled received MESSAGE: " + u) : void 0);
break;

case "RECEIPT":
v.push("function" == typeof r.onreceipt ? r.onreceipt(u) : void 0);
break;

case "ERROR":
v.push("function" == typeof o ? o(u) : void 0);
break;

default:
v.push("function" == typeof r.debug ? r.debug("Unhandled frame: " + u) : void 0);
}
return v;
}
"function" == typeof r.debug && r.debug("<<< PONG");
};
}(this);
this.ws.onclose = function(e) {
return function() {
var t;
t = "Whoops! Lost connection to " + e.ws.url;
"function" == typeof e.debug && e.debug(t);
e._cleanUp();
return "function" == typeof o ? o(t) : void 0;
};
}(this);
return this.ws.onopen = function(e) {
return function() {
"function" == typeof e.debug && e.debug("Web Socket Opened...");
a["accept-version"] = i.VERSIONS.supportedVersions();
a["heart-beat"] = [ e.heartbeat.outgoing, e.heartbeat.incoming ].join(",");
return e._transmit("CONNECT", a);
};
}(this);
};
r.prototype.disconnect = function(e, t) {
null == t && (t = {});
this._transmit("DISCONNECT", t);
this.ws.onclose = null;
this.ws.close();
this._cleanUp();
return "function" == typeof e ? e() : void 0;
};
r.prototype._cleanUp = function() {
this.connected = !1;
this.pinger && i.clearInterval(this.pinger);
if (this.ponger) return i.clearInterval(this.ponger);
};
r.prototype.send = function(e, t, r) {
null == t && (t = {});
null == r && (r = "");
t.destination = e;
return this._transmit("SEND", t, r);
};
r.prototype.subscribe = function(e, t, r) {
var n;
null == r && (r = {});
r.id || (r.id = "sub-" + this.counter++);
r.destination = e;
this.subscriptions[r.id] = t;
this._transmit("SUBSCRIBE", r);
n = this;
return {
id: r.id,
unsubscribe: function() {
return n.unsubscribe(r.id);
}
};
};
r.prototype.unsubscribe = function(e) {
delete this.subscriptions[e];
return this._transmit("UNSUBSCRIBE", {
id: e
});
};
r.prototype.begin = function(e) {
var t, r;
r = e || "tx-" + this.counter++;
this._transmit("BEGIN", {
transaction: r
});
t = this;
return {
id: r,
commit: function() {
return t.commit(r);
},
abort: function() {
return t.abort(r);
}
};
};
r.prototype.commit = function(e) {
return this._transmit("COMMIT", {
transaction: e
});
};
r.prototype.abort = function(e) {
return this._transmit("ABORT", {
transaction: e
});
};
r.prototype.ack = function(e, t, r) {
null == r && (r = {});
r["message-id"] = e;
r.subscription = t;
return this._transmit("ACK", r);
};
r.prototype.nack = function(e, t, r) {
null == r && (r = {});
r["message-id"] = e;
r.subscription = t;
return this._transmit("NACK", r);
};
return r;
}();
i = {
VERSIONS: {
V1_0: "1.0",
V1_1: "1.1",
V1_2: "1.2",
supportedVersions: function() {
return "1.1,1.0";
}
},
client: function(e, r) {
var n;
null == r && (r = [ "v10.stomp", "v11.stomp" ]);
n = new (i.WebSocketClass || WebSocket)(e, r);
return new t(n);
},
over: function(e) {
return new t(e);
},
Frame: n
};
"undefined" != typeof r && null !== r && (r.Stomp = i);
if ("undefined" != typeof window && null !== window) {
i.setInterval = function(e, t) {
return window.setInterval(t, e);
};
i.clearInterval = function(e) {
return window.clearInterval(e);
};
window.Stomp = i;
} else r || (self.Stomp = i);
}).call(void 0);
cc._RF.pop();
}, {} ],
stomp2: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "dc284LmQ99EBYMZCJ8cEd0t", "stomp2");
(function() {
var e, t, n, i, o = {}.hasOwnProperty, s = [].slice;
e = {
LF: "\n",
NULL: "\0"
};
n = function() {
var t;
function r(e, t, r) {
this.command = e;
this.headers = null != t ? t : {};
this.body = null != r ? r : "";
}
r.prototype.toString = function() {
var t, n, i, s, a;
t = [ this.command ];
(i = !1 === this.headers["content-length"]) && delete this.headers["content-length"];
a = this.headers;
for (n in a) if (o.call(a, n)) {
s = a[n];
t.push(n + ":" + s);
}
this.body && !i && t.push("content-length:" + r.sizeOfUTF8(this.body));
t.push(e.LF + this.body);
return t.join(e.LF);
};
r.sizeOfUTF8 = function(e) {
return e ? encodeURI(e).match(/%..|./g).length : 0;
};
t = function(t) {
var n, i, o, s, a, f, c, u, h, d, l, p, b, m, v, y, g;
s = t.search(RegExp("" + e.LF + e.LF));
o = (a = t.substring(0, s).split(e.LF)).shift();
f = {};
p = function(e) {
return e.replace(/^\s+|\s+$/g, "");
};
for (b = 0, v = (y = a.reverse()).length; b < v; b++) {
u = (d = y[b]).indexOf(":");
f[p(d.substring(0, u))] = p(d.substring(u + 1));
}
n = "";
l = s + 2;
if (f["content-length"]) {
h = parseInt(f["content-length"]);
n = ("" + t).substring(l, l + h);
} else {
i = null;
for (c = m = l, g = t.length; (l <= g ? m < g : m > g) && (i = t.charAt(c)) !== e.NULL; c = l <= g ? ++m : --m) n += i;
}
return new r(o, f, n);
};
r.unmarshall = function(r) {
var n, i, o, s;
i = r.split(RegExp("" + e.NULL + e.LF + "*"));
(s = {
frames: [],
partial: ""
}).frames = function() {
var e, r, o, s;
s = [];
for (e = 0, r = (o = i.slice(0, -1)).length; e < r; e++) {
n = o[e];
s.push(t(n));
}
return s;
}();
(o = i.slice(-1)[0]) === e.LF || -1 !== o.search(RegExp("" + e.NULL + e.LF + "*$")) ? s.frames.push(t(o)) : s.partial = o;
return s;
};
r.marshall = function(t, n, i) {
return new r(t, n, i).toString() + e.NULL;
};
return r;
}();
t = function() {
var t;
function r(e) {
this.ws = e;
this.ws.binaryType = "arraybuffer";
this.counter = 0;
this.connected = !1;
this.heartbeat = {
outgoing: 1e4,
incoming: 1e4
};
this.maxWebSocketFrameSize = 16384;
this.subscriptions = {};
this.partialData = "";
}
r.prototype.debug = function() {};
t = function() {
return Date.now ? Date.now() : new Date().valueOf;
};
r.prototype._transmit = function(e, t, r) {
var i;
i = n.marshall(e, t, r);
"function" == typeof this.debug && this.debug(">>> " + i);
for (;;) {
if (!(i.length > this.maxWebSocketFrameSize)) return this.ws.send(i);
this.ws.send(i.substring(0, this.maxWebSocketFrameSize));
i = i.substring(this.maxWebSocketFrameSize);
"function" == typeof this.debug && this.debug("remaining = " + i.length);
}
};
r.prototype._setupHeartbeat = function(r) {
var n, o, s, a, f, c;
if ((f = r.version) === i.VERSIONS.V1_1 || f === i.VERSIONS.V1_2) {
o = (c = function() {
var e, t, n, i;
i = [];
for (e = 0, t = (n = r["heart-beat"].split(",")).length; e < t; e++) {
a = n[e];
i.push(parseInt(a));
}
return i;
}())[0], n = c[1];
if (0 !== this.heartbeat.outgoing && 0 !== n) {
s = Math.max(this.heartbeat.outgoing, n);
"function" == typeof this.debug && this.debug("send PING every " + s + "ms");
this.pinger = i.setInterval(s, function(t) {
return function() {
t.ws.send(e.LF);
return "function" == typeof t.debug ? t.debug(">>> PING") : void 0;
};
}(this));
}
if (0 !== this.heartbeat.incoming && 0 !== o) {
s = Math.max(this.heartbeat.incoming, o);
"function" == typeof this.debug && this.debug("check PONG every " + s + "ms");
return this.ponger = i.setInterval(s, function(e) {
return function() {
var r;
if ((r = t() - e.serverActivity) > 2 * s) {
"function" == typeof e.debug && e.debug("did not receive server activity for the last " + r + "ms");
return e.ws.close();
}
};
}(this));
}
}
};
r.prototype._parseConnect = function() {
var e, t, r, n;
n = {};
switch ((e = 1 <= arguments.length ? s.call(arguments, 0) : []).length) {
case 2:
n = e[0], t = e[1];
break;

case 3:
e[1] instanceof Function ? (n = e[0], t = e[1], r = e[2]) : (n.login = e[0], n.passcode = e[1], 
t = e[2]);
break;

case 4:
n.login = e[0], n.passcode = e[1], t = e[2], r = e[3];
break;

default:
n.login = e[0], n.passcode = e[1], t = e[2], r = e[3], n.host = e[4];
}
return [ n, t, r ];
};
r.prototype.connect = function() {
var r, o, a, f;
r = 1 <= arguments.length ? s.call(arguments, 0) : [];
f = this._parseConnect.apply(this, r);
a = f[0], this.connectCallback = f[1], o = f[2];
"function" == typeof this.debug && this.debug("Opening Web Socket...");
this.ws.onmessage = function(r) {
return function(i) {
var s, a, f, c, u, h, d, l, p, b, m, v, y;
c = "undefined" != typeof ArrayBuffer && i.data instanceof ArrayBuffer ? (s = new Uint8Array(i.data), 
"function" == typeof r.debug && r.debug("--- got data length: " + s.length), function() {
var e, t, r;
r = [];
for (e = 0, t = s.length; e < t; e++) {
a = s[e];
r.push(String.fromCharCode(a));
}
return r;
}().join("")) : i.data;
r.serverActivity = t();
if (c !== e.LF) {
r.debug;
p = n.unmarshall(r.partialData + c);
r.partialData = p.partial;
y = [];
for (b = 0, m = (v = p.frames).length; b < m; b++) switch ((u = v[b]).command) {
case "CONNECTED":
"function" == typeof r.debug && r.debug("connected to server " + u.headers.server);
r.connected = !0;
r._setupHeartbeat(u.headers);
y.push("function" == typeof r.connectCallback ? r.connectCallback(u) : void 0);
break;

case "MESSAGE":
l = u.headers.subscription;
if (d = r.subscriptions[l] || r.onreceive) {
f = r;
h = u.headers["message-id"];
u.ack = function(e) {
null == e && (e = {});
return f.ack(h, l, e);
};
u.nack = function(e) {
null == e && (e = {});
return f.nack(h, l, e);
};
y.push(d(u));
} else y.push("function" == typeof r.debug ? r.debug("Unhandled received MESSAGE: " + u) : void 0);
break;

case "RECEIPT":
y.push("function" == typeof r.onreceipt ? r.onreceipt(u) : void 0);
break;

case "ERROR":
y.push("function" == typeof o ? o(u) : void 0);
break;

default:
y.push("function" == typeof r.debug ? r.debug("Unhandled frame: " + u) : void 0);
}
return y;
}
"function" == typeof r.debug && r.debug("<<< PONG");
};
}(this);
this.ws.onclose = function(e) {
return function() {
var t;
t = "Whoops! Lost connection to " + e.ws.url;
"function" == typeof e.debug && e.debug(t);
e._cleanUp();
e.ws.onCustomMessage("ONCLOSE");
return "function" == typeof o ? o(t) : void 0;
};
}(this);
return this.ws.onopen = function(e) {
return function() {
"function" == typeof e.debug && e.debug("Web Socket Opened...");
a["accept-version"] = i.VERSIONS.supportedVersions();
a["heart-beat"] = [ e.heartbeat.outgoing, e.heartbeat.incoming ].join(",");
return e._transmit("CONNECT", a);
};
}(this);
};
r.prototype.disconnect = function(e, t) {
_this.debug("ws.disconnect!!");
null == t && (t = {});
this._transmit("DISCONNECT", t);
this.ws.onclose = null;
this.ws.close();
this._cleanUp();
return "function" == typeof e ? e() : void 0;
};
r.prototype._cleanUp = function() {
this.connected = !1;
this.pinger && i.clearInterval(this.pinger);
if (this.ponger) return i.clearInterval(this.ponger);
};
r.prototype.send = function(e, t, r) {
null == t && (t = {});
null == r && (r = "");
t.destination = e;
return this._transmit("SEND", t, r);
};
r.prototype.subscribe = function(e, t, r) {
var n;
null == r && (r = {});
r.id || (r.id = "sub-" + this.counter++);
r.destination = e;
this.subscriptions[r.id] = t;
this._transmit("SUBSCRIBE", r);
this.ws.onCustomMessage("SUBSCRIBE", r);
n = this;
return {
id: r.id,
unsubscribe: function() {
return n.unsubscribe(r.id);
}
};
};
r.prototype.unsubscribe = function(e) {
delete this.subscriptions[e];
this.ws.onCustomMessage("UNSUBSCRIBE", {
id: e
});
return this._transmit("UNSUBSCRIBE", {
id: e
});
};
r.prototype.begin = function(e) {
var t, r;
r = e || "tx-" + this.counter++;
this._transmit("BEGIN", {
transaction: r
});
t = this;
return {
id: r,
commit: function() {
return t.commit(r);
},
abort: function() {
return t.abort(r);
}
};
};
r.prototype.commit = function(e) {
return this._transmit("COMMIT", {
transaction: e
});
};
r.prototype.abort = function(e) {
return this._transmit("ABORT", {
transaction: e
});
};
r.prototype.ack = function(e, t, r) {
null == r && (r = {});
r["message-id"] = e;
r.subscription = t;
return this._transmit("ACK", r);
};
r.prototype.nack = function(e, t, r) {
null == r && (r = {});
r["message-id"] = e;
r.subscription = t;
return this._transmit("NACK", r);
};
return r;
}();
i = {
VERSIONS: {
V1_0: "1.0",
V1_1: "1.1",
V1_2: "1.2",
supportedVersions: function() {
return "1.1,1.0";
}
},
client: function(e, r) {
var n;
null == r && (r = [ "v10.stomp", "v11.stomp" ]);
n = new (i.WebSocketClass || WebSocket)(e, r);
return new t(n);
},
over: function(e) {
return new t(e);
},
Frame: n
};
"undefined" != typeof r && null !== r && (r.Stomp = i);
if ("undefined" != typeof window && null !== window) {
i.setInterval = function(e, t) {
return window.setInterval(t, e);
};
i.clearInterval = function(e) {
return window.clearInterval(e);
};
window.Stomp = i;
} else r || (self.Stomp = i);
}).call(void 0);
cc._RF.pop();
}, {} ],
use_reversed_rotateTo: [ function(e, t) {
"use strict";
cc._RF.push(t, "67d41bgAOxOL62XdeRW/3BV", "use_reversed_rotateTo");
cc.RotateTo._reverse = !0;
cc._RF.pop();
}, {} ]
}, {}, [ "HelloWorld", "UIDatePicker", "UIItemDay", "DropDown", "DropDownItem", "DropDownOptionData", "Helloworld", "use_reversed_rotateTo", "BundleControl", "Configs", "Global", "HotUpdate", "Http", "Loading", "LogEvent.Facebook", "LogEvent.FireBase", "LogEvent", "Sockjs.min", "UtilsNative", "VersionConfig", "sockjs114", "stomp2", "stomp233" ]);